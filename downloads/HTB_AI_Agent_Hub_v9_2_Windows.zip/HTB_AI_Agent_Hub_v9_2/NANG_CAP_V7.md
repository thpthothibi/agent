# HTB Agent Hub v7 — Vận hành & Hồ sơ

## Phần xử lý thật trên Site
- Mục Vận hành & Hồ sơ mở mặc định. Hai nghiệp vụ: cộng hai nguồn TL + TN trên thang 10; đối chiếu nguồn điểm tổng với điểm cũ.
- Nhận nhiều Excel, đọc từng sheet và chọn cột riêng cho từng nguồn. Kiểm tra tiêu đề trùng, chọn trùng cột và vai trò nguồn.
- Ghép Họ tên + Lớp hoặc Mã học sinh + Lớp; không tự ghép gần đúng. Chuẩn hóa 11A1 / 11A01; kiểm tra sai khối; không tự đổi thang điểm, không tự làm tròn. Hỗ trợ tối đa 2 chữ số thập phân.
- Bốn bước thật: chuẩn hóa → ghép học sinh → tính điểm → đối chiếu. Lưu sau từng bước; chạy một bước, liên tục, tạm dừng ở ranh giới bước, hủy giữ hồ sơ và chạy lại bước lỗi.
- Lưu file đầu vào, cấu hình và kết quả vào IndexedDB trên trình duyệt. Khóa ghi một tab; tải lại sẽ đưa tác vụ đang chạy về tạm dừng.
- Khi duyệt, lưu SHA-256 nguồn + cấu hình + kết quả. Xuất kiểm tra lại dấu vân tay; mỗi hồ sơ bất biến. Thay nguồn/cấu hình phải tạo hồ sơ mới và duyệt lại.
- Excel xuất gồm kết quả đã duyệt, ngoại lệ, nhật ký và hồ sơ. Dòng nguồn gồm tên file, sheet và số dòng; không coi điểm thiếu là 0.
- Sao lưu/khôi phục JSON. Khôi phục tạo mã mới, tính lại từ đầu và bỏ duyệt cũ. Giới hạn 100 hồ sơ, 50.000 dòng nguồn/tác vụ, 15 MB/file, 60 MB/bản sao lưu.

## Hub Windows
- Lưu từng lần mở tool vào SQLite tại workspace/hub-runs.sqlite3; trạng thái, thao tác gần nhất và lịch sử được giữ qua lần khởi động.
- Sau khi Hub khởi động lại, tiến trình còn ghi đang mở được đánh dấu gián đoạn. Không bám vào PID cũ, không tự chạy lại, không tự ghi hệ thống ngoài.
- Bổ sung phiên bản Hub, thời điểm phản hồi và cảnh báo mất kết nối. Vẫn chỉ theo dõi tiến trình và một số mốc thao tác của tool desktop, chưa có số học sinh đã xử lý.

## Cách dùng
1. Mở Site → Vận hành & Hồ sơ → Thêm nhiều Excel. Có nút tải mẫu 3 sheet để thử.
2. Chọn nghiệp vụ trước khi thêm file. Chọn đúng môn/khối/năm/đợt; xác nhận vai trò và cột từng sheet. Muốn tự ghép hai học sinh trùng tên phải có mã học sinh phân biệt ở tất cả nguồn.
3. Lưu tác vụ mới → Xử lý / Tiếp tục, hoặc Chạy một bước.
4. Đọc bảng trước–sau và ngoại lệ. Tích duyệt đúng bản → Xuất Excel đã duyệt.
5. Sao lưu hồ sơ JSON định kỳ. Bản sao lưu chứa dữ liệu học sinh; bảo quản theo quyền truy cập của trường.
6. Tool Windows: giải nén bộ v7 ở thư mục mới, cài theo hướng dẫn rồi chạy Hub. Không chép đè khi tool đang chạy. Thư mục workspace của bản trước cần giữ riêng để đối chiếu nhật ký.

## Giới hạn đã công bố
- Chưa đồng bộ hồ sơ qua đám mây hoặc giữa các máy, chưa có phân quyền tổ bộ môn dùng chung. IndexedDB có thể bị xóa khi người dùng xóa dữ liệu trình duyệt; cần sao lưu.
- Chưa tự chuyển file giữa các tool desktop, chưa có toàn bộ tiến độ nghiệp vụ, chưa kiểm thử nhập/lưu/ ký trên tài khoản trường.
- Không tích hợp tự ghi Vietschool. Phê duyệt ở màn hình v7 chỉ cho xuất Excel.
- Cá chép, robot và phòng mô phỏng v6 giữ nguyên; mô phỏng tách khỏi xử lý thật.
