# HTB Agent Hub v8 — Rà soát ngoại lệ và bản sửa có truy vết

## Dùng trên Site
- Mục Vận hành & Hồ sơ giữ dữ liệu IndexedDB v7 và schema sao lưu v7 để tương thích.
- Hồ sơ chưa kết thúc từ bộ kiểm tra cũ được đưa về chờ chạy lại từ đầu; bỏ duyệt cũ. Hồ sơ đã xuất giữ lịch sử, muốn xuất lại phải tạo bản sửa và kiểm tra v8.
- Chọn Sửa từ bản sao để mở đầu vào và cấu hình thành bản nháp. Ghi lý do sửa; mở Xem / sửa dữ liệu bản nháp ở từng sheet để đổi tên, lớp, mã HS, điểm hoặc trạng thái.
- Có tìm dòng và phân trang 25 dòng/nguồn. Chọn Loại khỏi bản nháp cần nhập lý do; giữ vị trí dòng gốc và dữ liệu gốc trong hồ sơ.
- Lưu bản nháp trước khi tải lại hoặc đóng trang. Không tự động lưu mỗi lần gõ. Sao lưu hồ sơ JSON chỉ chứa tác vụ đã lưu, không chứa bản nháp.
- Lưu tác vụ mới tạo hồ sơ có mã mới và liên kết hồ sơ gốc; không sửa dữ liệu gốc. Bản trước bị đánh dấu đã có bản sửa và chặn xuất lại, kể cả đã được duyệt.
- Màn hình duyệt hiển thị riêng số dòng nguồn đã loại; lý do nằm trong Đầu vào & Cấu hình và file xuất.
- Đọc giá trị hiển thị Excel để giữ số 0 đầu của mã học sinh được định dạng bằng số.
- Kết quả có tìm kiếm theo tên/lớp/mã/lỗi, lọc ngoại lệ/chênh lệch/hợp lệ và phân trang 100 dòng; không giới hạn ở 300 dòng đầu.
- Xuất riêng danh sách ngoại lệ để phân công xử lý; chưa phải file điểm được duyệt.
- File kết quả đã duyệt bổ sung sheet Dòng nguồn đã loại và Lịch sử sửa.
- Đưa tác vụ vào hàng đợi → Chạy hàng đợi. Xử lý tuần tự từ hồ sơ cũ đến mới. Dừng khi có hồ sơ chờ rà soát/lỗi; sau khi xử lý cần bấm Chạy hàng đợi để tiếp tục. Tải lại không tự bật điều phối.
- Dừng điều phối không đóng tác vụ đang chạy. Tạm dừng an toàn dừng tác vụ ở ranh giới bước và tắt tự chuyển tác vụ.
- Lưu trữ/bỏ lưu trữ hồ sơ đã xuất hoặc hủy, không xóa dữ liệu. Sao lưu vẫn chứa hồ sơ lưu trữ.
- Báo cáo vận hành Excel tổng hợp phạm vi, trạng thái, số học sinh, ngoại lệ và các phiên bản hồ sơ.

## Giới hạn
Không tự ghi Vietschool/hệ thống bên ngoài; chưa đồng bộ giữa máy; chưa có phân quyền nhiều giáo viên. Hàng đợi mới chỉ chạy xử lý Excel trong Site, không chạy liên hoàn các tool desktop. Cá chép và robot không thay đổi trong v8. Không dùng Runway.
