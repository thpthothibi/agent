@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (set "HTB_PY=python") else (set "HTB_PY=py -3")
%HTB_PY% -c "import sys,tkinter; assert sys.version_info >= (3,10)" >nul 2>&1
if errorlevel 1 goto missing
if not exist .venv\Scripts\python.exe %HTB_PY% -m venv .venv
if errorlevel 1 goto error
.venv\Scripts\python.exe -m pip install --timeout 60 --retries 2 -r requirements.txt
if errorlevel 1 goto error
.venv\Scripts\python.exe -m playwright install chromium
if errorlevel 1 goto error
echo Cai dat hoan tat. Tool nhap diem can Google Chrome da cai tren Windows.
echo Neu khong mo duoc Chrome, chay 3_KIEM_TRA_KHOI_DONG.bat.
echo Mo 2_MO_HE_THONG.bat de su dung.
pause
exit /b 0
:missing
echo Can Python 3.10+ 64-bit voi Tcl/Tk. Khuyen dung Python 3.11 hoac 3.12.
pause
exit /b 1
:error
echo Cai dat chua thanh cong. Doc loi phia tren, kiem tra Internet va chay lai.
pause
exit /b 1
