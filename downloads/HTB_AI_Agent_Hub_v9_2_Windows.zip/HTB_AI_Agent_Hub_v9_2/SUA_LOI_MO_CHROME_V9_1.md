# Bản vá v9.1 — Bấm Bắt đầu nhập điểm nhưng không mở Chrome

## Nguyên nhân tìm thấy trong v9
Nút Bắt đầu nhập điểm gọi AutoApp.choose() trong tools/grades/vietschool_agent_v2.py. Hàm này gọi messagebox.askyesno để xin xác nhận, nhưng tệp chỉ import ttk và filedialog, không import messagebox. Tkinter ném NameError trước khi chọn file hoặc tạo worker, do đó chưa đến bước gọi Chrome. Lỗi callback thường chỉ hiện trong cửa sổ console hoặc workspace/grades-process.log.

## Đã sửa
- Import đúng messagebox. Giữ nguyên yêu cầu xác nhận trước khi chạy nhập điểm.
- Khi tác vụ đang chạy, bấm lại không mở thêm hộp thoại hoặc worker.
- Lỗi callback được thông báo bằng hộp thoại và ghi vào tools/grades/loi_giao_dien.txt; nếu worker chưa chạy thì giao diện nhận sự kiện lỗi để mở lại các nút. Không tự chạy lại hoặc tự ghi dữ liệu.
- Bổ sung hướng dẫn khi Playwright báo thiếu Chrome, thiếu thư viện hoặc profile Chrome Agent đang được sử dụng.
- Thêm 3_KIEM_TRA_KHOI_DONG.bat và diagnose_startup.py: kiểm tra Python, thư viện và đường dẫn Google Chrome; không mở trình duyệt, không đăng nhập và không nhập điểm. Báo cáo ở workspace/startup-check.txt.

## Cài bản sửa
1. Đóng cửa sổ tool và Hub đang chạy. Giữ lại thư mục cũ để đối chiếu dữ liệu/báo cáo; không cần xóa profile Chrome Agent.
2. Giải nén bộ v9.1 vào thư mục mới, không chạy trực tiếp bên trong ZIP.
3. Chạy 1_CAI_DAT_WINDOWS.bat lần đầu trong thư mục mới, rồi 2_MO_HE_THONG.bat.
4. Mở Nhập điểm, bấm Bắt đầu nhập điểm, đọc và xác nhận hộp thoại, chọn Excel hợp lệ.
5. Tool kiểm tra Excel trước khi mở Chrome. Excel lỗi hoặc không có nhóm điểm hợp lệ có thể làm dừng trước bước mở trình duyệt; đọc thông báo để sửa file.
6. Nếu vẫn không mở, chạy 3_KIEM_TRA_KHOI_DONG.bat. Tool cấu hình channel='chrome', nên cần Google Chrome. Chromium mà bộ cài Playwright tải về không thay thế Google Chrome trong cấu hình này.
7. Nếu báo profile đang được sử dụng, chỉ đóng cửa sổ Chrome Agent cũ rồi thử lại. Không xóa profile hoặc tắt toàn bộ Chrome cá nhân.

## Xác minh
- 8 kiểm tra riêng cho nút bắt đầu, xác nhận/hủy, chọn file/hủy file, worker được gọi qua mock, báo lỗi callback và hướng dẫn lỗi Chrome; không mở Chrome hoặc ghi điểm thật.
- 14 kiểm tra Hub sẵn có được giữ.
- Biên dịch cú pháp các tệp Python đã sửa.
- Chưa kiểm thử Google Chrome trên máy Windows của người dùng; không khẳng định mọi nguyên nhân không mở Chrome đã được loại bỏ. Nếu còn lỗi, cần đọc workspace/startup-check.txt và nhật ký khởi động tương ứng.
