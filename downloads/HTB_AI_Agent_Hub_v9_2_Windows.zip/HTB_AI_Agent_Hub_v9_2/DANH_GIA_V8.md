# Đánh giá sau v7 — 10/11/2026

Đã đọc mã nguồn Site và Hub. Đây là đánh giá kiến trúc và kiểm thử cục bộ; chưa kiểm thử Windows hay tài khoản thật của trường.

## Các điểm đã xử lý trong v8
1. Ghép Họ tên + Lớp từng có thể ghép nguồn TL/TN ghi mã học sinh khác nhau nếu mỗi vai trò chỉ có một dòng. V8 chặn khi các mã khác nhau.
2. V7 chỉ hiển thị 300 kết quả đầu, khiến người dùng khó rà soát đầy đủ danh sách lớn. V8 tìm/lọc toàn bộ kết quả và phân trang 100 dòng.
3. V7 chưa có luồng sửa ngoại lệ tại chỗ. V8 tạo bản nháp từ hồ sơ gốc, sửa dữ liệu từng nguồn và lưu thành hồ sơ mới; ghi lý do và danh sách giá trị trước–sau. Bản cũ giữ nguyên dữ liệu, bị chặn xuất lại khi có bản sửa.
4. V7 chưa có hàng đợi nghiệp vụ thật. V8 cho đưa tác vụ Excel vào hàng đợi, chạy tuần tự và dừng khi có kết quả cần rà soát/lỗi. Không điều khiển nghiệp vụ desktop.
5. V7 chưa có tổ chức hồ sơ kết thúc. V8 thêm lưu trữ/bỏ lưu trữ có nhật ký, tìm hồ sơ và báo cáo vận hành Excel.
6. V7 kiểm tra JSON có thể ném lỗi với bản ghi null. V8 trả lỗi định dạng an toàn và kiểm tra chỉ số/lý do dòng loại.

## Chưa coi là hoàn chỉnh
- Hồ sơ vẫn chỉ trên trình duyệt hiện tại; chưa có đồng bộ đám mây hay phân quyền theo môn/khối cho nhiều giáo viên.
- Tool Windows giữ nguyên nghiệp vụ, Hub chỉ theo dõi tiến trình và một số thao tác; chưa biết số học sinh đã xử lý và chưa chuyển file tự động giữa tool.
- Chưa có kiểm thử nhập điểm/phiếu lỗi/ký sổ trên tài khoản thật.
- Chưa kiểm thử tải 50.000 dòng, nhiều người dùng đồng thời hoặc các cấu trúc Excel thực tế của mọi môn.
- Cộng điểm hiện dùng TL + TN cùng thang điểm 10, tối đa hai chữ số thập phân; chưa có hệ số hoặc chuyển đổi thang.
- Giới hạn vẫn 100 hồ sơ. Lưu trữ không giải phóng dung lượng và không thay thế sao lưu.

Định hướng tiếp theo sau khi có dữ liệu thử của trường: kiểm chứng mẫu Excel theo môn, sau đó mới thêm đồng bộ và giao thức tiến độ nghiệp vụ cho từng tool. Không dùng hoạt cảnh robot để chứng minh một nghiệp vụ thật đã hoàn tất.
