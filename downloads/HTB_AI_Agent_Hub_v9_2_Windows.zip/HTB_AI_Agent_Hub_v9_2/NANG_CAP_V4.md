# v4 — Cá chép tự nhiên và chữ rõ

- Thay cá hoạt hình bằng hình cá chép tự nhiên nhìn từ trên xuống, màu cam/vàng/trắng, vây trong và vảy rõ. Ảnh mới được tạo bằng imagegen; không chứa dữ liệu người dùng.
- Chuyển động Canvas liên tục: sóng uốn thân tăng dần về đuôi, vây quạt nhẹ, bơi theo quỹ đạo cong, quay đầu theo hướng chuyển động, tăng/giảm tốc mềm.
- Không tải và thay từng ảnh khung hình trong khi cá bơi. Có bật/tắt chuyển động, tạm dừng và tự ngừng vẽ khi trang không hiển thị.
- Site có nút Xem cá lớn. Cỡ chữ chính/phụ, độ đậm và độ tương phản được tăng trong menu, bảng, nút, thẻ tool và hộp thoại.
- Nút A+ ghi nhớ lựa chọn cỡ chữ lớn trên trình duyệt. Giao diện điện thoại dùng một cột để giữ chữ đủ lớn.
- Hub Windows cũng sử dụng hình cá và bộ chuyển động mới, cùng chữ rõ hơn. Sáu bộ tool gốc giữ nghiệp vụ của v3.

Kiểm tra v4: TypeScript và JavaScript không lỗi; động cơ cá chạy 240 khung thử không phát sinh giá trị không hợp lệ, dừng/tiếp tục và giải phóng tài nguyên đạt. Đã quan sát cá, hồ cá lớn và chữ trên trình duyệt. Đây là nâng cấp giao diện và chuyển động, không chứng nhận lại các chức năng ghi lên hệ thống trường.
