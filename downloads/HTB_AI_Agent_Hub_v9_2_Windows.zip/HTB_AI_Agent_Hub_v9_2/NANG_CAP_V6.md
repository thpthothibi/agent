# v6 — Phòng mô phỏng luồng AI Agent & Robot gõ lệnh

Sáu quy trình: điểm thi liên hoàn, phòng thi/SBD, phiếu lỗi, văn bản/báo cáo, ký sổ đầu bài, skill/prompt. Mỗi quy trình có tám bước, cổng duyệt và nhánh rà soát ngoại lệ. Chạy/tạm dừng/tiếp tục/từng bước/chạy lại lỗi; tốc độ 0,5× / 1× / 2×; lịch sử và xuất nhật ký JSON.

Hoạt cảnh robot lấy đúng ảnh AI.jpg của người dùng làm nền. Bộ dựng Canvas tạo chuyển động nhẹ ở bàn tay và đầu, nhấp đèn mắt, quét sáng và mã chạy trên màn hình. Robot gõ khi luồng chạy, dừng khi tạm dừng; có nút thử riêng và bật/tắt hoạt cảnh. Video MP4 6 giây/24 fps kèm theo được dựng bằng mã và ffmpeg; không gọi Runway hay dịch vụ AI tạo video.

Site chuyển thống kê số dòng/cảnh báo sang phòng mô phỏng bằng postMessage cùng nguồn. Không truyền tên học sinh, điểm hoặc tài khoản vào hoạt cảnh. Sơ đồ và nhật ký ở đây chỉ là mô phỏng; duyệt bước không cấp quyền ghi thật.

Kiểm tra: cả sáu quy trình đi qua nhánh lỗi, cổng duyệt và kết thúc đúng; tạm dừng giữ tiến độ; duyệt sai trạng thái không vượt cổng. Kiểm tra TypeScript/JavaScript, định dạng video và giao diện trình duyệt. Chức năng nghiệp vụ thật của các tool gốc không thay đổi trong bản nâng cấp này.
