"""Local preflight only: does not open a browser, log in, or enter grades."""
import importlib.util,os,platform,shutil,sys
from pathlib import Path

def chrome_paths(environ=None):
    env=os.environ if environ is None else environ
    paths=[]
    found=shutil.which('chrome') or shutil.which('google-chrome')
    if found:paths.append(Path(found))
    for name in ('PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA'):
        if env.get(name):paths.append(Path(env[name])/'Google'/'Chrome'/'Application'/'chrome.exe')
    if os.name=='nt' and environ is None:
        try:
            import winreg
            for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
                for view in (winreg.KEY_WOW64_64KEY,winreg.KEY_WOW64_32KEY):
                    try:
                        with winreg.OpenKey(hive,r'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',0,winreg.KEY_READ|view) as key:
                            paths.append(Path(winreg.QueryValue(key,None).strip('"')))
                    except OSError:pass
        except ImportError:pass
    return list(dict.fromkeys(str(p) for p in paths if p.is_file()))

def main():
    lines=['HTB — Kiểm tra khởi động (không mở Chrome/không nhập điểm)', 'Python: '+platform.python_version(), 'Môi trường: '+sys.executable]
    missing=[]
    for module in ('tkinter','openpyxl','pyperclip','playwright'):
        try:ok=importlib.util.find_spec(module) is not None
        except (ImportError,ValueError):ok=False
        lines.append(module+': '+('OK' if ok else 'THIẾU'))
        if not ok:missing.append(module)
    paths=chrome_paths();lines.append('Google Chrome: '+('; '.join(paths) if paths else 'CHƯA TÌM THẤY ở các vị trí thông dụng'))
    lines.append('Tool nhập điểm yêu cầu Google Chrome. Chromium do Playwright tải xuống là trình duyệt khác.')
    lines.append('Nếu thiếu thư viện: chạy 1_CAI_DAT_WINDOWS.bat, rồi mở bằng 2_MO_HE_THONG.bat.')
    lines.append('Nếu vẫn không mở: xem tools/grades/loi_giao_dien.txt, tools/grades/loi_khoi_dong.txt và workspace/grades-process.log.')
    text='\n'.join(lines);print(text)
    folder=Path(__file__).resolve().parent/'workspace';folder.mkdir(exist_ok=True)
    (folder/'startup-check.txt').write_text(text,encoding='utf-8')
    return 1 if missing or not paths else 0
if __name__=='__main__':raise SystemExit(main())
