"""HTB unified local companion. Binds loopback only. No arbitrary shell commands or file paths."""
from __future__ import annotations
import argparse,json,os,secrets,subprocess,sys,threading,time,webbrowser,shutil,urllib.request,urllib.error,uuid
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse,unquote
from catalog import CATALOG,ROOT
from job_store import JobStore
_origin_file=ROOT/'site-origin.txt'
SITE_ORIGIN=os.environ.get('HTB_SITE_ORIGIN',_origin_file.read_text(encoding='utf-8').strip() if _origin_file.exists() else 'http://localhost:5173').rstrip('/')
_origin=urlparse(SITE_ORIGIN)
if _origin.scheme not in ('http','https') or not _origin.netloc or _origin.path or _origin.query or _origin.fragment:
 raise ValueError('HTB_SITE_ORIGIN / site-origin.txt phải là origin, ví dụ https://agent.truong.edu.vn; không kèm đường dẫn.')
TOKEN=secrets.token_urlsafe(32)
LOCK=threading.RLock();JOBS={};EVENTS=[];PROCESSES={};PORT=8781
STATE=ROOT/'workspace';STATE.mkdir(exist_ok=True)
STORE=JobStore(STATE/'hub-runs.sqlite3')
JOBS.update(STORE.recover())
AUDIT=STATE/'hub-events.jsonl'
if AUDIT.exists():
 try:EVENTS[:]=[json.loads(line) for line in AUDIT.read_text(encoding='utf-8').splitlines()[-500:]]
 except (ValueError,OSError):EVENTS[:]=[]

def event(tool,message,kind='info'):
 row={'time':time.strftime('%Y-%m-%d %H:%M:%S'),'tool':tool,'message':message,'kind':kind}
 with LOCK:
  EVENTS.append(row);EVENTS[:]=EVENTS[-500:]
  with AUDIT.open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
def safe_path(root,tail):
 p=(root/unquote(tail)).resolve()
 if not p.is_relative_to(root.resolve()) or not p.is_file():return None
 return p

def tool_command(key):
 if key not in CATALOG:raise ValueError('Tool không có trong danh mục')
 s=CATALOG[key];cwd=ROOT/'tools'/s['folder']
 if s['kind']=='desktop':return [sys.executable,'-u',str(ROOT/'run_tool.py'),key],cwd
 if s['kind']=='streamlit':return [sys.executable,'-m','streamlit','run',s['entry'],'--server.address=127.0.0.1','--server.port='+str(s['port']),'--server.headless=true','--browser.gatherUsageStats=false'],cwd
 if s['kind']=='node':
  node=shutil.which('node')
  if not node:raise ValueError('Cần cài Node.js 22+ để chạy AI API của Skill Studio; thư viện mẫu vẫn mở được.')
  # Original worker build has no dependencies and includes original server-side AI handler.
  result=subprocess.run([node,'scripts/build-ai.mjs'],cwd=cwd,capture_output=True,text=True,timeout=30)
  if result.returncode:raise ValueError('Không build được Skill Studio. Kiểm tra Node.js và thư mục tool.')
  return [node,s['entry'],'--host','127.0.0.1','--port',str(s['port'])],cwd
 raise ValueError('Tool này chạy trực tiếp trong trình duyệt')
def monitor(key,p):
 log_path=STATE/(key+'-process.log')
 with log_path.open('a',encoding='utf-8') as f:
  for line in p.stdout:
   f.write(line);f.flush()
   if line.startswith('{'):
    try:
     item=json.loads(line)
     if item.get('event') in ('opened','operation'):
      with LOCK:
       JOBS[key].update(last_activity=time.time(),last_operation=item.get('action','opened'))
       STORE.put(JOBS[key])
      event(key,item.get('message',''))
    except (ValueError,TypeError):pass
 code=p.wait()
 with LOCK:
  JOBS[key].update(status='closed' if code==0 else 'error',exit_code=code,ended=time.time())
  STORE.put(JOBS[key])
 event(key,'Cửa sổ/tiến trình đã đóng' if code==0 else 'Tiến trình lỗi. Xem workspace/'+key+'-process.log', 'info' if code==0 else 'error')
def launch(key):
 with LOCK:
  if key not in CATALOG:raise ValueError('Tool không hợp lệ')
  if key in PROCESSES and PROCESSES[key].poll() is None:return JOBS[key]
  command,cwd=tool_command(key)
  p=subprocess.Popen(command,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',env={**os.environ,'PYTHONUTF8':'1','PYTHONUNBUFFERED':'1'},creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name=='nt' else 0)
  PROCESSES[key]=p;JOBS[key]={'run_id':str(uuid.uuid4()),'last_activity':time.time(),'progress_kind':'process_only','id':key,'title':CATALOG[key]['title'],'status':'open','pid':p.pid,'started':time.time(),'kind':CATALOG[key]['kind']}
  if 'port' in CATALOG[key]:JOBS[key]['url']='http://127.0.0.1:'+str(CATALOG[key]['port'])
  STORE.put(JOBS[key])
  threading.Thread(target=monitor,args=(key,p),daemon=True).start()
  event(key,'Mở tool gốc. Trạng thái mở không đồng nghĩa nghiệp vụ đã hoàn tất.')
  return JOBS[key]
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def origin_allowed(self):return self.headers.get('Origin') in (None,SITE_ORIGIN,'http://127.0.0.1:'+str(PORT),'http://localhost:'+str(PORT))
 def host_allowed(self):return self.headers.get('Host') in ('127.0.0.1:'+str(PORT),'localhost:'+str(PORT))
 def headers_out(self,status,ctype='application/json;charset=utf-8'):
  self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','SAMEORIGIN')
  if self.headers.get('Origin') and self.origin_allowed():
   self.send_header('Access-Control-Allow-Origin',self.headers['Origin']);self.send_header('Vary','Origin');self.send_header('Access-Control-Allow-Headers','Authorization, Content-Type');self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS');self.send_header('Access-Control-Allow-Private-Network','true')
  self.end_headers()
 def reply(self,obj,status=200):self.headers_out(status);self.wfile.write(json.dumps(obj,ensure_ascii=False).encode())
 def auth(self):return self.host_allowed() and self.origin_allowed() and secrets.compare_digest(self.headers.get('Authorization',''),'Bearer '+TOKEN)
 def do_OPTIONS(self):
  if not self.host_allowed() or not self.origin_allowed():return self.reply({'error':'Nguồn không được phép'},403)
  self.headers_out(204)
 def do_GET(self):
  if not self.host_allowed() or not self.origin_allowed():return self.reply({'error':'Nguồn không được phép'},403)
  path=urlparse(self.path).path
  if path=='/api/health':return self.reply({'ok':True,'version':'9.2','mode':'local-companion','tools':len(CATALOG)})
  if path=='/api/state':
   if not self.auth():return self.reply({'error':'Cần mã ghép nối từ cửa sổ Hub trên máy tính'},401)
   with LOCK:return self.reply({'jobs':list(JOBS.values()),'events':EVENTS[-100:],'catalog':CATALOG,'history':STORE.history(),'server_time':time.time(),'version':'9.2'})
  if path=='/api/session':
   if self.headers.get('Origin') not in (None,'http://127.0.0.1:'+str(PORT),'http://localhost:'+str(PORT)):return self.reply({'error':'Chỉ cấp phiên cho giao diện trên máy'},403)
   return self.reply({'token':TOKEN})
  if path.startswith('/api/ai/') or path=='/api/ai/status':return self.proxy_skill()
  if path=='/':
   page=(ROOT/'local.html').read_text(encoding='utf-8').replace('__PAIR_TOKEN__',TOKEN)
   self.headers_out(200,'text/html;charset=utf-8');return self.wfile.write(page.encode())
  routes={'/flow-lab/':ROOT/'flow-lab','/tools/rooms/':ROOT/'tools/grades/phong_thi','/tools/skills/':ROOT/'tools/skills/public','/mascot/':ROOT/'mascot'}
  for prefix,root in routes.items():
   if path.startswith(prefix):
    target=safe_path(root,path[len(prefix):] or 'index.html')
    if target:
     import mimetypes
     self.headers_out(200,mimetypes.guess_type(target.name)[0] or 'application/octet-stream');return self.wfile.write(target.read_bytes())
  return self.reply({'error':'Không tìm thấy'},404)
 def read_json(self):
  size=int(self.headers.get('Content-Length','0'))
  if size<0 or size>32768:raise ValueError('Yêu cầu quá lớn')
  return json.loads(self.rfile.read(size) or b'{}')
 def do_POST(self):
  if not self.host_allowed() or not self.origin_allowed():return self.reply({'error':'Nguồn không được phép'},403)
  path=urlparse(self.path).path
  if path.startswith('/api/ai/'):return self.proxy_skill()
  if not self.auth():return self.reply({'error':'Mã ghép nối không hợp lệ'},401)
  try:
   data=self.read_json()
   if path=='/api/launch':
    if data.get('confirmed') is not True:raise ValueError('Cần người dùng xác nhận mở tool')
    return self.reply({'job':launch(data.get('tool',''))})
   if path=='/api/stop':
    # Closing only the owned subprocess, not arbitrary PIDs or Chrome sessions.
    if data.get('confirmed') is not True:raise ValueError('Cần xác nhận đóng tiến trình')
    key=data.get('tool','');p=PROCESSES.get(key)
    if p and p.poll() is None:
     if os.name=='nt':subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True,timeout=10)
     else:p.terminate()
     event(key,'Người dùng yêu cầu đóng tiến trình; trạng thái dữ liệu bên ngoài cần đối chiếu lại.','warning')
    return self.reply({'ok':True})
   return self.reply({'error':'Không tìm thấy'},404)
  except (ValueError,TypeError,OSError,subprocess.SubprocessError) as e:return self.reply({'error':str(e)},400)
 def proxy_skill(self):
  # Manual prompt library works without Node; AI generation uses the original Node worker.
  p=PROCESSES.get('skills')
  if not p or p.poll() is not None:return self.reply({'error':'Mở Skill Studio AI trong Hub để bật API Node.js.','available':False},503)
  path=urlparse(self.path).path
  if path not in ('/api/ai/status','/api/ai/models','/api/ai/generate'):return self.reply({'error':'Không tìm thấy'},404)
  if self.command=='POST' and self.headers.get('Origin') not in ('http://127.0.0.1:'+str(PORT),'http://localhost:'+str(PORT)):return self.reply({'error':'API AI cục bộ chỉ nhận từ giao diện trên máy'},403)
  try:
   size=int(self.headers.get('Content-Length','0'))
   if size>24000:raise ValueError('Yêu cầu quá lớn')
   body=self.rfile.read(size) if self.command=='POST' else None
   origin='http://127.0.0.1:8783'
   req=urllib.request.Request(origin+path,data=body,method=self.command,headers={'Content-Type':'application/json','Origin':origin})
   with urllib.request.urlopen(req,timeout=100) as response:
    self.headers_out(response.status);self.wfile.write(response.read(2000000))
  except Exception:return self.reply({'error':'API Skill Studio chưa sẵn sàng. Kiểm tra Node.js hoặc dùng nhập JSON thủ công.'},502)

def main():
 global PORT
 parser=argparse.ArgumentParser();parser.add_argument('--no-browser',action='store_true');parser.add_argument('--port',type=int,default=8781);args=parser.parse_args();PORT=args.port
 server=ThreadingHTTPServer(('127.0.0.1',PORT),Handler)
 print('HTB AI Agent Hub: http://127.0.0.1:'+str(PORT),flush=True)
 print('Mo trang tren de xem ma ghep noi; khong chia se ma ra ngoai.',flush=True)
 if not args.no_browser:threading.Timer(.6,lambda:webbrowser.open('http://127.0.0.1:'+str(PORT))).start()
 try:server.serve_forever()
 except KeyboardInterrupt:pass
 finally:
  server.server_close()
  for p in PROCESSES.values():
   if p.poll() is None:p.terminate()
if __name__=='__main__':main()
