# Kiểm tra v9 — 10/11/2026

- 18 kiểm tra engine Excel giữ từ v8.
- 14 kiểm tra Python Hub giữ từ v8.
- 14 kiểm tra cloud dùng D1/R2 cục bộ thật trong Miniflare, với tài khoản kiểm thử giả: chưa đăng nhập, khác nguồn, sai số phiên bản, ghi/đọc, gửi lại cùng nội dung, tách hai tài khoản, giữ lịch sử, hai ghi đồng thời, mất xác nhận sau commit, lỗi R2, bản lưu hỏng, giới hạn kích thước/trang, bảo toàn bản máy khi lấy cloud, phục hồi lịch sử thành hồ sơ mới, chặn khôi phục lúc đang chạy/kho máy đầy.
- TypeScript và bản production build được kiểm tra.
- Trình duyệt kiểm tra giao diện v9 và trạng thái chưa đăng nhập: nút lưu cloud bị khóa, có đường dẫn đăng nhập. Preview quản lý không giả lập đăng nhập ChatGPT.
- Không xác nhận đã thử đồng bộ bằng tài khoản thật của người dùng trên hai máy. Chưa thử tải tối đa 8 MB, Windows, hay tài khoản Vietschool/Sổ đầu bài thật.
- Kiểm thử HTTP trực tiếp từ executor tới preview không thực hiện được do hai môi trường tách mạng. Không thay cơ chế mạng hoặc auth để vượt giới hạn; kiểm tra server dùng bộ D1/R2 cô lập và UI dùng trình duyệt hỗ trợ.

Không dùng các kết quả trên để khẳng định đã xử lý hoặc gửi dữ liệu học sinh thật. Kho production được kiểm tra sau triển khai bằng công cụ quản trị Site; dữ liệu thật chỉ gửi khi người dùng chọn lưu.
