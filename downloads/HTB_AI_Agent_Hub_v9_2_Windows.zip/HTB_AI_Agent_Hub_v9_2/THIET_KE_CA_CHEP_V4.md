# Tài nguyên cá chép v4

Ảnh được tạo bằng công cụ imagegen tích hợp, lưu trong `mascot/koi-real-v4.png`. Bộ chuyển động dùng chung cho Site và Hub: `mascot/koi-engine.js`.

Yêu cầu tạo ảnh: một cá chép koi tự nhiên màu cam/vàng/trắng, nhìn thẳng từ trên xuống, thân thẳng để dựng chuyển động, đầu hướng phải và đuôi hướng trái; đủ toàn bộ vây mỏng, đuôi chẻ, vảy và râu tự nhiên, nền trong suốt. Không mặt người, không biểu cảm hoạt hình, không cảnh nền, không chữ. Hình này là bề mặt trung tính; động cơ Canvas tạo chuyển động uốn thân và lượn vòng liên tục trong trình duyệt.

Ảnh và chuyển động chỉ minh họa trạng thái, không điều khiển hay xác nhận hoàn tất các thao tác nghiệp vụ của nhà trường.
