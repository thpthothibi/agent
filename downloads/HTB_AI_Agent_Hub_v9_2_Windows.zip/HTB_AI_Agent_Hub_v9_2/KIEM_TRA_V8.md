# Kiểm tra bản v8 — 10/11/2026

- 18 kiểm tra engine Excel đạt: 10 kiểm tra v7 + xung đột mã HS giữa nguồn, loại dòng vẫn giữ dòng gốc, lịch sử trước–sau, tìm kết quả ngoài dòng 300, điều kiện dừng/chọn hàng đợi, JSON null/chỉ số loại không hợp lệ, tương thích sao lưu v7/v8, giữ mã HS dạng 001 khi Excel định dạng số có số 0 đầu.
- 14 kiểm tra Python Hub đạt.
- TypeScript không lỗi.
- Trình duyệt: giữ hồ sơ v7, tạo bản nháp sửa, đổi TL 7,25 → 7,50, lưu nháp rồi tải lại vẫn còn thay đổi; lưu bản sửa thành hồ sơ mới có liên kết và lịch sử; đưa vào hàng đợi; luồng dừng ở chờ rà soát với tổng 9,75; duyệt mới và tạo Excel; lưu trữ và lọc được hồ sơ lưu trữ.
- Kiểm tra giao diện xanh dương, chữ đậm, bộ lọc và lịch sử sửa hiển thị đúng.
- Chưa kiểm thử Windows, tài khoản trường, đồng thời nhiều giáo viên hay mức tải tối đa. Không có thao tác ghi hệ thống bên ngoài trong các kiểm tra.
