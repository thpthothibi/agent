# Kiểm tra v7 — 10/11/2026

- 10 kiểm tra engine xử lý Excel: phép cộng chính xác phần trăm điểm, nguồn TN thiếu, trùng khóa chuẩn hóa, mã học sinh phân biệt tên trùng, mã HS có tên khác, sai khối/nghỉ/vắng/trạng thái lạ, tổng vượt 10, giữ số dòng gốc, đối chiếu điểm tổng, thay đổi dấu vân tay và kiểm tra schema sao lưu.
- 14 kiểm tra Python Hub: 12 kiểm tra bảo vệ sẵn có + 2 kiểm tra SQLite phục hồi gián đoạn, không gắn lại PID cũ và không nhân đôi cùng lượt.
- TypeScript không lỗi.
- Giao diện trình duyệt: tải mẫu 3 sheet → nhận diện vai trò riêng → lưu hồ sơ → chạy một bước → tải lại còn điểm tiếp tục → tiếp tục đến chờ rà soát → duyệt SHA-256 → tạo Excel → sao lưu JSON → khôi phục tạo hồ sơ mới không có duyệt.
- Excel mẫu 7,25 + 2,25 = 9,50; điểm cũ 9,00, chênh lệch 0,50.
- Giới hạn: chưa kiểm thử cài đặt Windows, đăng nhập và thao tác ghi trên tài khoản trường; chưa kiểm thử tải 50.000 dòng hay nhiều giáo viên dùng đồng thời. Không coi các kiểm tra trên là bằng chứng đã xử lý dữ liệu trường.
