"""Run the preserved native GUI with an isolated import root. No credentials in arguments."""
import os,sys,runpy,json,time,traceback
from pathlib import Path
from catalog import CATALOG,ROOT
key=sys.argv[1]
if key not in CATALOG:raise SystemExit('Unknown tool')
spec=CATALOG[key];folder=ROOT/'tools'/spec['folder'];entry=folder/spec['entry']
sys.path.insert(0,str(folder));sys.path.insert(0,str(entry.parent));os.chdir(folder);sys.argv=[str(entry)]
print(json.dumps({'event':'opened','tool':key,'message':'Đang mở giao diện tool gốc'},ensure_ascii=False),flush=True)
# Report selected operation boundaries only; never dump arguments, passwords, keys or file contents.
tracked={'choose','start_run','enqueue_command','start_paste','stop_run','request_stop'}
def trace(frame,event,arg):
 if event=='call' and frame.f_code.co_name in tracked:
  file=Path(frame.f_code.co_filename)
  if file.is_relative_to(folder):
   print(json.dumps({'event':'operation','tool':key,'action':frame.f_code.co_name,'message':'Người dùng thao tác trong tool gốc: '+frame.f_code.co_name},ensure_ascii=False),flush=True)
 return trace
sys.setprofile(trace)
try:
 if key=='sum':
  from cong_diem.app import App
  root=__import__('tkinter').Tk();App(root);root.mainloop()
 else:runpy.run_path(str(entry),run_name='__main__')
except Exception:
 traceback.print_exc();sys.exit(1)
finally:sys.setprofile(None)
