"""Durable process records. No credentials, student rows, or command arguments."""
import sqlite3,json,time,uuid
class JobStore:
 def __init__(self,path):
  self.path=str(path)
  with self.connect() as db:
   db.execute('CREATE TABLE IF NOT EXISTS runs (run_id TEXT PRIMARY KEY, tool TEXT NOT NULL, status TEXT NOT NULL, record TEXT NOT NULL, updated REAL NOT NULL)')
 def connect(self):return sqlite3.connect(self.path,timeout=10)
 def put(self,record):
  with self.connect() as db:db.execute('INSERT INTO runs VALUES(?,?,?,?,?) ON CONFLICT(run_id) DO UPDATE SET status=excluded.status,record=excluded.record,updated=excluded.updated',(record['run_id'],record['id'],record['status'],json.dumps(record,ensure_ascii=False),time.time()))
 def history(self,limit=100):
  with self.connect() as db:return [json.loads(row[0]) for row in db.execute('SELECT record FROM runs ORDER BY updated DESC LIMIT ?',(limit,))]
 def recover(self):
  # A stored PID may now belong to another process. Never attach to or kill it.
  records=self.history(1000)
  for r in records:
   if r['status']=='open':
    r.update(status='interrupted',ended=time.time(),recovery='Hub đã khởi động lại. Mở tool và đối chiếu trước khi chạy lại.')
    self.put(r)
  latest={}
  for r in self.history(1000):latest.setdefault(r['id'],r)
  return latest
