import sys,unittest,threading,json,urllib.request,urllib.error
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import hub_server as hub
from catalog import CATALOG,ROOT
class HubTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.server=hub.ThreadingHTTPServer(('127.0.0.1',0),hub.Handler);hub.PORT=cls.server.server_address[1]
  cls.url='http://127.0.0.1:'+str(hub.PORT)
  cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close()
 def request(self,path,data=None,headers=None):
  req=urllib.request.Request(self.url+path,data=json.dumps(data).encode() if data is not None else None,headers=headers or {})
  try:
   with urllib.request.urlopen(req,timeout=3) as r:return r.status,r.read(),dict(r.headers)
  except urllib.error.HTTPError as r:return r.code,r.read(),dict(r.headers)
 def test_catalog(self):
  self.assertEqual(len(CATALOG),8)
  for s in CATALOG.values():self.assertTrue((ROOT/'tools'/s['folder']/s['entry']).is_file())
 def test_auth_required(self):self.assertEqual(self.request('/api/state')[0],401)
 def test_paired_status(self):self.assertEqual(self.request('/api/state',headers={'Authorization':'Bearer '+hub.TOKEN})[0],200)
 def test_origin_blocked(self):self.assertEqual(self.request('/api/session',headers={'Origin':'https://attacker.example'})[0],403)
 def test_host_blocked(self):self.assertEqual(self.request('/api/health',headers={'Host':'attacker.example'})[0],403)
 def test_site_cannot_read_session(self):self.assertEqual(self.request('/api/session',headers={'Origin':hub.SITE_ORIGIN})[0],403)
 def test_launch_needs_confirmation(self):
  self.assertEqual(self.request('/api/launch',{'tool':'grades'},headers={'Authorization':'Bearer '+hub.TOKEN})[0],400)
  self.assertFalse(hub.PROCESSES)
 def test_unknown_tool_blocked(self):
  self.assertEqual(self.request('/api/launch',{'tool':'../../evil','confirmed':True},headers={'Authorization':'Bearer '+hub.TOKEN})[0],400)
  self.assertFalse(hub.PROCESSES)
 def test_path_traversal(self):self.assertIsNone(hub.safe_path(ROOT/'tools/skills/public','../../../hub_server.py'))
 def test_preserved_guards(self):
  for file,marker in [('sdb/ai_agent_ky_thay_win.py','HTB Hub - Xác nhận thao tác'),('omr/vietschool_sbd_agent.py','HTB Hub - Duyệt chạy tool gốc'),('grades/vietschool_agent_v2.py','HTB Hub - Xác nhận tác vụ')]:self.assertIn(marker,(ROOT/'tools'/file).read_text())
  self.assertIn('DEFAULT_PIN = ""',(ROOT/'tools/sdb/ai_agent_ky_thay_win.py').read_text())
 def test_static_tool(self):
  status,body,_=self.request('/tools/rooms/index.html');self.assertEqual(status,200);self.assertIn(b'<!doctype',body.lower())
 def test_ai_needs_backend(self):self.assertEqual(self.request('/api/ai/status')[0],503)
if __name__=='__main__':unittest.main()
