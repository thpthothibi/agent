import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from job_store import JobStore
class PersistenceTests(unittest.TestCase):
 def test_recovery_never_reattaches_to_stored_pid(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'jobs.sqlite3';s=JobStore(p)
   s.put({'run_id':'one','id':'grades','status':'open','pid':99999})
   s.put({'run_id':'two','id':'sum','status':'closed'})
   recovered=JobStore(p).recover()
   self.assertEqual(recovered['grades']['status'],'interrupted')
   self.assertEqual(recovered['sum']['status'],'closed')
   self.assertIn('đối chiếu',recovered['grades']['recovery'])
   self.assertEqual(len(JobStore(p).history()),2)
 def test_upsert_does_not_duplicate_run(self):
  with tempfile.TemporaryDirectory() as d:
   s=JobStore(Path(d)/'jobs.sqlite3')
   for state in ['open','closed']:s.put({'run_id':'same','id':'grades','status':state})
   self.assertEqual(len(s.history()),1)
   self.assertEqual(s.history()[0]['status'],'closed')
if __name__=='__main__':unittest.main()
