import importlib,queue,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import Mock,patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'/'grades'))
# Clipboard is not exercised; these tests never start Playwright or Chrome.
try:import pyperclip
except ImportError:sys.modules['pyperclip']=types.SimpleNamespace(copy=Mock(),paste=Mock())
input_module=importlib.import_module('vietschool_agent_v2')
from startup_errors import install_callback_reporting,startup_hint

class StartButtonTests(unittest.TestCase):
 def app(self):
  app=types.SimpleNamespace(busy=False,cancel_event=None,events=queue.Queue(),worker=None,stopping=False)
  for attr in ('filevar','status','load','stop','progress'):setattr(app,attr,Mock())
  app.hub=types.SimpleNamespace(can_start=Mock(return_value=True),pick_file=Mock(return_value='demo.xlsx'))
  app.launch_when_ready=Mock()
  return app
 def test_confirmation_component_is_imported(self):
  self.assertTrue(callable(input_module.messagebox.askyesno))
 def test_acceptance_reaches_worker_launch_after_file_selection(self):
  app=self.app()
  with patch.object(input_module.messagebox,'askyesno',return_value=True):input_module.AutoApp.choose(app)
  self.assertTrue(app.busy)
  self.assertEqual(app.launch_when_ready.call_args.args[0],'demo.xlsx')
  app.hub.pick_file.assert_called_once()
 def test_decline_never_selects_file_or_launches(self):
  app=self.app()
  with patch.object(input_module.messagebox,'askyesno',return_value=False):input_module.AutoApp.choose(app)
  app.hub.pick_file.assert_not_called();app.launch_when_ready.assert_not_called()
  self.assertFalse(app.busy)
 def test_busy_click_does_not_show_another_confirmation(self):
  app=self.app();app.busy=True
  with patch.object(input_module.messagebox,'askyesno') as ask:input_module.AutoApp.choose(app)
  ask.assert_not_called();app.launch_when_ready.assert_not_called()
 def test_cancel_file_does_not_launch(self):
  app=self.app();app.hub.pick_file.return_value=''
  with patch.object(input_module.messagebox,'askyesno',return_value=True):input_module.AutoApp.choose(app)
  app.launch_when_ready.assert_not_called();self.assertFalse(app.busy)
 def test_worker_starts_with_no_external_actions_in_test(self):
  app=self.app();app.root=Mock();app.hub.released=Mock(return_value=True)
  with patch.object(input_module,'AutoWorker') as worker:
   input_module.AutoApp.launch_when_ready(app,'demo.xlsx',100)
   worker.assert_called_once();worker.return_value.start.assert_called_once()
 def test_callback_error_is_visible_and_cannot_retry(self):
  app=self.app();app.busy=True
  root=types.SimpleNamespace()
  with tempfile.TemporaryDirectory() as folder,patch('startup_errors.messagebox.showerror') as dialog:
   handler=install_callback_reporting(root,folder,lambda:[app])
   try:raise NameError("name 'messagebox' is not defined")
   except NameError:handler(*sys.exc_info())
   dialog.assert_called_once()
   self.assertIn('NameError',(Path(folder)/'loi_giao_dien.txt').read_text())
   self.assertEqual(app.events.get_nowait()[0],'error')
   app.launch_when_ready.assert_not_called()
 def test_browser_start_hints_preserve_profile(self):
  self.assertIn('Google Chrome',startup_hint('Chromium distribution chrome is not found'))
  self.assertIn('Không cần xóa',startup_hint('ProcessSingleton profile in use'))
if __name__=='__main__':unittest.main()
