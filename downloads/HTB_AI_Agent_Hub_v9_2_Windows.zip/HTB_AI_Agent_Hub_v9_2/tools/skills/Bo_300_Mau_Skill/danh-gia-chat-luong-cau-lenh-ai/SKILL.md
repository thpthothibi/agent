---
name: "danh-gia-chat-luong-cau-lenh-ai"
description: "Kiểm tra ngữ cảnh, nhiệm vụ, giới hạn và tiêu chí đầu ra. Sử dụng khi cần đánh giá chất lượng câu lệnh ai."
---

# Đánh giá chất lượng câu lệnh AI

## Vai trò
Trợ lý thiết kế tự động hóa

## Mục tiêu và ngữ cảnh sử dụng
Kiểm tra ngữ cảnh, nhiệm vụ, giới hạn và tiêu chí đầu ra. Sử dụng khi cần đánh giá chất lượng câu lệnh ai.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Quy trình thực tế, công cụ được phép dùng, ví dụ đầu vào, trạng thái, lỗi thường gặp và phạm vi được giao.

## Quy trình
1. Xác nhận nhiệm vụ đánh giá chất lượng câu lệnh ai, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Vẽ trạng thái công việc, điều kiện bắt đầu và kết thúc
3. Xác định điểm đọc dữ liệu, kiểm tra và hành động bên ngoài
4. Kiểm tra ngữ cảnh, nhiệm vụ, giới hạn và tiêu chí đầu ra.
5. Thiết kế cơ chế thử lại, chống trùng và tiếp tục sau lỗi
6. Lập ca kiểm thử cho thành công, thiếu dữ liệu và gián đoạn
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bảng đánh giá và phiên bản câu lệnh sửa.

## Kiểm tra chất lượng
- Không giả định có quyền hoặc công cụ chưa được cấp.
- Hành động ghi dữ liệu có bước đối chiếu, log và phạm vi rõ ràng.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Đánh giá chất lượng câu lệnh AI” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bảng đánh giá và phiên bản câu lệnh sửa.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Đánh giá chất lượng câu lệnh AI” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bảng đánh giá và phiên bản câu lệnh sửa.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
