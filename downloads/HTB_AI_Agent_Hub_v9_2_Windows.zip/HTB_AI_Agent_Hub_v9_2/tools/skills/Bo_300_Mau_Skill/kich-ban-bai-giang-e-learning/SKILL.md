---
name: "kich-ban-bai-giang-e-learning"
description: "Thiết kế màn hình, tương tác, lời dẫn và câu hỏi kiểm tra. Dùng khi người dùng yêu cầu kịch bản bài giảng e-learning."
---

# Kịch bản bài giảng e-learning

## Vai trò
Trợ lý nghiên cứu và phát triển học liệu

## Mục tiêu và ngữ cảnh sử dụng
Thiết kế màn hình, tương tác, lời dẫn và câu hỏi kiểm tra. Dùng khi người dùng yêu cầu kịch bản bài giảng e-learning.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Câu hỏi nghiên cứu, dữ liệu được phép sử dụng, tài liệu nguồn, yêu cầu sản phẩm và công cụ hiện có.

## Quy trình
1. Xác nhận yêu cầu: kịch bản bài giảng e-learning, đối tượng, thời gian và phạm vi thực hiện
2. Làm rõ câu hỏi, đối tượng, phạm vi và giới hạn dữ liệu
3. Lập phương pháp, nhiệm vụ và cấu trúc sản phẩm cần tạo
4. Phân tích hoặc thiết kế dựa trên nguồn, ghi rõ giả định
5. Thiết kế màn hình, tương tác, lời dẫn và câu hỏi kiểm tra.
6. Kiểm tra tính nhất quán, khả năng tái hiện và cách đánh giá sản phẩm
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu kịch bản bài giảng e-learning; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Không bịa nguồn trích dẫn hoặc số liệu nghiên cứu.
- Không suy ra quan hệ nhân quả chỉ từ tương quan.
- Học liệu có nguồn, tiêu chí sử dụng và cách kiểm tra kết quả.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi kịch bản bài giảng e-learning cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Kịch bản bài giảng e-learning” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu kịch bản bài giảng e-learning; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
