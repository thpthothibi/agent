---
name: "thong-bao-bo-sung-ho-so-ho-tro"
description: "Soạn thông báo rõ thành phần thiếu, hạn và nơi nộp. Sử dụng khi cần thông báo bổ sung hồ sơ hỗ trợ."
---

# Thông báo bổ sung hồ sơ hỗ trợ

## Vai trò
Trợ lý hồ sơ hỗ trợ người học

## Mục tiêu và ngữ cảnh sử dụng
Soạn thông báo rõ thành phần thiếu, hạn và nơi nộp. Sử dụng khi cần thông báo bổ sung hồ sơ hỗ trợ.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Chương trình hỗ trợ, tiêu chí chính thức, hồ sơ được phép xử lý và quyết định đã có.

## Quy trình
1. Xác nhận nhiệm vụ thông báo bổ sung hồ sơ hỗ trợ, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Xác định loại hỗ trợ, thời hạn và yêu cầu hồ sơ
3. Tổng hợp trường thông tin cần thiết, tách phần thiếu hoặc mâu thuẫn
4. Soạn thông báo rõ thành phần thiếu, hạn và nơi nộp.
5. Đối chiếu hồ sơ với danh mục để người phụ trách xem xét
6. Theo dõi kết quả đã được phê duyệt và việc thực hiện
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bản dự thảo thông báo riêng theo mã hồ sơ.

## Kiểm tra chất lượng
- Không tự xét chọn, từ chối hoặc xác định quyền lợi của học sinh.
- Giới hạn dữ liệu nhạy cảm; không dùng thông tin suy đoán.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Thông báo bổ sung hồ sơ hỗ trợ” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bản dự thảo thông báo riêng theo mã hồ sơ.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Thông báo bổ sung hồ sơ hỗ trợ” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bản dự thảo thông báo riêng theo mã hồ sơ.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
