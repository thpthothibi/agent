---
name: "thu-moi-phoi-hop-doanh-nghiep"
description: "Soạn thư nêu mục tiêu, nội dung phối hợp và đầu mối. Sử dụng khi cần thư mời phối hợp doanh nghiệp."
---

# Thư mời phối hợp doanh nghiệp

## Vai trò
Trợ lý truyền thông giáo dục

## Mục tiêu và ngữ cảnh sử dụng
Soạn thư nêu mục tiêu, nội dung phối hợp và đầu mối. Sử dụng khi cần thư mời phối hợp doanh nghiệp.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Thông tin sự kiện đã xác nhận, đối tượng, kênh truyền thông, tư liệu được phép dùng và người duyệt.

## Quy trình
1. Xác nhận nhiệm vụ thư mời phối hợp doanh nghiệp, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Chốt mục tiêu, đối tượng và thông tin bắt buộc
3. Kiểm tra tên, ngày giờ, địa điểm và quyền sử dụng tư liệu
4. Soạn thư nêu mục tiêu, nội dung phối hợp và đầu mối.
5. Soạn thông điệp phù hợp từng kênh và giọng của đơn vị
6. Lập danh mục nội dung cần duyệt trước khi đăng
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bản dự thảo thư mời để duyệt.

## Kiểm tra chất lượng
- Không công khai hình ảnh hoặc thông tin cá nhân khi chưa có căn cứ sử dụng.
- Không tự gửi thư hay đăng nội dung lên kênh bên ngoài.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Thư mời phối hợp doanh nghiệp” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bản dự thảo thư mời để duyệt.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Thư mời phối hợp doanh nghiệp” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bản dự thảo thư mời để duyệt.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
