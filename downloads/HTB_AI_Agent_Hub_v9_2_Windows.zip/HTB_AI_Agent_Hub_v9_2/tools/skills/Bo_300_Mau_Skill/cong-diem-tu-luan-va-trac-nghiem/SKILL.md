---
name: "cong-diem-tu-luan-va-trac-nghiem"
description: "Ghép mã học sinh và cộng theo công thức, thang điểm được cung cấp. Dùng khi người dùng yêu cầu cộng điểm tự luận và trắc nghiệm."
---

# Cộng điểm tự luận và trắc nghiệm

## Vai trò
Trợ lý nghiệp vụ khảo thí

## Mục tiêu và ngữ cảnh sử dụng
Ghép mã học sinh và cộng theo công thức, thang điểm được cung cấp. Dùng khi người dùng yêu cầu cộng điểm tự luận và trắc nghiệm.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Danh sách học sinh, mã định danh, lớp, môn, đợt kiểm tra, bảng điểm và quy tắc nghiệp vụ của đơn vị.

## Quy trình
1. Xác nhận yêu cầu: cộng điểm tự luận và trắc nghiệm, đối tượng, thời gian và phạm vi thực hiện
2. Xác nhận đúng năm học, đợt, khối, lớp và môn của từng nguồn
3. Chuẩn hóa mã định danh dưới dạng chuỗi, giữ số 0 đầu
4. Ghép theo mã; tách trường hợp trùng, thiếu hoặc mâu thuẫn để xác minh
5. Ghép mã học sinh và cộng theo công thức, thang điểm được cung cấp.
6. Đối chiếu tổng số học sinh và kết quả trước khi bàn giao
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu cộng điểm tự luận và trắc nghiệm; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Không ghép chỉ bằng họ tên khi trùng tên.
- Không đổi ô trống, nghỉ hoặc miễn thành điểm 0.
- Không ghi đè bảng gốc khi chưa được yêu cầu.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi cộng điểm tự luận và trắc nghiệm cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Cộng điểm tự luận và trắc nghiệm” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu cộng điểm tự luận và trắc nghiệm; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
