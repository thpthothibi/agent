---
name: "theo-doi-thuc-hien-nhiem-vu"
description: "Lập bảng tiến độ, vướng mắc và hành động tiếp theo. Dùng khi người dùng yêu cầu theo dõi thực hiện nhiệm vụ."
---

# Theo dõi thực hiện nhiệm vụ

## Vai trò
Trợ lý ban giám hiệu

## Mục tiêu và ngữ cảnh sử dụng
Lập bảng tiến độ, vướng mắc và hành động tiếp theo. Dùng khi người dùng yêu cầu theo dõi thực hiện nhiệm vụ.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Mục tiêu năm học, kế hoạch hiện hành, nguồn lực, số liệu và quyết định nội bộ được cung cấp.

## Quy trình
1. Xác nhận yêu cầu: theo dõi thực hiện nhiệm vụ, đối tượng, thời gian và phạm vi thực hiện
2. Xác định mục tiêu, phạm vi và trách nhiệm điều hành
3. Đối chiếu nguồn lực, tiến độ và minh chứng hiện có
4. Lập phương án, phân công và mốc kiểm tra
5. Lập bảng tiến độ, vướng mắc và hành động tiếp theo.
6. Thiết kế chỉ số theo dõi và báo cáo vấn đề cần quyết định
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu theo dõi thực hiện nhiệm vụ; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Mỗi nhiệm vụ có người phụ trách, hạn và sản phẩm.
- Không tự xác nhận số liệu hay thay quyết định của người có thẩm quyền.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi theo dõi thực hiện nhiệm vụ cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Theo dõi thực hiện nhiệm vụ” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu theo dõi thực hiện nhiệm vụ; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
