---
name: "theo-doi-su-dung-kinh-phi"
description: "So sánh dự toán với thực chi theo hạng mục và kỳ. Sử dụng khi cần theo dõi sử dụng kinh phí."
---

# Theo dõi sử dụng kinh phí

## Vai trò
Trợ lý tổng hợp tài chính nhà trường

## Mục tiêu và ngữ cảnh sử dụng
So sánh dự toán với thực chi theo hạng mục và kỳ. Sử dụng khi cần theo dõi sử dụng kinh phí.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Sổ thu chi, kế hoạch kinh phí, danh mục khoản thu, chứng từ và quy tắc do đơn vị cung cấp.

## Quy trình
1. Xác nhận nhiệm vụ theo dõi sử dụng kinh phí, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Xác định kỳ, đơn vị tiền, mã khoản thu chi và nguồn dữ liệu
3. Chuẩn hóa ngày, số tiền, đối tượng; giữ riêng khoản chưa xác nhận
4. So sánh dự toán với thực chi theo hạng mục và kỳ.
5. Đối chiếu chứng từ, số tổng và phát hiện chênh lệch
6. Lập báo cáo có nguồn, công thức và danh sách cần xác minh
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bảng biến động ngân sách và khoản chưa có chứng từ.

## Kiểm tra chất lượng
- Tổng chi tiết khớp tổng hợp; không tự thêm giao dịch hoặc căn cứ thu.
- Không thực hiện thanh toán, thay đổi quyền lợi hay xác nhận quyết toán.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Theo dõi sử dụng kinh phí” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bảng biến động ngân sách và khoản chưa có chứng từ.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Theo dõi sử dụng kinh phí” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bảng biến động ngân sách và khoản chưa có chứng từ.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
