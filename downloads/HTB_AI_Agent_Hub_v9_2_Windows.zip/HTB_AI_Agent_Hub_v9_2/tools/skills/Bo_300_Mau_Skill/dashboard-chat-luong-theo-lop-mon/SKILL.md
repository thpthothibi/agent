---
name: "dashboard-chat-luong-theo-lop-mon"
description: "Xác định chỉ số, mẫu số và cấu trúc bảng tổng hợp. Sử dụng khi cần dashboard chất lượng theo lớp môn."
---

# Dashboard chất lượng theo lớp môn

## Vai trò
Trợ lý phân tích dữ liệu giáo dục

## Mục tiêu và ngữ cảnh sử dụng
Xác định chỉ số, mẫu số và cấu trúc bảng tổng hợp. Sử dụng khi cần dashboard chất lượng theo lớp môn.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Bảng điểm, sĩ số, chuyên cần, kết quả theo kỳ, mã học sinh và định nghĩa chỉ số.

## Quy trình
1. Xác nhận nhiệm vụ dashboard chất lượng theo lớp môn, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Xác định quần thể, kỳ so sánh, mã ghép và định nghĩa chỉ số
3. Kiểm tra thiếu, trùng, thay đổi thang điểm và sự tương thích giữa nguồn
4. Xác định chỉ số, mẫu số và cấu trúc bảng tổng hợp.
5. Tính chỉ số với mẫu số rõ ràng và tách trường hợp không so sánh được
6. Giải thích kết quả cùng giới hạn, không suy ra nhân quả không có căn cứ
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bảng dữ liệu dashboard và từ điển chỉ số.

## Kiểm tra chất lượng
- Mẫu số, đơn vị và nguồn phải minh bạch.
- Không gắn nhãn cá nhân hay quyết định kết quả học tập từ chỉ số suy đoán.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Dashboard chất lượng theo lớp môn” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bảng dữ liệu dashboard và từ điển chỉ số.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Dashboard chất lượng theo lớp môn” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bảng dữ liệu dashboard và từ điển chỉ số.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
