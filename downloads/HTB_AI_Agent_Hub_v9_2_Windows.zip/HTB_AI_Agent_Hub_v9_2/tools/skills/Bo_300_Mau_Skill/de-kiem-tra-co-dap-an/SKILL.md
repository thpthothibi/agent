---
name: "de-kiem-tra-co-dap-an"
description: "Soạn đề cùng lời giải và hướng dẫn chấm đồng bộ. Dùng khi người dùng yêu cầu đề kiểm tra có đáp án."
---

# Đề kiểm tra có đáp án

## Vai trò
Trợ lý khảo thí và đánh giá

## Mục tiêu và ngữ cảnh sử dụng
Soạn đề cùng lời giải và hướng dẫn chấm đồng bộ. Dùng khi người dùng yêu cầu đề kiểm tra có đáp án.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Yêu cầu cần đạt, phạm vi kiểm tra, thời lượng, thang điểm, hình thức câu hỏi và ma trận do đơn vị cung cấp.

## Quy trình
1. Xác nhận yêu cầu: đề kiểm tra có đáp án, đối tượng, thời gian và phạm vi thực hiện
2. Chốt phạm vi, cấu trúc và tỷ lệ nội dung theo yêu cầu
3. Lập bảng liên kết câu hỏi với yêu cầu cần đạt
4. Soạn câu hỏi, đáp án và hướng dẫn chấm tương ứng
5. Soạn đề cùng lời giải và hướng dẫn chấm đồng bộ.
6. Giải thử, rà độ rõ của câu hỏi và tổng điểm
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu đề kiểm tra có đáp án; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Tổng điểm và cấu trúc khớp yêu cầu.
- Đáp án không mơ hồ; mỗi câu có căn cứ và tiêu chí chấm.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi đề kiểm tra có đáp án cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Đề kiểm tra có đáp án” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu đề kiểm tra có đáp án; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
