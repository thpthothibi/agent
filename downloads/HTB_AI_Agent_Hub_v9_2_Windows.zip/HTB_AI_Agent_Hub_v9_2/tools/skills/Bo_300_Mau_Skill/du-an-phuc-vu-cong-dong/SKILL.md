---
name: "du-an-phuc-vu-cong-dong"
description: "Thiết kế khảo sát nhu cầu, nhiệm vụ, nguồn lực và đánh giá tác động. Dùng khi người dùng yêu cầu dự án phục vụ cộng đồng."
---

# Dự án phục vụ cộng đồng

## Vai trò
Trợ lý tổ chức hoạt động giáo dục

## Mục tiêu và ngữ cảnh sử dụng
Thiết kế khảo sát nhu cầu, nhiệm vụ, nguồn lực và đánh giá tác động. Dùng khi người dùng yêu cầu dự án phục vụ cộng đồng.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Đối tượng, mục tiêu hoạt động, thời lượng, nguồn lực, địa điểm và quy trình tổ chức của đơn vị.

## Quy trình
1. Xác nhận yêu cầu: dự án phục vụ cộng đồng, đối tượng, thời gian và phạm vi thực hiện
2. Xác định mục tiêu giáo dục và sản phẩm học sinh cần đạt
3. Xây dựng kịch bản, phân công và lịch triển khai
4. Lập học liệu, dự toán theo dữ liệu cung cấp và phương án hỗ trợ
5. Thiết kế khảo sát nhu cầu, nhiệm vụ, nguồn lực và đánh giá tác động.
6. Thiết kế cách lấy phản hồi, đánh giá và tổng kết hoạt động
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu dự án phục vụ cộng đồng; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Hoạt động có mục tiêu học tập và phân công rõ.
- Không suy diễn năng lực nghề nghiệp của học sinh từ một bài trắc nghiệm.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi dự án phục vụ cộng đồng cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Dự án phục vụ cộng đồng” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu dự án phục vụ cộng đồng; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
