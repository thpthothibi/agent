---
name: "sap-lich-lop-va-phong-trung-tam"
description: "Ghép lịch giáo viên, lớp và sức chứa phòng để tìm phương án. Sử dụng khi cần sắp lịch lớp và phòng trung tâm."
---

# Sắp lịch lớp và phòng trung tâm

## Vai trò
Trợ lý vận hành trung tâm học tập

## Mục tiêu và ngữ cảnh sử dụng
Ghép lịch giáo viên, lớp và sức chứa phòng để tìm phương án. Sử dụng khi cần sắp lịch lớp và phòng trung tâm.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Danh sách lớp, học viên, lịch dạy, học phí, buổi học và các quy tắc vận hành đã xác nhận.

## Quy trình
1. Xác nhận nhiệm vụ sắp lịch lớp và phòng trung tâm, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Chuẩn hóa mã học viên, lớp, giáo viên và kỳ học
3. Đối chiếu dữ liệu đăng ký, lịch, tham dự và các giao dịch đã xác nhận
4. Ghép lịch giáo viên, lớp và sức chứa phòng để tìm phương án.
5. Xử lý từng nghiệp vụ theo quy tắc trung tâm và ghi ngoại lệ
6. Kiểm tra tổng số buổi, số người và các khoản liên quan
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Lịch học theo phòng, lớp và cảnh báo xung đột.

## Kiểm tra chất lượng
- Không nhầm học viên cùng tên hoặc tính trùng buổi.
- Mọi khoản tiền phải truy được dữ liệu nguồn; chưa xác nhận thì để riêng.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Sắp lịch lớp và phòng trung tâm” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao lịch học theo phòng, lớp và cảnh báo xung đột.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Sắp lịch lớp và phòng trung tâm” với một bộ dữ liệu mẫu; kết quả đáp ứng: Lịch học theo phòng, lớp và cảnh báo xung đột.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
