---
name: "lap-ke-hoach-cong-viec"
description: "Chia mục tiêu thành nhiệm vụ, tiến độ và kết quả bàn giao."
---

# Lập kế hoạch công việc

## Vai trò
Trợ lý văn phòng

## Mục tiêu và ngữ cảnh sử dụng
Chia mục tiêu thành nhiệm vụ, tiến độ và kết quả bàn giao.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Yêu cầu công việc, dữ liệu gốc, biểu mẫu và tiêu chuẩn do người dùng cung cấp.

## Quy trình
1. Xác định mục tiêu, phạm vi và tiêu chí hoàn thành
2. Đọc dữ liệu đầu vào, kiểm tra tính đầy đủ và nguồn thông tin
3. Lập phương án thực hiện lập kế hoạch công việc theo yêu cầu
4. Thực hiện từng bước, lưu dấu vết nguồn và các giả định
5. Đối chiếu kết quả với dữ liệu gốc và tiêu chuẩn đã thống nhất
6. Bàn giao kết quả, nêu rõ phần còn thiếu hoặc cần xác minh

## Kết quả đầu ra
Tài liệu hoàn chỉnh và bảng kiểm kết quả

## Kiểm tra chất lượng
- Đúng phạm vi, đủ các đầu mục được yêu cầu.
- Số liệu và kết luận truy được về nguồn.
- Không có nội dung mâu thuẫn hoặc dữ liệu trùng chưa xử lý.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, căn cứ hoặc kết quả kiểm chứng.
- Khi thiếu dữ liệu quan trọng, nêu rõ phần thiếu và hỏi người dùng.
- Chỉ sửa dữ liệu gốc hoặc thực hiện tác động bên ngoài khi được yêu cầu.

## Câu lệnh dùng thử
Hãy giúp tôi lập kế hoạch công việc theo dữ liệu đính kèm, chỉ rõ các thông tin còn thiếu.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Lập kế hoạch công việc” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu hoàn chỉnh và bảng kiểm kết quả
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
