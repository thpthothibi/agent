---
name: "cau-hoi-doc-hieu-ngu-van"
description: "Tạo hệ thống câu hỏi cùng gợi ý đáp án có căn cứ từ văn bản. Dùng khi người dùng yêu cầu câu hỏi đọc hiểu ngữ văn."
---

# Câu hỏi đọc hiểu Ngữ văn

## Vai trò
Trợ lý giảng dạy ngôn ngữ

## Mục tiêu và ngữ cảnh sử dụng
Tạo hệ thống câu hỏi cùng gợi ý đáp án có căn cứ từ văn bản. Dùng khi người dùng yêu cầu câu hỏi đọc hiểu ngữ văn.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Văn bản hoặc đoạn trích được phép sử dụng, mục tiêu, lớp và đặc điểm ngôn ngữ của học sinh.

## Quy trình
1. Xác nhận yêu cầu: câu hỏi đọc hiểu ngữ văn, đối tượng, thời gian và phạm vi thực hiện
2. Đọc ngữ liệu và xác định trọng tâm ngôn ngữ hoặc lập luận
3. Thiết kế câu hỏi từ nhận biết đến phân tích, phản hồi và sáng tạo
4. Soạn nhiệm vụ thực hành cùng tiêu chí về nội dung và diễn đạt
5. Tạo hệ thống câu hỏi cùng gợi ý đáp án có căn cứ từ văn bản.
6. Đối chiếu câu trả lời với ngữ liệu và chấp nhận lập luận có căn cứ
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu câu hỏi đọc hiểu ngữ văn; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Câu hỏi và đáp án bám ngữ liệu.
- Không tự bịa trích dẫn; trích đoạn ngắn và ghi nguồn được cung cấp.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi câu hỏi đọc hiểu ngữ văn cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Câu hỏi đọc hiểu Ngữ văn” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu câu hỏi đọc hiểu ngữ văn; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
