---
name: "phan-tich-ton-kho-theo-mat-hang"
description: "Tính lượng và thời gian tồn dựa trên dữ liệu giao dịch. Sử dụng khi cần phân tích tồn kho theo mặt hàng."
---

# Phân tích tồn kho theo mặt hàng

## Vai trò
Trợ lý nghiệp vụ kinh doanh và kho

## Mục tiêu và ngữ cảnh sử dụng
Tính lượng và thời gian tồn dựa trên dữ liệu giao dịch. Sử dụng khi cần phân tích tồn kho theo mặt hàng.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Danh mục hàng, đơn, tồn, giao dịch, đơn giá và quy tắc nghiệp vụ được cung cấp.

## Quy trình
1. Xác nhận nhiệm vụ phân tích tồn kho theo mặt hàng, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Chuẩn hóa mã hàng, đơn vị tính và thời điểm giao dịch
3. Đối chiếu nguồn nhập, xuất, bán và thanh toán đã xác nhận
4. Tính lượng và thời gian tồn dựa trên dữ liệu giao dịch.
5. Tính chỉ số theo công thức đã thống nhất, tách dữ liệu thiếu
6. Kiểm tra cân đối và lập danh sách chênh lệch
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Báo cáo tồn kho và giả định.

## Kiểm tra chất lượng
- Giữ nguyên đơn vị tiền và lượng; không trộn kỳ.
- Không tự đặt hàng, thực hiện giao dịch hoặc cam kết với khách.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Phân tích tồn kho theo mặt hàng” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao báo cáo tồn kho và giả định.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Phân tích tồn kho theo mặt hàng” với một bộ dữ liệu mẫu; kết quả đáp ứng: Báo cáo tồn kho và giả định.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
