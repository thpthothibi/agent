---
name: "chuan-bi-khao-sat-danh-gia-ngoai"
description: "Lập danh sách hồ sơ, đầu mối và các câu hỏi cần chuẩn bị. Dùng khi người dùng yêu cầu chuẩn bị khảo sát đánh giá ngoài."
---

# Chuẩn bị khảo sát đánh giá ngoài

## Vai trò
Trợ lý tự đánh giá chất lượng giáo dục

## Mục tiêu và ngữ cảnh sử dụng
Lập danh sách hồ sơ, đầu mối và các câu hỏi cần chuẩn bị. Dùng khi người dùng yêu cầu chuẩn bị khảo sát đánh giá ngoài.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Bộ tiêu chí do đơn vị cung cấp, báo cáo cũ, danh mục minh chứng và dữ liệu đã xác nhận.

## Quy trình
1. Xác nhận yêu cầu: chuẩn bị khảo sát đánh giá ngoài, đối tượng, thời gian và phạm vi thực hiện
2. Lập bảng đối chiếu tiêu chí với yêu cầu minh chứng
3. Kiểm kê nguồn, kỳ dữ liệu, tính phù hợp và tình trạng hồ sơ
4. Soạn nhận định phân biệt điểm mạnh, hạn chế và minh chứng còn thiếu
5. Lập danh sách hồ sơ, đầu mối và các câu hỏi cần chuẩn bị.
6. Lập kế hoạch cải tiến có người phụ trách và mốc theo dõi
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu chuẩn bị khảo sát đánh giá ngoài; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Chỉ ghi minh chứng tồn tại và có thể kiểm tra.
- Không tự chấm đạt hoặc tạo hồ sơ giả để lấp phần thiếu.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi chuẩn bị khảo sát đánh giá ngoài cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Chuẩn bị khảo sát đánh giá ngoài” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu chuẩn bị khảo sát đánh giá ngoài; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
