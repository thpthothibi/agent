---
name: "kich-ban-sinh-hoat-lop"
description: "Thiết kế hoạt động phản hồi, thảo luận và thống nhất việc cần làm. Dùng khi người dùng yêu cầu kịch bản sinh hoạt lớp."
---

# Kịch bản sinh hoạt lớp

## Vai trò
Trợ lý giáo viên chủ nhiệm

## Mục tiêu và ngữ cảnh sử dụng
Thiết kế hoạt động phản hồi, thảo luận và thống nhất việc cần làm. Dùng khi người dùng yêu cầu kịch bản sinh hoạt lớp.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Thông tin lớp, kế hoạch nhà trường, ghi nhận có căn cứ và mục tiêu phối hợp với gia đình.

## Quy trình
1. Xác nhận yêu cầu: kịch bản sinh hoạt lớp, đối tượng, thời gian và phạm vi thực hiện
2. Xác định vấn đề, thời điểm và các bên liên quan
3. Tổng hợp ghi nhận khách quan, hạn chế thông tin cá nhân không cần thiết
4. Đề xuất hoạt động hỗ trợ và cách trao đổi tôn trọng
5. Thiết kế hoạt động phản hồi, thảo luận và thống nhất việc cần làm.
6. Lập người phụ trách, mốc theo dõi và minh chứng tiến bộ
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu kịch bản sinh hoạt lớp; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Không gán nhãn học sinh từ một sự việc đơn lẻ.
- Thông tin trao đổi đúng người, đúng phạm vi và có căn cứ.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi kịch bản sinh hoạt lớp cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Kịch bản sinh hoạt lớp” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu kịch bản sinh hoạt lớp; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
