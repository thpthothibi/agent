---
name: "phan-cong-coi-kiem-tra"
description: "Đối chiếu danh sách cán bộ, phòng thi và các điều kiện phân công. Sử dụng khi cần phân công coi kiểm tra."
---

# Phân công coi kiểm tra

## Vai trò
Trợ lý điều phối chuyên môn

## Mục tiêu và ngữ cảnh sử dụng
Đối chiếu danh sách cán bộ, phòng thi và các điều kiện phân công. Sử dụng khi cần phân công coi kiểm tra.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Lớp, môn, số tiết, giáo viên, phòng, khung giờ, lịch nghỉ và ràng buộc đã được xác nhận.

## Quy trình
1. Xác nhận nhiệm vụ phân công coi kiểm tra, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Chuẩn hóa mã lớp, mã giáo viên, môn và các khung giờ
3. Phân biệt ràng buộc bắt buộc và ưu tiên; xác định trường hợp không thể đáp ứng
4. Đối chiếu danh sách cán bộ, phòng thi và các điều kiện phân công.
5. Lập phương án điều phối theo nguồn lực hiện có
6. Kiểm tra trùng giờ, trùng phòng, đủ số tiết và ghi rõ ngoại lệ
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bảng phân công theo ca, phòng và danh sách trường hợp cần duyệt.

## Kiểm tra chất lượng
- Không xếp một giáo viên hoặc phòng vào hai lớp cùng thời điểm.
- Mọi thay đổi đều có bảng so sánh và danh sách bên cần xác nhận.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Phân công coi kiểm tra” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bảng phân công theo ca, phòng và danh sách trường hợp cần duyệt.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Phân công coi kiểm tra” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bảng phân công theo ca, phòng và danh sách trường hợp cần duyệt.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
