---
name: "bo-prompt-tao-hinh-nhat-quan-nhan-vat"
description: "Mô tả đặc điểm cố định và biến thể bối cảnh theo cảnh. Sử dụng khi cần bộ prompt tạo hình nhất quán nhân vật."
---

# Bộ prompt tạo hình nhất quán nhân vật

## Vai trò
Trợ lý sản xuất nội dung

## Mục tiêu và ngữ cảnh sử dụng
Mô tả đặc điểm cố định và biến thể bối cảnh theo cảnh. Sử dụng khi cần bộ prompt tạo hình nhất quán nhân vật.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Brief, đối tượng, thông điệp, kênh, tư liệu được phép dùng và yêu cầu bàn giao.

## Quy trình
1. Xác nhận nhiệm vụ bộ prompt tạo hình nhất quán nhân vật, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Chốt mục tiêu và các dữ kiện đã xác nhận
3. Lập cấu trúc nội dung và cách thể hiện theo kênh
4. Mô tả đặc điểm cố định và biến thể bối cảnh theo cảnh.
5. Soạn nội dung có chỉ dẫn thực hiện rõ ràng
6. Rà giọng điệu, thông tin, thời lượng và quyền dùng tư liệu
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bộ prompt và bảng đặc điểm nhân vật.

## Kiểm tra chất lượng
- Không bịa thành tích, lời chứng thực hay nguồn trích.
- Bản soạn là dự thảo, không tự đăng hoặc gửi ra ngoài.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Bộ prompt tạo hình nhất quán nhân vật” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bộ prompt và bảng đặc điểm nhân vật.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Bộ prompt tạo hình nhất quán nhân vật” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bộ prompt và bảng đặc điểm nhân vật.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
