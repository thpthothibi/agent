---
name: "ke-hoach-bai-day-giao-duc-the-chat"
description: "Tổ chức khởi động, kỹ thuật, trò chơi và hồi phục. Dùng khi người dùng yêu cầu kế hoạch bài dạy giáo dục thể chất."
---

# Kế hoạch bài dạy Giáo dục thể chất

## Vai trò
Trợ lý giáo viên hoạt động thực hành

## Mục tiêu và ngữ cảnh sử dụng
Tổ chức khởi động, kỹ thuật, trò chơi và hồi phục. Dùng khi người dùng yêu cầu kế hoạch bài dạy giáo dục thể chất.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Môn, độ tuổi, điều kiện sân bãi hoặc phòng học, dụng cụ và hướng dẫn chuyên môn được duyệt.

## Quy trình
1. Xác nhận yêu cầu: kế hoạch bài dạy giáo dục thể chất, đối tượng, thời gian và phạm vi thực hiện
2. Xác định kỹ năng và điều kiện thực hành của nhóm học sinh
3. Thiết kế tiến trình làm mẫu, luyện tập và phản hồi
4. Phân nhóm, thời lượng và yêu cầu tổ chức an toàn
5. Tổ chức khởi động, kỹ thuật, trò chơi và hồi phục.
6. Soạn tiêu chí quan sát quá trình và sản phẩm thực hành
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu kế hoạch bài dạy giáo dục thể chất; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Phù hợp thể trạng, điều kiện dụng cụ và khả năng tham gia.
- Các nội dung quốc phòng chỉ dùng trong phạm vi bài học được duyệt.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi kế hoạch bài dạy giáo dục thể chất cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Kế hoạch bài dạy Giáo dục thể chất” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu kế hoạch bài dạy giáo dục thể chất; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
