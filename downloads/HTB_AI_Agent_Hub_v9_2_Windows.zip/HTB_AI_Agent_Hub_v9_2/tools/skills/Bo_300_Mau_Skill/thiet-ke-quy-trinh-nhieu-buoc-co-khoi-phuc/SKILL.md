---
name: "thiet-ke-quy-trinh-nhieu-buoc-co-khoi-phuc"
description: "Chia nhiệm vụ thành checkpoint để chạy tiếp sau lỗi. Sử dụng khi cần thiết kế quy trình nhiều bước có khôi phục."
---

# Thiết kế quy trình nhiều bước có khôi phục

## Vai trò
Trợ lý thiết kế tự động hóa

## Mục tiêu và ngữ cảnh sử dụng
Chia nhiệm vụ thành checkpoint để chạy tiếp sau lỗi. Sử dụng khi cần thiết kế quy trình nhiều bước có khôi phục.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Quy trình thực tế, công cụ được phép dùng, ví dụ đầu vào, trạng thái, lỗi thường gặp và phạm vi được giao.

## Quy trình
1. Xác nhận nhiệm vụ thiết kế quy trình nhiều bước có khôi phục, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Vẽ trạng thái công việc, điều kiện bắt đầu và kết thúc
3. Xác định điểm đọc dữ liệu, kiểm tra và hành động bên ngoài
4. Chia nhiệm vụ thành checkpoint để chạy tiếp sau lỗi.
5. Thiết kế cơ chế thử lại, chống trùng và tiếp tục sau lỗi
6. Lập ca kiểm thử cho thành công, thiếu dữ liệu và gián đoạn
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Sơ đồ trạng thái và quy tắc khôi phục.

## Kiểm tra chất lượng
- Không giả định có quyền hoặc công cụ chưa được cấp.
- Hành động ghi dữ liệu có bước đối chiếu, log và phạm vi rõ ràng.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Thiết kế quy trình nhiều bước có khôi phục” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao sơ đồ trạng thái và quy tắc khôi phục.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Thiết kế quy trình nhiều bước có khôi phục” với một bộ dữ liệu mẫu; kết quả đáp ứng: Sơ đồ trạng thái và quy tắc khôi phục.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
