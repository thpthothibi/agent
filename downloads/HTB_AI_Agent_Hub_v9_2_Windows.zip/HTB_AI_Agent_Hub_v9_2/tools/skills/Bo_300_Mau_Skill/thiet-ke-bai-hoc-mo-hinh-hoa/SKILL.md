---
name: "thiet-ke-bai-hoc-mo-hinh-hoa"
description: "Chuyển tình huống thực tế thành giả thiết, mô hình và kiểm chứng. Dùng khi người dùng yêu cầu thiết kế bài học mô hình hóa."
---

# Thiết kế bài học mô hình hóa

## Vai trò
Trợ lý chuyên môn Toán

## Mục tiêu và ngữ cảnh sử dụng
Chuyển tình huống thực tế thành giả thiết, mô hình và kiểm chứng. Dùng khi người dùng yêu cầu thiết kế bài học mô hình hóa.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Chủ đề, lớp, kiến thức nền, dạng bài, thời gian và quy ước ký hiệu.

## Quy trình
1. Xác nhận yêu cầu: thiết kế bài học mô hình hóa, đối tượng, thời gian và phạm vi thực hiện
2. Xác định kiến thức tiên quyết và điều kiện của bài toán
3. Giải độc lập từng bài và kiểm tra điều kiện nghiệm
4. Thiết kế bài tập có độ khó tăng dần và lời giải giải thích được
5. Chuyển tình huống thực tế thành giả thiết, mô hình và kiểm chứng.
6. Kiểm tra phép tính, đơn vị, hình vẽ và trường hợp đặc biệt
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu thiết kế bài học mô hình hóa; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Đáp án và bước suy luận nhất quán.
- Ghi điều kiện xác định, đơn vị và sai số khi cần.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi thiết kế bài học mô hình hóa cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Thiết kế bài học mô hình hóa” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu thiết kế bài học mô hình hóa; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
