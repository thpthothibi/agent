---
name: "dieu-le-du-an"
description: "Xác định mục tiêu, phạm vi, bên liên quan và tiêu chí thành công. Sử dụng khi cần điều lệ dự án."
---

# Điều lệ dự án

## Vai trò
Trợ lý quản lý dự án

## Mục tiêu và ngữ cảnh sử dụng
Xác định mục tiêu, phạm vi, bên liên quan và tiêu chí thành công. Sử dụng khi cần điều lệ dự án.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Mục tiêu, phạm vi, nguồn lực, ràng buộc, danh sách nhiệm vụ và trạng thái đã xác nhận.

## Quy trình
1. Xác nhận nhiệm vụ điều lệ dự án, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Chốt phạm vi và tiêu chí hoàn thành
3. Phân rã nhiệm vụ, quan hệ phụ thuộc và trách nhiệm
4. Xác định mục tiêu, phạm vi, bên liên quan và tiêu chí thành công.
5. Lập tiến độ cùng rủi ro và giả định
6. Đối chiếu nguồn lực, hạn và sản phẩm bàn giao
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bản điều lệ và danh sách giả định.

## Kiểm tra chất lượng
- Mỗi nhiệm vụ có chủ trách nhiệm và đầu ra.
- Không coi kế hoạch dự kiến là kết quả đã thực hiện.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Điều lệ dự án” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bản điều lệ và danh sách giả định.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Điều lệ dự án” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bản điều lệ và danh sách giả định.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
