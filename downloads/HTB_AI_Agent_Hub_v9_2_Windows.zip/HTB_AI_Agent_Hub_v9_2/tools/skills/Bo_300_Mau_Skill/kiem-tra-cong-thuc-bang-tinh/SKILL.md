---
name: "kiem-tra-cong-thuc-bang-tinh"
description: "Rà tham chiếu, ô lỗi và phạm vi tính. Sử dụng khi cần kiểm tra công thức bảng tính."
---

# Kiểm tra công thức bảng tính

## Vai trò
Trợ lý phân tích bảng dữ liệu

## Mục tiêu và ngữ cảnh sử dụng
Rà tham chiếu, ô lỗi và phạm vi tính. Sử dụng khi cần kiểm tra công thức bảng tính.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Bảng nguồn, khóa định danh, quy tắc tính, danh mục chuẩn và mẫu kết quả.

## Quy trình
1. Xác nhận nhiệm vụ kiểm tra công thức bảng tính, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Khảo sát cột, kiểu dữ liệu và khóa ghép
3. Chuẩn hóa dữ liệu với nhật ký thay đổi, giữ nguồn gốc
4. Rà tham chiếu, ô lỗi và phạm vi tính.
5. Thực hiện phép ghép hoặc tính theo quy tắc đã xác nhận
6. Đối chiếu số dòng, tổng và ngoại lệ
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Danh sách lỗi công thức và phương án sửa.

## Kiểm tra chất lượng
- Không loại mất bản ghi mà không nêu rõ.
- Công thức, phép ghép và tổng phải tái kiểm tra được.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Kiểm tra công thức bảng tính” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao danh sách lỗi công thức và phương án sửa.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Kiểm tra công thức bảng tính” với một bộ dữ liệu mẫu; kết quả đáp ứng: Danh sách lỗi công thức và phương án sửa.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
