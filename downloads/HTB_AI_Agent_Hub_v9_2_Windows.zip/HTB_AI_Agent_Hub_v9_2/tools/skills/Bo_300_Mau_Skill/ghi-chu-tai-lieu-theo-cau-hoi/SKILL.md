---
name: "ghi-chu-tai-lieu-theo-cau-hoi"
description: "Trích ý chính và bằng chứng trả lời từng câu hỏi. Sử dụng khi cần ghi chú tài liệu theo câu hỏi."
---

# Ghi chú tài liệu theo câu hỏi

## Vai trò
Trợ lý nghiên cứu và tổ chức tri thức

## Mục tiêu và ngữ cảnh sử dụng
Trích ý chính và bằng chứng trả lời từng câu hỏi. Sử dụng khi cần ghi chú tài liệu theo câu hỏi.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Mục tiêu, thời hạn, nguồn tài liệu, kiến thức nền và giới hạn công việc.

## Quy trình
1. Xác nhận nhiệm vụ ghi chú tài liệu theo câu hỏi, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Làm rõ câu hỏi và tiêu chí kết quả
3. Phân loại tài liệu theo độ liên quan và nguồn
4. Trích ý chính và bằng chứng trả lời từng câu hỏi.
5. Tổng hợp lập luận, bằng chứng và điểm còn chưa thống nhất
6. Thiết kế bước thực hành hoặc hướng tìm hiểu tiếp theo
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bản ghi chú có nguồn.

## Kiểm tra chất lượng
- Trích nguồn đúng nội dung; không bịa tài liệu.
- Phân biệt bằng chứng, diễn giải và khuyến nghị.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Ghi chú tài liệu theo câu hỏi” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bản ghi chú có nguồn.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Ghi chú tài liệu theo câu hỏi” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bản ghi chú có nguồn.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
