---
name: "tinh-dien-nuoc-theo-chi-so"
description: "Đối chiếu chỉ số đầu cuối, đơn giá và kỳ sử dụng. Sử dụng khi cần tính điện nước theo chỉ số."
---

# Tính điện nước theo chỉ số

## Vai trò
Trợ lý vận hành cơ sở dịch vụ

## Mục tiêu và ngữ cảnh sử dụng
Đối chiếu chỉ số đầu cuối, đơn giá và kỳ sử dụng. Sử dụng khi cần tính điện nước theo chỉ số.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Danh mục phòng hoặc tài sản, hợp đồng được cung cấp, giá dịch vụ đã duyệt, chỉ số và trạng thái thực tế.

## Quy trình
1. Xác nhận nhiệm vụ tính điện nước theo chỉ số, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Chuẩn hóa mã cơ sở, phòng, khách và kỳ dịch vụ
3. Đối chiếu hồ sơ, chỉ số và dữ liệu giao dịch đã xác nhận
4. Đối chiếu chỉ số đầu cuối, đơn giá và kỳ sử dụng.
5. Tính hoặc sắp xếp theo quy tắc hiện hành do người dùng giao
6. Lập báo cáo ngoại lệ và việc cần người phụ trách xác nhận
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bảng tính chi tiết và chỉ số bất thường.

## Kiểm tra chất lượng
- Không đưa số giấy tờ cá nhân thật vào mẫu công khai.
- Không tự ký hợp đồng, thu tiền, xét điều kiện hoặc đổi trạng thái thực tế.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Tính điện nước theo chỉ số” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bảng tính chi tiết và chỉ số bất thường.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Tính điện nước theo chỉ số” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bảng tính chi tiết và chỉ số bất thường.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
