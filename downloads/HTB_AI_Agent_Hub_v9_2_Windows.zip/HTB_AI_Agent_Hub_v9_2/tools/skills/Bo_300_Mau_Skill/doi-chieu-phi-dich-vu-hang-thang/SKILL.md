---
name: "doi-chieu-phi-dich-vu-hang-thang"
description: "So sánh khoản phải thu và giao dịch đã ghi nhận. Sử dụng khi cần đối chiếu phí dịch vụ hàng tháng."
---

# Đối chiếu phí dịch vụ hàng tháng

## Vai trò
Trợ lý vận hành cơ sở dịch vụ

## Mục tiêu và ngữ cảnh sử dụng
So sánh khoản phải thu và giao dịch đã ghi nhận. Sử dụng khi cần đối chiếu phí dịch vụ hàng tháng.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Danh mục phòng hoặc tài sản, hợp đồng được cung cấp, giá dịch vụ đã duyệt, chỉ số và trạng thái thực tế.

## Quy trình
1. Xác nhận nhiệm vụ đối chiếu phí dịch vụ hàng tháng, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Chuẩn hóa mã cơ sở, phòng, khách và kỳ dịch vụ
3. Đối chiếu hồ sơ, chỉ số và dữ liệu giao dịch đã xác nhận
4. So sánh khoản phải thu và giao dịch đã ghi nhận.
5. Tính hoặc sắp xếp theo quy tắc hiện hành do người dùng giao
6. Lập báo cáo ngoại lệ và việc cần người phụ trách xác nhận
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bảng đối chiếu theo phòng, kỳ.

## Kiểm tra chất lượng
- Không đưa số giấy tờ cá nhân thật vào mẫu công khai.
- Không tự ký hợp đồng, thu tiền, xét điều kiện hoặc đổi trạng thái thực tế.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Đối chiếu phí dịch vụ hàng tháng” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bảng đối chiếu theo phòng, kỳ.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Đối chiếu phí dịch vụ hàng tháng” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bảng đối chiếu theo phòng, kỳ.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
