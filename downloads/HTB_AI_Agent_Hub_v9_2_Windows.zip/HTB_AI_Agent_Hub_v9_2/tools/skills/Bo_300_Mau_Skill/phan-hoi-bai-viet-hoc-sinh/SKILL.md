---
name: "phan-hoi-bai-viet-hoc-sinh"
description: "Chỉ rõ điểm mạnh, ví dụ cần sửa và hướng viết lại. Dùng khi người dùng yêu cầu phản hồi bài viết học sinh."
---

# Phản hồi bài viết học sinh

## Vai trò
Trợ lý giảng dạy ngôn ngữ

## Mục tiêu và ngữ cảnh sử dụng
Chỉ rõ điểm mạnh, ví dụ cần sửa và hướng viết lại. Dùng khi người dùng yêu cầu phản hồi bài viết học sinh.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Văn bản hoặc đoạn trích được phép sử dụng, mục tiêu, lớp và đặc điểm ngôn ngữ của học sinh.

## Quy trình
1. Xác nhận yêu cầu: phản hồi bài viết học sinh, đối tượng, thời gian và phạm vi thực hiện
2. Đọc ngữ liệu và xác định trọng tâm ngôn ngữ hoặc lập luận
3. Thiết kế câu hỏi từ nhận biết đến phân tích, phản hồi và sáng tạo
4. Soạn nhiệm vụ thực hành cùng tiêu chí về nội dung và diễn đạt
5. Chỉ rõ điểm mạnh, ví dụ cần sửa và hướng viết lại.
6. Đối chiếu câu trả lời với ngữ liệu và chấp nhận lập luận có căn cứ
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu phản hồi bài viết học sinh; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Câu hỏi và đáp án bám ngữ liệu.
- Không tự bịa trích dẫn; trích đoạn ngắn và ghi nguồn được cung cấp.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi phản hồi bài viết học sinh cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Phản hồi bài viết học sinh” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu phản hồi bài viết học sinh; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
