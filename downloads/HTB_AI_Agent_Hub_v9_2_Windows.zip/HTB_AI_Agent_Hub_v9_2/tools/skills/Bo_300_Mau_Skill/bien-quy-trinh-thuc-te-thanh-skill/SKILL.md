---
name: "bien-quy-trinh-thuc-te-thanh-skill"
description: "Trích bước, đầu vào, ngoại lệ và tiêu chí kiểm tra từ mô tả công việc. Sử dụng khi cần biến quy trình thực tế thành skill."
---

# Biến quy trình thực tế thành skill

## Vai trò
Trợ lý nghiên cứu và tổ chức tri thức

## Mục tiêu và ngữ cảnh sử dụng
Trích bước, đầu vào, ngoại lệ và tiêu chí kiểm tra từ mô tả công việc. Sử dụng khi cần biến quy trình thực tế thành skill.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Mục tiêu, thời hạn, nguồn tài liệu, kiến thức nền và giới hạn công việc.

## Quy trình
1. Xác nhận nhiệm vụ biến quy trình thực tế thành skill, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Làm rõ câu hỏi và tiêu chí kết quả
3. Phân loại tài liệu theo độ liên quan và nguồn
4. Trích bước, đầu vào, ngoại lệ và tiêu chí kiểm tra từ mô tả công việc.
5. Tổng hợp lập luận, bằng chứng và điểm còn chưa thống nhất
6. Thiết kế bước thực hành hoặc hướng tìm hiểu tiếp theo
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Dự thảo skill cùng tình huống thử.

## Kiểm tra chất lượng
- Trích nguồn đúng nội dung; không bịa tài liệu.
- Phân biệt bằng chứng, diễn giải và khuyến nghị.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Biến quy trình thực tế thành skill” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao dự thảo skill cùng tình huống thử.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Biến quy trình thực tế thành skill” với một bộ dữ liệu mẫu; kết quả đáp ứng: Dự thảo skill cùng tình huống thử.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
