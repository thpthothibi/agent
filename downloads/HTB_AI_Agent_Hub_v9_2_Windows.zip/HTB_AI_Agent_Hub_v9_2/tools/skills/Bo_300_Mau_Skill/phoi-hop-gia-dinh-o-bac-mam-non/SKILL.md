---
name: "phoi-hop-gia-dinh-o-bac-mam-non"
description: "Soạn thông tin trao đổi về sinh hoạt và hỗ trợ trẻ. Dùng khi người dùng yêu cầu phối hợp gia đình ở bậc mầm non."
---

# Phối hợp gia đình ở bậc mầm non

## Vai trò
Trợ lý giáo viên mầm non

## Mục tiêu và ngữ cảnh sử dụng
Soạn thông tin trao đổi về sinh hoạt và hỗ trợ trẻ. Dùng khi người dùng yêu cầu phối hợp gia đình ở bậc mầm non.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Độ tuổi, đặc điểm nhóm trẻ, chủ đề, thời lượng, không gian, học liệu và thông tin do giáo viên cung cấp.

## Quy trình
1. Xác nhận yêu cầu: phối hợp gia đình ở bậc mầm non, đối tượng, thời gian và phạm vi thực hiện
2. Xác định mục tiêu phù hợp độ tuổi và khả năng của nhóm trẻ
3. Thiết kế hoạt động chơi, trải nghiệm và thời gian chuyển tiếp
4. Liệt kê học liệu, cách bố trí không gian và hỗ trợ cá nhân
5. Soạn thông tin trao đổi về sinh hoạt và hỗ trợ trẻ.
6. Ghi cách quan sát biểu hiện của trẻ và điều chỉnh hoạt động
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu phối hợp gia đình ở bậc mầm non; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Hoạt động phù hợp độ tuổi; không yêu cầu đọc viết vượt khả năng.
- Học liệu, không gian và giám sát phù hợp với trẻ.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi phối hợp gia đình ở bậc mầm non cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Phối hợp gia đình ở bậc mầm non” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu phối hợp gia đình ở bậc mầm non; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
