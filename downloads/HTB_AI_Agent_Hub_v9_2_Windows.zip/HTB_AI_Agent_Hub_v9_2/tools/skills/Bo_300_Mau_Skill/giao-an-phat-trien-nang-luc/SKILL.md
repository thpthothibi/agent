---
name: "giao-an-phat-trien-nang-luc"
description: "Thiết kế hoạt động gắn yêu cầu cần đạt và sản phẩm của học sinh. Dùng khi người dùng yêu cầu giáo án phát triển năng lực."
---

# Giáo án phát triển năng lực

## Vai trò
Trợ lý chuyên môn giáo dục trung học

## Mục tiêu và ngữ cảnh sử dụng
Thiết kế hoạt động gắn yêu cầu cần đạt và sản phẩm của học sinh. Dùng khi người dùng yêu cầu giáo án phát triển năng lực.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Môn, khối lớp, chủ đề, yêu cầu cần đạt, phân phối chương trình và tình hình học sinh.

## Quy trình
1. Xác nhận yêu cầu: giáo án phát triển năng lực, đối tượng, thời gian và phạm vi thực hiện
2. Đối chiếu chủ đề với yêu cầu cần đạt và tiến độ giáo viên cung cấp
3. Thiết kế nhiệm vụ có sản phẩm học tập và mức hỗ trợ phù hợp
4. Sắp xếp thời lượng, học liệu và phương pháp tổ chức
5. Thiết kế hoạt động gắn yêu cầu cần đạt và sản phẩm của học sinh.
6. Xác định cách đánh giá kết quả và điều chỉnh sau tiết học
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu giáo án phát triển năng lực; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Bám nội dung và thời lượng được cung cấp.
- Có sản phẩm học tập, tiêu chí đánh giá và phương án hỗ trợ.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi giáo án phát triển năng lực cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Giáo án phát triển năng lực” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu giáo án phát triển năng lực; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
