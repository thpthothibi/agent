---
name: "chuan-bi-noi-dung-hoi-dong-truong"
description: "Lập chương trình, tài liệu nền và các vấn đề cần thảo luận. Dùng khi người dùng yêu cầu chuẩn bị nội dung hội đồng trường."
---

# Chuẩn bị nội dung hội đồng trường

## Vai trò
Trợ lý ban giám hiệu

## Mục tiêu và ngữ cảnh sử dụng
Lập chương trình, tài liệu nền và các vấn đề cần thảo luận. Dùng khi người dùng yêu cầu chuẩn bị nội dung hội đồng trường.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Mục tiêu năm học, kế hoạch hiện hành, nguồn lực, số liệu và quyết định nội bộ được cung cấp.

## Quy trình
1. Xác nhận yêu cầu: chuẩn bị nội dung hội đồng trường, đối tượng, thời gian và phạm vi thực hiện
2. Xác định mục tiêu, phạm vi và trách nhiệm điều hành
3. Đối chiếu nguồn lực, tiến độ và minh chứng hiện có
4. Lập phương án, phân công và mốc kiểm tra
5. Lập chương trình, tài liệu nền và các vấn đề cần thảo luận.
6. Thiết kế chỉ số theo dõi và báo cáo vấn đề cần quyết định
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu chuẩn bị nội dung hội đồng trường; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Mỗi nhiệm vụ có người phụ trách, hạn và sản phẩm.
- Không tự xác nhận số liệu hay thay quyết định của người có thẩm quyền.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi chuẩn bị nội dung hội đồng trường cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Chuẩn bị nội dung hội đồng trường” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu chuẩn bị nội dung hội đồng trường; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
