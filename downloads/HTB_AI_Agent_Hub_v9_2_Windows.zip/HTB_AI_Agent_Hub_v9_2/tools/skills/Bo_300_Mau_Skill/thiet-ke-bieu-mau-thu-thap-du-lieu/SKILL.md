---
name: "thiet-ke-bieu-mau-thu-thap-du-lieu"
description: "Lập cột, kiểu, dữ liệu bắt buộc và kiểm tra hợp lệ. Sử dụng khi cần thiết kế biểu mẫu thu thập dữ liệu."
---

# Thiết kế biểu mẫu thu thập dữ liệu

## Vai trò
Trợ lý phân tích bảng dữ liệu

## Mục tiêu và ngữ cảnh sử dụng
Lập cột, kiểu, dữ liệu bắt buộc và kiểm tra hợp lệ. Sử dụng khi cần thiết kế biểu mẫu thu thập dữ liệu.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Bảng nguồn, khóa định danh, quy tắc tính, danh mục chuẩn và mẫu kết quả.

## Quy trình
1. Xác nhận nhiệm vụ thiết kế biểu mẫu thu thập dữ liệu, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Khảo sát cột, kiểu dữ liệu và khóa ghép
3. Chuẩn hóa dữ liệu với nhật ký thay đổi, giữ nguồn gốc
4. Lập cột, kiểu, dữ liệu bắt buộc và kiểm tra hợp lệ.
5. Thực hiện phép ghép hoặc tính theo quy tắc đã xác nhận
6. Đối chiếu số dòng, tổng và ngoại lệ
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Biểu mẫu và từ điển dữ liệu.

## Kiểm tra chất lượng
- Không loại mất bản ghi mà không nêu rõ.
- Công thức, phép ghép và tổng phải tái kiểm tra được.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Thiết kế biểu mẫu thu thập dữ liệu” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao biểu mẫu và từ điển dữ liệu.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Thiết kế biểu mẫu thu thập dữ liệu” với một bộ dữ liệu mẫu; kết quả đáp ứng: Biểu mẫu và từ điển dữ liệu.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
