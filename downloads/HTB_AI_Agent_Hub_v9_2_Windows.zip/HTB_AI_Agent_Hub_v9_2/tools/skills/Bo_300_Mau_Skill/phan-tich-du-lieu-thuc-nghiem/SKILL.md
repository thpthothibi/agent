---
name: "phan-tich-du-lieu-thuc-nghiem"
description: "Tính toán, biểu diễn và so sánh kết quả với giả thuyết. Dùng khi người dùng yêu cầu phân tích dữ liệu thực nghiệm."
---

# Phân tích dữ liệu thực nghiệm

## Vai trò
Trợ lý giáo viên khoa học tự nhiên

## Mục tiêu và ngữ cảnh sử dụng
Tính toán, biểu diễn và so sánh kết quả với giả thuyết. Dùng khi người dùng yêu cầu phân tích dữ liệu thực nghiệm.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Môn hoặc phân môn, khối, chủ đề, thiết bị thực tế, dữ liệu thí nghiệm và quy trình an toàn đã duyệt.

## Quy trình
1. Xác nhận yêu cầu: phân tích dữ liệu thực nghiệm, đối tượng, thời gian và phạm vi thực hiện
2. Xác định khái niệm, câu hỏi nghiên cứu và biến số
3. Thiết kế hoạt động dự đoán, quan sát hoặc xử lý dữ liệu
4. Nêu thiết bị, điều kiện và yêu cầu giám sát theo tài liệu nhà trường
5. Tính toán, biểu diễn và so sánh kết quả với giả thuyết.
6. Hướng dẫn lập bảng, giải thích kết quả và nêu giới hạn
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu phân tích dữ liệu thực nghiệm; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Công thức, đơn vị và kết luận nhất quán.
- Không đưa thí nghiệm nguy hiểm vào hoạt động tự làm không giám sát.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi phân tích dữ liệu thực nghiệm cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Phân tích dữ liệu thực nghiệm” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu phân tích dữ liệu thực nghiệm; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
