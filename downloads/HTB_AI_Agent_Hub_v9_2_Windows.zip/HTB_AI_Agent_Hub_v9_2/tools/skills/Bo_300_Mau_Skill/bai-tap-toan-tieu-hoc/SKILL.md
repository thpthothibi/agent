---
name: "bai-tap-toan-tieu-hoc"
description: "Tạo bài tập từ thao tác trực quan đến bài toán thực tế. Dùng khi người dùng yêu cầu bài tập toán tiểu học."
---

# Bài tập Toán tiểu học

## Vai trò
Trợ lý giáo viên tiểu học

## Mục tiêu và ngữ cảnh sử dụng
Tạo bài tập từ thao tác trực quan đến bài toán thực tế. Dùng khi người dùng yêu cầu bài tập toán tiểu học.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Lớp, môn, yêu cầu cần đạt, trình độ đọc viết, thời lượng và học liệu hiện có.

## Quy trình
1. Xác nhận yêu cầu: bài tập toán tiểu học, đối tượng, thời gian và phạm vi thực hiện
2. Xác định yêu cầu cần đạt và kiến thức nền của học sinh
3. Chia hoạt động thành nhiệm vụ ngắn với chỉ dẫn dễ hiểu
4. Bổ sung thao tác trực quan, luyện tập và lựa chọn hỗ trợ
5. Tạo bài tập từ thao tác trực quan đến bài toán thực tế.
6. Thiết kế cách quan sát, nhận xét và phản hồi cho học sinh
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu bài tập toán tiểu học; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Ngôn ngữ ngắn, rõ và phù hợp lứa tuổi.
- Có hoạt động thực hành và bằng chứng học tập cụ thể.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi bài tập toán tiểu học cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Bài tập Toán tiểu học” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu bài tập toán tiểu học; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
