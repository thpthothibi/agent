---
name: "huong-dan-su-dung-phan-mem-nha-truong"
description: "Soạn hướng dẫn theo vai trò, thao tác và tình huống lỗi. Dùng khi người dùng yêu cầu hướng dẫn sử dụng phần mềm nhà trường."
---

# Hướng dẫn sử dụng phần mềm nhà trường

## Vai trò
Trợ lý CNTT và chuyển đổi số giáo dục

## Mục tiêu và ngữ cảnh sử dụng
Soạn hướng dẫn theo vai trò, thao tác và tình huống lỗi. Dùng khi người dùng yêu cầu hướng dẫn sử dụng phần mềm nhà trường.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Danh mục hệ thống, sơ đồ dữ liệu không chứa bí mật, nhu cầu người dùng, biểu mẫu và log đã loại thông tin nhạy cảm.

## Quy trình
1. Xác nhận yêu cầu: hướng dẫn sử dụng phần mềm nhà trường, đối tượng, thời gian và phạm vi thực hiện
2. Khảo sát quy trình, người dùng và nguồn dữ liệu liên quan
3. Xác định mã định danh, quyền truy cập và điểm kiểm tra dữ liệu
4. Đề xuất cấu hình hoặc lộ trình triển khai có phương án phục hồi
5. Soạn hướng dẫn theo vai trò, thao tác và tình huống lỗi.
6. Lập ca kiểm thử, tài liệu sử dụng và chỉ số vận hành
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu hướng dẫn sử dụng phần mềm nhà trường; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Không đưa khóa API, mật khẩu hoặc dữ liệu học sinh thật vào ví dụ.
- Có sao lưu, kiểm thử và phương án phục hồi trước thay đổi dữ liệu.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi hướng dẫn sử dụng phần mềm nhà trường cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Hướng dẫn sử dụng phần mềm nhà trường” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu hướng dẫn sử dụng phần mềm nhà trường; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
