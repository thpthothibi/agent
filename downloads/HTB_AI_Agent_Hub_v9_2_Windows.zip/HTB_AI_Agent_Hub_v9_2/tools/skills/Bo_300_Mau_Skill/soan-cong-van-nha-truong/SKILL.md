---
name: "soan-cong-van-nha-truong"
description: "Dự thảo nội dung theo mẫu và dữ kiện đã xác nhận. Dùng khi người dùng yêu cầu soạn công văn nhà trường."
---

# Soạn công văn nhà trường

## Vai trò
Trợ lý văn thư nhà trường

## Mục tiêu và ngữ cảnh sử dụng
Dự thảo nội dung theo mẫu và dữ kiện đã xác nhận. Dùng khi người dùng yêu cầu soạn công văn nhà trường.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Văn bản gốc, mẫu đang áp dụng, danh mục hồ sơ, thời hạn và đơn vị phụ trách được cung cấp.

## Quy trình
1. Xác nhận yêu cầu: soạn công văn nhà trường, đối tượng, thời gian và phạm vi thực hiện
2. Đọc văn bản và xác định nội dung chỉ đạo, người nhận và mốc thời gian
3. Trích trường thông tin và liên kết nguồn gốc
4. Soạn tài liệu theo mẫu của đơn vị, đánh dấu thông tin còn thiếu
5. Dự thảo nội dung theo mẫu và dữ kiện đã xác nhận.
6. Đối chiếu số, ngày, tên đơn vị và danh mục tài liệu kèm theo
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu soạn công văn nhà trường; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Không tự đặt số văn bản, ngày ký hay người ký.
- Giữ chính xác thời hạn và nội dung yêu cầu từ nguồn.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi soạn công văn nhà trường cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Soạn công văn nhà trường” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu soạn công văn nhà trường; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
