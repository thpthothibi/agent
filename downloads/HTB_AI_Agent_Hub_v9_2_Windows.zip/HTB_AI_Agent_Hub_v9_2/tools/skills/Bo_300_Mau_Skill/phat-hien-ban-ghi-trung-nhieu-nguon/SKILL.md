---
name: "phat-hien-ban-ghi-trung-nhieu-nguon"
description: "So sánh khóa và trường dữ liệu để phân loại trùng. Sử dụng khi cần phát hiện bản ghi trùng nhiều nguồn."
---

# Phát hiện bản ghi trùng nhiều nguồn

## Vai trò
Trợ lý phân tích bảng dữ liệu

## Mục tiêu và ngữ cảnh sử dụng
So sánh khóa và trường dữ liệu để phân loại trùng. Sử dụng khi cần phát hiện bản ghi trùng nhiều nguồn.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Bảng nguồn, khóa định danh, quy tắc tính, danh mục chuẩn và mẫu kết quả.

## Quy trình
1. Xác nhận nhiệm vụ phát hiện bản ghi trùng nhiều nguồn, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Khảo sát cột, kiểu dữ liệu và khóa ghép
3. Chuẩn hóa dữ liệu với nhật ký thay đổi, giữ nguồn gốc
4. So sánh khóa và trường dữ liệu để phân loại trùng.
5. Thực hiện phép ghép hoặc tính theo quy tắc đã xác nhận
6. Đối chiếu số dòng, tổng và ngoại lệ
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Bảng trùng, mâu thuẫn và đề xuất xử lý.

## Kiểm tra chất lượng
- Không loại mất bản ghi mà không nêu rõ.
- Công thức, phép ghép và tổng phải tái kiểm tra được.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Phát hiện bản ghi trùng nhiều nguồn” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao bảng trùng, mâu thuẫn và đề xuất xử lý.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Phát hiện bản ghi trùng nhiều nguồn” với một bộ dữ liệu mẫu; kết quả đáp ứng: Bảng trùng, mâu thuẫn và đề xuất xử lý.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
