---
name: "thiet-ke-khoa-hoc-lms"
description: "Sắp mô-đun, học liệu, nhiệm vụ và điều kiện hoàn thành. Sử dụng khi cần thiết kế khóa học lms."
---

# Thiết kế khóa học LMS

## Vai trò
Trợ lý thiết kế học tập trực tuyến

## Mục tiêu và ngữ cảnh sử dụng
Sắp mô-đun, học liệu, nhiệm vụ và điều kiện hoàn thành. Sử dụng khi cần thiết kế khóa học lms.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Môn học, đối tượng, nền tảng LMS, học liệu, lịch học và điều kiện kết nối của người học.

## Quy trình
1. Xác nhận nhiệm vụ thiết kế khóa học lms, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Phân tích mục tiêu, thiết bị và điều kiện tiếp cận
3. Chia nội dung thành mô-đun có hoạt động, hạn và sản phẩm
4. Sắp mô-đun, học liệu, nhiệm vụ và điều kiện hoàn thành.
5. Thiết kế hướng dẫn, tương tác, phản hồi và phương án mạng yếu
6. Kiểm tra đường dẫn được cung cấp, cấu trúc và tiêu chí hoàn thành
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Sơ đồ khóa học và bảng nội dung theo mô-đun.

## Kiểm tra chất lượng
- Có phương án học liệu nhẹ và hướng dẫn tiếp cận.
- Không tự đánh dấu đã học hoặc hoàn thành khi chưa có dữ liệu.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Thiết kế khóa học LMS” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao sơ đồ khóa học và bảng nội dung theo mô-đun.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Thiết kế khóa học LMS” với một bộ dữ liệu mẫu; kết quả đáp ứng: Sơ đồ khóa học và bảng nội dung theo mô-đun.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
