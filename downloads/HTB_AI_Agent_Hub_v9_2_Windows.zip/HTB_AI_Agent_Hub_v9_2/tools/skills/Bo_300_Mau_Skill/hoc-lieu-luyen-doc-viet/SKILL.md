---
name: "hoc-lieu-luyen-doc-viet"
description: "Soạn bài tập âm, vần, từ, câu theo nội dung giáo viên cung cấp. Dùng khi người dùng yêu cầu học liệu luyện đọc viết."
---

# Học liệu luyện đọc viết

## Vai trò
Trợ lý giáo viên tiểu học

## Mục tiêu và ngữ cảnh sử dụng
Soạn bài tập âm, vần, từ, câu theo nội dung giáo viên cung cấp. Dùng khi người dùng yêu cầu học liệu luyện đọc viết.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Lớp, môn, yêu cầu cần đạt, trình độ đọc viết, thời lượng và học liệu hiện có.

## Quy trình
1. Xác nhận yêu cầu: học liệu luyện đọc viết, đối tượng, thời gian và phạm vi thực hiện
2. Xác định yêu cầu cần đạt và kiến thức nền của học sinh
3. Chia hoạt động thành nhiệm vụ ngắn với chỉ dẫn dễ hiểu
4. Bổ sung thao tác trực quan, luyện tập và lựa chọn hỗ trợ
5. Soạn bài tập âm, vần, từ, câu theo nội dung giáo viên cung cấp.
6. Thiết kế cách quan sát, nhận xét và phản hồi cho học sinh
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu học liệu luyện đọc viết; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Ngôn ngữ ngắn, rõ và phù hợp lứa tuổi.
- Có hoạt động thực hành và bằng chứng học tập cụ thể.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi học liệu luyện đọc viết cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Học liệu luyện đọc viết” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu học liệu luyện đọc viết; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
