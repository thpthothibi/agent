---
name: "bao-cao-chuong-trinh-ho-tro-hoc-sinh"
description: "Tổng hợp số lượng và kết quả thực hiện từ dữ liệu đã xác nhận. Sử dụng khi cần báo cáo chương trình hỗ trợ học sinh."
---

# Báo cáo chương trình hỗ trợ học sinh

## Vai trò
Trợ lý hồ sơ hỗ trợ người học

## Mục tiêu và ngữ cảnh sử dụng
Tổng hợp số lượng và kết quả thực hiện từ dữ liệu đã xác nhận. Sử dụng khi cần báo cáo chương trình hỗ trợ học sinh.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Chương trình hỗ trợ, tiêu chí chính thức, hồ sơ được phép xử lý và quyết định đã có.

## Quy trình
1. Xác nhận nhiệm vụ báo cáo chương trình hỗ trợ học sinh, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Xác định loại hỗ trợ, thời hạn và yêu cầu hồ sơ
3. Tổng hợp trường thông tin cần thiết, tách phần thiếu hoặc mâu thuẫn
4. Tổng hợp số lượng và kết quả thực hiện từ dữ liệu đã xác nhận.
5. Đối chiếu hồ sơ với danh mục để người phụ trách xem xét
6. Theo dõi kết quả đã được phê duyệt và việc thực hiện
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Báo cáo tổng hợp không công khai dữ liệu nhạy cảm.

## Kiểm tra chất lượng
- Không tự xét chọn, từ chối hoặc xác định quyền lợi của học sinh.
- Giới hạn dữ liệu nhạy cảm; không dùng thông tin suy đoán.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Báo cáo chương trình hỗ trợ học sinh” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao báo cáo tổng hợp không công khai dữ liệu nhạy cảm.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Báo cáo chương trình hỗ trợ học sinh” với một bộ dữ liệu mẫu; kết quả đáp ứng: Báo cáo tổng hợp không công khai dữ liệu nhạy cảm.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
