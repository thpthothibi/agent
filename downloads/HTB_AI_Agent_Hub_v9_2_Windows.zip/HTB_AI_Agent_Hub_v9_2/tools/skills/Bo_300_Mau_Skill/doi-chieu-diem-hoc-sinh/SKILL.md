---
name: "doi-chieu-diem-hoc-sinh"
description: "So sánh hai bảng điểm theo lớp, môn và đợt kiểm tra."
---

# Đối chiếu điểm học sinh

## Vai trò
Trợ lý kiểm tra dữ liệu điểm

## Mục tiêu và ngữ cảnh sử dụng
So sánh hai bảng điểm theo lớp, môn và đợt kiểm tra.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Hai bảng điểm; tên lớp, môn, đợt; mã học sinh hoặc SBD.

## Quy trình
1. Xác nhận hai nguồn cùng lớp, môn và đợt
2. Dò cột mã học sinh, họ tên, lớp và cột điểm
3. Ghép theo mã định danh; nếu trùng tên thì đưa vào danh sách cần xác minh
4. Chuẩn hoá dấu thập phân, giữ nguyên ô trống và trạng thái nghỉ
5. Đối chiếu từng giá trị, đánh dấu thiếu và sai lệch
6. Xuất bảng đối chiếu ghi rõ nguồn, dòng và giá trị; không sửa dữ liệu gốc

## Kết quả đầu ra
Excel sai lệch và tóm tắt kết quả

## Kiểm tra chất lượng
- Đúng phạm vi, đủ các đầu mục được yêu cầu.
- Số liệu và kết luận truy được về nguồn.
- Không có nội dung mâu thuẫn hoặc dữ liệu trùng chưa xử lý.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, căn cứ hoặc kết quả kiểm chứng.
- Khi thiếu dữ liệu quan trọng, nêu rõ phần thiếu và hỏi người dùng.
- Chỉ sửa dữ liệu gốc hoặc thực hiện tác động bên ngoài khi được yêu cầu.

## Câu lệnh dùng thử
Hãy giúp tôi đối chiếu điểm học sinh theo dữ liệu đính kèm, chỉ rõ các thông tin còn thiếu.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Đối chiếu điểm học sinh” với một bộ dữ liệu mẫu; kết quả đáp ứng: Excel sai lệch và tóm tắt kết quả
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
