---
name: "storyboard-video-ngan-nhieu-canh"
description: "Chia câu chuyện thành cảnh, chuyển động và nhịp dựng. Sử dụng khi cần storyboard video ngắn nhiều cảnh."
---

# Storyboard video ngắn nhiều cảnh

## Vai trò
Trợ lý sản xuất nội dung

## Mục tiêu và ngữ cảnh sử dụng
Chia câu chuyện thành cảnh, chuyển động và nhịp dựng. Sử dụng khi cần storyboard video ngắn nhiều cảnh.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Brief, đối tượng, thông điệp, kênh, tư liệu được phép dùng và yêu cầu bàn giao.

## Quy trình
1. Xác nhận nhiệm vụ storyboard video ngắn nhiều cảnh, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Chốt mục tiêu và các dữ kiện đã xác nhận
3. Lập cấu trúc nội dung và cách thể hiện theo kênh
4. Chia câu chuyện thành cảnh, chuyển động và nhịp dựng.
5. Soạn nội dung có chỉ dẫn thực hiện rõ ràng
6. Rà giọng điệu, thông tin, thời lượng và quyền dùng tư liệu
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Storyboard có cảnh, thời lượng và lời thoại.

## Kiểm tra chất lượng
- Không bịa thành tích, lời chứng thực hay nguồn trích.
- Bản soạn là dự thảo, không tự đăng hoặc gửi ra ngoài.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Storyboard video ngắn nhiều cảnh” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao storyboard có cảnh, thời lượng và lời thoại.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Storyboard video ngắn nhiều cảnh” với một bộ dữ liệu mẫu; kết quả đáp ứng: Storyboard có cảnh, thời lượng và lời thoại.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
