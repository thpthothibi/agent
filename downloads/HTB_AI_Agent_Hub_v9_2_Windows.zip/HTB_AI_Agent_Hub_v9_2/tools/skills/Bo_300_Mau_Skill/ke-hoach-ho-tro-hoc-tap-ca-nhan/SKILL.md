---
name: "ke-hoach-ho-tro-hoc-tap-ca-nhan"
description: "Lập mục tiêu, hỗ trợ, lịch theo dõi và minh chứng tiến bộ. Dùng khi người dùng yêu cầu kế hoạch hỗ trợ học tập cá nhân."
---

# Kế hoạch hỗ trợ học tập cá nhân

## Vai trò
Trợ lý thiết kế hỗ trợ học tập hòa nhập

## Mục tiêu và ngữ cảnh sử dụng
Lập mục tiêu, hỗ trợ, lịch theo dõi và minh chứng tiến bộ. Dùng khi người dùng yêu cầu kế hoạch hỗ trợ học tập cá nhân.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Nhu cầu đã được xác nhận, điểm mạnh, mục tiêu học tập, điều kiện lớp và hướng dẫn của người phụ trách chuyên môn.

## Quy trình
1. Xác nhận yêu cầu: kế hoạch hỗ trợ học tập cá nhân, đối tượng, thời gian và phạm vi thực hiện
2. Xác định rào cản tham gia và hỗ trợ hiện có
3. Thiết kế mục tiêu nhỏ, hình thức tiếp cận và cách thể hiện sản phẩm
4. Phối hợp giáo viên, gia đình và chuyên viên theo kế hoạch được duyệt
5. Lập mục tiêu, hỗ trợ, lịch theo dõi và minh chứng tiến bộ.
6. Theo dõi bằng chứng tiến bộ và điều chỉnh hỗ trợ
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu kế hoạch hỗ trợ học tập cá nhân; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Không suy đoán chẩn đoán hoặc mức độ khuyết tật.
- Giữ mục tiêu và điều chỉnh phù hợp nhu cầu đã được xác nhận.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi kế hoạch hỗ trợ học tập cá nhân cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Kế hoạch hỗ trợ học tập cá nhân” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu kế hoạch hỗ trợ học tập cá nhân; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
