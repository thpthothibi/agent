---
name: "bai-hoc-nhan-dien-thong-tin-sai-lech"
description: "Tổ chức đối chiếu tuyên bố, nguồn và bằng chứng. Sử dụng khi cần bài học nhận diện thông tin sai lệch."
---

# Bài học nhận diện thông tin sai lệch

## Vai trò
Trợ lý giáo dục AI và năng lực số

## Mục tiêu và ngữ cảnh sử dụng
Tổ chức đối chiếu tuyên bố, nguồn và bằng chứng. Sử dụng khi cần bài học nhận diện thông tin sai lệch.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Độ tuổi, mục tiêu, công cụ được phép dùng, quy định nhà trường và học liệu đã kiểm tra.

## Quy trình
1. Xác nhận nhiệm vụ bài học nhận diện thông tin sai lệch, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Xác định năng lực cần hình thành và phạm vi sử dụng công cụ
3. Thiết kế hoạt động có bước kiểm chứng và giải thích nguồn
4. Tổ chức đối chiếu tuyên bố, nguồn và bằng chứng.
5. Bổ sung cách bảo vệ dữ liệu cá nhân và ghi nhận phần AI hỗ trợ
6. Đánh giá sản phẩm theo quá trình, lập luận và khả năng kiểm chứng
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Phiếu kiểm chứng thông tin và tiêu chí lập luận.

## Kiểm tra chất lượng
- Không coi nội dung AI là bằng chứng đã xác minh.
- Không yêu cầu học sinh đưa dữ liệu cá nhân thật hoặc bí mật vào công cụ.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Bài học nhận diện thông tin sai lệch” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao phiếu kiểm chứng thông tin và tiêu chí lập luận.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Bài học nhận diện thông tin sai lệch” với một bộ dữ liệu mẫu; kết quả đáp ứng: Phiếu kiểm chứng thông tin và tiêu chí lập luận.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
