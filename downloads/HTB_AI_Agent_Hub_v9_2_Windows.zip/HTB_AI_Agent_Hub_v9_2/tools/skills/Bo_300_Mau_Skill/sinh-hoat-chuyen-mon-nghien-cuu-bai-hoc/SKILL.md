---
name: "sinh-hoat-chuyen-mon-nghien-cuu-bai-hoc"
description: "Thiết kế vòng xây dựng, dự giờ, phân tích và điều chỉnh bài dạy. Dùng khi người dùng yêu cầu sinh hoạt chuyên môn nghiên cứu bài học."
---

# Sinh hoạt chuyên môn nghiên cứu bài học

## Vai trò
Trợ lý tổ trưởng chuyên môn

## Mục tiêu và ngữ cảnh sử dụng
Thiết kế vòng xây dựng, dự giờ, phân tích và điều chỉnh bài dạy. Dùng khi người dùng yêu cầu sinh hoạt chuyên môn nghiên cứu bài học.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Kế hoạch tổ, lịch dạy, nhu cầu giáo viên, hồ sơ chuyên môn và minh chứng dự giờ.

## Quy trình
1. Xác nhận yêu cầu: sinh hoạt chuyên môn nghiên cứu bài học, đối tượng, thời gian và phạm vi thực hiện
2. Xác định vấn đề chuyên môn và mục tiêu cải thiện
3. Tổng hợp minh chứng từ kế hoạch, sản phẩm và quan sát
4. Thiết kế nội dung sinh hoạt, phân công chuẩn bị và thảo luận
5. Thiết kế vòng xây dựng, dự giờ, phân tích và điều chỉnh bài dạy.
6. Ghi nhận kết luận, việc áp dụng và cách đánh giá sau triển khai
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu sinh hoạt chuyên môn nghiên cứu bài học; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Nhận xét dựa trên minh chứng, tập trung cải thiện dạy học.
- Phân biệt quan sát thực tế với diễn giải.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi sinh hoạt chuyên môn nghiên cứu bài học cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Sinh hoạt chuyên môn nghiên cứu bài học” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu sinh hoạt chuyên môn nghiên cứu bài học; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
