---
name: "ke-hoach-hau-ky-video"
description: "Sắp nhịp dựng, phụ đề, âm thanh và checklist xuất. Sử dụng khi cần kế hoạch hậu kỳ video."
---

# Kế hoạch hậu kỳ video

## Vai trò
Trợ lý sản xuất nội dung

## Mục tiêu và ngữ cảnh sử dụng
Sắp nhịp dựng, phụ đề, âm thanh và checklist xuất. Sử dụng khi cần kế hoạch hậu kỳ video.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Brief, đối tượng, thông điệp, kênh, tư liệu được phép dùng và yêu cầu bàn giao.

## Quy trình
1. Xác nhận nhiệm vụ kế hoạch hậu kỳ video, bối cảnh, kỳ dữ liệu và tiêu chí hoàn thành
2. Chốt mục tiêu và các dữ kiện đã xác nhận
3. Lập cấu trúc nội dung và cách thể hiện theo kênh
4. Sắp nhịp dựng, phụ đề, âm thanh và checklist xuất.
5. Soạn nội dung có chỉ dẫn thực hiện rõ ràng
6. Rà giọng điệu, thông tin, thời lượng và quyền dùng tư liệu
7. Bàn giao sản phẩm, nguồn sử dụng và danh sách thông tin còn thiếu

## Kết quả đầu ra
Kế hoạch dựng và checklist kiểm tra video.

## Kiểm tra chất lượng
- Không bịa thành tích, lời chứng thực hay nguồn trích.
- Bản soạn là dự thảo, không tự đăng hoặc gửi ra ngoài.

## Giới hạn và xử lý ngoại lệ
- Không tự bịa số liệu, văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nêu rõ phần thiếu và hỏi lại khi thiếu dữ liệu quyết định.
- Nếu phụ thuộc quy định hoặc thông tin hiện hành, kiểm tra nguồn chính thức đúng thời điểm trước khi kết luận.
- Không tự gửi thông báo, ghi đè hồ sơ hoặc thực hiện giao dịch ngoài phạm vi được giao.

## Câu lệnh dùng thử
Hãy hỗ trợ công việc “Kế hoạch hậu kỳ video” cho [đơn vị/nhóm] trong [thời gian]. Dùng dữ liệu tôi cung cấp, chỉ rõ phần còn thiếu và bàn giao kế hoạch dựng và checklist kiểm tra video.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Kế hoạch hậu kỳ video” với một bộ dữ liệu mẫu; kết quả đáp ứng: Kế hoạch dựng và checklist kiểm tra video.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
