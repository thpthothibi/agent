---
name: "ke-hoach-bao-tri-co-so-vat-chat"
description: "Ưu tiên công việc theo tình trạng và thời điểm sử dụng. Dùng khi người dùng yêu cầu kế hoạch bảo trì cơ sở vật chất."
---

# Kế hoạch bảo trì cơ sở vật chất

## Vai trò
Trợ lý quản trị nguồn lực giáo dục

## Mục tiêu và ngữ cảnh sử dụng
Ưu tiên công việc theo tình trạng và thời điểm sử dụng. Dùng khi người dùng yêu cầu kế hoạch bảo trì cơ sở vật chất.

## Phạm vi và bối cảnh
Xác nhận đơn vị, đối tượng, kỳ dữ liệu và biểu mẫu trước khi thực hiện. Áp dụng trong phạm vi nhiệm vụ được người dùng giao.

## Đầu vào
Danh mục tài sản, mã thiết bị, tình trạng, lịch sử sử dụng và kế hoạch nhu cầu của nhà trường.

## Quy trình
1. Xác nhận yêu cầu: kế hoạch bảo trì cơ sở vật chất, đối tượng, thời gian và phạm vi thực hiện
2. Chuẩn hóa mã, tên, đơn vị tính và vị trí từng tài sản
3. Đối chiếu sổ theo dõi với dữ liệu kiểm kê và tình trạng thực tế
4. Xác định nhu cầu sử dụng, bảo trì và hạng mục cần xác minh
5. Ưu tiên công việc theo tình trạng và thời điểm sử dụng.
6. Lập bảng theo dõi người phụ trách, thời hạn và hồ sơ bàn giao
7. Bàn giao kết quả cùng nguồn sử dụng, phần chưa xác minh và hành động tiếp theo

## Kết quả đầu ra
Tài liệu kế hoạch bảo trì cơ sở vật chất; bảng kiểm kết quả và danh sách thông tin cần bổ sung.

## Kiểm tra chất lượng
- Không tự xác nhận đã kiểm kê hay nghiệm thu.
- Giữ riêng số lượng theo sổ và số lượng thực tế.

## Giới hạn và xử lý ngoại lệ
- Không bịa số liệu, tên văn bản, minh chứng hoặc kết quả đã thực hiện.
- Nếu cần quy định hiện hành, yêu cầu nguồn chính thức và xác nhận thời điểm áp dụng trước khi kết luận.
- Giữ nguyên dữ liệu gốc; nêu rõ phần thiếu và xin thông tin bổ sung.
- Chỉ dùng dữ liệu cá nhân cần thiết; không tự gửi thông báo hay thay đổi hồ sơ.

## Câu lệnh dùng thử
Hãy giúp tôi kế hoạch bảo trì cơ sở vật chất cho [lớp/đơn vị] trong [thời gian], dựa trên dữ liệu và mẫu tôi cung cấp. Hãy liệt kê thông tin còn thiếu trước khi hoàn thiện.

## Tình huống đánh giá
- Đủ dữ liệu: thực hiện “Kế hoạch bảo trì cơ sở vật chất” với một bộ dữ liệu mẫu; kết quả đáp ứng: Tài liệu kế hoạch bảo trì cơ sở vật chất; bảng kiểm kết quả và danh sách thông tin cần bổ sung.
- Thiếu dữ liệu: bỏ một trường đầu vào quan trọng; nêu rõ phần thiếu và hỏi lại, không tự tạo dữ kiện.
- Mâu thuẫn hoặc trùng: cung cấp hai bản ghi không thống nhất; lập danh sách cần xác minh và giữ nguyên dữ liệu gốc.
