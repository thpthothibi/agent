"""Regression coverage for missing names and Excel enrichment; browser tests are optional."""
import unittest
from search_and_duplicates import search_in_grading


class SearchRegressionTests(unittest.TestCase):
    def test_placeholder_name_and_class_are_enriched_from_excel(self):
        rows=[dict(file='a.jpg',sbd='10001001',name='—',**{'class':'-', 'score':'0','code':'101'})]
        roster=[dict(sbd='10001001',name='Trần Ngọc Khánh',**{'class':'10A01'})]
        items,stats=search_in_grading(rows,roster,name_query='tran khanh',class_query='10A1')
        self.assertEqual(len(items),1)
        self.assertEqual(items[0]['proposal']['name'],'Trần Ngọc Khánh')
        self.assertEqual(items[0]['proposal']['class'],'10A01')
        self.assertIn('Điểm: 0',items[0]['status'])

    def test_all_class_query_with_or_without_accents(self):
        rows=[dict(file='a.jpg',sbd='10001001',name='Nguyễn An',**{'class':'10A01','score':'5'})]
        for query in ['Tất cả','tat ca','TẤT CẢ LỚP','ALL','*']:
            with self.subTest(query=query):
                items,_=search_in_grading(rows,name_query='nguyen an',class_query=query)
                self.assertEqual(len(items),1)

    def test_missing_students_roster_enriches_blank_names_without_excel(self):
        rows=[dict(file='a.jpg',sbd='10001001',name='',**{'class':'','score':''})]
        missing=[dict(sbd='10001001',name='Trần Ngọc Khánh',**{'class':'10A01'})]
        items,_=search_in_grading(rows,name_query='khanh',missing_roster=missing)
        self.assertEqual(len(items),1)
        self.assertEqual(items[0]['proposal']['name'],'Trần Ngọc Khánh')

    def test_zero_results_are_valid(self):
        items,stats=search_in_grading([],name_query='Khánh')
        self.assertEqual(items,[])
        self.assertEqual(stats['total_results'],0)

if __name__=='__main__':
    unittest.main()
