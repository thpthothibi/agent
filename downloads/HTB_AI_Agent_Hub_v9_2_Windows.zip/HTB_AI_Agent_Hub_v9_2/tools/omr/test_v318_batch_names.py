import unittest
from search_and_duplicates import list_students_in_batch

class BatchNamesTests(unittest.TestCase):
    def test_no_excel_required_and_zero_score_preserved(self):
        rows=[{'file':'a.jpg','sbd':'10001001','name':'Trần Ngọc Khánh','class':'10A01','score':'0'}]
        items,stats=list_students_in_batch(rows)
        self.assertEqual(items[0]['proposal']['name'],'Trần Ngọc Khánh')
        self.assertEqual(stats['named_results'],1)
        self.assertIn('Điểm: 0',items[0]['status'])

    def test_excel_enrichment_is_scoped_to_actual_batch(self):
        rows=[{'file':'a.jpg','sbd':'10001001','name':'—','class':'-'}]
        roster=[{'sbd':'10001001','name':'Trần Ngọc Khánh','class':'10A01'},
                {'sbd':'11001001','name':'Nguyễn An','class':'11A01'}]
        items,stats=list_students_in_batch(rows,roster)
        self.assertEqual(len(items),1)
        self.assertEqual(items[0]['proposal']['name'],'Trần Ngọc Khánh')

    def test_missing_students_of_current_batch_and_unnamed_sheets(self):
        rows=[{'file':'a.jpg','sbd':'unknown','name':'','class':''}]
        missing=[{'sbd':'10001001','name':'Trần Ngọc Khánh','class':'10A01'}]
        items,stats=list_students_in_batch(rows,missing_roster=missing)
        self.assertEqual(len(items),2)
        self.assertEqual(stats['named_results'],1)
        self.assertEqual(stats['unnamed_results'],1)

if __name__=='__main__':unittest.main()
