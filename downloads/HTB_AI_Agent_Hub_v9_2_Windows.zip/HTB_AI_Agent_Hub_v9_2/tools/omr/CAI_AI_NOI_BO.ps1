param(
    [string]$Model = "qwen3-vl:2b"
)
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  CAI DAT AI NOI BO (OLLAMA - $Model)" -ForegroundColor Cyan
Write-Host "  Luu y: Chi danh cho may manh (RAM >= 8GB). Neu may yeu, hay chon che do 'Khong dung AI'." -ForegroundColor Yellow
Write-Host "=========================================================="
$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if (-not $ollama) {
    $localOllama = "$env:LOCALAPPDATA\Programs\Ollama\ollama.exe"
    if (Test-Path $localOllama) {
        $ollama = $localOllama
    } else {
        Write-Host "Chua cai Ollama. Hay tai Ollama cho Windows tai https://ollama.com/download" -ForegroundColor Red
        exit 1
    }
}
& $ollama pull $Model
Write-Host "Da tai xong model $Model!" -ForegroundColor Green
