# -*- coding: utf-8 -*-
"""Double-click this file in Windows Explorer to install all required libraries
using the exact Python interpreter associated with .py files (`sys.executable -m pip`).
"""
import subprocess
import sys

PACKAGES = ["selenium>=4.15.0", "Pillow>=10.0.0", "openpyxl>=3.1.0", "opencv-python>=4.8.0", "numpy>=1.24.0"]

def main():
    print("=" * 68)
    print("  CAI DAT THU VIEN HTB VIETSCHOOL AGENT v3.18")
    print("  Python:", sys.executable)
    print("=" * 68)
    try:
        subprocess.run([sys.executable, "-m", "ensurepip", "--upgrade"], check=False)
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], check=False)
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade"] + PACKAGES)
        print("\n[THANH CONG] Da cai dat day du thu vien! Dang mo giao dien chinh...")
        import vietschool_sbd_agent
        vietschool_sbd_agent.main()
    except Exception as exc:
        print("\n[LOI]:", exc)
        input("\nNhan Enter de dong cua so...")

if __name__ == "__main__":
    main()
