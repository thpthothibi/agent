@echo off
taskkill /F /IM ollama.exe 2>nul
taskkill /F /IM ollama_llama_server.exe 2>nul
echo Da tat tien trinh AI ngam (Ollama) de giai phong RAM/CPU.
pause
