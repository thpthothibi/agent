# -*- coding: utf-8 -*-
"""Choose SBD/identity and (optionally) Exam-Code anomalies *before* opening a VietSchool sheet."""
from collections import defaultdict, Counter
from vietschool_sbd_agent import blank, norm, class_key, number


def select_sbd_anomalies(webrows, official_roster=(), *, include_excel_mismatches=True, exam_catalog=None, selected_subject=''):
    official_by_sbd=defaultdict(set)
    official_by_person=defaultdict(set)
    rows_by_person=defaultdict(list)
    rows_by_sbd=defaultdict(list)
    check_sbd=bool(official_roster) or (exam_catalog is None)
    for st in (official_roster or ()):
        sbd=str(st.get('sbd') or '').strip()
        nm=norm(st.get('name'))
        cls=class_key(st.get('class'))
        if sbd and nm and cls:
            official_by_sbd[sbd].add((nm,cls))
            official_by_person[(nm,cls)].add(sbd)
    for row in webrows:
        key=(norm(row.get('name')),class_key(row.get('class')))
        sbd=str(row.get('sbd') or '').strip()
        if all(key): rows_by_person[key].append(row)
        if sbd: rows_by_sbd[sbd].append(row)

    result=[]
    counts=Counter()
    for row in webrows:
        reasons=[]
        sbd=str(row.get('sbd') or '').strip()
        nm=norm(row.get('name'));cls=class_key(row.get('class'))
        key=(nm,cls)
        def flag(reason):
            if reason not in reasons:
                reasons.append(reason)
                counts[reason]+=1

        if check_sbd:
            if blank(row.get('name')): flag('Thiếu họ tên')
            if blank(row.get('sbd')): flag('Thiếu SBD')
            elif not number(sbd,8,8): flag('SBD sai định dạng (cần 8 chữ số)')
            elif include_excel_mismatches and official_by_sbd and sbd not in official_by_sbd:
                flag('SBD không có trong danh sách Excel')
            if sbd and len(rows_by_sbd[sbd])>1:
                flag('Trùng SBD giữa các phiếu')
            if nm and cls:
                if len(rows_by_person[key])>1:
                    flag('Trùng họ tên + lớp giữa các phiếu')
                if len(official_by_person.get(key,()))>1:
                    flag('Trùng họ tên + lớp trong Excel (nhiều SBD)')
                if include_excel_mismatches and official_by_sbd:
                    owners=official_by_sbd.get(sbd,set())
                    if owners and key not in owners:
                        flag('SBD không khớp họ tên/lớp Excel')
                    if key in official_by_person and sbd not in official_by_person[key]:
                        flag('Họ tên + lớp có SBD khác trong Excel')
            if sbd in official_by_sbd and len(official_by_sbd[sbd])>1:
                flag('Một SBD thuộc nhiều học sinh trong Excel')

        if exam_catalog is not None:
            raw_code=str(row.get('code') or '').strip()
            if hasattr(exam_catalog,'resolve_batch_codes'):
                _,valid_codes,scope_err=exam_catalog.resolve_batch_codes(row,webrows,selected_subject)
            else:
                _,valid_codes,scope_err=exam_catalog.valid_codes(row,selected_subject)
            expected_lens={len(c) for c in valid_codes} if valid_codes else {3,4}
            min_len=min(expected_lens) if expected_lens else 3
            max_len=max(expected_lens) if expected_lens else 4
            if blank(raw_code):
                flag('Thiếu mã đề')
            elif not number(raw_code,min_len,max_len):
                flag('Mã đề sai định dạng')
            elif valid_codes and raw_code not in valid_codes:
                flag('Mã đề không có trong danh sách mẫu')
            elif scope_err and not valid_codes:
                flag('Chưa xác định môn để đối chiếu mã đề')

        if reasons:result.append((row,reasons))
    return result, {'scanned':len(webrows), 'selected':len(result),
                    'skipped':len(webrows)-len(result),'by_reason':dict(counts)}
