@echo off
chcp 65001 >nul 2>nul
title HTB VIETSCHOOL AGENT v3.18
cd /d "%~dp0"
set "PY_EXE="
set "PY_ARGS="

if exist "%~dp0.venv\Scripts\python.exe" (
    set "PY_EXE=%~dp0.venv\Scripts\python.exe"
    goto :found_py
)
if exist "%~dp0..\.venv\Scripts\python.exe" (
    set "PY_EXE=%~dp0..\.venv\Scripts\python.exe"
    goto :found_py
)

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    py -3 -c "import sys; raise SystemExit(0 if sys.version_info>=(3,9) else 1)" >nul 2>nul
    if %ERRORLEVEL% EQU 0 (
        set "PY_EXE=py"
        set "PY_ARGS=-3"
        goto :found_py
    )
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    python -c "import sys; raise SystemExit(0 if sys.version_info>=(3,9) else 1)" >nul 2>nul
    if %ERRORLEVEL% EQU 0 (
        set "PY_EXE=python"
        goto :found_py
    )
)

for %%V in (313 312 311 310 39) do (
    if exist "%LocalAppData%\Programs\Python\Python%%V\python.exe" (
        set "PY_EXE=%LocalAppData%\Programs\Python\Python%%V\python.exe"
        goto :found_py
    )
    if exist "%ProgramFiles%\Python%%V\python.exe" (
        set "PY_EXE=%ProgramFiles%\Python%%V\python.exe"
        goto :found_py
    )
    if exist "%ProgramFiles(x86)%\Python%%V\python.exe" (
        set "PY_EXE=%ProgramFiles(x86)%\Python%%V\python.exe"
        goto :found_py
    )
    if exist "C:\Python%%V\python.exe" (
        set "PY_EXE=C:\Python%%V\python.exe"
        goto :found_py
    )
)

for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "$p = Get-ChildItem -Path \"$env:LOCALAPPDATA\Programs\Python\Python*\python.exe\",\"C:\Python*\python.exe\" -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName; if($p){Write-Output $p}"`) do (
    if exist "%%P" (
        set "PY_EXE=%%P"
        goto :found_py
    )
)

echo [LOI] Khong tim thay Python 3.9+ tren may tinh!
echo Hay cai Python tu https://www.python.org/downloads/ roi thu lai.
pause
exit /b 1

:found_py
echo Dang khoi dong HTB VietSchool Agent bang: "%PY_EXE%" %PY_ARGS%
"%PY_EXE%" %PY_ARGS% -c "import selenium, PIL, openpyxl, cv2, numpy" >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Phat hien thieu thu vien. Dang tu dong cai dat qua python -m pip...
    "%PY_EXE%" %PY_ARGS% -m ensurepip --upgrade >nul 2>nul
    "%PY_EXE%" %PY_ARGS% -m pip install --upgrade selenium Pillow openpyxl opencv-python numpy
)
"%PY_EXE%" %PY_ARGS% "%~dp0vietschool_sbd_agent.py"
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Chuong trinh dung voi ma loi %ERRORLEVEL%.
    pause
)
