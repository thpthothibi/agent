# -*- coding: utf-8 -*-
from __future__ import annotations
import tempfile, unittest, json
from pathlib import Path
from unittest.mock import patch
from vietschool_sbd_agent import Runner, NoAI, Record, audit_bubbles_match


def row(file, name='', sbd='20006140', code='2345', score='5', cls='11B6'):
    return {'file':file, 'name':name, 'sbd':sbd, 'code':code, 'score':score,'class':cls}


def bubble(sbd='20006140', code='2345'):
    return {'sbd':sbd,'code':code,
        'masks':{'sbd':[[int(x)] for x in sbd], 'code':[[int(x)] for x in code]},
        'confidence':{'sbd':8,'code':4}}


class BatchBrowser:
    def __init__(self,data):
        self.data=data;self.writes=[];self.opened=[];self.closed=0;self.current=''
    def scan(self):return [dict(x) for x in self.data]
    def missing_students(self):return []
    def open(self,f):self.current=f;self.opened.append(f)
    def close(self):self.closed+=1
    def image(self):return self.current.encode(),self.current.encode()
    def read_modal_fields(self):return {'sbd':'','code':''}
    def write(self,p,journal):
        self.writes.append((self.current,dict(p)))
        journal('before_field',{'field':'sbd'})
    def verify(self,file,p):
        updated=None
        for r in self.data:
            if r['file']==file:
                r.update({k:p[k] for k in ('sbd','code')})
                r['name']=p.get('name') or r['name']
                r['class']=p.get('class') or r['class']
                r['score']='5'
                updated=dict(r)
        if updated is None:raise AssertionError('Unexpected file')
        return updated


class BatchVisionAI:
    def test(self):return 'mock-image-reader'
    def read(self,b):
        name=b.decode();num=int(name.split('.')[0][1:]);return {
            'sbd':f'{20006140+num:08d}', 'code':'2345',
            'name':'Học Sinh '+str(num),'class':'11B6', 'clear':num!=2
        }


class BatchTests(unittest.TestCase):
    def test_full_run_continues_after_an_ambiguous_sheet(self):
        entries=[row(f'f{i}.jpg', sbd=f'{40006140+i:08d}') for i in range(5)]
        with tempfile.TemporaryDirectory() as tmp:
            b=BatchBrowser(entries)
            runner=Runner(b,BatchVisionAI(),lambda *a:None,lambda:None,tmp)
            runner.run()
            self.assertEqual(len(runner.records),5)
            self.assertEqual(len(b.writes),4)
            self.assertEqual(len(set(file for file,_ in b.writes)),4)
            self.assertEqual(b.opened[:5],[f'f{i}.jpg' for i in range(5)])
            self.assertEqual(runner.records[2].status,'Cần kiểm tra')
            self.assertEqual(sum(r.status=='Đã xác minh' for r in runner.records),4)
            self.assertGreaterEqual(b.closed,1)
            logs=[json.loads(l) for l in (Path(tmp)/'nhat_ky.jsonl').read_text('utf-8').splitlines()]
            self.assertEqual(logs[-1]['event'],'final_scan')
            self.assertEqual(logs[-1]['details']['processed'],5)

    def test_trial_mode_only_one(self):
        entries=[row(f'f{i}.jpg') for i in range(5)]
        with tempfile.TemporaryDirectory() as tmp:
            b=BatchBrowser(entries);r=Runner(b,BatchVisionAI(),lambda *a:None,lambda:None,tmp,max_records=1)
            r.run()
            self.assertEqual(len(r.records),1);self.assertEqual(len(b.writes),1)


if __name__=='__main__':unittest.main()
