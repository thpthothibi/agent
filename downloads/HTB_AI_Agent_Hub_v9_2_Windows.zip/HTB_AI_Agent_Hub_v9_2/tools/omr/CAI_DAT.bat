@echo off
chcp 65001 >nul 2>nul
title CAI DAT HTB VIETSCHOOL AGENT v3.18
cd /d "%~dp0"
echo ====================================================================
echo   CAI DAT THU VIEN CHO HTB VIETSCHOOL AGENT v3.18
echo   (Tu dong tim Python va cai bang python -m pip, khong can PATH)
echo ====================================================================
echo.
set "PY_EXE="
set "PY_ARGS="

if exist "%~dp0.venv\Scripts\python.exe" (
    set "PY_EXE=%~dp0.venv\Scripts\python.exe"
    goto :found_py
)
if exist "%~dp0..\.venv\Scripts\python.exe" (
    set "PY_EXE=%~dp0..\.venv\Scripts\python.exe"
    goto :found_py
)

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    py -3 -c "import sys; raise SystemExit(0 if sys.version_info>=(3,9) else 1)" >nul 2>nul
    if %ERRORLEVEL% EQU 0 (
        set "PY_EXE=py"
        set "PY_ARGS=-3"
        goto :found_py
    )
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    python -c "import sys; raise SystemExit(0 if sys.version_info>=(3,9) else 1)" >nul 2>nul
    if %ERRORLEVEL% EQU 0 (
        set "PY_EXE=python"
        goto :found_py
    )
)

for %%V in (313 312 311 310 39) do (
    if exist "%LocalAppData%\Programs\Python\Python%%V\python.exe" (
        set "PY_EXE=%LocalAppData%\Programs\Python\Python%%V\python.exe"
        goto :found_py
    )
    if exist "%ProgramFiles%\Python%%V\python.exe" (
        set "PY_EXE=%ProgramFiles%\Python%%V\python.exe"
        goto :found_py
    )
    if exist "%ProgramFiles(x86)%\Python%%V\python.exe" (
        set "PY_EXE=%ProgramFiles(x86)%\Python%%V\python.exe"
        goto :found_py
    )
    if exist "C:\Python%%V\python.exe" (
        set "PY_EXE=C:\Python%%V\python.exe"
        goto :found_py
    )
)

for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "$p = Get-ChildItem -Path \"$env:LOCALAPPDATA\Programs\Python\Python*\python.exe\",\"C:\Python*\python.exe\" -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName; if($p){Write-Output $p}"`) do (
    if exist "%%P" (
        set "PY_EXE=%%P"
        goto :found_py
    )
)

echo [LOI] Khong tim thay Python 3.9+ tren may tinh!
echo Hay tai va cai Python 3.11+ tu https://www.python.org/downloads/
echo (Nho tich chon "Add python.exe to PATH" khi cai Python).
pause
exit /b 1

:found_py
echo [OK] Da tim thay Python: "%PY_EXE%" %PY_ARGS%
"%PY_EXE%" %PY_ARGS% --version
echo.
echo [1/3] Kiem tra va kich hoat module pip (ensurepip)...
"%PY_EXE%" %PY_ARGS% -m ensurepip --upgrade >nul 2>nul
"%PY_EXE%" %PY_ARGS% -m pip install --upgrade pip
echo.
echo [2/3] Dang cai dat cac thu vien can thiet (selenium, pillow, openpyxl, opencv-python, numpy)...
"%PY_EXE%" %PY_ARGS% -m pip install --upgrade -r "%~dp0requirements.txt"
if %ERRORLEVEL% NEQ 0 (
    echo [THU LAI] Dang cai truc tiep tung goi thu vien...
    "%PY_EXE%" %PY_ARGS% -m pip install --upgrade selenium Pillow openpyxl opencv-python numpy
)
echo.
echo [3/3] Kiem tra thu vien sau khi cai dat...
"%PY_EXE%" %PY_ARGS% -c "import tkinter, selenium, PIL, openpyxl, cv2, numpy; print('[THANH CONG] Tat ca thu vien da san sang 100%%!')"
if %ERRORLEVEL% NEQ 0 (
    echo [CANH BAO] Co thu vien chua nap duoc. Hay kiem tra ket noi mang Internet roi chay lai CAI_DAT.bat.
    pause
    exit /b 1
)
echo.
echo ====================================================================
echo   CAI DAT HOAN TAT! Dang mo giao dien HTB VietSchool Agent...
echo   (Tu lan sau ban chi can bam CHAY_AGENT.bat hoac vietschool_sbd_agent.py)
echo ====================================================================
"%PY_EXE%" %PY_ARGS% "%~dp0vietschool_sbd_agent.py"
pause
