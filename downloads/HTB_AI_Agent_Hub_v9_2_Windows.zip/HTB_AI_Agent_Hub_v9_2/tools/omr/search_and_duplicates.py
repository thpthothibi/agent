# -*- coding: utf-8 -*-
"""Search students by Name & Class inside 'Chấm điểm' (Chấm bài giấy) and detect
Duplicate Names / Mis-shaded SBDs that cause students to have NO multiple-choice score.

Features:
1. `search_in_grading(webrows, official_roster, name_query='', class_query='', missing_roster=())`:
   - Finds matching sheets on the VietSchool grading table (by Name, Class, SBD, or image filename).
   - Also finds matching students in the official Excel roster (or 'HS thiếu bài') who currently
     have NO multiple-choice score / NO sheet on VietSchool, and automatically pairs each missing
     student with their top suspected mis-shaded or duplicate sheets on VietSchool!
2. `find_duplicate_names_and_missing_scores(webrows, official_roster, class_query='', missing_roster=())`:
   - Detects all Duplicate-Name (`Trùng họ tên`) and Duplicate-SBD (`Trùng SBD`) sheets on VietSchool.
   - Detects all Same-Name students in the Excel roster (`Trùng tên trong Excel`) where one student
     has a score and the other has NO score (e.g., shaded their namesake's SBD).
   - Detects all sheets on VietSchool that have NO score (`Phiếu trống điểm trắc nghiệm`).
   - Detects all students in the Excel roster (or `HS thiếu bài`) who have NO multiple-choice score,
     automatically ranking which unidentified (`Thiếu họ tên`) or duplicate (`Trùng SBD`) sheet on
     VietSchool is most likely their paper (by matching 3-digit Student ID suffix, 5..7/8 SBD columns,
     or same class/duplicate name).
3. `export_search_report(items, out_path)`:
   - Saves the search / duplicate-name investigation table to UTF-8 BOM CSV for Excel.
"""
from __future__ import annotations
import csv
from collections import defaultdict
from pathlib import Path
from vietschool_sbd_agent import blank, norm, class_key, same_class, number
from sbd_excel_only import _expand_old_sbd_pattern, _bubble_agreement_count, _names_match_fuzzy


def _given_name(full_name: str) -> str:
    tokens = norm(full_name).split()
    return tokens[-1] if tokens else ''


def _matches_name_query(candidate_name: str, candidate_sbd: str, candidate_file: str, query: str) -> bool:
    q = norm(query)
    if not q:
        return True
    cn = norm(candidate_name)
    cs = norm(candidate_sbd)
    cf = norm(candidate_file)
    if q in cn or q in cs or q in cf:
        return True
    q_tokens = q.split()
    c_tokens = cn.split()
    if q_tokens and c_tokens and all(any(qt in ct for ct in c_tokens) for qt in q_tokens):
        return True
    return False


def _matches_class_query(candidate_cls: str, class_query: str) -> bool:
    cq = str(class_query or '').strip()
    if not cq or norm(cq) in ('TAT CA', 'TAT CA LOP', 'ALL', '*'):
        return True
    if not candidate_cls:
        return False
    if same_class(candidate_cls, cq):
        return True
    return class_key(cq) in class_key(candidate_cls) or norm(cq).replace(' ', '') in norm(candidate_cls).replace(' ', '')


def find_suspected_sheets_for_student(student, webrows, official_roster=()):
    """Given a student {'sbd':..., 'name':..., 'class':...} who is missing their multiple-choice
    score on VietSchool, search `webrows` for the sheets most likely to be theirs:
    1. Sheets with the SAME student name or same given name (duplicate name / namesake collision).
    2. Duplicate-SBD sheets (`Trùng SBD`) in the same class or with a 1-digit SBD difference.
    3. Unidentified sheets (`Thiếu họ tên` / wrong SBD) whose SBD shares the student's 3-digit
       ID suffix (`sbd[5:8]`), or matches 5..7/8 digits of the student's SBD.
    Returns list of dicts: [{'file':..., 'old_sbd':..., 'old_name':..., 'old_class':..., 'code':..., 'score':..., 'why':..., 'rank_score':...}]
    """
    st_sbd = str(student.get('sbd') or '').strip()
    st_name = str(student.get('name') or '').strip()
    st_cls = str(student.get('class') or '').strip()
    st_norm = norm(st_name)
    st_given = _given_name(st_name)

    rows_by_sbd = defaultdict(list)
    rows_by_name = defaultdict(list)
    for r in (webrows or ()):
        rs = str(r.get('sbd') or '').strip()
        rn = norm(r.get('name'))
        if rs:
            rows_by_sbd[rs].append(r)
        if rn:
            rows_by_name[rn].append(r)

    suspects = []
    for r in (webrows or ()):
        r_file = str(r.get('file') or '').strip()
        r_sbd = str(r.get('sbd') or '').strip()
        r_name = str(r.get('name') or '').strip()
        r_cls = str(r.get('class') or '').strip()
        r_code = str(r.get('code') or '').strip()
        r_score = str(r.get('score') or '').strip()
        r_norm = norm(r_name)

        is_dup_sbd = bool(r_sbd and len(rows_by_sbd[r_sbd]) > 1)
        is_dup_name = bool(r_norm and len(rows_by_name[r_norm]) > 1)
        is_missing_name = blank(r_name)

        # Compute digit similarity between student's SBD and sheet's SBD/pattern
        pat = _expand_old_sbd_pattern(r_sbd)
        mask = [[int(c)] if c.isdigit() else [] for c in pat] if len(pat) == 8 else []
        def_m, comp_m, conf_m = _bubble_agreement_count(st_sbd, mask) if (len(st_sbd) == 8 and len(mask) == 8) else (0, 0, 8)
        suffix3_match = (len(st_sbd) == 8 and len(pat) == 8 and pat[:2] == st_sbd[:2] and pat[5:8] == st_sbd[5:8])
        same_cls = bool(st_cls and r_cls and same_class(st_cls, r_cls))
        exact_same_name = bool(st_norm and r_norm and (st_norm == r_norm or _names_match_fuzzy(st_name, r_name)))
        same_given_in_cls = bool(same_cls and st_given and r_norm and _given_name(r_name) == st_given)

        reasons = []
        score_pts = 0

        if exact_same_name:
            reasons.append(f"Trùng họ tên '{r_name}' ({r_cls or 'chưa rõ lớp'})")
            score_pts += 100
        elif same_given_in_cls and is_dup_sbd:
            reasons.append(f"Cùng tên '{st_given}' trong lớp {st_cls} & đang trùng SBD {r_sbd}")
            score_pts += 85

        if is_dup_sbd and same_cls:
            reasons.append(f"Phiếu trùng SBD {r_sbd} cùng lớp {st_cls} (hiện tên {r_name})")
            score_pts += 75
        elif is_dup_sbd and def_m >= 6:
            reasons.append(f"Phiếu trùng SBD {r_sbd} khớp {def_m}/8 số với SBD {st_sbd}")
            score_pts += 70

        if is_missing_name:
            if suffix3_match:
                reasons.append(f"Phiếu thiếu tên có SBD '{r_sbd}' khớp mã số HS #{st_sbd[5:8]}")
                score_pts += 90
            elif def_m >= 5:
                reasons.append(f"Phiếu thiếu tên có SBD '{r_sbd}' khớp {def_m}/8 cột với {st_sbd}")
                score_pts += 40 + def_m * 6
            elif len(st_sbd) == 8 and r_sbd and st_sbd[5:8] in r_sbd:
                reasons.append(f"Phiếu thiếu tên có SBD '{r_sbd}' chứa đuôi #{st_sbd[5:8]}")
                score_pts += 55

        if score_pts > 0:
            suspects.append({
                'file': r_file,
                'old_sbd': r_sbd,
                'old_name': r_name,
                'old_class': r_cls,
                'code': r_code,
                'score': r_score,
                'why': '; '.join(reasons),
                'rank_score': score_pts + def_m,
                'matched_cols': def_m,
            })

    suspects.sort(key=lambda x: x['rank_score'], reverse=True)
    return suspects[:5]


def search_in_grading(webrows, official_roster=(), name_query='', class_query='', missing_roster=()):
    """Search by `name_query` and `class_query` across BOTH the VietSchool grading table (`webrows`)
    and the official Excel student roster (`official_roster` / `missing_roster`).

    Returns (ui_records_list, summary_dict) where each item in `ui_records_list` has the exact
    dict format expected by the UI Treeview (`file`, `reason`, `old`, `proposal`, `status`, `note`).
    """
    rows_by_sbd = defaultdict(list)
    rows_by_name = defaultdict(list)
    graded_sbds = set()
    all_web_sbds = set()
    for r in (webrows or ()):
        rs = str(r.get('sbd') or '').strip()
        rn = norm(r.get('name'))
        if rs:
            rows_by_sbd[rs].append(r)
            all_web_sbds.add(rs)
            if not blank(r.get('score')) and not blank(r.get('name')):
                graded_sbds.add(rs)
        if rn:
            rows_by_name[rn].append(r)

    official_roster = list(official_roster or ())
    known = {str(st.get('sbd') or '').strip() for st in official_roster}
    official_roster += [st for st in (missing_roster or ()) if str(st.get('sbd') or '').strip() not in known]
    official_by_sbd = {str(st.get('sbd') or '').strip(): st for st in (official_roster or ()) if st.get('sbd')}

    ui_items = []
    seen_files = set()
    matched_web_count = 0
    missing_score_count = 0

    # 1. Search on VietSchool grading table (`webrows`)
    for r in (webrows or ()):
        r_file = str(r.get('file') or '').strip()
        r_sbd = str(r.get('sbd') or '').strip()
        r_name = str(r.get('name') or '').strip()
        r_cls = str(r.get('class') or '').strip()
        r_code = str(r.get('code') or '').strip()
        r_score = str(r.get('score') or '').strip()

        # Also check official Excel name/class if VietSchool left name/class blank
        excel_st = official_by_sbd.get(r_sbd, {})
        eff_name = str(excel_st.get('name') or '') if blank(r_name) else r_name
        eff_cls = str(excel_st.get('class') or '') if blank(r_cls) else r_cls

        if not (_matches_name_query(eff_name, r_sbd, r_file, name_query) or
                _matches_name_query(str(excel_st.get('name') or ''), r_sbd, r_file, name_query)):
            continue
        if not _matches_class_query(eff_cls, class_query):
            continue

        matched_web_count += 1
        seen_files.add(r_file)
        flags = []
        if blank(r_name):
            flags.append('Thiếu họ tên')
        if blank(r_score):
            flags.append('Không có điểm TN')
        if r_sbd and len(rows_by_sbd[r_sbd]) > 1:
            flags.append(f'Trùng SBD ({len(rows_by_sbd[r_sbd])} phiếu)')
        if norm(eff_name) and len(rows_by_name[norm(eff_name)]) > 1:
            flags.append(f'Trùng họ tên ({len(rows_by_name[norm(eff_name)])} phiếu)')
        if official_by_sbd and r_sbd not in official_by_sbd:
            flags.append('SBD ngoài Excel')

        status_str = f"Điểm: {r_score}" if not blank(r_score) else 'KHÔNG CÓ ĐIỂM TN'
        if flags:
            status_str = ('Cần kiểm tra • ' if blank(r_score) or 'Trùng' in ' '.join(flags) or blank(r_name) else '') + status_str

        note_parts = [f"Lớp: {eff_cls or '(trống)'}", f"SBD hiện tại: {r_sbd or '(trống)'}", f"Mã đề: {r_code or '(trống)'}", f"Điểm: {r_score or '(chưa có điểm)'}"]
        if flags:
            note_parts.append('Cảnh báo: ' + ', '.join(flags))

        ui_items.append({
            'file': r_file,
            'reason': flags if flags else ['Phiếu trên bảng chấm'],
            'old': dict(r),
            'proposal': {'sbd': r_sbd, 'code': r_code, 'name': eff_name, 'class': eff_cls},
            'after': {},
            'status': status_str,
            'note': ' | '.join(note_parts),
        })

    # 2. Search in Excel Roster & 'HS thiếu bài' for matching students who have NO sheet / NO score on VietSchool!
    combined_roster = list(official_roster or ())
    seen_roster_sbds = {str(st.get('sbd') or '').strip() for st in combined_roster}
    for ms in (missing_roster or ()):
        ms_sbd = str(ms.get('sbd') or '').strip()
        if ms_sbd and ms_sbd not in seen_roster_sbds:
            combined_roster.append(ms)
            seen_roster_sbds.add(ms_sbd)

    for st in combined_roster:
        st_sbd = str(st.get('sbd') or '').strip()
        st_name = str(st.get('name') or '').strip()
        st_cls = str(st.get('class') or '').strip()
        if not st_sbd or not st_name:
            continue
        if not _matches_name_query(st_name, st_sbd, '', name_query):
            continue
        if not _matches_class_query(st_cls, class_query):
            continue

        # Check if this student already has a valid scored sheet on webrows
        if st_sbd in graded_sbds and len(rows_by_sbd.get(st_sbd, ())) == 1:
            continue

        # If the student has no sheet at all on webrows (missing score because they shaded the wrong SBD!)
        if st_sbd not in all_web_sbds:
            missing_score_count += 1
            suspects = find_suspected_sheets_for_student(st, webrows, official_roster=combined_roster)
            if suspects:
                top_sus = suspects[0]
                sus_summary = '; '.join(
                    f"{s['file']} (SBD đang ghi: {s['old_sbd'] or 'trống'}, {s['why']})"
                    for s in suspects[:3]
                )
                # Use the top suspected sheet's filename if not already shown, or create a linked row
                row_id = top_sus['file'] if top_sus['file'] not in seen_files else f"[THIẾU BÀI: {st_sbd}] { top_sus['file'] }"
                seen_files.add(row_id)
                ui_items.append({
                    'file': row_id,
                    'target_file': top_sus['file'],
                    'reason': ['HS chưa có điểm TN (nghi tô sai SBD)'],
                    'old': {'file': top_sus['file'], 'sbd': top_sus['old_sbd'], 'code': top_sus['code'], 'name': top_sus['old_name'], 'class': top_sus['old_class'], 'score': top_sus['score']},
                    'proposal': {'sbd': st_sbd, 'code': top_sus['code'], 'name': st_name, 'class': st_cls},
                    'after': {},
                    'status': 'KHÔNG CÓ ĐIỂM TN (Nghi tô sai)',
                    'note': f"HS {st_name} ({st_cls} - SBD đúng: {st_sbd}) chưa có bài trên bảng! Phiếu nghi của HS này: {sus_summary}",
                })
            else:
                row_id = f"[CHƯA CÓ BÀI] {st_sbd} - {st_name}"
                ui_items.append({
                    'file': row_id,
                    'target_file': '',
                    'reason': ['HS chưa có bài / không có điểm TN'],
                    'old': {'file': '', 'sbd': '', 'code': '', 'name': st_name, 'class': st_cls, 'score': ''},
                    'proposal': {'sbd': st_sbd, 'code': '', 'name': st_name, 'class': st_cls},
                    'after': {},
                    'status': 'CHƯA CÓ ĐIỂM TN',
                    'note': f"HS {st_name} (Lớp {st_cls} - SBD chuẩn: {st_sbd}) hiện chưa có phiếu/điểm trắc nghiệm trên bảng VietSchool.",
                })

    summary = {
        'total_results': len(ui_items),
        'matched_sheets': matched_web_count,
        'missing_score_students': missing_score_count,
    }
    return ui_items, summary


def find_duplicate_names_and_missing_scores(webrows, official_roster=(), class_query='', missing_roster=()):
    """Comprehensive detector for:
    1. Duplicate student names (`Trùng họ tên`) and duplicate SBDs (`Trùng SBD`) on the VietSchool table,
       paired with any missing-score student in the same class / same name / nearby SBD.
    2. Duplicate student names in the Excel roster (`Trùng họ tên trong Excel`) where one namesake
       has a sheet and the other has NO multiple-choice score (`không có điểm trắc nghiệm`).
    3. Sheets on VietSchool that have NO multiple-choice score (`Thiếu điểm trắc nghiệm` / `Thiếu họ tên`).
    4. Students in the Excel roster / `HS thiếu bài` who have NO multiple-choice score (`Không có điểm TN`)
       along with their top suspected mis-shaded sheets on VietSchool.
    """
    combined_roster = list(official_roster or ())
    seen_r_sbds = {str(st.get('sbd') or '').strip() for st in combined_roster}
    for ms in (missing_roster or ()):
        ms_sbd = str(ms.get('sbd') or '').strip()
        if ms_sbd and ms_sbd not in seen_r_sbds:
            combined_roster.append(ms)
            seen_r_sbds.add(ms_sbd)

    rows_by_sbd = defaultdict(list)
    rows_by_name = defaultdict(list)
    rows_by_given_cls = defaultdict(list)
    all_web_sbds = set()
    graded_sbds = set()

    for r in (webrows or ()):
        rs = str(r.get('sbd') or '').strip()
        rn = norm(r.get('name'))
        rc = class_key(r.get('class'))
        if rs:
            rows_by_sbd[rs].append(r)
            all_web_sbds.add(rs)
            if not blank(r.get('score')) and not blank(r.get('name')):
                graded_sbds.add(rs)
        if rn:
            rows_by_name[rn].append(r)
            if rc:
                rows_by_given_cls[(_given_name(rn), rc)].append(r)

    roster_by_name = defaultdict(list)
    roster_by_cls = defaultdict(list)
    unassigned_students = []
    for st in combined_roster:
        sbd = str(st.get('sbd') or '').strip()
        nm = str(st.get('name') or '').strip()
        cls = str(st.get('class') or '').strip()
        if not sbd or not nm:
            continue
        roster_by_name[norm(nm)].append(st)
        roster_by_cls[class_key(cls)].append(st)
        if sbd not in all_web_sbds:
            unassigned_students.append(st)

    results = []
    seen_keys = set()

    # GROUP 1: Duplicate Names or Duplicate SBDs on the VietSchool table (`Trùng tên / Trùng SBD`)
    for r in (webrows or ()):
        r_file = str(r.get('file') or '').strip()
        r_sbd = str(r.get('sbd') or '').strip()
        r_name = str(r.get('name') or '').strip()
        r_cls = str(r.get('class') or '').strip()
        r_code = str(r.get('code') or '').strip()
        r_score = str(r.get('score') or '').strip()
        r_norm = norm(r_name)

        if not _matches_class_query(r_cls, class_query) and class_query:
            continue

        dup_sbd_group = rows_by_sbd.get(r_sbd, []) if r_sbd else []
        dup_name_group = rows_by_name.get(r_norm, []) if r_norm else []
        excel_same_name = roster_by_name.get(r_norm, []) if r_norm else []

        reasons = []
        if len(dup_name_group) > 1:
            reasons.append(f'Trùng họ tên trên bảng ({len(dup_name_group)} phiếu)')
        if len(dup_sbd_group) > 1:
            reasons.append(f'Trùng SBD trên bảng ({len(dup_sbd_group)} phiếu)')
        if len(excel_same_name) > 1:
            missing_namesakes = [x for x in excel_same_name if str(x.get('sbd') or '').strip() not in all_web_sbds]
            if missing_namesakes:
                reasons.append(f'Trùng tên với HS đang mất điểm ({len(missing_namesakes)} HS)')

        if not reasons:
            continue

        # Find which missing-score student(s) in the same class, same name, or nearby SBD could own this duplicate sheet!
        candidate_missing = []
        if r_norm and len(excel_same_name) > 1:
            for st in excel_same_name:
                if str(st.get('sbd') or '').strip() not in all_web_sbds:
                    candidate_missing.append((100, st, 'Trùng họ tên trong Excel chưa có điểm'))
        if r_cls:
            for st in roster_by_cls.get(class_key(r_cls), ()):
                st_sbd = str(st.get('sbd') or '').strip()
                if st_sbd not in all_web_sbds:
                    sim = sum(a == b for a, b in zip(st_sbd, r_sbd)) if len(st_sbd) == 8 and len(r_sbd) == 8 else 0
                    same_gn = (_given_name(st.get('name', '')) == _given_name(r_name)) if r_name else False
                    candidate_missing.append((80 if same_gn else 50 + sim, st, f"Cùng lớp {st.get('class')} chưa có bài (khớp {sim}/8 số SBD)"))
        for st in unassigned_students:
            st_sbd = str(st.get('sbd') or '').strip()
            if len(st_sbd) == 8 and len(r_sbd) == 8 and st_sbd != r_sbd:
                sim = sum(a == b for a, b in zip(st_sbd, r_sbd))
                if sim >= 7:
                    candidate_missing.append((75 + sim, st, f"Lệch 1 số SBD ({st_sbd}) & chưa có bài"))

        candidate_missing.sort(key=lambda x: x[0], reverse=True)
        seen_cand_sbds = set()
        unique_cands = []
        for _, st, why_c in candidate_missing:
            cs = str(st.get('sbd') or '').strip()
            if cs not in seen_cand_sbds:
                seen_cand_sbds.add(cs)
                unique_cands.append((st, why_c))

        prop_sbd = r_sbd
        prop_name = r_name
        prop_cls = r_cls
        sug_note = ''
        if unique_cands:
            top_st, _ = unique_cands[0]
            if len(unique_cands) == 1:
                prop_sbd = str(top_st.get('sbd') or '').strip()
                prop_name = str(top_st.get('name') or '').strip()
                prop_cls = str(top_st.get('class') or '').strip()
            sug_list = '; '.join(f"{st['sbd']} - {st['name']} ({st['class']}) [{w}]" for st, w in unique_cands[:4])
            sug_note = f" | Gợi ý HS mất điểm nghi tô nhầm vào phiếu này: {sug_list}"

        seen_keys.add(r_file)
        results.append({
            'file': r_file,
            'target_file': r_file,
            'reason': reasons,
            'old': dict(r),
            'proposal': {'sbd': prop_sbd, 'code': r_code, 'name': prop_name, 'class': prop_cls},
            'after': {},
            'status': f"TRÙNG TÊN/SBD (Điểm: {r_score or 'Trống'})",
            'note': f"Phiếu đang ghi: {r_sbd} — {r_name} ({r_cls}), Mã đề: {r_code}, Điểm: {r_score or 'Trống'}{sug_note}",
        })

    # GROUP 2: Sheets on VietSchool that are missing Name or missing Score (`Tô sai SBD / Không có điểm TN`)
    for r in (webrows or ()):
        r_file = str(r.get('file') or '').strip()
        if r_file in seen_keys:
            continue
        r_sbd = str(r.get('sbd') or '').strip()
        r_name = str(r.get('name') or '').strip()
        r_cls = str(r.get('class') or '').strip()
        r_code = str(r.get('code') or '').strip()
        r_score = str(r.get('score') or '').strip()

        if class_query and r_cls and not _matches_class_query(r_cls, class_query):
            continue
        if not blank(r_name) and not blank(r_score):
            continue

        # If class_query is set and r_cls is blank, check if any candidate student in that class matches this sheet
        pat = _expand_old_sbd_pattern(r_sbd)
        mask = [[int(c)] if c.isdigit() else [] for c in pat] if len(pat) == 8 else []
        matching_unassigned = []
        for st in unassigned_students:
            if class_query and not _matches_class_query(st.get('class', ''), class_query):
                continue
            st_sbd = str(st.get('sbd') or '').strip()
            def_m, _, _ = _bubble_agreement_count(st_sbd, mask) if (len(st_sbd) == 8 and len(mask) == 8) else (0, 0, 8)
            suffix3 = (len(st_sbd) == 8 and len(pat) == 8 and pat[:2] == st_sbd[:2] and pat[5:8] == st_sbd[5:8])
            if suffix3 or def_m >= 5:
                matching_unassigned.append((100 if suffix3 else def_m, st, f"khớp mã HS #{st_sbd[5:8]}" if suffix3 else f"khớp {def_m}/8 cột"))

        if class_query and blank(r_cls) and not matching_unassigned:
            continue

        matching_unassigned.sort(key=lambda x: x[0], reverse=True)
        prop_sbd = r_sbd
        prop_name = r_name
        prop_cls = r_cls
        sug_note = ''
        if matching_unassigned:
            top_st = matching_unassigned[0][1]
            if len(matching_unassigned) == 1 or matching_unassigned[0][0] == 100:
                prop_sbd = top_st['sbd']
                prop_name = top_st['name']
                prop_cls = top_st['class']
            sug_str = '; '.join(f"{st['sbd']} - {st['name']} ({st['class']}) [{w}]" for _, st, w in matching_unassigned[:4])
            sug_note = f" | Gợi ý HS chưa có bài khớp phiếu này: {sug_str}"

        reasons = []
        if blank(r_name):
            reasons.append('Thiếu họ tên (tô sai SBD)')
        if blank(r_score):
            reasons.append('Không có điểm trắc nghiệm')

        seen_keys.add(r_file)
        results.append({
            'file': r_file,
            'target_file': r_file,
            'reason': reasons,
            'old': dict(r),
            'proposal': {'sbd': prop_sbd, 'code': r_code, 'name': prop_name, 'class': prop_cls},
            'after': {},
            'status': 'KHÔNG CÓ ĐIỂM TN' if blank(r_score) else f'THIẾU TÊN (Điểm: {r_score})',
            'note': f"SBD trên phiếu: '{r_sbd}', Mã đề: '{r_code}', Điểm: '{r_score or 'Trống'}'{sug_note}",
        })

    # GROUP 3: Unassigned students in Excel / HS thiếu bài who have NO sheet / NO score on VietSchool
    for st in unassigned_students:
        st_sbd = str(st.get('sbd') or '').strip()
        st_name = str(st.get('name') or '').strip()
        st_cls = str(st.get('class') or '').strip()
        if class_query and not _matches_class_query(st_cls, class_query):
            continue

        suspects = find_suspected_sheets_for_student(st, webrows, official_roster=combined_roster)
        top_file = suspects[0]['file'] if suspects else ''
        row_id = f"[HS MẤT ĐIỂM: {st_sbd}] {top_file}" if top_file else f"[HS CHƯA CÓ BÀI] {st_sbd} - {st_name}"
        if row_id in seen_keys:
            continue
        seen_keys.add(row_id)

        if suspects:
            sus_text = '; '.join(f"{s['file']} (SBD: {s['old_sbd']}, {s['why']})" for s in suspects[:3])
            note_str = f"HS {st_name} ({st_cls} - SBD đúng: {st_sbd}) chưa có điểm TN! Phiếu nghi của HS này: {sus_text}"
        else:
            note_str = f"HS {st_name} ({st_cls} - SBD đúng: {st_sbd}) chưa có phiếu/điểm trắc nghiệm trên bảng."

        results.append({
            'file': row_id,
            'target_file': top_file,
            'reason': ['HS không có điểm TN (nghi tô sai / trùng tên)' if suspects else 'HS chưa có bài trên bảng'],
            'old': {'file': top_file, 'sbd': suspects[0]['old_sbd'] if suspects else '', 'code': suspects[0]['code'] if suspects else '', 'name': st_name, 'class': st_cls, 'score': ''},
            'proposal': {'sbd': st_sbd, 'code': suspects[0]['code'] if suspects else '', 'name': st_name, 'class': st_cls},
            'after': {},
            'status': 'HS MẤT ĐIỂM TN',
            'note': note_str,
        })

    summary = {
        'total_results': len(results),
        'unassigned_students': len(unassigned_students),
    }
    return results, summary


def export_search_report(items, out_path: Path):
    """Export search / duplicate-name / missing-score investigation results to CSV."""
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow([
            'Ảnh phiếu / Mã dòng', 'Phân loại', 'SBD trên bảng', 'SBD đúng đề xuất (Excel)',
            'Mã đề', 'Họ và tên học sinh', 'Lớp', 'Điểm hiện tại', 'Trạng thái', 'Chi tiết & Gợi ý phiếu nghi vấn'
        ])
        def safe(v):
            s = str(v if v is not None else '')
            return "'" + s if s.startswith(('=', '+', '-', '@')) or (s.startswith('0') and s.isdigit()) else s
        for r in items:
            old = r.get('old', {})
            prop = r.get('proposal', {})
            writer.writerow([
                safe(r.get('file', '')),
                safe('; '.join(r.get('reason', []))),
                safe(old.get('sbd', '')),
                safe(prop.get('sbd', '')),
                safe(prop.get('code') or old.get('code', '')),
                safe(prop.get('name') or old.get('name', '')),
                safe(prop.get('class') or old.get('class', '')),
                safe(old.get('score', '')),
                safe(r.get('status', '')),
                safe(r.get('note', '')),
            ])
    return out_path


def list_students_in_batch(webrows, official_roster=(), missing_roster=()):
    """List current-batch sheets and explicitly missing students, without importing other batches."""
    webrows = list(webrows or ())
    missing_roster = list(missing_roster or ())
    batch_sbds = {str(r.get('sbd') or '').strip() for r in webrows + missing_roster}
    scoped_roster = [st for st in (official_roster or ())
                     if str(st.get('sbd') or '').strip() in batch_sbds]
    items, stats = search_in_grading(webrows, scoped_roster, missing_roster=missing_roster)
    stats['named_results'] = sum(not blank(r.get('proposal', {}).get('name')) for r in items)
    stats['unnamed_results'] = len(items) - stats['named_results']
    return items, stats
