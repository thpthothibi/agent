# -*- coding: utf-8 -*-
"""SBD & Exam Code targeted tests."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import cv2
import numpy as np
from openpyxl import Workbook
from phieu_vision import read_bubbles, parse_ocr_handwriting_text
from roster_excel import load_roster
from sbd_candidate_filter import select_sbd_anomalies
from sbd_excel_only import ExcelSBDRunner, sbd_evidence, code_evidence, extract_handwriting
from test_batch import BatchBrowser, bubble, row
from vietschool_sbd_agent import NoAI, DOM


class TargetedSBDTests(unittest.TestCase):
    def setUp(self):
        self.official=[
            {'sbd':'20006140','name':'Bùi Gia Huy','class':'11B06'},
            {'sbd':'20006141','name':'Nguyễn Văn An','class':'11B06'},
            {'sbd':'20006142','name':'Nguyễn Thị Bình','class':'11B06'},
            {'sbd':'20008205','name':'Ngô Quốc Lâm','class':'11A08'},
            {'sbd':'20006143','name':'Trần Ngọc Khánh','class':'11B06'},
            {'sbd':'20006144','name':'Trần Ngọc Khánh','class':'11B06'},
            {'sbd':'20006145','name':'Lê Thanh Hải','class':'11B06'},
        ]

    def selected(self,rows):
        pairs,stats=select_sbd_anomalies(rows,self.official)
        return {r['file']:why for r,why in pairs},stats

    def test_healthy_rows_never_selected(self):
        rows=[row('ok.jpg','Bùi Gia Huy','20006140',cls='11B6'),
              row('score_only.jpg','Nguyễn Văn An','20006141',score='',cls='11B6'),
              row('code_only.jpg','Nguyễn Thị Bình','20006142',code='',cls='11B6')]
        selected,stats=self.selected(rows)
        self.assertFalse(selected)
        self.assertEqual(stats['skipped'],3)

    def test_same_sbd_missing_name_can_be_resaved_only_when_verified(self):
        old=row('missing.jpg',name='',sbd='20006140',cls='',score='5')
        action,p,why=sbd_evidence(old,bubble('20006140'),self.official,[old])
        self.assertEqual(action,'write')
        self.assertEqual(p['sbd'],'20006140')
        self.assertIn('Thiếu họ tên',why)

    def test_faint_bubble_marks_to_mo_recovered_directly_by_read_bubbles(self):
        image=np.full((1000,1400,3),255,np.uint8)
        xs=[450+32*i for i in range(8)]
        ys=[220+35*j for j in range(10)]
        sbd='20008205'
        for x in xs:
            for y in ys:
                cv2.circle(image,(x,y),12,(50,50,50),2)
        for i,d in enumerate(sbd):
            y=ys[int(d)]
            if i in (0,1,2,3):
                cv2.circle(image,(xs[i],y),9,(40,40,40),-1)
            elif i in (4,5):
                cv2.circle(image,(xs[i],y),5,(110,110,110),-1)
            else:
                cv2.circle(image,(xs[i],y),9,(172,172,172),-1)
        raw=cv2.imencode('.png',image)[1].tobytes()
        res=read_bubbles(raw)
        self.assertEqual(res['sbd'],'20008205')

    def test_grade_prefix_plus_unique_3digit_suffix_when_room_shaded_in_middle_cols(self):
        roster = [
            {'sbd': '10019714', 'name': 'Lê Hoàng Nam', 'class': '10A19'},
            {'sbd': '10016132', 'name': 'Trần Minh Quân', 'class': '10A16'},
            {'sbd': '10014835', 'name': 'Phạm Gia Bảo', 'class': '10A14'},
            {'sbd': '10006264', 'name': 'Võ Thị Ngọc', 'class': '10A06'},
        ]
        old1 = row('p1.jpg', name='', sbd='10001714', code='5746', cls='', score='3.55')
        act1, p1, why1 = sbd_evidence(old1, bubble('10001714', '5746'), roster, [old1])
        self.assertEqual(act1, 'write', why1)
        self.assertEqual(p1['sbd'], '10019714')

        old2 = row('p2.jpg', name='', sbd='10111264', code='6014', cls='', score='4.55')
        act2, p2, why2 = sbd_evidence(old2, bubble('10111264', '6014'), roster, [old2])
        self.assertEqual(act2, 'write', why2)
        self.assertEqual(p2['sbd'], '10006264')

    def test_exam_code_template_and_auto_suggest_fill_on_real_batch_patterns(self):
        from exam_codes import load_exam_codes
        cat = load_exam_codes(Path(__file__).with_name('MAU_DANH_SACH_MA_DE.xlsx'))
        self.assertEqual(sorted(cat.all_codes), ['1631', '1677', '1777', '1946', '3138', '4651', '5573', '9741'])

        for wrong_c, expected_c in [('5570', '5573'), ('4650', '4651'), ('3038', '3138'), ('9740', '9741')]:
            old_r = row('f.jpg', name='HS A', sbd='10006212', code=wrong_c, score='')
            dec, chosen, why, hint = code_evidence(old_r, bubble('10006212', wrong_c), cat, [old_r])
            self.assertEqual(dec, 'write', why)
            self.assertEqual(chosen, expected_c)

        for short_c, expected_c in [('4 5', '4651'), ('5', '5573')]:
            old_r = row('f2.jpg', name='', sbd='10001714', code=short_c, score='')
            dec, chosen, why, hint = code_evidence(old_r, None, cat, [old_r])
            self.assertEqual(dec, 'write', why)
            self.assertEqual(chosen, expected_c)

    def test_no_table_reload_after_each_save_preserves_scroll_position(self):
        reload_calls = []
        old1 = row('s1.jpg', name='', sbd='20008905', code='101', cls='', score='4.00')
        old2 = row('s2.jpg', name='', sbd='2000?140', code='102', cls='', score='5.00')
        class ScrollPreservingBrowser(BatchBrowser):
            def reload_grading_table(self):
                reload_calls.append(self.current)
            def locate_visible(self, file):
                return next((dict(r) for r in self.data if r['file'] == file), None)
            def read_modal_fields(self):
                if self.current == 's1.jpg':
                    return {'sbd': '20008205', 'code': '101', 'name': 'Ngô Quốc Lâm', 'class': '11A08'}
                return {'sbd': '20006140', 'code': '102', 'name': 'Bùi Gia Huy', 'class': '11B06'}
        b_map = {'s1.jpg': bubble('20008905', '0101'), 's2.jpg': bubble('20006140', '0102')}
        with tempfile.TemporaryDirectory() as tmp:
            b = ScrollPreservingBrowser([old1, old2])
            with patch('sbd_excel_only.read_bubbles', side_effect=lambda raw: b_map[raw.decode()]):
                runner = ExcelSBDRunner(b, NoAI(), lambda *a: None, lambda: None, tmp,
                    official_roster=self.official, audit_all=True)
                runner.run()
            self.assertEqual(reload_calls, [])
            self.assertEqual([r.status for r in runner.records], ['Đã xác minh SBD', 'Đã xác minh SBD'])
            self.assertTrue((Path(tmp) / 'goi_y_sbd.csv').exists())

    def test_handwritten_sbd_boxed_digits_and_detailed_goi_y_sbd_export(self):
        roster = [
            {'sbd': '10019714', 'name': 'Lê Hoàng Nam', 'class': '10A19'},
            {'sbd': '10016542', 'name': 'Trần Minh Quân', 'class': '10A16'},
            {'sbd': '10016548', 'name': 'Phạm Gia Bảo', 'class': '10A16'},
        ]
        hw = parse_ocr_handwriting_text('Họ và tên: ...\nSBD: 1 O | O 1 9 | 7 I 4\nMã đề: 5573', official_roster=roster)
        self.assertIsNotNone(hw)
        self.assertEqual(hw['sbd'], '10019714')
        self.assertEqual(hw['code'], '5573')

        r1 = row('hw_sbd.jpg', name='', sbd='10 49', code='5573', cls='', score='5')
        r2 = row('ambig_1654.jpg', name='', sbd='1001654', code='5573', cls='', score='5')
        with tempfile.TemporaryDirectory() as tmp:
            b = BatchBrowser([r1, r2])
            with patch('sbd_excel_only.read_bubbles', side_effect=ValueError('blur')), \
                 patch('sbd_excel_only.read_handwriting_ocr', side_effect=lambda top, *a, **kw: hw if top == b'hw_sbd.jpg' else None):
                runner = ExcelSBDRunner(b, NoAI(), lambda *a: None, lambda: None, tmp,
                    official_roster=roster, audit_all=True)
                runner.run()
            self.assertEqual(runner.records[0].status, 'Đã xác minh SBD')
            self.assertEqual(runner.records[0].proposal['sbd'], '10019714')
            self.assertEqual(runner.records[1].status, 'Cần kiểm tra')
            self.assertIn('Gợi ý SBD gần nhất:', runner.records[1].note)
            self.assertIn('10016542', runner.records[1].note)
            self.assertIn('10016548', runner.records[1].note)
            goi_y_csv = (Path(tmp) / 'goi_y_sbd.csv').read_text(encoding='utf-8-sig')
            self.assertIn('10019714', goi_y_csv)
            self.assertIn('10016542 - Trần Minh Quân', goi_y_csv)


if __name__=='__main__':
    unittest.main()
