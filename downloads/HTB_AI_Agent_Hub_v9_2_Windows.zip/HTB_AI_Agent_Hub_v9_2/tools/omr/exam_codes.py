# -*- coding: utf-8 -*-
"""Danh mục mã đề theo môn hoặc theo đợt chấm: CSV/XLSX thuần Python, không tải dữ liệu lên mạng.

Hỗ trợ cả 2 định dạng file mẫu:
1. Chỉ có cột 'Mã đề' (hoặc cột 'Môn thi' để trống): dùng chung cho toàn bộ đợt chấm hiện tại.
2. Có cột 'Môn thi' + 'Mã đề' (và tùy chọn sheet 'Gán môn phiếu'): phân theo từng môn.
"""
from __future__ import annotations
import csv
import io
import re
import unicodedata
import zipfile
from collections import defaultdict
from pathlib import Path
from xml.etree import ElementTree as ET

XNS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
RNS = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
PKG = '{http://schemas.openxmlformats.org/package/2006/relationships}'
HEADERS_SUBJECT = {'mon','monthi','tenmon','monhoc','monday','bo mon','subject','monthituychon'}
HEADERS_CODE = {'made','made thi','madechinhthuc','madethi','de','examcode','mabaithi','cacmade'}
HEADERS_FILE = {'anhphieu','phieutraloi','tenanh','tenfile','file','filename','anhbaithi'}
DEFAULT_BATCH_SUBJECT = 'Đợt chấm hiện tại'

SUBJECT_ALIASES = {'hoa':'hoahoc','hoahoc':'hoahoc','su':'lichsu','lichsu':'lichsu',
    'dia':'diali','diali':'diali','dia ly':'diali','toan':'toan',
    'ktpl':'giaoduckinhtevaphapluat','gdktpl':'giaoduckinhtevaphapluat',
    'giaoduckinhtevaphapluat':'giaoduckinhtevaphapluat',
    'ly':'vatli','vatli':'vatli','sinh':'sinhhoc','sinhhoc':'sinhhoc',
    'van':'nguvan','nguvan':'nguvan','tienganh':'tienganh','anh':'tienganh'}


def subject_key(value):
    key=normal(value).replace(' ','').replace('-','')
    return SUBJECT_ALIASES.get(key,key)


def normal(v):
    v=unicodedata.normalize('NFD',str(v or '')).replace('đ','d').replace('Đ','D')
    return ''.join(c for c in v if unicodedata.category(c)!='Mn').lower().strip()


def header(v):
    h=re.sub(r'[^a-z0-9]','',normal(v))
    if h.startswith('monthi'):
        return 'monthi'
    if h.startswith('made'):
        return 'made'
    return h


def _style_zero_pad_map(z):
    pad_by_xf={}
    if 'xl/styles.xml' not in z.namelist():
        return pad_by_xf
    try:
        sroot=ET.fromstring(z.read('xl/styles.xml'))
        num_fmts={}
        for nf in sroot.findall('.//'+XNS+'numFmts/'+XNS+'numFmt'):
            fmt_id=nf.attrib.get('numFmtId','')
            code=nf.attrib.get('formatCode','')
            m=re.fullmatch(r'0{2,6}',code.strip())
            if fmt_id and m:
                num_fmts[fmt_id]=len(m.group(0))
        for idx,xf in enumerate(sroot.findall('.//'+XNS+'cellXfs/'+XNS+'xf')):
            fmt_id=xf.attrib.get('numFmtId','')
            if fmt_id in num_fmts:
                pad_by_xf[str(idx)]=num_fmts[fmt_id]
    except Exception:
        pass
    return pad_by_xf


def _cell_text(c, shared, pad_by_xf=None):
    kind=c.get('t','')
    if kind=='inlineStr':return ''.join(t.text or '' for t in c.iter(XNS+'t')).strip()
    v=c.find(XNS+'v')
    if v is None:return ''
    value=(v.text or '').strip()
    if kind=='s':
        try:return shared[int(value)].strip()
        except (ValueError,IndexError):return ''
    if pad_by_xf and kind in ('','n'):
        s_idx=c.get('s','')
        width=pad_by_xf.get(s_idx,0)
        if width and re.fullmatch(r'\d+(\.0)?',value):
            digits=value[:-2] if value.endswith('.0') else value
            if len(digits)<width:
                return digits.zfill(width)
    return value


def _xlsx_sheets(path):
    with zipfile.ZipFile(path) as z:
        if 'xl/workbook.xml' not in z.namelist():raise ValueError('Đây không phải tệp Excel hợp lệ.')
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[''.join(t.text or '' for t in si.iter(XNS+'t')) for si in root.findall(XNS+'si')]
        pad_by_xf=_style_zero_pad_map(z)
        root=ET.fromstring(z.read('xl/workbook.xml'))
        relations={}
        rel_path='xl/_rels/workbook.xml.rels'
        if rel_path in z.namelist():
            relroot=ET.fromstring(z.read(rel_path))
            for link in relroot:
                target=link.attrib.get('Target','')
                if target.startswith('/'):target=target.lstrip('/')
                else:target='xl/'+target
                relations[link.attrib.get('Id','')]=target
        for i, sheet in enumerate(root.findall('.//'+XNS+'sheet'),1):
            name=sheet.attrib.get('name',f'Sheet{i}')
            rid=sheet.attrib.get(RNS+'id','')
            target=relations.get(rid,f'xl/worksheets/sheet{i}.xml')
            if target not in z.namelist():
                from posixpath import normpath
                target=normpath(target)
            if target not in z.namelist():continue
            xml=ET.fromstring(z.read(target))
            out=[]
            for node in xml.findall('.//'+XNS+'sheetData/'+XNS+'row'):
                cells={}
                for cell in node.findall(XNS+'c'):
                    address=cell.attrib.get('r','')
                    m=re.match(r'([A-Z]+)',address)
                    if not m:continue
                    col=0
                    for c in m.group(1):col=col*26+ord(c)-64
                    if 1<=col<=64:cells[col-1]=_cell_text(cell,shared,pad_by_xf)
                if cells:
                    width=max(cells)+1
                    out.append([cells.get(j,'') for j in range(width)])
            yield name,out


def _csv_sheets(path):
    raw=path.read_bytes();content=None
    for encoding in ('utf-8-sig','utf-16','cp1258','cp1252'):
        try:content=raw.decode(encoding);break
        except UnicodeError:pass
    if content is None:raise ValueError('Không nhận được bảng mã của tệp CSV.')
    try:dialect=csv.Sniffer().sniff(content[:8192],delimiters=',;\t')
    except csv.Error:dialect=csv.excel
    yield 'Danh sách mã đề',list(csv.reader(io.StringIO(content),dialect))


def _codes(text):
    text=str(text or '').strip()
    if not text:return []
    pieces=re.split(r'[,;/\n\r\t ]+',text)
    out=[]
    for item in pieces:
        item=item.strip()
        if not item:continue
        if re.fullmatch(r'[0-9]{2,6}\.0',item):item=item[:-2]
        if not re.fullmatch(r'[0-9]{2,6}',item):
            raise ValueError(f'Mã đề "{item}" không hợp lệ: yêu cầu từ 2 đến 6 chữ số.')
        out.append(item)
    return out


class ExamCodeCatalog:
    def __init__(self, records, file_subjects=()):
        by_subject=defaultdict(set);labels={}
        for subject,code in records:
            key=subject_key(subject)
            if not key or not code:continue
            by_subject[key].add(str(code));labels.setdefault(key,str(subject).strip())
        if not by_subject:raise ValueError('Chưa có danh sách mã đề hợp lệ theo môn.')
        self.by_subject=dict(by_subject);self.labels=labels
        self.file_subjects={}
        for filename,subject in file_subjects:
            filename=Path(str(filename or '').replace('\\','/')).name.strip().lower()
            key=subject_key(subject)
            if not filename or key not in self.by_subject:
                raise ValueError(f'Gán môn cho ảnh {filename}: môn {subject} không có trong danh mục mã đề.')
            if filename in self.file_subjects and self.file_subjects[filename]!=key:
                raise ValueError(f'Ảnh {filename} được gán hai môn khác nhau trong Excel.')
            self.file_subjects[filename]=key
        self.all_codes=set().union(*by_subject.values())

    @property
    def subjects(self):return sorted(self.labels.values(),key=normal)

    def key(self,subject):return subject_key(subject)

    def scope(self,row,selected='',bubble_code=''):
        selected=str(selected or '').strip()
        if selected=='TẤT CẢ MÔN (tự nhận diện)':selected=''
        row_subject=str(row.get('subject') or '').strip()
        row_key=self.key(row_subject) if row_subject else ''
        filename=Path(str(row.get('file') or '').replace('\\','/')).name.strip().lower()
        mapped=self.file_subjects.get(filename,'')
        if row_key and mapped and row_key!=mapped:
            return None,'Môn trên VietSchool không khớp môn gán theo tên ảnh trong Excel.'
        if row_key and row_key not in self.by_subject:
            return None,f'Chưa có mã đề của môn {row_subject} trong Excel.'
        key=row_key or mapped
        if selected:
            requested=self.key(selected)
            if requested not in self.by_subject:return None,f'Chưa có môn {selected} trong file mã đề.'
            if key and key!=requested:return None,'Môn trên phiếu khác môn đã chọn trong Agent.'
            key=key or requested
        if not key and len(self.by_subject)==1:
            key=next(iter(self.by_subject))
        if not key:
            return None,('Chưa rõ môn của phiếu trong đợt nhiều môn. '
                'Cần cột Môn ở VietSchool, Gemini/Ollama đọc rõ tên Bài thi hai lượt, '
                'hoặc sheet Gán môn phiếu (Ảnh phiếu, Môn) trong Excel. '
                'Không xác định môn chỉ từ mã tô có thể sai.')
        return key,''

    def valid_codes(self,row,selected='',bubble_code=''):
        key,reason=self.scope(row,selected,bubble_code)
        return key,sorted(self.by_subject.get(key,set())),reason

    def resolve_batch_codes(self, row, webrows=(), selected=''):
        key, codes, reason = self.valid_codes(row, selected)
        if codes:
            return key, codes, ''
        if reason and ('không khớp' in reason or 'khác môn đã chọn' in reason or 'Chưa có môn' in reason or 'Chưa có mã đề của môn' in reason):
            return None, [], reason
        if webrows:
            scored_codes = {
                str(r.get('code') or '').strip()
                for r in webrows
                if str(r.get('score') or '').strip() not in ('', '-', '—', '–', 'null', 'undefined')
                and str(r.get('code') or '').strip() in self.all_codes
            }
            if scored_codes:
                matching_keys = [k for k, cset in self.by_subject.items() if cset & scored_codes]
                if len(matching_keys) == 1:
                    k = matching_keys[0]
                    return k, sorted(self.by_subject[k]), ''
                if len(matching_keys) > 1:
                    union_codes = sorted(set().union(*(self.by_subject[k] for k in matching_keys)))
                    return 'batch_multi', union_codes, ''
        if self.all_codes:
            return 'all_catalog', sorted(self.all_codes), ''
        return None, [], reason

    def issue(self,row,selected=''):
        key,codes,_=self.valid_codes(row,selected)
        raw=str(row.get('code') or '').strip()
        if key and raw not in codes:
            return 'Thiếu mã đề theo danh mục' if not raw else 'Mã đề không thuộc danh sách môn'
        return ''

    def nearest_filled_code(self, filled, codes):
        filled=str(filled or '').strip()
        same_length=[c for c in codes if len(c)==len(filled)]
        if not (filled.isdigit() and 2<=len(filled)<=6 and same_length):
            return {'candidate':'','distance':None,'ranked':[],'safe':False}
        ordered=sorted((sum(a!=b for a,b in zip(filled,c)),c) for c in same_length)
        best_dist=ordered[0][0]
        winners=[c for dist,c in ordered if dist==best_dist]
        candidate=(winners[0] if best_dist==1 and len(winners)==1 and filled not in same_length else '')
        return {'candidate':candidate,'distance':best_dist,
                'ranked':ordered[:5], 'safe':bool(candidate)}

    def advise(self,row,bubbles=None,selected=''):
        raw=str(row.get('code') or '').strip()
        bubble=str((bubbles or {}).get('code') or '').strip()
        key,codes,reason=self.valid_codes(row,selected,bubble if bubble.isdigit() else '')
        subject=self.labels.get(key,'') if key else ''
        ans={'subject':subject,'codes':codes,'current':raw,'bubble':bubble,
             'candidate':'','reason':reason,'evidence':'','valid':(raw in codes if key else None),
             'method':'','distance':None,'ranked':[]}
        if not key:return ans
        if bubble and bubble.isdigit() and len(bubble)==4:
            if bubble in codes:
                ans['candidate']=bubble;ans['method']='exact'
                ans['evidence']='4 ô mã đề tô rõ; thuộc danh sách môn'
            else:
                near=self.nearest_filled_code(bubble,codes)
                ans['distance']=near['distance'];ans['ranked']=near['ranked']
                if near['safe']:
                    ans['candidate']=near['candidate'];ans['method']='nearest_one_digit'
                    ans['evidence']=(f'Ô tô {bubble} gần duy nhất mã đề chính thức {near["candidate"]} '
                        '(lệch đúng 1 chữ số). CHỈ được tự lưu khi danh tính học sinh '
                        'khớp duy nhất Excel, 6+/8 ô SBD đọc chắc và không có cảnh báo xung đột.')
                else:
                    close=', '.join(f'{c} ({d} vị trí)' for d,c in near['ranked'])
                    ans['reason']=(f'Ô tô {bubble} KHÔNG thuộc danh sách {subject}; '
                        f'không có mã gần duy nhất lệch đúng 1 chữ số. Gần nhất: {close}. Cần xem lại ảnh.')
            return ans
        if len(bubble)==4 and '?' in bubble and sum(c.isdigit() for c in bubble)>=2:
            matches=[code for code in codes if len(code)==4 and all(a=='?' or a==b for a,b in zip(bubble,code))]
            if len(matches)==1:
                ans['candidate']=matches[0];ans['method']='partial_unique';ans['evidence']='Khớp duy nhất các ô tô đọc rõ và danh sách mã đề theo môn'
            else:
                ans['reason']=f'Ô mã đề đọc {bubble}; có {len(matches)} mã phù hợp: '+', '.join(matches[:20])
            return ans
        if len(codes)==1 and not raw:
            ans['candidate']=codes[0]
            ans['evidence']='Môn chỉ có một mã đề; mã đang trống, không có ô tô đọc rõ để đối chiếu'
            return ans
        if len(codes)==1 and raw not in codes and not bubble:
            ans['candidate']=codes[0]
            ans['evidence']='Môn chỉ có một mã đề nhưng chưa đọc được ô tô; cần xác minh trước khi ghi'
            return ans
        ans['reason']=('Mã hiện tại hợp lệ; cần ảnh tô nếu muốn xác minh' if raw in codes
                       else 'Mã hiện tại không thuộc danh sách môn; các mã hợp lệ: '+', '.join(codes[:25]))
        return ans


def load_exam_codes(path):
    path=Path(path)
    if not path.is_file():raise ValueError('Không tìm thấy danh sách mã đề.')
    if path.stat().st_size>25_000_000:raise ValueError('File danh sách mã đề quá lớn (trên 25 MB).')
    suffix=path.suffix.lower()
    sheets=_xlsx_sheets(path) if suffix=='.xlsx' else _csv_sheets(path) if suffix=='.csv' else None
    if sheets is None:raise ValueError('Chỉ hỗ trợ file mã đề Excel .xlsx hoặc CSV .csv.')
    out=[];per_file=[]
    generic_sheet_names={'sheet1','sheet2','sheet3','danh sach ma de','danhsachmade','mau danh sach ma de','maudanhsachmade'}
    skip_sheet_names={'huong dan','huongdan','huong dan & vi du','huong dan va vi du','vi du','vidu'}
    for name,rows in sheets:
        if normal(name) in skip_sheet_names:
            continue
        for row_index,row in enumerate(rows[:25]):
            heads=[header(h) for h in row]
            idx_code=next((i for i,v in enumerate(heads) if v in {header(a) for a in HEADERS_CODE}),None)
            idx_sub=next((i for i,v in enumerate(heads) if v in {header(a) for a in HEADERS_SUBJECT}),None)
            idx_file=next((i for i,v in enumerate(heads) if v in {header(a) for a in HEADERS_FILE}),None)
            if idx_code is None and not (idx_sub is not None and idx_file is not None):continue
            for data in rows[row_index+1:]:
                row_joined=' '.join(str(x or '') for x in data)
                if '[vi du]' in normal(row_joined) or 'example row' in normal(row_joined):
                    continue
                sub=(str(data[idx_sub] or '').strip() if idx_sub is not None and idx_sub<len(data) else '')
                if not sub and normal(name) not in generic_sheet_names:
                    sub=name.strip()
                filename=str(data[idx_file] or '').strip() if idx_file is not None and idx_file<len(data) else ''
                text=str(data[idx_code] or '').strip() if idx_code is not None and idx_code<len(data) else ''
                if not sub or normal(sub) in generic_sheet_names:
                    if filename:
                        raise ValueError(f'Chưa điền tên môn cho mã đề/ảnh (sheet {name}).')
                    if text:
                        sub=DEFAULT_BATCH_SUBJECT
                    else:
                        continue
                if filename:per_file.append((filename,sub))
                if text:
                    for value in _codes(text):out.append((sub,value))
            break
    return ExamCodeCatalog(out,per_file)
