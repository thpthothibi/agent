# -*- coding: utf-8 -*-
"""Unit tests for:
1. Selecting grading batches (`list_grading_batches`, `select_grading_batch`)
2. Searching in grading by Name + Class (`search_in_grading`), including finding students
   who have NO multiple-choice score and pairing them with suspected mis-shaded/duplicate sheets
3. Finding Duplicate Names & Mis-shaded SBDs with no multiple-choice score (`find_duplicate_names_and_missing_scores`)
4. Exporting search & duplicate-name reports (`export_search_report`)
5. SBD + Exam Code targeted batch repair without resetting scroll position (`ExcelSBDRunner`)
"""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from exam_codes import ExamCodeCatalog, load_exam_codes
from phieu_vision import read_bubbles, parse_ocr_handwriting_text
from roster_excel import load_roster
from sbd_candidate_filter import select_sbd_anomalies
from sbd_excel_only import ExcelSBDRunner, sbd_evidence, code_evidence, extract_handwriting
from search_and_duplicates import (
    search_in_grading,
    find_duplicate_names_and_missing_scores,
    find_suspected_sheets_for_student,
    export_search_report,
)
from vietschool_sbd_agent import NoAI, Browser


def row(file, name='', sbd='20006140', code='2345', score='5', cls='11B6', subject=''):
    return {'file': file, 'name': name, 'sbd': sbd, 'code': code, 'score': score, 'class': cls, 'subject': subject}


def bubble(sbd='20006140', code='2345'):
    return {
        'sbd': sbd,
        'code': code,
        'masks': {'sbd': [[int(x)] for x in sbd], 'code': [[int(x)] for x in code]},
        'confidence': {'sbd': 8, 'code': 4},
    }


class MockBatchBrowser:
    def __init__(self, data):
        self.data = [dict(x) for x in data]
        self.writes = []
        self.opened = []
        self.closed = 0
        self.current = ''
        self.reload_called = 0

    def scan(self):
        return [dict(x) for x in self.data]

    def missing_students(self):
        return []

    def open(self, f):
        self.current = f
        self.opened.append(f)

    def close(self):
        self.closed += 1

    def image(self):
        return self.current.encode(), self.current.encode()

    def locate_visible(self, file):
        return next((dict(r) for r in self.data if r['file'] == file), None)

    def read_modal_fields(self):
        if self.writes and self.writes[-1][0] == self.current:
            p = self.writes[-1][1]
            return {'sbd': p.get('sbd', ''), 'code': p.get('code', ''), 'name': p.get('name', ''), 'class': p.get('class', '')}
        return {'sbd': '', 'code': ''}

    def write(self, p, journal):
        self.writes.append((self.current, dict(p)))
        for r in self.data:
            if r['file'] == self.current:
                r['sbd'] = p.get('sbd', r['sbd'])
                r['code'] = p.get('code', r['code'])
                if p.get('name'): r['name'] = p['name']
                if p.get('class'): r['class'] = p['class']
        journal('before_field', {'field': 'sbd'})

    def write_sbd_only(self, p, journal):
        self.write(p, journal)

    def write_code_only(self, p, journal):
        self.write(p, journal)

    def reload_grading_table(self):
        self.reload_called += 1


class SearchAndDuplicateTests(unittest.TestCase):
    def setUp(self):
        self.roster = [
            {'sbd': '10006212', 'name': 'Phạm Thái Hòa', 'class': '10A06'},
            {'sbd': '10006213', 'name': 'Nguyễn Minh Hòa', 'class': '10A06'},
            {'sbd': '10008084', 'name': 'Lê Quốc Bảo', 'class': '10A08'},
            {'sbd': '10008085', 'name': 'Trần Quốc Bảo', 'class': '10A08'},
            {'sbd': '10012520', 'name': 'Trịnh Nguyễn Quỳnh Như', 'class': '10A12'},
            {'sbd': '10012525', 'name': 'Trịnh Nguyễn Quỳnh Như', 'class': '10A12'},
            {'sbd': '10019714', 'name': 'Lê Hoàng Nam', 'class': '10A19'},
        ]
        self.webrows = [
            # Duplicate SBD 10006212 on two sheets (student 10006213 shaded 10006212 by mistake!)
            row('dup_hoa_1.jpg', name='Phạm Thái Hòa', sbd='10006212', code='4650', score='', cls='10A06'),
            row('dup_hoa_2.jpg', name='Phạm Thái Hòa', sbd='10006212', code='4651', score='8.0', cls='10A06'),
            # Duplicate name in Excel (two students named Trịnh Nguyễn Quỳnh Như in 10A12, both shaded 10012520!)
            row('dup_nhu_1.jpg', name='Trịnh Nguyễn Quỳnh Như', sbd='10012520', code='3138', score='7.5', cls='10A12'),
            row('dup_nhu_2.jpg', name='Trịnh Nguyễn Quỳnh Như', sbd='10012520', code='9740', score='', cls='10A12'),
            # Student Lê Hoàng Nam (10019714) shaded Exam Room 01 -> 10001714 (so name is blank on VietSchool)
            row('nam_misshaded.jpg', name='', sbd='10001714', code='9741', score='6.5', cls=''),
            # Normal healthy student
            row('bao_ok.jpg', name='Lê Quốc Bảo', sbd='10008084', code='9741', score='9.0', cls='10A08'),
        ]

    def test_search_by_name_and_class_finds_both_present_and_missing_score_students(self):
        # 1. Search for 'Hòa' in class '10A6' (matches '10A06'):
        # Should find the 2 sheets of Phạm Thái Hòa AND find that Nguyễn Minh Hòa (10006213) has NO score,
        # pairing Nguyễn Minh Hòa with the duplicate sheets dup_hoa_1.jpg / dup_hoa_2.jpg!
        items, stats = search_in_grading(self.webrows, self.roster, name_query='Hòa', class_query='10A6')
        self.assertEqual(stats['matched_sheets'], 2)
        self.assertEqual(stats['missing_score_students'], 1)
        missing_item = [x for x in items if x['proposal']['sbd'] == '10006213'][0]
        self.assertEqual(missing_item['proposal']['name'], 'Nguyễn Minh Hòa')
        self.assertIn('dup_hoa', missing_item['note'])
        self.assertIn(missing_item['target_file'], ('dup_hoa_1.jpg', 'dup_hoa_2.jpg'))

    def test_search_missing_student_pairs_with_unidentified_sheet_by_student_id_suffix(self):
        # Search for 'Lê Hoàng Nam' in '10A19':
        # Even though VietSchool has NO row named 'Lê Hoàng Nam' (because he shaded 10001714),
        # searching 'Lê Hoàng Nam' + '10A19' finds him in Excel AND pairs him with 'nam_misshaded.jpg' (10001714)!
        items, stats = search_in_grading(self.webrows, self.roster, name_query='Lê Hoàng Nam', class_query='10A19')
        self.assertEqual(stats['missing_score_students'], 1)
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['target_file'], 'nam_misshaded.jpg')
        self.assertEqual(items[0]['proposal']['sbd'], '10019714')
        self.assertIn('#714', items[0]['note'])

    def test_find_duplicate_names_and_missing_scores_detects_all_groups(self):
        items, stats = find_duplicate_names_and_missing_scores(self.webrows, self.roster)
        files_or_ids = [x['file'] for x in items]
        # Detects duplicate sheets on table (dup_hoa_1, dup_hoa_2, dup_nhu_1, dup_nhu_2)
        self.assertIn('dup_hoa_1.jpg', files_or_ids)
        self.assertIn('dup_nhu_1.jpg', files_or_ids)
        # Detects dup_nhu_1/2 suggests namesake Trịnh Nguyễn Quỳnh Như (10012525) who is missing score!
        nhu_item = next(x for x in items if x['file'] == 'dup_nhu_1.jpg')
        self.assertEqual(nhu_item['proposal']['sbd'], '10012525')
        self.assertIn('10012525', nhu_item['note'])
        # Detects nam_misshaded.jpg and suggests 10019714 (Lê Hoàng Nam)
        nam_item = next(x for x in items if x['file'] == 'nam_misshaded.jpg')
        self.assertEqual(nam_item['proposal']['sbd'], '10019714')

        with tempfile.TemporaryDirectory() as tmp:
            csv_path = export_search_report(items, Path(tmp) / 'tim_kiem_trung_ten_mat_diem.csv')
            self.assertTrue(csv_path.is_file())
            content = csv_path.read_text(encoding='utf-8-sig')
            self.assertIn('Nguyễn Minh Hòa', content)
            self.assertIn('10012525', content)
            self.assertIn('10019714', content)

    def test_combined_sbd_and_exam_code_batch_without_scroll_reset(self):
        cat = load_exam_codes(Path(__file__).with_name('MAU_DANH_SACH_MA_DE.xlsx'))
        b = MockBatchBrowser(self.webrows)
        b_map = {r['file']: bubble(r['sbd'], r['code']) for r in self.webrows}
        with tempfile.TemporaryDirectory() as tmp:
            with patch('sbd_excel_only.read_bubbles', side_effect=lambda raw: b_map[raw.decode()]):
                runner = ExcelSBDRunner(b, NoAI(), lambda *a: None, lambda: None, tmp,
                    official_roster=self.roster, audit_all=True, exam_catalog=cat)
                runner.run()
            # Verify reload_grading_table was NEVER called during per-sheet verification (preserving scrollTop!)
            self.assertEqual(b.reload_called, 0)
            # Verify nam_misshaded.jpg was auto-fixed to 10019714
            nam_rec = next(r for r in runner.records if r.file == 'nam_misshaded.jpg')
            self.assertEqual(nam_rec.status, 'Đã xác minh SBD')
            self.assertEqual(nam_rec.proposal['sbd'], '10019714')
            # Verify dup_hoa_1.jpg had its exam code 4650 auto-fixed to 4651!
            hoa1_rec = next(r for r in runner.records if r.file == 'dup_hoa_1.jpg')
            self.assertEqual(hoa1_rec.proposal['code'], '4651')
            self.assertTrue((Path(tmp) / 'goi_y_sbd.csv').is_file())
            self.assertTrue((Path(tmp) / 'goi_y_ma_de.csv').is_file())


if __name__ == '__main__':
    unittest.main()
