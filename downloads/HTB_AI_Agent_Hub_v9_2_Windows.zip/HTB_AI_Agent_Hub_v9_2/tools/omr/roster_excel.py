# -*- coding: utf-8 -*-
"""Load official student roster from Excel (.xlsx) or CSV (.csv) offline.
Supports:
- Single 'Họ và tên' column OR split 'Họ và chữ lót' + 'Tên' columns.
- Preserves leading zeros on SBD even when Excel stores SBD as a numeric cell formatted as 00000000.
"""
from __future__ import annotations
import csv
import io
import re
import unicodedata
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

XNS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
RNS = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'

HEADERS_SBD = {'sbd', 'sobaodanh', 'mahocsinh', 'mahs', 'masinhvien', 'studentid'}
HEADERS_NAME = {'hovaten', 'hoten', 'tenhocsinh', 'hotenhocsinh', 'fullname', 'name'}
HEADERS_LAST_MIDDLE = {'ho', 'hovachulot', 'hodem', 'holot', 'hovatenlot'}
HEADERS_FIRST = {'ten', 'tenhs', 'tenchinh', 'firstname'}
HEADERS_CLASS = {'lop', 'tenlop', 'lophoc', 'class', 'classname'}


def _norm_header(v):
    s = unicodedata.normalize('NFD', str(v or '')).replace('đ', 'd').replace('Đ', 'D')
    s = ''.join(c for c in s if unicodedata.category(c) != 'Mn').lower()
    return re.sub(r'[^a-z0-9]', '', s)


def _style_zero_pad_map(z):
    pad_by_xf = {}
    if 'xl/styles.xml' not in z.namelist():
        return pad_by_xf
    try:
        sroot = ET.fromstring(z.read('xl/styles.xml'))
        num_fmts = {}
        for nf in sroot.findall('.//' + XNS + 'numFmts/' + XNS + 'numFmt'):
            fmt_id = nf.attrib.get('numFmtId', '')
            code = nf.attrib.get('formatCode', '')
            m = re.fullmatch(r'0{4,12}', code.strip())
            if fmt_id and m:
                num_fmts[fmt_id] = len(m.group(0))
        for idx, xf in enumerate(sroot.findall('.//' + XNS + 'cellXfs/' + XNS + 'xf')):
            fmt_id = xf.attrib.get('numFmtId', '')
            if fmt_id in num_fmts:
                pad_by_xf[str(idx)] = num_fmts[fmt_id]
    except Exception:
        pass
    return pad_by_xf


def _cell_text(c, shared, pad_by_xf=None):
    kind = c.get('t', '')
    if kind == 'inlineStr':
        return ''.join(t.text or '' for t in c.iter(XNS + 't')).strip()
    v = c.find(XNS + 'v')
    if v is None:
        return ''
    value = (v.text or '').strip()
    if kind == 's':
        try:
            return shared[int(value)].strip()
        except (ValueError, IndexError):
            return ''
    if re.fullmatch(r'\d+\.0', value):
        value = value[:-2]
    if pad_by_xf and kind in ('', 'n'):
        s_idx = c.get('s', '')
        width = pad_by_xf.get(s_idx, 0)
        if width and value.isdigit() and len(value) < width:
            return value.zfill(width)
    return value


def _xlsx_rows(path: Path):
    with zipfile.ZipFile(path) as z:
        if 'xl/workbook.xml' not in z.namelist():
            raise ValueError('Tệp Excel danh sách học sinh không hợp lệ.')
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            root = ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared = [''.join(t.text or '' for t in si.iter(XNS + 't')) for si in root.findall(XNS + 'si')]
        pad_by_xf = _style_zero_pad_map(z)
        wb_root = ET.fromstring(z.read('xl/workbook.xml'))
        relations = {}
        rel_path = 'xl/_rels/workbook.xml.rels'
        if rel_path in z.namelist():
            relroot = ET.fromstring(z.read(rel_path))
            for link in relroot:
                target = link.attrib.get('Target', '')
                target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
                relations[link.attrib.get('Id', '')] = target
        for i, sheet in enumerate(wb_root.findall('.//' + XNS + 'sheet'), 1):
            rid = sheet.attrib.get(RNS + 'id', '')
            target = relations.get(rid, f'xl/worksheets/sheet{i}.xml')
            if target not in z.namelist():
                from posixpath import normpath
                target = normpath(target)
            if target not in z.namelist():
                continue
            xml = ET.fromstring(z.read(target))
            rows = []
            for node in xml.findall('.//' + XNS + 'sheetData/' + XNS + 'row'):
                cells = {}
                for cell in node.findall(XNS + 'c'):
                    address = cell.attrib.get('r', '')
                    m = re.match(r'([A-Z]+)', address)
                    if not m:
                        continue
                    col = 0
                    for ch in m.group(1):
                        col = col * 26 + ord(ch) - 64
                    if 1 <= col <= 64:
                        cells[col - 1] = _cell_text(cell, shared, pad_by_xf)
                if cells:
                    width = max(cells) + 1
                    rows.append([cells.get(j, '') for j in range(width)])
            if rows:
                yield rows


def _csv_rows(path: Path):
    raw = path.read_bytes()
    content = None
    for enc in ('utf-8-sig', 'utf-16', 'cp1258', 'cp1252'):
        try:
            content = raw.decode(enc)
            break
        except UnicodeError:
            pass
    if content is None:
        raise ValueError('Không đọc được bảng mã của tệp CSV học sinh.')
    try:
        dialect = csv.Sniffer().sniff(content[:8192], delimiters=',;\t')
    except csv.Error:
        dialect = csv.excel
    yield list(csv.reader(io.StringIO(content), dialect))


def load_roster(path):
    """Load [{'sbd':..., 'name':..., 'class':...}] from Excel/CSV."""
    p = Path(path)
    if not p.is_file():
        raise ValueError('Không tìm thấy tệp danh sách học sinh: ' + str(path))
    suffix = p.suffix.lower()
    sheets = _xlsx_rows(p) if suffix == '.xlsx' else _csv_rows(p) if suffix == '.csv' else None
    if sheets is None:
        raise ValueError('Chỉ hỗ trợ danh sách học sinh định dạng .xlsx hoặc .csv.')

    students = []
    seen = set()
    for rows in sheets:
        for r_idx, row in enumerate(rows[:30]):
            heads = [_norm_header(h) for h in row]
            idx_sbd = next((i for i, h in enumerate(heads) if h in HEADERS_SBD), None)
            idx_cls = next((i for i, h in enumerate(heads) if h in HEADERS_CLASS), None)
            idx_name = next((i for i, h in enumerate(heads) if h in HEADERS_NAME), None)
            idx_ho = next((i for i, h in enumerate(heads) if h in HEADERS_LAST_MIDDLE), None)
            idx_ten = next((i for i, h in enumerate(heads) if h in HEADERS_FIRST), None)
            if idx_sbd is None or idx_cls is None or (idx_name is None and (idx_ho is None or idx_ten is None)):
                continue
            for data in rows[r_idx + 1:]:
                sbd = str(data[idx_sbd] if idx_sbd < len(data) else '').strip()
                if re.fullmatch(r'\d+\.0', sbd):
                    sbd = sbd[:-2]
                cls = str(data[idx_cls] if idx_cls < len(data) else '').strip()
                if idx_name is not None and idx_name < len(data) and str(data[idx_name] or '').strip():
                    name = ' '.join(str(data[idx_name]).split())
                elif idx_ho is not None and idx_ten is not None:
                    ho = str(data[idx_ho] if idx_ho < len(data) else '').strip()
                    ten = str(data[idx_ten] if idx_ten < len(data) else '').strip()
                    name = ' '.join(f'{ho} {ten}'.split())
                else:
                    name = ''
                if not sbd and not name and not cls:
                    continue
                if not re.fullmatch(r'\d{4,12}', sbd) or not name or not cls:
                    continue
                key = (sbd, name, cls)
                if key not in seen:
                    seen.add(key)
                    students.append({'sbd': sbd, 'name': name, 'class': cls})
            break
    return students
