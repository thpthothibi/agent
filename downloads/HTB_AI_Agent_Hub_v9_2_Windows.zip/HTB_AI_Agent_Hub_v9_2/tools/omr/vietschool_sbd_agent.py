# -*- coding: utf-8 -*-
"""HTB VietSchool Agent v3.18+. Python 3.10+. Run this file to open the Windows UI.
Automatically installs missing Python packages on first run if needed, opens Chrome Agent,
logs into VietSchool, filters rows with missing/wrong SBD or Exam Code in 'Chấm bài',
supports selecting 'Đợt chấm', searching by Student Name + Class, finding
Duplicate Names / Mis-shaded SBDs with no multiple-choice score, and editing
SBD / Mã đề without resetting scroll position to the top of the table.
"""
from __future__ import annotations
import base64, csv, io, json, os, queue, re, shutil, subprocess, sys, threading, time, unicodedata
import urllib.request, urllib.error
from collections import defaultdict
from dataclasses import dataclass, asdict, field
from datetime import datetime
from pathlib import Path


def _auto_bootstrap_dependencies():
    """If the user double-clicks vietschool_sbd_agent.py directly before running CAI_DAT.bat,
    automatically install any missing required packages using `sys.executable -m pip`.
    """
    if '--api-worker' in sys.argv:
        return
    required = [
        ('selenium', 'selenium>=4.15.0'),
        ('PIL', 'Pillow>=10.0.0'),
        ('openpyxl', 'openpyxl>=3.1.0'),
        ('cv2', 'opencv-python>=4.8.0'),
        ('numpy', 'numpy>=1.24.0'),
    ]
    missing = []
    for mod_name, pkg_spec in required:
        try:
            __import__(mod_name)
        except ImportError:
            missing.append(pkg_spec)
    if not missing:
        return
    print(f'Dang tu dong cai dat thu vien con thieu ({", ".join(missing)}) bang {sys.executable}...')
    try:
        subprocess.run([sys.executable, '-m', 'ensurepip', '--upgrade'], capture_output=True, timeout=60)
    except Exception:
        pass
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '--upgrade'] + missing)
        print('Da cai dat xong thu vien!')
    except Exception as exc:
        print(f'Loi khi tu cai thu vien: {exc}. Hay chay file CAI_DAT.bat.')


if __name__ == '__main__':
    _auto_bootstrap_dependencies()

from phieu_vision import read_bubbles, consistent_with_mask, match_official
from roster_excel import load_roster
from exam_codes import load_exam_codes

ROOT = Path(__file__).resolve().parent
URL = 'https://nhapdiem.truonghocviet.vn/'
API = 'https://generativelanguage.googleapis.com/v1beta/'
HTTP_IMAGE_TIMEOUT = 90
HTTP_LIST_TIMEOUT = 20
API_TEST_BUDGET = 90
LOCAL_TIMEOUT = 300
LOCAL_MODELS = ('qwen3-vl:2b','qwen3-vl:4b','qwen3-vl:8b')
NO_AI_LABEL = 'Không dùng AI (Tự bấm Xem & sửa theo quy tắc / trực tiếp)'
NO_AI_ALIASES = (
    NO_AI_LABEL,
    'Không dùng AI (Nhẹ máy — Đối chiếu & Duyệt nhanh)',
    'Không dùng AI',
    'NoAI',
    'no-ai',
)

class Review(Exception): pass
class TemporaryGeminiUnavailable(Review): pass
class StopRun(Exception): pass
class Fatal(Exception): pass
class APIError(Fatal):
    def __init__(self,code):self.code=code;super().__init__(f'Gemini HTTP {code}. Kiểm tra key, model và dự án.')

sys.modules.setdefault('vietschool_sbd_agent', sys.modules[__name__])


def short_error(exc):
    msg = str(exc or '').strip()
    return msg.splitlines()[0][:260] if msg else type(exc).__name__


def load_api_key():
    try:
        value=(ROOT/'gemini_key.txt').read_text(encoding='utf-8-sig').strip()
        if value:return value
    except OSError:pass
    return os.environ.get('GEMINI_API_KEY','').strip()


def save_api_key(value):
    value=value.strip()
    if not value or any(c.isspace() for c in value):raise Fatal('API key không được rỗng hoặc có khoảng trắng ở giữa.')
    path=ROOT/'gemini_key.txt';temp=path.with_suffix('.tmp')
    temp.write_text(value,encoding='utf-8');os.replace(temp,path)


def norm(value):
    s = unicodedata.normalize('NFD', str(value or '')).replace('đ','d').replace('Đ','D')
    return ' '.join(''.join(c for c in s if unicodedata.category(c) != 'Mn').upper().split())


def blank(v):
    return v is None or str(v).strip().lower() in ('','-','—','–','null','undefined')


def number(s, low=1, high=12):
    return isinstance(s,str) and bool(re.fullmatch(r'[0-9]{%d,%d}'%(low,high),s))


def same_class(a,b):
    def canonical(s):
        s=norm(s).replace(' ','');m=re.fullmatch(r'(\d{2})([A-Z]+)0*(\d+)',s)
        return (m[1],m[2],int(m[3])) if m else s
    return bool(a and b and canonical(a)==canonical(b))


def class_key(value):
    n=norm(value).replace(' ','')
    m=re.fullmatch(r'(\d{2})([A-Z]+)0*(\d+)',n)
    return f'{m.group(1)}{m.group(2)}{int(m.group(3)):02d}' if m else n


def issues(row):
    result=[]
    for key,label in [('name','Thiếu họ tên'),('sbd','Thiếu SBD'),('code','Thiếu mã đề'),('score','Thiếu điểm')]:
        if blank(row.get(key)):result.append(label)
    if not blank(row.get('sbd')) and not number(str(row['sbd']).strip(),4,12):
        result.append('SBD không hợp lệ')
    if not blank(row.get('code')) and not number(str(row['code']).strip(),2,6):
        result.append('Mã đề không hợp lệ')
    return result


def _edit_distance_le1(a: str, b: str) -> bool:
    if a == b:
        return True
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la == lb:
        return sum(x != y for x, y in zip(a, b)) <= 1
    if la > lb:
        a, b = b, a
    i = j = diffs = 0
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1; j += 1
        else:
            diffs += 1
            if diffs > 1:
                return False
            j += 1
    return True


def audit_identity_conflicts(scanned, official=()):
    by_name=defaultdict(list);by_sbd=defaultdict(list)
    official_names=defaultdict(set);official_sbd=defaultdict(set)
    findings=[];seen=set()
    for r in official:
        if not blank(r.get('name')) and r.get('class'):
            official_names[(norm(r['name']),class_key(r['class']))].add(str(r.get('sbd') or '').strip())
            official_sbd[str(r.get('sbd') or '').strip()].add((norm(r['name']),class_key(r['class'])))
    for row in scanned:
        if row.get('name') and row.get('class'):
            by_name[(norm(row['name']),class_key(row['class']))].append(row)
        if number(str(row.get('sbd') or ''),4,12):by_sbd[str(row['sbd'])].append(row)
    def add(rows,label,explanation):
        for row in rows:
            key=(str(row.get('file')),label)
            if key in seen:continue
            seen.add(key)
            findings.append({'file':str(row.get('file') or ''),'name':str(row.get('name') or ''),
                'class':str(row.get('class') or ''),'sbd':str(row.get('sbd') or ''),
                'issue':label,'details':explanation})
    for (name,cls),group in by_name.items():
        if len(group)>1:
            numbers=sorted({str(r.get('sbd') or '') for r in group})
            add(group,'Trùng họ tên + lớp trên bảng chấm',f"Cùng tên/lớp xuất hiện ở {len(group)} phiếu (SBD: {', '.join(numbers)})")
        elif len(official_names.get((name,cls),()))>1:
            add(group,'Trùng họ tên + lớp trong danh sách Excel',f"Danh sách chính thức có nhiều SBD cho cùng tên/lớp")
    for sbd,group in by_sbd.items():
        if len(group)>1:
            add(group,'Trùng SBD trên bảng chấm',f"SBD {sbd} xuất hiện ở {len(group)} phiếu")
    for row in scanned:
        sbd=str(row.get('sbd') or '').strip()
        if sbd and sbd in official_sbd and row.get('name') and row.get('class'):
            key=(norm(row['name']),class_key(row['class']))
            if key not in official_sbd[sbd]:
                add([row],'Lệch họ tên/lớp so với Excel',f"SBD {sbd} không khớp họ tên/lớp trong danh sách Excel")
    return findings


def audit_bubbles_match(old, bubbles):
    if not isinstance(bubbles, dict):
        return False
    sbd = str(old.get('sbd') or '').strip()
    code = str(old.get('code') or '').strip()
    return (not blank(old.get('name')) and not blank(old.get('score'))
            and number(sbd, 8, 8) and number(code, 3, 6)
            and bubbles.get('sbd') == sbd and bubbles.get('code') == code)


def verify_bubble_agreement(bubbles, proposal, require_code=True):
    if not isinstance(bubbles, dict):
        raise Review('Không đọc được ô tô để đối chiếu.')
    s_mask = bubbles.get('masks', {}).get('sbd', [])
    c_mask = bubbles.get('masks', {}).get('code', [])
    sbd = str(proposal.get('sbd') or '').strip()
    code = str(proposal.get('code') or '').strip()
    if len(s_mask) == 8 and sbd:
        if not consistent_with_mask(sbd, s_mask, min_known=6, max_unknown=2):
            raise Review(f'SBD đề xuất {sbd} mâu thuẫn với các ô tô SBD trên ảnh ({bubbles.get("sbd")}).')
    if require_code and len(c_mask) == 4 and len(code) == 4:
        if not consistent_with_mask(code, c_mask, min_known=2, max_unknown=2):
            raise Review(f'Mã đề đề xuất {code} mâu thuẫn với các ô tô mã đề trên ảnh ({bubbles.get("code")}).')


def unique_official_identity(old, bubbles, official, webrows=()):
    if not official or not isinstance(bubbles, dict):
        return False
    sbd = str(old.get('sbd') or '').strip()
    if not number(sbd, 8, 8) or bubbles.get('sbd') != sbd:
        return False
    if sum(1 for r in webrows if str(r.get('sbd') or '').strip() == sbd) > 1:
        return False
    matches = [st for st in official if str(st.get('sbd') or '').strip() == sbd]
    owners = {(norm(st.get('name')), class_key(st.get('class'))) for st in matches if st.get('name') and st.get('class')}
    if len(owners) != 1:
        return False
    if not blank(old.get('name')) and norm(old.get('name')) != norm(matches[0]['name']):
        return False
    return True


def verified_image_subject(first, second, catalog, row=None):
    if not isinstance(first, dict) or not isinstance(second, dict) or not catalog:
        return ''
    if not first.get('subject_clear') or not second.get('subject_clear'):
        return ''
    s1 = str(first.get('subject') or '').strip()
    s2 = str(second.get('subject') or '').strip()
    if not s1 or not s2:
        return ''
    k1 = catalog.key(s1)
    k2 = catalog.key(s2)
    if not k1 or k1 != k2 or k1 not in catalog.by_subject:
        return ''
    if row and row.get('file'):
        fn = Path(str(row.get('file') or '').replace('\\', '/')).name.strip().lower()
        mapped = catalog.file_subjects.get(fn, '')
        if mapped and mapped != k1:
            return ''
    return catalog.labels.get(k1, s1)


def verified_handwritten_code(first, second, catalog, row=None, selected_subject=''):
    if not isinstance(first, dict) or not isinstance(second, dict) or not catalog:
        return ''
    if not first.get('code_clear') or not second.get('code_clear'):
        return ''
    c1 = str(first.get('code') or '').strip()
    c2 = str(second.get('code') or '').strip()
    if not c1 or c1 != c2:
        return ''
    _, codes, _ = catalog.valid_codes(row or {}, selected_subject)
    return c1 if c1 in codes else ''


def independent_sbd_only_proposal(old, bubbles, official, webrows=()):
    if not official or not isinstance(bubbles, dict):
        return None
    mask = bubbles.get('masks', {}).get('sbd', [])
    if len(mask) != 8:
        return None
    known = sum(len(d) == 1 for d in mask)
    if known < 6 or 8 - known > 2:
        return None
    used_sbd = {
        str(r.get('sbd') or '').strip()
        for r in (webrows or ())
        if r.get('file') != old.get('file') and not blank(r.get('name')) and str(r.get('sbd') or '').strip()
    }
    old_name = str(old.get('name') or '').strip()
    old_cls = str(old.get('class') or '').strip()
    old_code = str(old.get('code') or '').strip()
    candidates = []
    for st in official:
        s = str(st.get('sbd') or '').strip()
        nm = str(st.get('name') or '').strip()
        cl = str(st.get('class') or '').strip()
        if not s or not nm or not cl or s in used_sbd:
            continue
        if not consistent_with_mask(s, mask, min_known=6, max_unknown=2):
            continue
        if old_name and norm(old_name) != norm(nm):
            continue
        if old_cls and not same_class(old_cls, cl):
            continue
        candidates.append({'sbd': s, 'code': old_code, 'name': nm, 'class': cl,
                           'evidence': f"Ô tô SBD ({bubbles.get('sbd')}) khớp duy nhất HS Excel: {s} — {nm} ({cl})."})
    distinct = {(c['sbd'], norm(c['name']), class_key(c['class'])) for c in candidates}
    return candidates[0] if len(distinct) == 1 else None


@dataclass
class Record:
    file: str
    old: dict
    reason: list
    status: str = 'Chờ xử lý'
    proposal: dict = field(default_factory=dict)
    after: dict = field(default_factory=dict)
    note: str = ''


class NoAI:
    def __init__(self, prompt_user=None, auto_single_match=True, default_code='', exam_catalog=None, selected_subject='', log=lambda s: None):
        self.prompt_user = prompt_user
        self.auto_single_match = auto_single_match
        self.default_code = default_code
        self.exam_catalog = exam_catalog
        self.selected_subject = selected_subject
        self.log = log
        self.handwriting_ai = None

    def test(self):
        return 'no-ai'

    def resolve(self, old, webrows=(), official_roster=(), bubbles=None, top_image=b''):
        if self.exam_catalog:
            key, codes, reason = self.exam_catalog.valid_codes(old, self.selected_subject)
            if not key and blank(old.get('code')):
                raise Review(reason or 'Chưa rõ môn của phiếu.')
        if bubbles and official_roster:
            prop = independent_sbd_only_proposal(old, bubbles, official_roster, webrows)
            if prop:
                return prop
        raise Review('Cần kiểm tra thủ công.')


def api_process(req, timeout, control, on_wait=lambda s: None):
    payload = json.dumps(req).encode('utf-8')
    proc = subprocess.Popen(
        [sys.executable, str(Path(__file__).resolve()), '--api-worker'],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    )
    try:
        proc.stdin.write(payload); proc.stdin.close()
        start = time.monotonic()
        last_log = 0
        while True:
            control()
            ret = proc.poll()
            if ret is not None:
                out = proc.stdout.read().decode('utf-8', errors='replace').strip()
                try:
                    return json.loads(out) if out else {'status': 500, 'detail': 'Empty worker output'}
                except Exception:
                    return {'status': 500, 'detail': out[:200]}
            elapsed = int(time.monotonic() - start)
            if elapsed >= timeout:
                proc.kill()
                return {'status': 504, 'detail': 'Timeout'}
            if elapsed >= 5 and elapsed - last_log >= 5:
                last_log = elapsed
                on_wait(elapsed)
            time.sleep(0.25)
    finally:
        if proc.poll() is None:
            try: proc.kill()
            except Exception: pass


def http_worker():
    raw = sys.stdin.buffer.read().decode('utf-8')
    req = json.loads(raw)
    provider = req.get('provider', 'gemini')
    path = req.get('path', '')
    payload = req.get('payload')
    key = req.get('key', '')
    try:
        if provider == 'ollama':
            url = f'http://127.0.0.1:11434/api/{path}'
            data = json.dumps(payload).encode('utf-8') if payload is not None else None
            r = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
        else:
            sep = '&' if '?' in path else '?'
            url = f'{API}{path}{sep}key={key}'
            data = json.dumps(payload).encode('utf-8') if payload is not None else None
            r = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(r, timeout=HTTP_IMAGE_TIMEOUT) as resp:
            body = resp.read().decode('utf-8')
            sys.stdout.write(json.dumps({'status': resp.status, 'data': json.loads(body)}))
    except urllib.error.HTTPError as e:
        detail = ''
        try: detail = e.read().decode('utf-8', errors='replace')[:300]
        except Exception: pass
        sys.stdout.write(json.dumps({'status': e.code, 'detail': detail}))
    except Exception as e:
        sys.stdout.write(json.dumps({'status': 503, 'detail': str(e)[:300]}))


class Gemini:
    def __init__(self, key, model='', control=lambda: None, log=lambda s: None):
        self.key = key.strip()
        self.model = model.strip()
        self.control = control
        self.log = log
        self.options = []
        self.deadline = None

    def delay(self, sec):
        end = time.monotonic() + sec
        while time.monotonic() < end:
            self.control()
            time.sleep(min(0.2, max(0.01, end - time.monotonic())))

    def call(self, path, payload=None):
        for attempt in range(3):
            self.control()
            if self.deadline and time.monotonic() > self.deadline:
                raise TemporaryGeminiUnavailable('Hết thời gian chờ phản hồi Gemini.')
            limit = HTTP_IMAGE_TIMEOUT if payload else HTTP_LIST_TIMEOUT
            label = f'Đọc ảnh với {self.model or "Gemini"}' if payload else 'Kiểm tra danh sách model Gemini'
            r = api_process({'provider': 'gemini', 'key': self.key, 'path': path, 'payload': payload},
                            limit, self.control, lambda sec: self.log(f'{label} — đã chờ {sec} giây…'))
            status = r.get('status', 0)
            if status == 200:
                return r.get('data', {})
            if status == 429:
                raise Fatal('Gemini HTTP 429: Hết hạn mức (quota) API key. Chuyển sang chế độ "Không dùng AI".')
            if status in (500, 502, 503, 504):
                if attempt < 2:
                    self.delay(1.5 * (attempt + 1))
                    continue
                raise TemporaryGeminiUnavailable(f'Gemini HTTP {status} quá tải tạm thời.')
            raise APIError(status)
        raise TemporaryGeminiUnavailable('Gemini tạm quá tải.')

    def models(self):
        data = self.call('models')
        return [m.get('name', '').split('/')[-1] for m in data.get('models', [])
                if 'generateContent' in m.get('supportedGenerationMethods', [])]

    def rank_models(self, names):
        preferred = ['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-flash']
        out = [p for p in preferred if p in names]
        for n in names:
            if 'flash' in n and n not in out:
                out.append(n)
        return out or names[:3]

    def select(self):
        if self.model and self.model != 'no-ai':
            self.options = [self.model]
            return self.model
        avail = self.rank_models(self.models())
        if not avail:
            raise Fatal('API key không có model Gemini hỗ trợ đọc ảnh.')
        self.options = avail[:3]
        self.model = self.options[0]
        return self.model

    def generate(self, prompt, image):
        mime = 'image/jpeg' if isinstance(image, (bytes, bytearray)) and image[:2] == b'\xff\xd8' else 'image/png'
        request = {'contents': [{'parts': [{'text': prompt}, {'inline_data': {'mime_type': mime, 'data': base64.b64encode(image).decode()}}]}],
                   'generationConfig': {'temperature': 0, 'responseMimeType': 'application/json'}}
        initial_model = self.model
        try:
            data = self.call('models/' + self.model + ':generateContent', request)
        except (TemporaryGeminiUnavailable, APIError) as initial_err:
            missing = isinstance(initial_err, APIError) and initial_err.code == 404
            if isinstance(initial_err, APIError) and not missing:
                raise
            if missing:
                candidates = self.rank_models(self.models())
            else:
                candidates = list(getattr(self, 'options', []) or [])
            fallbacks = [m for m in candidates if m != initial_model][:2]
            if not fallbacks:
                if missing:
                    raise Fatal('Gemini HTTP 404: không có model thay thế phù hợp.')
                raise
            last_error = initial_err
            for fallback in fallbacks:
                self.control()
                try:
                    data = self.call('models/' + fallback + ':generateContent', request)
                    self.model = fallback
                    self.options = [fallback] + [m for m in candidates if m != fallback][:2]
                    break
                except APIError as err:
                    if err.code != 404: raise
                    last_error = err
                except TemporaryGeminiUnavailable as err:
                    last_error = err
            else:
                raise Fatal('Không có model Gemini khả dụng.') from last_error
        text = ''.join(x.get('text', '') for x in data.get('candidates', [{}])[0].get('content', {}).get('parts', []) if not x.get('thought')) if data.get('candidates') else ''
        try:
            return json.loads(re.sub(r'^```(?:json)?\s*|\s*```$', '', text.strip()))
        except (ValueError, TypeError):
            raise Review('Gemini không trả JSON đọc ảnh hợp lệ.') from None

    def test(self):
        from PIL import Image
        b = io.BytesIO(); Image.new('RGB', (32, 32), 'white').save(b, 'PNG')
        self.deadline = time.monotonic() + API_TEST_BUDGET
        try:
            self.select()
            for selected in self.options or [self.model]:
                self.control(); self.model = selected
                try:
                    res = self.generate('Return JSON {"ok":true}. This is an image capability test.', b.getvalue())
                    if isinstance(res, dict) and res.get('ok') is True:
                        return self.model
                except APIError as e:
                    if e.code not in (400, 404): raise
                except TemporaryGeminiUnavailable:
                    pass
                except Review:
                    pass
            raise Fatal('Chưa kiểm tra được Gemini.')
        finally:
            self.deadline = None

    def prepare_images(self, full, top):
        try:
            from PIL import Image, ImageEnhance
            first = Image.open(io.BytesIO(full)).convert('RGB')
            if first.height >= first.width * 1.15:
                first = first.crop((0, 0, first.width, max(1, int(first.height * .50))))
                second = Image.open(io.BytesIO(top)).convert('RGB')
            else:
                second = ImageEnhance.Contrast(first.copy()).enhance(1.12)
            outputs = []
            for im in (first, second):
                im.thumbnail((1400, 1000)); out = io.BytesIO(); im.save(out, 'PNG'); outputs.append(out.getvalue())
            return tuple(outputs)
        except Exception:
            return full, top

    def read_handwriting_for_sbd(self, full, top, candidates=()):
        header_bytes = top or full
        try:
            from PIL import Image, ImageOps
            im = Image.open(io.BytesIO(full or top)).convert('RGB')
            if im.height >= im.width * 1.12:
                im = im.crop((0, 0, im.width, max(220, int(im.height * .42))))
            im = ImageOps.autocontrast(im, cutoff=1)
            im.thumbnail((1150, 620))
            buf = io.BytesIO(); im.save(buf, 'JPEG', quality=84)
            header_bytes = buf.getvalue()
        except Exception:
            pass
        hint_block = ''
        if candidates and len(candidates) <= 120:
            lines = [f"{st.get('name','')} | Lớp {st.get('class','')} | SBD {st.get('sbd','')}" for st in candidates[:120]]
            hint_block = '\nDanh sách học sinh trong Excel của đợt thi:\n' + '\n'.join(lines)
        prompt = (
            'Đọc phần ĐẦU PHIẾU TRẮC NGHIỆM (Họ và tên thí sinh, Lớp, Số báo danh viết tay, Mã đề viết tay, bảng 8 cột ô tô SBD và 4 cột ô tô Mã đề). '
            'Đọc chính xác HỌ VÀ TÊN học sinh viết tay trên phiếu, LỚP, SBD viết tay và MÃ ĐỀ viết tay. '
            'Ở bảng ô tô SBD (8 cột) và Mã đề (4 cột), đọc cả những ô học sinh TÔ MỜ (nếu nhìn thấy vết chì mờ trong ô thì ghi chữ số đó, nếu cột hoàn toàn trống thì ghi ?). '
            'Trả về đúng JSON: {"name":"họ và tên học sinh viết tay","class":"lớp","sbd":"SBD viết tay nếu có","sbd_bubbles":"8 ký tự cột ô tô SBD","code":"mã đề viết tay nếu có","code_bubbles":"4 ký tự cột ô tô Mã đề","clear":true}.'
            + hint_block
        )
        prev_deadline = getattr(self, 'deadline', None)
        self.deadline = time.monotonic() + 25
        try:
            if not getattr(self, 'model', ''):
                self.select()
            return self.generate(prompt, header_bytes)
        finally:
            self.deadline = prev_deadline

    def read(self, image):
        return self.generate('''Đọc PHIẾU TRẮC NGHIỆM. Trả JSON: {"subject":"tên môn hoặc rỗng", "subject_clear":true, "sbd":"chuỗi số viết tay hoặc rỗng", "code":"mã đề VIẾT TAY", "code_clear":true, "name":"họ tên viết tay", "class":"lớp", "sbd_bubbles":"số từ ô tô", "code_bubbles":"số từ ô tô", "clear":true, "note":"ngắn"}.''', image)


class Ollama(Gemini):
    def __init__(self, model='qwen3-vl:2b', control=lambda: None, log=lambda s: None):
        self.model = model.strip() or 'qwen3-vl:2b'; self.control = control; self.log = log
        if self.model not in LOCAL_MODELS:
            raise Fatal('Chế độ nội bộ hỗ trợ qwen3-vl:2b, :4b hoặc :8b.')


def make_analyzer(provider_label, key, model, control, log, **kwargs):
    p = str(provider_label or '').strip()
    if p in NO_AI_ALIASES or p.startswith('Không dùng AI') or model == 'no-ai':
        return NoAI(
            prompt_user=kwargs.get('prompt_user'),
            auto_single_match=kwargs.get('auto_single_match', True),
            default_code=kwargs.get('default_code', ''),
            exam_catalog=kwargs.get('exam_catalog'),
            selected_subject=kwargs.get('selected_subject', ''),
            log=log,
        )
    if p.startswith('Ollama'):
        return Ollama(model or 'qwen3-vl:2b', control, log)
    return Gemini(key, model, control, log)


def stop_local_ai():
    if os.name == 'nt':
        try:
            subprocess.run(['taskkill', '/F', '/IM', 'ollama.exe'], capture_output=True, timeout=5,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            subprocess.run(['taskkill', '/F', '/IM', 'ollama_llama_server.exe'], capture_output=True, timeout=5,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except Exception:
            pass
    return 'Đã dừng tiến trình AI nội bộ (Ollama) và giải phóng RAM/CPU.'


def login_file():
    return ROOT / '.vietschool_login.bin'


def save_login(username, password):
    payload = json.dumps({'username': username, 'password': password}).encode('utf-8')
    if os.name == 'nt':
        try:
            import ctypes
            from ctypes import wintypes
            class DATA_BLOB(ctypes.Structure):
                _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_char))]
            buf = ctypes.create_string_buffer(payload, len(payload))
            blob_in = DATA_BLOB(len(payload), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
            blob_out = DATA_BLOB()
            if ctypes.windll.crypt32.CryptProtectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
                encrypted = ctypes.string_at(blob_out.pbData, blob_out.cbData)
                ctypes.windll.kernel32.LocalFree(blob_out.pbData)
                login_file().write_bytes(encrypted)
                return
        except Exception:
            pass
    login_file().write_bytes(base64.b64encode(payload))


def read_login():
    p = login_file()
    if not p.is_file():
        return {}, ''
    raw = p.read_bytes()
    if not raw:
        return {}, ''
    # 1. Try Windows DPAPI decryption first (compatible with existing .vietschool_login.bin on user's PC)
    if os.name == 'nt':
        try:
            import ctypes
            from ctypes import wintypes
            class DATA_BLOB(ctypes.Structure):
                _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_char))]
            buf = ctypes.create_string_buffer(raw, len(raw))
            blob_in = DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
            blob_out = DATA_BLOB()
            if ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
                decrypted = ctypes.string_at(blob_out.pbData, blob_out.cbData)
                ctypes.windll.kernel32.LocalFree(blob_out.pbData)
                data = json.loads(decrypted.decode('utf-8'))
                if isinstance(data, dict):
                    return data, 'Đã nạp thông tin đăng nhập lưu trên máy.'
        except Exception:
            pass
    # 2. Fallback to Base64 JSON
    try:
        data = json.loads(base64.b64decode(raw).decode('utf-8'))
        if isinstance(data, dict):
            return data, 'Đã nạp thông tin đăng nhập lưu trên máy.'
    except Exception:
        pass
    return {}, ''


def _find_chrome_executable():
    """Locate Google Chrome (or Microsoft Edge fallback) on Windows/Linux."""
    candidates = []
    if os.name == 'nt':
        for env_key in ('ProgramFiles', 'ProgramFiles(x86)', 'LocalAppData'):
            base = os.environ.get(env_key, '')
            if base:
                candidates.append(Path(base) / 'Google' / 'Chrome' / 'Application' / 'chrome.exe')
                candidates.append(Path(base) / 'Microsoft' / 'Edge' / 'Application' / 'msedge.exe')
        try:
            import winreg
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                for subkey in (r'Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',):
                    try:
                        with winreg.OpenKey(hive, subkey) as k:
                            val, _ = winreg.QueryValueEx(k, '')
                            if val:
                                candidates.insert(0, Path(val))
                    except OSError:
                        pass
        except Exception:
            pass
    for cmd in ('chrome', 'chrome.exe', 'google-chrome', 'chromium', 'chromium-browser'):
        w = shutil.which(cmd)
        if w:
            candidates.append(Path(w))
    for c in candidates:
        if c and c.is_file():
            return str(c)
    return ''


def _debugger_listening(addr: str) -> bool:
    try:
        with urllib.request.urlopen(f'http://{addr}/json/version', timeout=1.5) as resp:
            return resp.status == 200
    except Exception:
        return False


def ensure_chrome(addr, control=lambda: None, log=lambda s: None):
    """Ensure Chrome is running with `--remote-debugging-port` at `addr`.
    If not already listening, automatically launch Chrome with a dedicated profile folder.
    """
    addr = (addr or '127.0.0.1:9222').strip()
    if ':' not in addr:
        addr = f'127.0.0.1:{addr}'
    host, port_str = addr.rsplit(':', 1)
    port = int(port_str) if port_str.isdigit() else 9222
    addr = f'{host}:{port}'

    if _debugger_listening(addr):
        return addr, False

    chrome_exe = _find_chrome_executable()
    if not chrome_exe:
        raise Fatal('Không tìm thấy Google Chrome trên máy. Hãy cài Google Chrome hoặc mở sẵn Chrome với --remote-debugging-port=' + str(port))

    profile_dir = Path(os.environ.get('LOCALAPPDATA', str(ROOT))) / f'HTB_VietSchool_Chrome_{port}'
    profile_dir.mkdir(parents=True, exist_ok=True)
    log(f'Đang khởi động Chrome Agent tại {addr} ({chrome_exe})…')
    subprocess.Popen([
        chrome_exe,
        f'--remote-debugging-port={port}',
        f'--user-data-dir={profile_dir}',
        '--no-first-run',
        '--no-default-browser-check',
        URL,
    ])
    until = time.monotonic() + 18.0
    while time.monotonic() < until:
        control()
        if _debugger_listening(addr):
            return addr, True
        time.sleep(0.35)
    raise Fatal(f'Đã gọi mở Chrome nhưng cổng {addr} chưa phản hồi sau 18 giây. Hãy đóng các cửa sổ Chrome Agent cũ rồi thử lại.')


DOM = r"""
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[đĐ]/g,'d').toLowerCase().replace(/\s+/g,' ').trim();
const txt=e=>String(e?.innerText??e?.textContent??'').replace(/\s+/g,' ').trim();
const vis=e=>{if(!e)return false;const st=getComputedStyle(e);if(st.display==='none'||st.visibility==='hidden'||Number(st.opacity)===0)return false;const r=e.getBoundingClientRect();return r.width>1&&r.height>1;};
const cells=r=>Array.from(r?.querySelectorAll('td,th,[role="gridcell"],[role="columnheader"],.wj-cell')||[]);
const fileCell=r=>cells(r).find(c=>/\.(jpg|jpeg|png|bmp|tif|tiff|webp)$/i.test(txt(c)));
const rows=()=>Array.from(document.querySelectorAll('tr,[role="row"],.wj-row')).filter(r=>vis(r)&&fileCell(r));
const _headerMap=r=>{
  // Use headers belonging to this grid, never a different table or dialog.
  const root=r.closest('table,.wj-flexgrid,[role="grid"],.dx-datagrid')||document;
  const hs=Array.from(root.querySelectorAll('th,[role="columnheader"],.wj-colheaders .wj-cell')).filter(vis);
  const groups=new Map();
  for(const e of hs){const parent=e.closest('tr,[role="row"],.wj-row')||e.parentElement;
    if(!groups.has(parent))groups.set(parent,[]);groups.get(parent).push(e);}
  for(const es of groups.values()){
    const labels=es.map(e=>norm(txt(e)));
    const idxOf=pats=>{let i=labels.findIndex(h=>pats.includes(h));
      return i>=0?i:labels.findIndex(h=>pats.some(p=>h.startsWith(p+' ')));};
    const f=idxOf(['phieu tra loi','ten anh','anh phieu','ten file','file','anh bai lam','ten phieu']);
    if(f<0)continue;
    return {file:f,name:idxOf(['ho va ten','ho ten','ho ten hoc sinh','ten hoc sinh']),
      last:idxOf(['ho va chu lot','ho va ten lot','ho dem','ho lot','ho']),
      first:idxOf(['ten','ten hs']),class:idxOf(['lop','ten lop']),
      subject:idxOf(['mon','mon thi','mon hoc']),sbd:idxOf(['sbd','so bao danh']),
      code:idxOf(['ma de','ma de thi']),score:idxOf(['diem','tong diem','diem tn','diem trac nghiem'])};
  }
  return null;
};
const data=r=>{
  const cs=cells(r).map(txt);
  const fIdx=cs.findIndex(t=>/\.(jpg|jpeg|png|bmp|tif|tiff|webp)$/i.test(t));
  const file=fIdx>=0?cs[fIdx]:'';
  const hm=_headerMap(r);
  if(hm && hm.sbd>=0 && cs.length>hm.sbd){
    const shift=fIdx-hm.file;
    const at=idx=>(idx>=0 && (idx+shift)>=0 && (idx+shift)<cs.length)?cs[idx+shift]:'';
    return {file,name:at(hm.name)||[at(hm.last),at(hm.first)].filter(Boolean).join(' '),
      class:at(hm.class),subject:at(hm.subject),sbd:at(hm.sbd),code:at(hm.code),score:at(hm.score)};
  }
  // Without usable headers, distinguish split-name vs full-name layouts by class position.
  const isClass=t=>/^\d{1,2}\s*[a-z]\s*\d{1,2}$/i.test(t);
  const split=isClass(cs[fIdx+3]||'')&&!isClass(cs[fIdx+2]||'');
  const offset=split?1:0;
  return {file,name:split?[cs[fIdx+1],cs[fIdx+2]].filter(Boolean).join(' '):cs[fIdx+1]||'',
    class:cs[fIdx+2+offset]||'',subject:cs[fIdx+3+offset]||'',
    sbd:cs[fIdx+4+offset]||'',code:cs[fIdx+5+offset]||'',score:cs[fIdx+6+offset]||''};
};
// Only controls explicitly identified as grading batches are allowed to change a batch.
const batchControl=()=>{
  const native=Array.from(document.querySelectorAll('select')).filter(vis);
  const label=e=>norm([e.id,e.name,e.getAttribute('aria-label'),e.getAttribute('title'),
    ...Array.from(e.labels||[]).map(txt)].filter(Boolean).join(' '));
  const marked=native.filter(e=>/dot.?cham|grading.?batch|batch|dot.?thi/.test(label(e).replace(/[_-]/g,'')));
  if(marked.length===1)return marked[0];
  const candidates=native.filter(e=>{
    const opts=Array.from(e.options||[]).map(o=>norm(txt(o)));
    return opts.length && !opts.some(t=>/^(tat ca|loi sbd|loi ma de|chua cham|da cham)$/.test(t)) &&
      !opts.every(t=>/^\d+$/.test(t)||/^\d{1,2}[a-z]\d{1,2}$/.test(t));
  });
  return candidates.length===1?candidates[0]:null;
};
const scrollBox=()=>{
  const wj=document.querySelector('[wj-part="root"]');
  if(wj&&wj.scrollHeight>wj.clientHeight+4)return wj;
  return Array.from(document.querySelectorAll('*')).filter(e=>vis(e)&&e.scrollHeight>e.clientHeight+10&&['auto','scroll'].includes(getComputedStyle(e).overflowY)).sort((a,b)=>b.clientHeight-a.clientHeight)[0]||document.scrollingElement;
};
const xemRow=file=>rows().find(r=>txt(fileCell(r))===file);
const xemTarget=file=>{
  const r=xemRow(file);
  if(!r)return {status:'not-visible',reason:'Dòng chưa nằm trong vùng hiển thị'};
  const isXemBtn=e=>vis(e)&&(/^xem$/i.test(norm(txt(e)))||e.classList.contains('cbt-act-main')||/xem/i.test(norm(e.getAttribute('title')||'')));
  const bs=Array.from(r.querySelectorAll('button,a,[role="button"],.cbt-act-main,.btn,.dx-link')).filter(e=>isXemBtn(e)&&!Array.from(e.children).some(isXemBtn));
  if(bs.length===1)return {status:'found',element:bs[0],source:'exact-row-xem'};
  if(bs.length>1)return {status:'found',element:bs[0],source:'first-row-xem'};
  // Check frozen action column at same vertical coordinate (Wijmo frozen cells)
  const rr=r.getBoundingClientRect();
  const midY=(rr.top+rr.bottom)/2;
  const pageXem=Array.from(document.querySelectorAll('button.cbt-act-main,button,a,[role="button"]')).filter(e=>{
    if(!isXemBtn(e))return false;
    const br=e.getBoundingClientRect();
    return Math.abs((br.top+br.bottom)/2 - midY) <= Math.max(14, rr.height*0.55);
  });
  if(pageXem.length===1)return {status:'found',element:pageXem[0],source:'aligned-y-xem'};
  return {status:'ambiguous',reason:'Số nút Xem trong dòng: '+bs.length};
};
const modal=expectedFile=>{
  const sn=document.getElementById('txtSBD'),cn=document.getElementById('txtMaDe'),fn=document.getElementById('lblTenfile');
  if(sn&&cn&&vis(sn)&&vis(cn)){
    const cur=fn?String(fn.value||txt(fn)||'').trim():'';
    if(!expectedFile||!cur||cur.toLowerCase().includes(String(expectedFile).toLowerCase())){
      let p=sn.parentElement;
      while(p&&p!==document.body&&!p.contains(cn))p=p.parentElement;
      return p||document.body;
    }
  }
  const dialogs=Array.from(document.querySelectorAll('[role="dialog"],.dx-overlay-content,.dx-popup-normal,.modal,.modal-content')).filter(vis);
  if(dialogs.length)return dialogs[dialogs.length-1];
  throw Error('Chưa mở cửa sổ Xem của phiếu '+expectedFile);
};
const input=(root,label)=>{
  const idAliases=label==='sbd'?['txtsbd','sbd','sobaodanh','txtsobaodanh']:['txtmade','made','madethi'];
  for(const id of idAliases){
    const el=root.querySelector('#'+id+',[id="'+id+'" i],[name="'+id+'" i]') || document.getElementById(id);
    if(el&&vis(el))return el;
  }
  const ins=Array.from(root.querySelectorAll('input:not([type="hidden"])')).filter(vis);
  return label==='sbd'?ins[0]:ins[1];
};
const nav=(dir,clickIt)=>{
  const sel=dir==='next'?'.dx-navigate-button.dx-next-button,[aria-label*="Next" i]':'.dx-navigate-button.dx-prev-button,[aria-label*="Prev" i]';
  const b=document.querySelector(sel);
  if(!b||!vis(b))return {present:false,disabled:true};
  const dis=b.classList.contains('dx-state-disabled')||b.disabled||b.getAttribute('aria-disabled')==='true';
  if(!dis&&clickIt)b.click();
  return {present:true,disabled:dis};
};
const xemDebug=file=>({file,visibleRows:rows().map(data)});
"""


def verified(row, proposal):
    if not row:
        return False
    return (str(row.get('sbd') or '').strip() == str(proposal.get('sbd') or '').strip()
            and str(row.get('code') or '').strip() == str(proposal.get('code') or '').strip()
            and not blank(row.get('name')))


class Browser:
    def __init__(self, control=lambda: None):
        self.control = control
        self.driver = None
        self.frame_path = []
        self.grid_bound = False
        self.batch = None
        self.expected = None
        self.last_xem_source = ''
        self.file_scroll_top = {}

    def delay(self, sec):
        end = time.monotonic() + sec
        while time.monotonic() < end:
            self.control()
            time.sleep(min(0.1, max(0.01, end - time.monotonic())))

    def check(self):
        self.control()
        if not self.driver:
            raise Fatal('Chưa kết nối Chrome.')

    def connect(self, address='127.0.0.1:9222'):
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        opts = Options()
        opts.debugger_address = address
        self.driver = webdriver.Chrome(options=opts)
        self.grid_bound = False
        try:
            handles = list(self.driver.window_handles)
            for h in handles:
                self.driver.switch_to.window(h)
                cur_url = (self.driver.current_url or '').lower()
                if 'truonghocviet.vn' in cur_url:
                    break
        except Exception:
            pass

    def login(self, username, password, log=lambda s: None):
        self.check()
        try:
            self.driver.switch_to.default_content()
            cur_url = (self.driver.current_url or '').lower()
            if 'truonghocviet.vn' not in cur_url:
                log('Đang mở trang VietSchool (' + URL + ')…')
                self.driver.get(URL)
                self.delay(1.5)
            if not username or not password:
                return
            for _ in range(10):
                self.control()
                state = self.driver.execute_script("""
                    const p=Array.from(document.querySelectorAll('input[type="password"]')).find(e=>e.offsetParent!==null);
                    if(!p)return {hasLogin:false};
                    const form=p.closest('form')||document.body;
                    const u=Array.from(form.querySelectorAll('input[type="text"],input[type="tel"],input:not([type="password"]):not([type="hidden"]):not([type="checkbox"]):not([type="submit"])')).find(e=>e.offsetParent!==null);
                    return {hasLogin:!!(u&&p)};
                """)
                if state and state.get('hasLogin'):
                    log('Đang điền tài khoản và đăng nhập VietSchool…')
                    self.driver.execute_script("""
                        const p=Array.from(document.querySelectorAll('input[type="password"]')).find(e=>e.offsetParent!==null);
                        const form=p.closest('form')||document.body;
                        const u=Array.from(form.querySelectorAll('input[type="text"],input[type="tel"],input:not([type="password"]):not([type="hidden"]):not([type="checkbox"]):not([type="submit"])')).find(e=>e.offsetParent!==null);
                        const setVal=(el,val)=>{
                          const setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value')?.set;
                          if(setter)setter.call(el,val);else el.value=val;
                          el.dispatchEvent(new Event('input',{bubbles:true}));
                          el.dispatchEvent(new Event('change',{bubbles:true}));
                        };
                        setVal(u,arguments[0]);
                        setVal(p,arguments[1]);
                        const btn=form.querySelector('button[type="submit"],input[type="submit"],.btn-login,button');
                        if(btn)btn.click();
                    """, username, password)
                    self.delay(2.0)
                    return
                if self.driver.find_elements('css selector', 'iframe,frame'):
                    return
                self.delay(0.35)
        except Exception:
            pass

    def switch_frame_path(self, path):
        self.driver.switch_to.default_content()
        for idx in path:
            frames = [f for f in self.driver.find_elements('css selector', 'iframe,frame') if f.is_displayed()]
            self.driver.switch_to.frame(frames[idx])
        self.frame_path = list(path)

    def bind_grid(self, timeout=10):
        self.check()
        until = time.monotonic() + timeout
        while time.monotonic() < until:
            self.control()
            todo = [[]]
            seen = 0
            while todo and seen < 32:
                path = todo.pop(0); seen += 1
                try:
                    self.switch_frame_path(path)
                    ok = self.driver.execute_script(DOM + "return rows().length>0 || !!document.querySelector('.wj-flexgrid,[wj-part=\"root\"]') || Array.from(document.querySelectorAll('th,[role=\"columnheader\"]')).some(e=>/phieu tra loi|ten anh|ten file|so bao danh|sbd/.test(norm(txt(e))));")
                    if ok:
                        self.grid_bound = True
                        self.batch = self.context()
                        return True
                    frames = [f for f in self.driver.find_elements('css selector', 'iframe,frame') if f.is_displayed()]
                    if len(path) < 4:
                        todo.extend(path + [i] for i in range(len(frames)))
                except Exception:
                    pass
            self.delay(0.35)
        raise Fatal('Chưa tìm thấy bảng Chấm bài giấy trên Chrome. Hãy mở mục Chấm bài giấy → Chấm bài.')

    def context(self):
        try:
            return self.driver.execute_script("""
                const s=Array.from(document.querySelectorAll('select')).map(e=>e.value).join('|');
                return location.pathname+'#'+s;
            """)
        except Exception:
            return ''

    def js(self, script, *args):
        self.check()
        if not self.grid_bound:
            self.bind_grid()
        return self.driver.execute_script(DOM + script, *args)

    def list_grading_batches(self):
        """Read all available 'Đợt chấm' options from the VietSchool grading page."""
        self.check()
        if not self.grid_bound:
            try:
                self.bind_grid(timeout=6)
            except Exception:
                pass
        res = self.driver.execute_script(DOM + r"""
            const s=batchControl();
            if(s)return {current:txt(s.selectedOptions[0]),batches:Array.from(s.options).map(txt).filter(Boolean),kind:'select'};
            return {current:'',batches:[],kind:'none'};
        """)
        return res or {'current': '', 'batches': [], 'kind': 'none'}

    def select_grading_batch(self, batch_label: str):
        """Select a specific 'Đợt chấm' on VietSchool by its visible text and wait for the table to update."""
        self.check()
        if not self.grid_bound:
            self.bind_grid(timeout=6)
        target = str(batch_label or '').strip()
        if not target:
            return False
        changed = self.driver.execute_script(DOM + r"""
            const s=batchControl(),target=norm(arguments[0]);
            if(!s)return {ok:false};
            const matches=Array.from(s.options).filter(o=>norm(txt(o))===target);
            if(matches.length!==1)return {ok:false};
            const o=matches[0];
            if(s.value!==o.value){
              const setter=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set;
              setter.call(s,o.value);
              s.dispatchEvent(new Event('input',{bubbles:true}));
              s.dispatchEvent(new Event('change',{bubbles:true}));
            }
            return {ok:true};
        """, target)
        if not changed or not changed.get('ok'):
            return False
        self.file_scroll_top = {}
        self.wait_for_table()
        info = self.list_grading_batches()
        if norm(info.get('current')) != norm(target):
            raise Fatal('Đợt chấm chưa chuyển đúng. Hãy chọn đợt trên Chrome rồi quét lại.')
        self.batch = self.context()
        return True

    def wait_for_table(self, timeout=15):
        """Wait for visible loading overlays to disappear and grid contents to settle."""
        until = time.monotonic() + timeout
        previous = None
        stable = 0
        self.delay(1.0)
        while time.monotonic() < until:
            self.control()
            current = self.js(r"""
                const loading=Array.from(document.querySelectorAll('.dx-loadpanel,.loading,[aria-busy="true"]')).some(vis);
                return {loading, rows:rows().map(data)};
            """)
            if not current['loading'] and current == previous:
                stable += 1
                if stable >= 3:
                    return
            else:
                stable = 0
            previous = current
            self.delay(0.3)
        raise Fatal('Bảng chấm chưa tải xong; hãy đợi rồi quét lại.')

    def show_all_for_search(self):
        """Search all sheets rather than only the current error filter."""
        changed = self.js(r"""
            const candidates=Array.from(document.querySelectorAll('select')).filter(vis).filter(s=>{
              const os=Array.from(s.options).map(o=>norm(txt(o)));
              return os.includes('tat ca')&&os.some(t=>/loi sbd|loi ma de|chua cham|da cham/.test(t));
            });
            let changed=false;
            for(const s of candidates){
              const o=Array.from(s.options).find(o=>norm(txt(o))==='tat ca');
              if(o&&s.value!==o.value){s.value=o.value;s.dispatchEvent(new Event('input',{bubbles:true}));s.dispatchEvent(new Event('change',{bubbles:true}));changed=true;}
            }
            return changed;
        """)
        if changed:
            self.wait_for_table()
        self.batch = self.context()
        return changed

    def close_missing_dialog(self):
        try:
            self.driver.execute_script(DOM + r"""
                const ds=Array.from(document.querySelectorAll('[role="dialog"],.modal,.dx-overlay-content')).filter(e=>vis(e)&&/thieu bai/i.test(norm(txt(e))));
                for(const d of ds){
                  const b=d.querySelector('.close,.btn-close,.dx-closebutton,button');
                  if(b)b.click();
                }
            """)
        except Exception:
            pass

    def close_any_viewer(self):
        if not self.driver:
            return
        for _ in range(4):
            try:
                st = self._modal_status(self.expected or '')
                if st.get('state') == 'none':
                    self.expected = None
                    return
                closed = self.js(r"""
const isClose=e=>{
  if(!vis(e)||e.disabled)return false;
  const t=norm(txt(e));
  if(/^(×|✕|✖|x|dong|close)$/i.test(t))return true;
  const attrs=norm([e.className,e.id,e.getAttribute('aria-label'),e.getAttribute('title'),e.getAttribute('data-dismiss'),e.getAttribute('data-bs-dismiss'),e.getAttribute('onclick')].filter(Boolean).join(' '));
  if(/close|dong|dismiss|hide|btn-close|dx-closebutton/.test(attrs))return true;
  return !!e.querySelector('.btn-close,.dx-icon-close,i[class*="times"],i[class*="close"],i[class*="x-lg"]');
};
const s=document.getElementById('txtSBD'),c=document.getElementById('txtMaDe');
let roots=[];
if(s&&vis(s)){
  let best=null;
  for(let p=s.parentElement;p&&p!==document.body;p=p.parentElement){
    if(Array.from(p.querySelectorAll('tr,[role="row"]')).some(fileCell))break;
    best=p;
  }
  if(best)roots.push(best);
}
roots=roots.concat(Array.from(document.querySelectorAll('[role="dialog"],.dx-overlay-content,.dx-popup-normal,.modal,.modal-content,.el-dialog,.ant-modal')).filter(e=>vis(e)&&!Array.from(e.querySelectorAll('tr,[role="row"]')).some(fileCell)));
for(const root of roots){
  const bs=Array.from(root.querySelectorAll('button,a,[role="button"],.btn,.dx-button,.close,.btn-close,.dx-closebutton,span,div,i')).filter(e=>isClose(e)&&!Array.from(e.children).some(isClose));
  if(bs.length){bs[0].click();return true;}
}
return false;
""")
                if not closed:
                    from selenium.webdriver import ActionChains
                    from selenium.webdriver.common.keys import Keys
                    ActionChains(self.driver).send_keys(Keys.ESCAPE).perform()
                self.delay(0.35)
            except Exception:
                break

    def close(self):
        if not self.driver:
            return
        self.close_any_viewer()
        self.expected = None

    def page_signature(self):
        return self.js("return rows().map(r=>data(r).file).join('|');")

    def turn_page(self, direction):
        before = self.page_signature()
        state = self.js("return nav(arguments[0],true);", direction)
        if not state.get('present') or state.get('disabled'):
            return False
        for _ in range(40):
            self.delay(0.2)
            if self.page_signature() != before:
                return True
        raise Fatal('Chuyển trang không tiến triển.')

    def first_page(self):
        for _ in range(300):
            if not self.turn_page('prev'):
                return
        raise Fatal('Không về được trang đầu.')

    def walk_page(self, visit, reset_top=True):
        if not hasattr(self, 'file_scroll_top'):
            self.file_scroll_top = {}
        if reset_top:
            self.js("const s=scrollBox();if(s){s.scrollTop=0;s.dispatchEvent(new Event('scroll',{bubbles:true}));}")
            self.delay(0.35)
        for _ in range(2000):
            self.check()
            state = self.js("const s=scrollBox();return s?{top:s.scrollTop,h:s.clientHeight,total:s.scrollHeight}:null;")
            cur_top = state['top'] if state else 0
            rs = self.js('return rows().map(data);')
            for r in rs:
                if r.get('file') and r['file'] not in self.file_scroll_top:
                    self.file_scroll_top[r['file']] = cur_top
                if visit(r):
                    return True
            if not state:
                return False
            if state['top'] + state['h'] >= state['total'] - 3:
                self.delay(0.3)
                for r in self.js('return rows().map(data);'):
                    if r.get('file') and r['file'] not in self.file_scroll_top:
                        self.file_scroll_top[r['file']] = state['top']
                    if visit(r):
                        return True
                return False
            self.js("const s=scrollBox();s.scrollTop+=Math.max(60,s.clientHeight*.65);s.dispatchEvent(new Event('scroll',{bubbles:true}));")
            self.delay(0.22)
            after = self.js('return scrollBox()?.scrollTop;')
            if after == state['top']:
                raise Fatal('Vùng cuộn không tiến triển; dừng với kết quả chưa đầy đủ.')
        raise Fatal('Vượt giới hạn cuộn; chưa quét hết bảng.')

    def scan(self):
        self.close()
        self.close_missing_dialog()
        if not self.grid_bound:
            self.bind_grid()
        self.file_scroll_top = {}
        self.first_page()
        result = {}
        expected = self.driver.execute_script("const m=(document.body.innerText||'').match(/Đã chấm\\s*(\\d+)\\s*\\/\\s*(\\d+)/i);return m?Number(m[2]):null;")
        def collect(r):
            if r['file'] in result and result[r['file']] != r:
                raise Fatal('Trùng tên ảnh nhưng dữ liệu khác nhau; không đủ khóa định danh.')
            result[r['file']] = r
            return False
        for _ in range(300):
            self.walk_page(collect, reset_top=True)
            if not self.turn_page('next'):
                if not result and expected:
                    raise Fatal(f'Quét được 0/{expected} phiếu. Chọn Lọc: Tất cả rồi thử lại.')
                return list(result.values())
        raise Fatal('Vượt giới hạn phân trang; chưa quét hết.')

    def _click_xem(self, file, method='webdriver'):
        selected = self.js('return xemTarget(arguments[0]);', file)
        if selected['status'] == 'not-visible':
            return False
        if selected['status'] != 'found':
            self.save_xem_diagnostic(file, selected.get('reason', 'Không nhận nút Xem'))
            raise Review('Không nhận nút Xem duy nhất: ' + selected.get('reason', ''))
        self.last_xem_source = selected.get('source', '')
        try:
            self.driver.execute_script("arguments[0].scrollIntoView({block:'center',inline:'nearest'});", selected['element'])
            self.delay(0.22)
            again = self.js('return xemTarget(arguments[0]);', file)
            if again['status'] != 'found':
                raise Review('Dòng/nút Xem thay đổi sau khi cuộn; không tự bấm dòng khác.')
            el = again['element']
            if method == 'webdriver':
                el.click()
            elif method == 'row-doubleclick':
                from selenium.webdriver import ActionChains
                cell = self.js('return fileCell(xemRow(arguments[0]));', file)
                cell.location_once_scrolled_into_view
                self.delay(0.2)
                cell = self.js('return fileCell(xemRow(arguments[0]));', file)
                ActionChains(self.driver).move_to_element(cell).pause(0.15).double_click(cell).perform()
            elif method == 'actions':
                from selenium.webdriver import ActionChains
                ActionChains(self.driver).move_to_element(el).pause(0.12).click().perform()
            elif method == 'keyboard':
                from selenium.webdriver.common.keys import Keys
                el.send_keys(Keys.ENTER)
            elif method == 'javascript':
                result = self.js("const t=xemTarget(arguments[0]);if(t.status!=='found'||!t.element.isConnected)return false;t.element.click();return true;", file)
                if result is not True:
                    raise Review('Nút Xem biến mất trước cú bấm JavaScript.')
            else:
                raise ValueError('Unknown click strategy')
            self.last_xem_source = selected.get('source', '') + ' • ' + method
            return True
        except (StopRun, Fatal, Review):
            raise
        except Exception as exc:
            self.save_xem_diagnostic(file, f'{method}: {short_error(exc)}')
            raise Review('Không thể bấm Xem theo cách ' + method + ': ' + short_error(exc)) from None

    def _modal_status(self, file):
        return self.js(r"""
try {modal(arguments[0]);return {state:'expected'};}catch(error){
 const sn=document.getElementById('txtSBD'),cn=document.getElementById('txtMaDe'),fn=document.getElementById('lblTenfile');
 if(sn&&cn&&vis(sn)&&vis(cn)){
   return {state:'other',reason:'Ô sửa SBD/Mã đề đang hiển thị: '+String(error).slice(0,170),
     viewerFile:fn&&vis(fn)?String(fn.value||'').trim():'(chưa đọc được tên file)'};
 }
 const nodes=Array.from(document.querySelectorAll('[role="dialog"],.dx-overlay-content,.dx-popup-content,.dx-popup-normal,.modal,.modal-content,.el-dialog,.ant-modal')).filter(vis);
 const roots=nodes.filter(e=>!nodes.some(o=>o!==e&&o.contains(e)));
 const editing=roots.filter(e=>{
   const fieldCount=Array.from(e.querySelectorAll('input')).filter(vis).length;
   const hasSave=Array.from(e.querySelectorAll('button,a,[role="button"]')).some(b=>vis(b)&&/luu chinh sua|luu lai|cap nhat/.test(norm(txt(b))));
   const labels=norm(txt(e));return hasSave||(fieldCount>=2&&labels.includes('sbd')&&labels.includes('ma de'));
 });
 if(editing.length)return {state:'other',reason:String(error).slice(0,220),popups:editing.length};
 return {state:'none',reason:String(error).slice(0,220)};
}
""", file)

    def _wait_modal(self, file, timeout=2.0):
        until = time.monotonic() + timeout
        last = {'state': 'none'}
        while time.monotonic() < until:
            self.control()
            last = self._modal_status(file)
            if last['state'] == 'expected':
                return True
            self.delay(0.2)
        if last['state'] == 'other':
            raise Fatal('Có cửa sổ chỉnh sửa đang mở nhưng không xác nhận đúng ảnh ' + file + '. Dừng để tránh sửa nhầm; hãy xuất chẩn đoán.')
        return False

    def _recover_xem_grid(self):
        self.expected = None
        self.reload_grading_table()
        self.check()

    def _recover_xem_page(self):
        self.expected = None
        old_batch = self.batch
        self.driver.switch_to.default_content()
        self.driver.refresh()
        self.grid_bound = False
        self.bind_grid(timeout=18)
        if old_batch != self.context():
            raise Fatal('Sau tải lại trang, bộ lọc/đợt chấm đã thay đổi. Dừng để tránh sửa nhầm đợt.')
        self.batch = old_batch
        self.check()

    def save_xem_diagnostic(self, file, reason):
        payload = {'file': file, 'status': 'unavailable'}
        try: payload = self.js('return xemDebug(arguments[0]);', file)
        except Exception as exc: payload['domError'] = short_error(exc)
        payload['reasonFromPython'] = str(reason)[:500]
        try: payload['viewerStatus'] = self._modal_status(file)
        except Exception as exc: payload['viewerStatusError'] = short_error(exc)
        payload['when'] = datetime.now().isoformat(timespec='seconds')
        try: (ROOT / 'xem_debug.json').write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
        except OSError: pass

    def locate_visible(self, file):
        """Return row dict if file is currently visible in the viewport without scrolling."""
        try:
            current = self.js('return rows().map(data);')
        except Exception:
            current = []
        for r in current:
            if r.get('file') == file:
                return r
        return None

    def locate(self, file, open_it=False):
        self.close_missing_dialog()
        if not hasattr(self, 'file_scroll_top'):
            self.file_scroll_top = {}
        r_vis = self.locate_visible(file)
        if r_vis:
            if open_it and not self._click_xem(file):
                raise Review('Dòng phiếu đã chuyển vị trí ngay trước lúc bấm Xem.')
            return r_vis

        target_top = self.file_scroll_top.get(file)
        if target_top is not None:
            try:
                self.js("const s=scrollBox();if(s){s.scrollTop=Math.max(0,arguments[0]-40);s.dispatchEvent(new Event('scroll',{bubbles:true}));}", target_top)
                self.delay(0.22)
                r_jump = self.locate_visible(file)
                if r_jump:
                    if open_it and not self._click_xem(file):
                        raise Review('Dòng phiếu đã chuyển vị trí ngay trước lúc bấm Xem.')
                    return r_jump
            except (StopRun, Fatal, Review):
                raise
            except Exception:
                pass

        found = None
        def visit(r):
            nonlocal found
            if r['file'] != file:
                return False
            found = r
            if open_it:
                ok = self._click_xem(file)
                if not ok:
                    raise Review('Dòng đã đổi vị trí trong lúc mở. Thử ở lượt sau.')
            return True

        if self.walk_page(visit, reset_top=False):
            return found

        self.first_page()
        for _ in range(300):
            if self.walk_page(visit, reset_top=True):
                return found
            if not self.turn_page('next'):
                return None
        raise Fatal('Vượt giới hạn tìm phiếu.')

    def open(self, file):
        self.close(); self.close_missing_dialog(); self.check()
        self.last_xem_source = ''
        failures = []
        strategies = ('webdriver', 'row-doubleclick', 'actions', 'javascript',
                      'row-doubleclick', 'webdriver', 'row-doubleclick', 'keyboard')
        for attempt, method in enumerate(strategies):
            self.control()
            if attempt == 4:
                if self._modal_status(file)['state'] == 'other':
                    raise Fatal('Cửa sổ chỉnh sửa không xác minh được đang mở; dừng an toàn.')
                try: self._recover_xem_grid()
                except (Fatal, StopRun): raise
                except Exception as exc: failures.append('Tải lại bảng: ' + short_error(exc))
            elif attempt == 6:
                if self._modal_status(file)['state'] == 'other':
                    raise Fatal('Cửa sổ chỉnh sửa không xác minh được đang mở; dừng an toàn.')
                try: self._recover_xem_page()
                except (Fatal, StopRun): raise
                except Exception as exc: failures.append('Khôi phục Chrome: ' + short_error(exc))
            state = self._modal_status(file)
            if state['state'] == 'expected':
                self.expected = file; return
            if state['state'] == 'other':
                self.close_any_viewer()
                state = self._modal_status(file)
                if state['state'] == 'expected':
                    self.expected = file; return
                if state['state'] == 'other':
                    raise Fatal('Có cửa sổ chỉnh sửa đang mở không trùng ảnh. Dừng trước khi bấm tiếp.')
            try:
                if not self.locate(file, False):
                    raise Review('Không tìm thấy tên ảnh sau khi bảng tải lại.')
                if not self._click_xem(file, method):
                    raise Review('Nút Xem không còn trong vùng đang xem.')
                if self._wait_modal(file, 4.0):
                    self.expected = file; return
                failures.append(method + ': bấm thành công nhưng không xuất hiện cửa sổ')
            except (Fatal, StopRun):
                raise
            except Review as exc:
                failures.append(method + ': ' + short_error(exc))
        self.expected = None
        reason = '; '.join(failures[-5:])
        self.save_xem_diagnostic(file, reason)
        raise Review('Không mở được Xem sau các cách bấm và khôi phục giao diện. ' + reason[:180])

    def read_modal_fields(self):
        try:
            return self.js(r"""const r=modal(arguments[0]);
const sbd=(input(r,'sbd').value||'').trim();
const code=(input(r,'ma de').value||'').trim();
let name='',cls='';
const nameEl=r.querySelector('#lblHoTen,#txtHoTen,[id*="HoTen" i],[id*="hoten" i],[class*="student-name" i]')||document.querySelector('#lblHoTen,#txtHoTen');
const clsEl=r.querySelector('#lblLop,#txtLop,[id*="TenLop" i],[id*="Lop" i],[class*="student-class" i]')||document.querySelector('#lblLop,#txtLop');
if(nameEl&&vis(nameEl))name=(nameEl.value||txt(nameEl)||'').trim();
if(clsEl&&vis(clsEl))cls=(clsEl.value||txt(clsEl)||'').trim();
return {sbd,code,name,class:cls,modalText:txt(r).slice(0,600)};""", self.expected)
        except Exception:
            return {'sbd': '', 'code': '', 'name': '', 'class': ''}

    def wait_for_chrome_edit(self, file, candidates=(), suggested_code='', log=lambda s: None, timeout=90):
        hint_text = f" (Gợi ý HS thiếu bài: {candidates[0]['sbd']} — {candidates[0]['name']})" if candidates else ''
        log(f"[{file}] Đã mở cửa sổ Xem trên Chrome{hint_text}. Hãy sửa SBD / Mã đề ngay trong cửa sổ Xem của VietSchool rồi bấm Lưu/Đóng…")
        end = time.monotonic() + timeout
        last_valid = None
        while time.monotonic() < end:
            self.control()
            try:
                fields = self.js("const r=modal(arguments[0]);return {sbd:(input(r,'sbd').value||'').trim(),code:(input(r,'ma de').value||'').trim()};", file)
                if number(fields.get('sbd', ''), 4, 12) and number(fields.get('code', ''), 2, 6):
                    last_valid = fields
            except Exception:
                self.expected = None
                if last_valid:
                    return {'action': 'apply', 'sbd': last_valid['sbd'], 'code': last_valid['code'], 'name': '', 'class': ''}
                return {'action': 'skip'}
            time.sleep(0.25)
        if last_valid:
            return {'action': 'apply', 'sbd': last_valid['sbd'], 'code': last_valid['code'], 'name': '', 'class': ''}
        return {'action': 'skip'}

    def image(self):
        self.check()
        el = None
        for _ in range(12):
            self.control()
            try:
                el = self.js("""const r=modal(arguments[0]);let es=[];for(let p=r;p&&p!==document.body;p=p.parentElement){if(Array.from(p.querySelectorAll('tr,[role="row"]')).some(fileCell))break;es=Array.from(p.querySelectorAll('canvas,img')).filter(e=>vis(e)&&e.getBoundingClientRect().width>260&&e.getBoundingClientRect().height>180&&(e.tagName==='CANVAS'?e.width>260:(e.complete&&e.naturalWidth>260)));if(es.length)break;}es.sort((a,b)=>b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight);return es.length?es[0]:null;""", self.expected)
                if el is not None:
                    break
            except Exception:
                pass
            self.delay(0.25)
        if el is None:
            el = self.js("""const r=modal(arguments[0]);let es=[];for(let p=r;p&&p!==document.body;p=p.parentElement){if(Array.from(p.querySelectorAll('tr,[role="row"]')).some(fileCell))break;es=Array.from(p.querySelectorAll('canvas,img')).filter(e=>vis(e)&&e.getBoundingClientRect().width>260&&e.getBoundingClientRect().height>180);if(es.length)break;}es.sort((a,b)=>b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight);if(!es.length)throw Error('Không tìm thấy ảnh phiếu trong cửa sổ.');return es[0];""", self.expected)
        from PIL import Image
        data = self.driver.execute_script("try{const e=arguments[0];if(e.tagName==='CANVAS')return e.toDataURL('image/png');const c=document.createElement('canvas');c.width=e.naturalWidth;c.height=e.naturalHeight;if(!c.width)return null;c.getContext('2d').drawImage(e,0,0);return c.toDataURL('image/png');}catch{return null;}", el)
        raw = base64.b64decode(data.split(',', 1)[1]) if data and data.startswith('data:image/png;base64,') else None
        if not raw:
            try:
                img_url = self.driver.execute_script("const e=arguments[0];return e.tagName==='IMG'?(e.currentSrc||e.src||''):'';", el)
                if isinstance(img_url, str) and img_url.startswith(('http://', 'https://')):
                    cookies = '; '.join(f"{c['name']}={c['value']}" for c in (self.driver.get_cookies() or []) if c.get('name'))
                    ua = self.driver.execute_script("return navigator.userAgent||'Mozilla/5.0';")
                    req_headers = {'User-Agent': ua, 'Referer': URL}
                    if cookies:
                        req_headers['Cookie'] = cookies
                    req = urllib.request.Request(img_url, headers=req_headers)
                    with urllib.request.urlopen(req, timeout=8) as resp:
                        fetched = resp.read(15 * 1024 * 1024)
                        if len(fetched) > 512:
                            raw = fetched
            except Exception:
                raw = None
        if not raw:
            saved_state = None
            try:
                saved_state = self.driver.execute_script(r"""const e=arguments[0];
const sc=e.parentElement;
const prev={eStyle:e.getAttribute('style')||'',scLeft:sc?sc.scrollLeft:0,scTop:sc?sc.scrollTop:0};
if(sc&&sc.scrollWidth>sc.clientWidth+10){
  e.style.setProperty('max-width','100%','important');
  e.style.setProperty('width','100%','important');
  e.style.setProperty('height','auto','important');
  e.style.setProperty('transform','none','important');
  sc.scrollLeft=0;sc.scrollTop=0;
}
return prev;""", el)
                self.delay(0.15)
                raw = el.screenshot_as_png
            finally:
                if saved_state is not None:
                    try:
                        self.driver.execute_script("const e=arguments[0],p=arguments[1];if(p.eStyle)e.setAttribute('style',p.eStyle);else e.removeAttribute('style');if(e.parentElement){e.parentElement.scrollLeft=p.scLeft;e.parentElement.scrollTop=p.scTop;}", el, saved_state)
                    except Exception:
                        pass
        im = Image.open(io.BytesIO(raw)).convert('RGB')
        if im.width < 350 or im.height < 250:
            try:
                render = Image.open(io.BytesIO(el.screenshot_as_png)).convert('RGB')
                if render.width >= 350 and render.height >= 250:
                    im = render
            except Exception:
                pass
        if im.width < 350 or im.height < 250:
            raise Review('Ảnh phiếu quá nhỏ, kể cả sau khi chụp vùng ảnh hiển thị.')
        im.thumbnail((2400, 3400)); b = io.BytesIO(); im.save(b, 'PNG')
        top = im.crop((0, 0, im.width, max(250, int(im.height * .52))))
        top.thumbnail((2400, 2000)); b2 = io.BytesIO(); top.save(b2, 'PNG')
        return b.getvalue(), b2.getvalue()

    def write(self, p, journal):
        return self._write_fields(p, journal, fields=(('sbd', 'sbd'), ('code', 'ma de')))

    def write_sbd_only(self, p, journal):
        return self._write_fields(p, journal, fields=(('sbd', 'sbd'),))

    def write_code_only(self, p, journal):
        return self._write_fields(p, journal, fields=(('code', 'ma de'),))

    def _write_fields(self, p, journal, fields):
        self.check(); self.js('modal(arguments[0]);return true;', self.expected)
        from selenium.webdriver.common.keys import Keys
        for field_name, label in fields:
            self.check(); el = self.js('return input(modal(arguments[0]),arguments[1]);', self.expected, label)
            old = (el.get_attribute('value') or '').strip()
            if old == p[field_name] and len(fields) > 1:
                continue
            journal('before_field', {'field': field_name, 'old': old, 'new': p[field_name]})
            try:
                el.click(); el.send_keys(Keys.CONTROL, 'a'); el.send_keys(Keys.BACKSPACE); el.send_keys(p[field_name]); el.send_keys(Keys.ENTER); el.send_keys(Keys.TAB)
            except Exception:
                pass
            try:
                self.driver.execute_script("""const e=arguments[0],v=arguments[1];
const setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value')?.set;
if(setter)setter.call(e,v);else e.value=v;
e.dispatchEvent(new Event('input',{bubbles:true}));
e.dispatchEvent(new Event('change',{bubbles:true}));
for(const ev of ['keydown','keypress','keyup']){
  e.dispatchEvent(new KeyboardEvent(ev,{bubbles:true,cancelable:true,key:'Enter',code:'Enter',keyCode:13,which:13}));
}
e.dispatchEvent(new Event('blur',{bubbles:true}));""", el, p[field_name])
            except Exception:
                pass
            self.delay(0.6)
            self.js('modal(arguments[0]);return true;', self.expected)
        count = self.js(r"""const r=modal(arguments[0]);
const isSave=e=>{
  if(!vis(e)||e.disabled||e.getAttribute('aria-disabled')==='true'||e.matches('.dx-state-disabled,.disabled'))return false;
  const idNorm=norm(e.id||e.name||'').replace(/[^a-z0-9]/g,'');
  if(['btnluu','btnsave','cmdluu','luuchinhsua'].includes(idNorm))return true;
  const labels=[txt(e),e.value,e.getAttribute('title'),e.getAttribute('aria-label'),e.getAttribute('data-original-title')].filter(Boolean).map(norm);
  return labels.some(label=>/^(luu|luu lai|luu chinh sua|luu thong tin|luu phieu|cap nhat|save)(\s*\(.*\))?$/.test(label));
};
let bs=[];
const outer=r.closest('[role="dialog"],.dx-overlay-content,.dx-popup-normal,.modal,.modal-content,.el-dialog,.ant-modal')||r;
for(let p=outer;p&&p!==document.body;p=p.parentElement){
  if(Array.from(p.querySelectorAll('tr,[role="row"]')).some(fileCell))break;
  const cand=Array.from(p.querySelectorAll('button,a,input[type="button"],input[type="submit"],[role="button"],.btn,.dx-button')).filter(e=>isSave(e)&&!Array.from(e.children).some(isSave));
  const uniq=[...new Set(cand.map(e=>e.closest('button,a,input[type="button"],input[type="submit"],[role="button"],.btn,.dx-button')||e))];
  if(uniq.length===1){bs=uniq;break;}
  if(uniq.length>1)bs=uniq;
}
if(bs.length===1){
  bs[0].scrollIntoView({block:'center'});bs[0].click();
  return {count:1,method:'save-button',text:txt(bs[0])||bs[0].value||bs[0].id||'Lưu'};
}
const sbdInput=input(r,'sbd');
const codeInput=input(r,'ma de');
const grp=sbdInput?.parentElement;
if(grp){
  const adj=Array.from(grp.querySelectorAll('button,a,[role="button"],.btn,.input-group-text,.input-group-append button')).filter(e=>vis(e)&&!e.disabled&&e!==sbdInput);
  if(adj.length===1){adj[0].click();return {count:1,method:'sbd-adjacent-button',text:txt(adj[0])||adj[0].title||'🔍'};}
}
if((sbdInput&&String(sbdInput.value||'').trim().length>=4)||(codeInput&&String(codeInput.value||'').trim().length>=2)){
  return {count:1,method:'blur-enter-autosave',text:'Enter/Blur Autosave'};
}
return {count:bs.length,text:bs.map(e=>txt(e)||e.value||e.id||'')};""", self.expected)
        if count.get('count') != 1:
            raise Review('Không nhận chính xác nút Lưu chỉnh sửa trong cửa sổ Xem; không giả định đã lưu.')
        journal('clicked_save', {'button': count.get('text', ''), 'method': count.get('method', '')})
        self.delay(1.0)

    def reload_grading_table(self):
        self.close()
        if not self.grid_bound:
            self.bind_grid()
        refreshed = self.js(r"""const sel='button,a,input[type="button"],[role="button"],.btn,.dx-button';
          const isReload=e=>{
            if(!vis(e)||e.disabled)return false;
            const vals=[txt(e),e.value,e.getAttribute('title'),e.getAttribute('aria-label')].filter(Boolean).map(norm);
            if(vals.some(t=>/^(tai lai|lam moi|nap lai|reload|refresh)$/.test(t)))return true;
            return !!e.querySelector('.dx-icon-refresh,.fa-refresh,.fa-sync,.glyphicon-refresh');
          };
          const bs=Array.from(document.querySelectorAll(sel)).filter(e=>isReload(e)&&!Array.from(e.children).some(isReload));
          if(bs.length!==1)return {ok:false,n:bs.length};
          bs[0].click();return {ok:true};""")
        if not refreshed.get('ok'):
            raise Review('Không tìm được duy nhất nút Tải lại để kiểm tra dữ liệu đã lưu; chưa xác minh.')
        self.file_scroll_top = {}
        self.delay(1.0)
        for _ in range(20):
            self.control()
            try:
                self.js('return rows().map(data).length;')
                return
            except Exception:
                self.delay(0.35)
        raise Review('Bảng chưa tải lại được sau thao tác Lưu; chưa xác minh.')

    def verify(self, file, p):
        self.reload_grading_table()
        for _ in range(8):
            self.control()
            row = self.locate(file)
            if verified(row, p):
                return row
            self.delay(0.7)
        raise Review('Bảng sau Tải lại chưa khớp SBD/mã đề/họ tên/lớp/điểm.')

    def missing_students(self):
        self.check()
        self.close_missing_dialog()
        clicked = self.js("""const bs=Array.from(document.querySelectorAll('button,a,[role="button"],.btn,.dx-button')).filter(e=>vis(e)&&/^(hs|hoc sinh|ds hs|danh sach hs)\\s*thieu bai\\b/.test(norm(txt(e))));if(bs.length!==1)return false;bs[0].click();return true;""")
        if not clicked:
            return []
        self.delay(0.7)
        find = r"""const rs=Array.from(document.querySelectorAll('[role="dialog"],.modal,.modal-content,.el-dialog,.ant-modal,.dx-popup-content,.dx-overlay-content,.dx-popup-normal')).filter(e=>vis(e)&&!Array.from(e.querySelectorAll('tr')).some(fileCell)&&e.querySelector('table,[role="grid"]'));const small=rs.filter(e=>!rs.some(o=>o!==e&&e.contains(o)));if(small.length!==1)throw Error('Không nhận cửa sổ HS thiếu bài.');const root=small[0];"""
        result = {}
        try:
            root = self.js(find + 'return root;')
            extract = r"""
const root=arguments[0],rs=Array.from(root.querySelectorAll('tr,[role="row"]')).filter(vis);
let m=null;
for(const r of rs){const n=cells(r).map(e=>norm(txt(e))),candidate={name:n.findIndex(t=>['ho va ten','ho ten','ten hoc sinh'].includes(t)),last:n.findIndex(t=>['ho va chu lot','ho dem','ho lot'].includes(t)),first:n.indexOf('ten'),class:n.indexOf('lop'),sbd:n.findIndex(t=>['sbd','so bao danh'].includes(t))};if(candidate.class>=0&&candidate.sbd>=0&&(candidate.name>=0||(candidate.last>=0&&candidate.first>=0))){m=candidate;break;}}
if(!m)return {rows:[],unsupported:true};const out=[];
for(const r of rs){const c=cells(r),at=i=>i>=0?txt(c[i]):'';const o={name:at(m.name)||[at(m.last),at(m.first)].filter(Boolean).join(' '),sbd:at(m.sbd),class:at(m.class)};if(/^\d{4,12}$/.test(o.sbd)&&o.name&&o.class)out.push(o);}
const sc=Array.from(root.querySelectorAll('*')).filter(e=>e.scrollHeight>e.clientHeight+4&&['scroll','auto'].includes(getComputedStyle(e).overflowY)&&e.querySelector('tr,[role="row"]')).sort((a,b)=>b.clientWidth-a.clientWidth||a.clientHeight-b.clientHeight)[0];
return {rows:out,scroll:sc||null,top:sc?.scrollTop||0,height:sc?.clientHeight||0,total:sc?.scrollHeight||0};
"""
            state = self.js(extract, root)
            if state.get('unsupported'):
                return []
            for r in state['rows']:
                result[(r['sbd'], r['name'], r['class'])] = r
            return list(result.values())
        finally:
            self.close_missing_dialog()

    def diagnostic(self):
        snapshot = {'version': '3.18', 'documents': []}; todo = [[]]; seen = 0
        while todo and seen < 64:
            self.control(); path = todo.pop(0); seen += 1
            try:
                self.switch_frame_path(path)
                info = self.driver.execute_script("""return {url:location.origin+location.pathname,ready:document.readyState,title:document.title,
headers:Array.from(document.querySelectorAll('th,[role=columnheader]')).map(e=>e.innerText),
tables:Array.from(document.querySelectorAll('table')).slice(0,10).map(e=>({class:e.className,rows:e.rows.length})),
inputs:Array.from(document.querySelectorAll('input')).filter(e=>e.getClientRects().length).map(e=>({id:e.id,name:e.name,type:e.type,placeholder:e.placeholder,autocomplete:e.autocomplete,class:e.className})),
buttons:Array.from(document.querySelectorAll('button,input[type=submit],[role=button]')).filter(e=>e.getClientRects().length).slice(0,40).map(e=>({text:(e.innerText||e.value||e.textContent||'').slice(0,80),type:e.type,class:e.className})),
frames:Array.from(document.querySelectorAll('iframe,frame')).map(e=>({id:e.id,name:e.name,visible:!!e.getClientRects().length,src:(e.src||'').split('?')[0].split('#')[0]})),shadowHosts:Array.from(document.querySelectorAll('*')).filter(e=>e.shadowRoot).map(e=>({tag:e.tagName,id:e.id}))};""")
                snapshot['documents'].append({'frame_path': path, **info})
                if len(path) < 5:
                    todo.extend(path + [i] for i, f in enumerate(self.driver.find_elements('css selector', 'iframe,frame')) if f.is_displayed())
            except (StopRun, Fatal):
                raise
            except Exception:
                snapshot['documents'].append({'frame_path': path, 'error': 'Không đọc được khung này.'})
        self.driver.switch_to.default_content(); self.frame_path = []; self.grid_bound = False
        return snapshot


class Runner:
    def __init__(self, browser, ai, emit, control, output, max_records=0, official_roster=(), audit_all=False, exam_catalog=None, selected_subject='', nearest_one_digit=True):
        self.browser = browser; self.ai = ai; self.emit = emit; self.control = control; self.output = Path(output); self.max_records = max_records
        self.official_roster = list(official_roster); self.audit_all = bool(audit_all)
        self.exam_catalog = exam_catalog; self.selected_subject = str(selected_subject or '').strip()
        self.nearest_one_digit = bool(nearest_one_digit)
        self.code_advice = {}
        self.output.mkdir(parents=True, exist_ok=True); self.records = []; self.active = None

    def event(self, kind, details):
        entry = {'time': datetime.now().isoformat(timespec='seconds'), 'file': self.active.file if self.active else '', 'event': kind, 'details': details}
        with (self.output / 'nhat_ky.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(entry, ensure_ascii=False) + '\n'); f.flush(); os.fsync(f.fileno())

    def checkpoint(self):
        tmp = self.output / 'tien_do.tmp'
        tmp.write_text(json.dumps([asdict(r) for r in self.records], ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, self.output / 'tien_do.json')
        if len(self.records) <= 20 or self.active is None:
            self.emit('records', [asdict(r) for r in self.records])
        else:
            self.emit('record', asdict(self.active))

    def report(self):
        collisions = getattr(self, 'conflicts', [])
        with (self.output / 'trung_ho_ten_lop.csv').open('w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Ảnh phiếu', 'Họ tên VietSchool', 'Lớp', 'SBD VietSchool', 'Loại cảnh báo', 'Chi tiết'])
            for x in collisions:
                writer.writerow([x.get(k, '') for k in ('file', 'name', 'class', 'sbd', 'issue', 'details')])
        with (self.output / 'goi_y_ma_de.csv').open('w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Ảnh phiếu', 'Môn thi', 'Mã đề VietSchool', 'Mã đề trên ô tô', 'Các mã đề chính thức', 'Đề xuất', 'Căn cứ / cảnh báo', 'Trạng thái xử lý', 'Mã viết tay xác minh 2 lượt', 'Cách đối chiếu', 'Số vị trí lệch', 'Các mã gần nhất'])
            for r in self.records:
                hint = self.code_advice.get(r.file, {})
                writer.writerow([r.file, hint.get('subject', ''), r.old.get('code', ''), hint.get('bubble', ''),
                    ', '.join(hint.get('codes', [])), hint.get('candidate', ''),
                    hint.get('evidence', '') or hint.get('reason', ''), r.status, hint.get('handwritten', ''),
                    hint.get('method', ''), hint.get('distance', ''),
                    ', '.join(f'{code}: {dist} vị trí' for dist, code in hint.get('ranked', []))])
        def safe(v):
            s = str(v or '')
            return "'" + s if s.startswith(('=', '+', '-', '@')) or re.fullmatch(r'0\d+', s) else s
        with (self.output / 'bao_cao.csv').open('w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f); writer.writerow(['Ảnh phiếu', 'Lỗi ban đầu', 'SBD cũ', 'SBD mới', 'Mã đề cũ', 'Mã đề mới', 'Họ tên trên ảnh', 'Họ tên VietSchool', 'Điểm sau', 'Trạng thái', 'Ghi chú'])
            for r in self.records:
                writer.writerow([safe(v) for v in [r.file, ', '.join(r.reason), r.old.get('sbd'), r.proposal.get('sbd'), r.old.get('code'), r.proposal.get('code'), r.proposal.get('name'), r.after.get('name'), r.after.get('score'), r.status, r.note]])

    def run(self):
        try:
            self.control()
            roster = self.browser.scan()
            problems = [r for r in roster if issues(r) or (self.exam_catalog and self.exam_catalog.issue(r, self.selected_subject))]
            if self.exam_catalog:
                problems.sort(key=lambda entry: (0 if self.exam_catalog.issue(entry, self.selected_subject) else 1))
            problem_files = {item['file'] for item in problems}
            candidates = (problems + [r for r in roster if r['file'] not in problem_files]) if self.audit_all else problems
            self.records = [Record(r['file'], dict(r), issues(r) or
                ([self.exam_catalog.issue(r, self.selected_subject)] if self.exam_catalog and self.exam_catalog.issue(r, self.selected_subject) else ['Rà soát SBD/mã đề trên ảnh']))
                for r in candidates]
            for r in self.records:
                if self.exam_catalog:
                    self.code_advice[r.file] = self.exam_catalog.advise(r.old, None, self.selected_subject)
            self.conflicts = audit_identity_conflicts(roster, self.official_roster)
            self.conflicts_by_file = {}
            for item in self.conflicts:
                self.conflicts_by_file.setdefault(item['file'], []).append(item)
            if self.max_records:
                self.records = self.records[:self.max_records]
            self.event('scan', {'total': len(roster), 'initial_errors': len(problems), 'selected': len(self.records)})
            self.checkpoint(); self.report()
            if not self.records:
                return
            outage_streak = 0
            for idx, r in enumerate(self.records, 1):
                self.control(); self.active = r
                try:
                    if isinstance(self.ai, NoAI) and issues(r.old) == ['Thiếu điểm'] and not (self.exam_catalog and self.exam_catalog.issue(r.old, self.selected_subject)):
                        r.status = 'Cần kiểm tra điểm'
                        r.note = 'Phiếu chỉ thiếu điểm; không tự sửa.'
                        continue
                    self.browser.open(r.file)
                    full, top = self.browser.image()
                    bubbles = None
                    try:
                        bubbles = read_bubbles(full)
                    except Exception:
                        bubbles = None
                    if not isinstance(self.ai, NoAI):
                        img1, img2 = (self.ai.prepare_images(full, top) if hasattr(self.ai, 'prepare_images') else (full, top))
                        a = self.ai.read(img1); self.control()
                        b = self.ai.read(img2); self.control()
                        outage_streak = 0
                        img_sub = verified_image_subject(a, b, self.exam_catalog, r.old) if self.exam_catalog else ''
                        if img_sub:
                            self.event('subject_from_image', {'subject': img_sub})
                        eff_sub = self.selected_subject or img_sub
                        hw_code = verified_handwritten_code(a, b, self.exam_catalog, {**r.old, 'subject': eff_sub or r.old.get('subject', '')}, eff_sub) if self.exam_catalog else ''
                        if self.exam_catalog and hw_code:
                            if not self.official_roster or not unique_official_identity(r.old, bubbles or {'sbd': a.get('sbd', ''), 'code': a.get('code', '')}, self.official_roster, roster):
                                if not (a.get('clear') and b.get('clear') and a.get('sbd') == b.get('sbd') and any(st.get('sbd') == a.get('sbd') for st in self.official_roster)):
                                    raise Review('Chưa xác minh duy nhất danh tính học sinh trong Excel.')
                            sbd_val = a.get('sbd') if (a.get('clear') and a.get('sbd') == b.get('sbd') and a.get('sbd')) else r.old.get('sbd')
                            p = {'sbd': sbd_val, 'code': hw_code, 'name': a.get('name') or r.old.get('name', ''), 'class': a.get('class') or r.old.get('class', '')}
                            if bubbles and bubbles.get('code') and bubbles.get('code') != hw_code:
                                self.event('wrong_painted_exam_code', {'painted': bubbles.get('code'), 'handwritten': hw_code})
                            self.code_advice[r.file] = {**self.code_advice.get(r.file, {}), 'candidate': hw_code, 'handwritten': hw_code, 'method': 'handwritten_2pass', 'evidence': 'Mã đề chữ viết tay xác minh 2 lượt'}
                            r.proposal = p
                            self.browser.write(p, self.event)
                            r.after = self.browser.verify(r.file, p)
                            r.status = 'Đã xác minh'
                            r.note = f'Đã sửa theo mã đề chữ viết tay xác minh 2 lượt: {hw_code}'
                            self.browser.close()
                            continue
                        if not (a.get('clear') and b.get('clear') and a.get('sbd') == b.get('sbd') and a.get('code') == b.get('code')):
                            raise Review('Hai lượt đọc AI chưa thống nhất hoặc ảnh mờ.')
                        p = {'sbd': a['sbd'], 'code': a['code'], 'name': a.get('name', ''), 'class': a.get('class', '')}
                        r.proposal = p
                        self.browser.write(p, self.event)
                        r.after = self.browser.verify(r.file, p)
                        r.status = 'Đã xác minh'
                        self.browser.close()
                        continue

                    if self.exam_catalog:
                        adv = self.exam_catalog.advise(r.old, bubbles, self.selected_subject)
                        self.code_advice[r.file] = adv
                        sbd_prop = independent_sbd_only_proposal(r.old, bubbles, self.official_roster, roster) if (bubbles and self.official_roster) else None
                        if sbd_prop and (not adv.get('candidate') or adv.get('method') == 'nearest_one_digit'):
                            p = {'sbd': sbd_prop['sbd'], 'code': str(r.old.get('code') or ''), 'name': sbd_prop['name'], 'class': sbd_prop['class']}
                            r.proposal = p
                            self.event('sbd_only_deferred_code', {'sbd': p['sbd'], 'code': p['code']})
                            self.browser.write(p, self.event)
                            r.after = self.browser.verify(r.file, p)
                            r.status = 'Đã xác minh SBD'
                            r.note = 'Đã sửa SBD theo Excel; Mã đề GIỮ NGUYÊN (CHƯA XÁC MINH).'
                            self.browser.close()
                            continue
                        if adv.get('candidate'):
                            method = adv.get('method', '')
                            if method == 'nearest_one_digit':
                                if not self.nearest_one_digit or not unique_official_identity(r.old, bubbles, self.official_roster, roster):
                                    raise Review('Không tự lưu mã đề gần đúng khi chưa xác minh danh tính duy nhất.')
                                if r.old.get('code') in adv.get('codes', []):
                                    raise Review('Mã đề cũ đã hợp lệ; không tự ghi đè bằng mã gần đúng.')
                                self.event('one_digit_code_repair', {'from': r.old.get('code'), 'to': adv['candidate']})
                                adv['evidence'] = 'Suy luận lệch 1 chữ số: ' + adv.get('evidence', '')
                            elif not method and len(adv.get('codes', [])) == 1:
                                if not unique_official_identity(r.old, bubbles, self.official_roster, roster):
                                    raise Review('Chưa xác minh danh tính duy nhất.')
                                self.event('single_official_code', {'code': adv['candidate']})
                            if adv['candidate'] == str(r.old.get('code') or '').strip() and not issues(r.old):
                                r.status = 'Chưa đọc mã viết tay'
                                r.note = 'Ô tô khớp nhưng chế độ Không AI chưa kiểm tra mã VIẾT TAY.'
                                self.browser.close()
                                continue
                            p = {'sbd': str(r.old.get('sbd') or ''), 'code': adv['candidate'], 'name': str(r.old.get('name') or ''), 'class': str(r.old.get('class') or '')}
                            r.proposal = p
                            self.browser.write(p, self.event)
                            r.after = self.browser.verify(r.file, p)
                            r.status = 'Đã xác minh'
                            r.note = adv.get('evidence', '')
                            self.browser.close()
                            continue
                        raise Review(adv.get('reason') or 'Mã đề cần kiểm tra.')

                    if bubbles and audit_bubbles_match(r.old, bubbles):
                        r.status = 'Đã khớp ô tô'
                        self.browser.close()
                        continue
                    sbd_prop = independent_sbd_only_proposal(r.old, bubbles, self.official_roster, roster) if (bubbles and self.official_roster) else None
                    if sbd_prop:
                        r.proposal = sbd_prop
                        self.browser.write(sbd_prop, self.event)
                        r.after = self.browser.verify(r.file, sbd_prop)
                        r.status = 'Đã xác minh'
                        self.browser.close()
                        continue
                    raise Review('Cần kiểm tra thủ công.')
                except (StopRun, Fatal):
                    raise
                except TemporaryGeminiUnavailable as exc:
                    outage_streak += 1
                    r.status = 'Cần kiểm tra'; r.note = short_error(exc)
                    self.browser.close()
                    if outage_streak >= 3:
                        raise Fatal('Gemini quá tải liên tiếp trên 3 phiếu.')
                except Exception as exc:
                    outage_streak = 0
                    r.status = 'Cần kiểm tra'; r.note = short_error(exc)
                    self.browser.close()
                finally:
                    self.checkpoint(); self.report()
            self.active = None
            self.event('final_scan', {'processed': len(self.records)})
        except StopRun:
            self.event('stopped', {})
        except Exception as exc:
            self.event('aborted', {'reason': short_error(exc)})
            self.emit('log', 'Dừng an toàn: ' + short_error(exc))
        finally:
            self.checkpoint(); self.report(); self.emit('done', str(self.output))


def main():
    import tkinter as tk
    from tkinter import ttk, messagebox, scrolledtext
    root = tk.Tk()
    root.title('HTB • VietSchool LỌC PHIẾU LỖI, TÌM KIẾM & SỬA SBD / MÃ ĐỀ — v3.18')
    root.geometry('1260x860')
    events = queue.Queue()
    stop = threading.Event(); pause = threading.Event()
    state = {'busy': False, 'browser': None, 'output': None, 'cached_webrows': [], 'active_records_by_id': {}}

    def emit(kind, data):
        events.put((kind, data))

    def control():
        while pause.is_set() and not stop.is_set():
            time.sleep(0.1)
        if stop.is_set():
            raise StopRun()

    def run_thread(fn):
        if state['busy']:
            return
        stop.clear(); pause.clear(); state['busy'] = True
        def wrapper():
            try:
                fn()
            except StopRun:
                emit('log', 'Đã dừng theo yêu cầu.')
            except Exception as exc:
                emit('log', 'Lỗi: ' + short_error(exc))
            finally:
                emit('idle', None)
        threading.Thread(target=wrapper, daemon=True).start()

    header_lbl = ttk.Label(root, text='LỌC PHIẾU LỖI SBD & MÃ ĐỀ • TÌM KIẾM TRONG CHẤM ĐIỂM • DÒ TRÙNG TÊN / MẤT ĐIỂM (v3.18)',
                           font=('Segoe UI', 13, 'bold'), foreground='#0f4c81')
    header_lbl.pack(fill='x', padx=14, pady=(8, 2))

    settings = ttk.LabelFrame(root, text='Kết nối & Chế độ xử lý', padding=8)
    settings.pack(fill='x', padx=14, pady=4)
    key = tk.StringVar(value=load_api_key())
    model = tk.StringVar(value='no-ai')
    address = tk.StringVar(value='127.0.0.1:9222')
    provider = tk.StringVar(value=NO_AI_LABEL)
    auto_single_var = tk.BooleanVar(value=True)
    default_code_var = tk.StringVar(value='')
    official_path = tk.StringVar(value='')
    codes_path = tk.StringVar(value='')
    subject_var = tk.StringVar(value='TẤT CẢ MÔN (tự nhận diện)')
    manual_var = tk.BooleanVar(value=False)
    audit_all_var = tk.BooleanVar(value=True)

    ttk.Label(settings, text='API key (chỉ dùng cho Gemini)').grid(row=0, column=0, sticky='w')
    ttk.Entry(settings, textvariable=key, show='*', width=42).grid(row=0, column=1, padx=8, sticky='w')
    ttk.Label(settings, text='Model').grid(row=0, column=2, sticky='w')
    ttk.Entry(settings, textvariable=model, width=26).grid(row=0, column=3, padx=8, sticky='w')
    def store_key():
        if state['busy']: return
        try: save_api_key(key.get()); emit('log', 'Đã lưu API key hiện tại trên máy.')
        except Exception as e: messagebox.showerror('Lưu API key', short_error(e))
    ttk.Button(settings, text='Lưu key', command=store_key).grid(row=0, column=4, padx=6, sticky='w')

    ttk.Label(settings, text='Chrome').grid(row=1, column=0, sticky='w', pady=4)
    ttk.Entry(settings, textvariable=address, width=28).grid(row=1, column=1, sticky='w', padx=8)
    ttk.Label(settings, text='Bộ đọc / Chế độ').grid(row=2, column=0, sticky='w')
    chooser = ttk.Combobox(settings, textvariable=provider, values=[NO_AI_LABEL, 'Gemini', 'Ollama (không cần key)'], state='readonly', width=44)
    chooser.grid(row=2, column=1, sticky='w', padx=8)
    def change_provider(_event=None):
        p = provider.get()
        if p.startswith('Không dùng AI'): model.set('no-ai')
        elif p.startswith('Ollama'): model.set('qwen3-vl:2b')
        else: model.set('')
    chooser.bind('<<ComboboxSelected>>', change_provider)

    def install_local():
        if state['busy']: return
        selected = model.get().strip() if provider.get().startswith('Ollama') else 'qwen3-vl:2b'
        if selected not in LOCAL_MODELS: selected = 'qwen3-vl:2b'
        if os.name != 'nt': messagebox.showinfo('AI nội bộ', 'Cài Ollama từ ollama.com rồi chạy: ollama pull ' + selected); return
        script = ROOT / 'CAI_AI_NOI_BO.ps1'
        if not script.is_file(): messagebox.showerror('AI nội bộ', 'Thiếu CAI_AI_NOI_BO.ps1.'); return
        subprocess.Popen(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(script), '-Model', selected],
                         creationflags=subprocess.CREATE_NEW_CONSOLE)

    def kill_ollama_ui():
        msg = stop_local_ai(); emit('log', msg); messagebox.showinfo('Giải phóng máy (Tắt AI ngầm)', msg)

    ttk.Button(settings, text='Tắt AI ngầm (Đỡ đơ máy)', command=kill_ollama_ui).grid(row=2, column=2, padx=6, sticky='w')
    ttk.Button(settings, text='Cài AI nội bộ (Máy mạnh)', command=install_local).grid(row=2, column=3, padx=6, sticky='w')
    noai_bar = ttk.Frame(settings); noai_bar.grid(row=3, column=0, columnspan=5, sticky='w', pady=(4, 2))
    ttk.Checkbutton(noai_bar, text='Tự sửa SBD & Mã đề khi khớp duy nhất danh sách mẫu', variable=auto_single_var).pack(side='left')

    saved, load_note = read_login()
    username = tk.StringVar(value=saved.get('username', '')); password = tk.StringVar(value=saved.get('password', ''))
    remember = tk.BooleanVar(value=bool(saved))
    auth = ttk.LabelFrame(root, text='Đăng nhập VietSchool tự động', padding=6); auth.pack(fill='x', padx=14, pady=3)
    ttk.Label(auth, text='SĐT / tài khoản').grid(row=0, column=0)
    ttk.Entry(auth, textvariable=username, width=25).grid(row=0, column=1, padx=6)
    ttk.Label(auth, text='Mật khẩu').grid(row=0, column=2)
    ttk.Entry(auth, textvariable=password, show='*', width=25).grid(row=0, column=3, padx=6)
    ttk.Checkbutton(auth, text='Nhớ trên máy này (mã hóa Windows)', variable=remember).grid(row=0, column=5, padx=6, sticky='w')

    def retain_login(u, p):
        if remember.get(): save_login(u, p)
        elif login_file().exists(): login_file().unlink()

    def forget_login():
        if state['busy']: return
        if login_file().exists(): login_file().unlink()
        username.set(''); password.set(''); remember.set(False); emit('log', 'Đã xóa đăng nhập lưu trên máy.')
    ttk.Button(auth, text='Xóa đăng nhập đã lưu', command=forget_login).grid(row=0, column=6, padx=4)

    def auto_login():
        if state['busy']: return
        addr = address.get().strip(); u = username.get().strip(); pw = password.get()
        try: retain_login(u, pw)
        except Exception as e: messagebox.showerror('Lưu đăng nhập', short_error(e)); return
        def work():
            actual, _ = ensure_chrome(addr, control, lambda s: emit('log', s))
            emit('address', actual)
            browser = Browser(control); state['browser'] = browser; browser.connect(actual)
            browser.login(u, pw, lambda s: emit('log', s))
            emit('log', 'Đã đăng nhập. Chọn Chấm bài giấy → Chấm bài và đúng đợt chấm.')
        run_thread(work)
    ttk.Button(auth, text='Mở Chrome & Đăng nhập', command=auto_login).grid(row=0, column=4, padx=6)
    if load_note:
        emit('log', load_note)

    def open_chrome():
        addr = address.get().strip()
        def work():
            actual, _ = ensure_chrome(addr, control, lambda s: emit('log', s))
            emit('address', actual)
            emit('log', 'Chrome Agent sẵn sàng tại ' + actual + '.')
        run_thread(work)
    ttk.Button(settings, text='Mở Chrome Agent', command=open_chrome).grid(row=1, column=2, padx=6, sticky='w')

    files_bar = ttk.Frame(root, padding=4); files_bar.pack(fill='x', padx=14)
    def select_roster():
        from tkinter import filedialog
        path = filedialog.askopenfilename(title='Chọn danh sách học sinh chính thức',
            filetypes=[('Excel & CSV', '*.xlsx *.csv'), ('Excel', '*.xlsx'), ('CSV', '*.csv')])
        if path:
            try:
                people = load_roster(path)
                official_path.set(path)
                emit('log', f'Đã nạp danh sách {len(people)} học sinh từ Excel.')
            except Exception as e:
                messagebox.showerror('Danh sách HS', short_error(e))
    ttk.Button(files_bar, text='Tải danh sách HS Excel / CSV', command=select_roster).pack(side='left', padx=5)
    ttk.Label(files_bar, textvariable=official_path, foreground='#14639a').pack(side='left', fill='x', expand=True)
    ttk.Checkbutton(files_bar, text='Chờ sửa tay khi phiếu mơ hồ', variable=manual_var).pack(side='right', padx=5)

    code_bar = ttk.Frame(root, padding=4); code_bar.pack(fill='x', padx=14)
    def select_codes():
        from tkinter import filedialog
        path = filedialog.askopenfilename(title='Chọn danh sách mã đề CHÍNH THỨC',
            filetypes=[('Excel & CSV', '*.xlsx *.csv'), ('Excel', '*.xlsx'), ('CSV', '*.csv')])
        if not path: return
        try:
            catalog = load_exam_codes(path)
            codes_path.set(path)
            audit_all_var.set(True)
            combo_subject.configure(values=['TẤT CẢ MÔN (tự nhận diện)'] + catalog.subjects)
            subject_var.set('TẤT CẢ MÔN (tự nhận diện)')
            emit('log', f'Đã nạp {sum(len(x) for x in catalog.by_subject.values())} mã đề từ file mẫu.')
        except Exception as e:
            messagebox.showerror('Danh sách mã đề', short_error(e))

    def extract_codes_from_table():
        if state['busy']: return
        addr = address.get().strip()
        def work():
            actual, _ = ensure_chrome(addr, control, lambda s: emit('log', s)); emit('address', actual)
            b = Browser(control); state['browser'] = b; b.connect(actual)
            if not b.grid_bound: b.bind_grid()
            rows_now = b.scan()
            state['cached_webrows'] = rows_now
            scored_codes = sorted({
                str(r.get('code') or '').strip()
                for r in rows_now
                if not blank(r.get('score')) and number(str(r.get('code') or '').strip(), 2, 6)
            })
            if not scored_codes:
                raise Fatal('Chưa tìm thấy mã đề nào đã có điểm trên bảng VietSchool. Hãy tải file MAU_DANH_SACH_MA_DE.xlsx.')
            auto_path = ROOT / 'MAU_DANH_SACH_MA_DE_TU_DONG.csv'
            with auto_path.open('w', encoding='utf-8-sig', newline='') as f:
                w = csv.writer(f)
                w.writerow(['Môn thi', 'Mã đề', 'Ghi chú'])
                for c in scored_codes:
                    w.writerow(['Đợt chấm hiện tại', c, 'Tự động trích xuất từ các phiếu đã có điểm trên VietSchool'])
            catalog = load_exam_codes(auto_path)
            codes_path.set(str(auto_path))
            combo_subject.configure(values=['TẤT CẢ MÔN (tự nhận diện)'] + catalog.subjects)
            subject_var.set('TẤT CẢ MÔN (tự nhận diện)')
            emit('log', f'Đã tự động lấy {len(scored_codes)} mã đề hợp lệ từ bảng VietSchool (' + ', '.join(scored_codes) + f') và lưu vào {auto_path.name}.')
        run_thread(work)

    ttk.Button(code_bar, text='Tải danh sách MÃ ĐỀ Excel / CSV', command=select_codes).pack(side='left', padx=5)
    ttk.Button(code_bar, text='Tự lấy Mã đề từ bảng VietSchool', command=extract_codes_from_table).pack(side='left', padx=5)
    ttk.Label(code_bar, textvariable=codes_path, foreground='#14639a', width=40).pack(side='left', fill='x', expand=True)
    ttk.Label(code_bar, text='Phạm vi môn:').pack(side='left', padx=4)
    combo_subject = ttk.Combobox(code_bar, textvariable=subject_var, values=['TẤT CẢ MÔN (tự nhận diện)'], state='readonly', width=24)
    combo_subject.pack(side='right', padx=5)

    # Search & Duplicate-Name / Missing-Score Investigation Section
    search_frame = ttk.LabelFrame(root, text='Tìm kiếm trong Chấm điểm • Chọn Đợt chấm • Tìm Trùng tên & HS Tô sai Không có điểm trắc nghiệm', padding=6)
    search_frame.pack(fill='x', padx=14, pady=4)

    batch_var = tk.StringVar(value='')
    search_name_var = tk.StringVar(value='')
    search_class_var = tk.StringVar(value='')

    row_batch = ttk.Frame(search_frame); row_batch.pack(fill='x', pady=(0, 4))
    ttk.Label(row_batch, text='Đợt chấm:').pack(side='left', padx=(2, 4))
    batch_combo = ttk.Combobox(row_batch, textvariable=batch_var, values=[], width=42, state='readonly')
    batch_combo.pack(side='left', padx=4)

    def refresh_batches_and_scan():
        if state['busy']: return
        addr = address.get().strip()
        def work():
            actual, _ = ensure_chrome(addr, control, lambda s: emit('log', s)); emit('address', actual)
            b = Browser(control); state['browser'] = b; b.connect(actual)
            if not b.grid_bound: b.bind_grid()
            state['cached_webrows'] = []
            emit('clear', None)
            b.show_all_for_search()
            info = b.list_grading_batches()
            batches = info.get('batches', [])
            cur = info.get('current', '')
            emit('batches', (batches, cur))
            emit('log', 'Đang quét bảng Chấm điểm hiện tại để phục vụ tìm kiếm nhanh…')
            rows_now = b.scan()
            state['cached_webrows'] = rows_now
            emit('log', f'Đã nạp đợt chấm "{cur or "hiện tại"}" ({len(rows_now)} phiếu trên bảng). Bạn có thể gõ Tên + Lớp để tìm hoặc bấm Tìm Trùng Tên & HS Mất Điểm.')
        run_thread(work)

    def on_select_batch(_event=None):
        chosen = batch_var.get().strip()
        if not chosen or state['busy']: return
        addr = address.get().strip()
        def work():
            actual, _ = ensure_chrome(addr, control, lambda s: emit('log', s)); emit('address', actual)
            b = Browser(control)
            state['browser'] = b
            b.connect(actual)
            b.bind_grid()
            state['cached_webrows'] = []
            emit('clear', None)
            if b.select_grading_batch(chosen):
                emit('log', f'Đã chuyển sang đợt chấm: {chosen}. Đang quét danh sách phiếu của đợt chấm này…')
                rows_now = b.scan()
                state['cached_webrows'] = rows_now
                emit('log', f'Đã quét {len(rows_now)} phiếu của đợt chấm "{chosen}".')
            else:
                emit('log', f'Không tự chuyển được đợt chấm "{chosen}"; hãy chọn trực tiếp trên Chrome rồi bấm Quét bảng.')
        run_thread(work)

    batch_combo.bind('<<ComboboxSelected>>', on_select_batch)
    ttk.Button(row_batch, text='🔄 Lấy Đợt chấm & Quét bảng', command=refresh_batches_and_scan).pack(side='left', padx=4)

    row_search = ttk.Frame(search_frame); row_search.pack(fill='x', pady=2)
    ttk.Label(row_search, text='Họ tên / SBD:').pack(side='left', padx=(2, 4))
    ent_name = ttk.Entry(row_search, textvariable=search_name_var, width=28)
    ent_name.pack(side='left', padx=4)
    ttk.Label(row_search, text='Lớp:').pack(side='left', padx=(6, 4))
    ent_cls = ttk.Entry(row_search, textvariable=search_class_var, width=12)
    ent_cls.pack(side='left', padx=4)

    def fresh_search_rows(addr, chosen):
        state['cached_webrows'] = []
        emit('clear', None)
        actual, _ = ensure_chrome(addr, control, lambda s: emit('log', s))
        emit('address', actual)
        b = Browser(control)
        state['browser'] = b
        b.connect(actual)
        b.bind_grid()
        if chosen and not b.select_grading_batch(chosen):
            raise Fatal('Không xác nhận được đợt chấm đã chọn. Chọn đợt trên Chrome rồi bấm Lấy Đợt chấm & Quét bảng.')
        if b.show_all_for_search():
            emit('log', 'Đã chuyển bộ lọc phiếu sang Tất cả để tìm đủ học sinh.')
        info = b.list_grading_batches()
        emit('batches', (info.get('batches', []), info.get('current', '')))
        emit('log', 'Đang quét lại dữ liệu của đợt chấm hiện tại…')
        webrows = b.scan()
        state['cached_webrows'] = webrows
        emit('log', f'Đã đọc {len(webrows)} phiếu, {sum(not blank(r.get("name")) for r in webrows)} phiếu có tên trên bảng.')
        return b, webrows

    def auto_get_batch_student_names():
        if state['busy']: return
        addr = address.get().strip()
        chosen = batch_var.get().strip()
        roster_file = official_path.get().strip()
        search_name_var.set('')
        search_class_var.set('')
        def work():
            from search_and_duplicates import list_students_in_batch, export_search_report
            official_students = load_roster(roster_file) if roster_file else []
            b, webrows = fresh_search_rows(addr, chosen)
            try:
                missing_list = b.missing_students()
            except StopRun:
                raise
            except Exception as exc:
                missing_list = []
                emit('log', 'Chưa đọc được HS thiếu bài: ' + short_error(exc) + '. Tiếp tục lấy tên từ bảng chấm.')
            items, stats = list_students_in_batch(webrows, official_students, missing_list)
            out = ROOT / 'ket_qua' / 'danh_sach_hs_dot_cham.csv'
            export_search_report(items, out)
            state['output'] = out.parent
            emit('clear', None)
            emit('records', items)
            emit('log', f"ĐÃ LẤY TÊN HS ĐỢT CHẤM: {stats['named_results']} dòng có tên / {stats['total_results']} dòng; "
                        f"{stats['unnamed_results']} dòng chưa xác định tên. Đã lưu {out.name}. "
                        "Một học sinh có nhiều phiếu có thể xuất hiện nhiều dòng.")
            if stats['unnamed_results']:
                emit('log', 'Phiếu trống tên: tải Excel đúng đợt để đối chiếu theo SBD. SBD tô sai chưa khớp thì cần kiểm tra ảnh phiếu.')
            if not items:
                emit('log', 'Đợt hiện tại chưa đọc được phiếu hoặc danh sách HS thiếu bài. Kiểm tra đợt và bộ lọc trên Chrome.')
        run_thread(work)

    ttk.Button(row_batch, text='Tự lấy tên HS trong đợt chấm',
               command=auto_get_batch_student_names).pack(side='left', padx=4)

    def do_search_student(_event=None):
        if state['busy']: return
        nq = search_name_var.get().strip()
        cq = search_class_var.get().strip()
        addr = address.get().strip()
        roster_file = official_path.get().strip()
        chosen = batch_var.get().strip()
        def work():
            from search_and_duplicates import search_in_grading, export_search_report
            official_students = load_roster(roster_file) if roster_file else []
            b, webrows = fresh_search_rows(addr, chosen)
            try:
                missing_list = b.missing_students()
            except StopRun:
                raise
            except Exception as exc:
                missing_list = []
                emit('log', 'Chưa đọc được HS thiếu bài: ' + short_error(exc) + '. Tiếp tục tìm trong bảng và Excel.')
            items, stats = search_in_grading(webrows, official_students, name_query=nq, class_query=cq, missing_roster=missing_list)
            out = ROOT / 'ket_qua' / 'tim_kiem_gan_nhat.csv'
            state['output'] = out.parent
            export_search_report(items, out)
            emit('clear', None)
            emit('records', items)
            if not items:
                emit('log', 'Không tìm thấy. Kiểm tra đợt chấm, lớp, tên và tải Excel danh sách HS đúng đợt nếu phiếu bị mất tên do tô sai SBD.')
            emit('log', f"KẾT QUẢ TÌM KIẾM (Tên/SBD='{nq or 'Tất cả'}', Lớp='{cq or 'Tất cả'}'): "
                        f"{stats['total_results']} dòng ({stats['matched_sheets']} phiếu trên bảng, "
                        f"{stats['missing_score_students']} HS trong Excel chưa có điểm TN kèm gợi ý phiếu tô sai). "
                        f"Nháy đúp vào dòng bất kỳ để mở Xem phiếu trên Chrome!")
        run_thread(work)

    def do_find_duplicates_and_missing_scores():
        if state['busy']: return
        cq = search_class_var.get().strip()
        addr = address.get().strip()
        roster_file = official_path.get().strip()
        chosen = batch_var.get().strip()
        def work():
            from search_and_duplicates import find_duplicate_names_and_missing_scores, export_search_report
            official_students = load_roster(roster_file) if roster_file else []
            b, webrows = fresh_search_rows(addr, chosen)
            try:
                missing_list = b.missing_students()
            except StopRun:
                raise
            except Exception as exc:
                missing_list = []
                emit('log', 'Chưa đọc được HS thiếu bài: ' + short_error(exc) + '. Tiếp tục tìm trong bảng và Excel.')
            items, stats = find_duplicate_names_and_missing_scores(webrows, official_students, class_query=cq, missing_roster=missing_list)
            out = ROOT / 'ket_qua' / 'tim_kiem_trung_ten_mat_diem.csv'
            state['output'] = out.parent
            export_search_report(items, out)
            emit('clear', None)
            emit('records', items)
            if not items:
                emit('log', 'Không tìm thấy. Kiểm tra đợt chấm, lớp, tên và tải Excel danh sách HS đúng đợt nếu phiếu bị mất tên do tô sai SBD.')
            emit('log', f"DÒ TRÙNG TÊN & HS TÔ SAI KHÔNG CÓ ĐIỂM TN (Lớp='{cq or 'Tất cả'}'): "
                        f"Phát hiện {stats['total_results']} trường hợp (phiếu trùng tên/trùng SBD, phiếu trống điểm, và HS mất điểm kèm gợi ý phiếu nghi tô sai). "
                        f"Báo cáo: {out.name}. Nháy đúp dòng để mở Xem trên Chrome!")
        run_thread(work)

    ent_name.bind('<Return>', do_search_student)
    ent_cls.bind('<Return>', do_search_student)
    ttk.Button(row_search, text='🔍 Tìm theo Tên & Lớp', command=do_search_student).pack(side='left', padx=4)
    ttk.Button(row_search, text='👥 Tìm Trùng Tên & HS Tô Sai Không Có Điểm', command=do_find_duplicates_and_missing_scores).pack(side='left', padx=4)

    audit_bar = ttk.Frame(root, padding=2); audit_bar.pack(fill='x', padx=18)
    ttk.Checkbutton(audit_bar, text='Đối chiếu Excel cả SBD 8 chữ số & Mã đề mẫu (chỉ mở phiếu nghi lỗi)',
        variable=audit_all_var).pack(side='left', padx=8)
    near_var = tk.BooleanVar(value=True)
    ttk.Checkbutton(audit_bar, text='Tự động gợi ý & điền Mã đề lệch 1 chữ số / khuyết ô khi khớp duy nhất danh sách mẫu',
        variable=near_var).pack(side='left', padx=12)

    bar = ttk.Frame(root, padding=4); bar.pack(fill='x', padx=4)
    def start_run(max_records=0):
        if state['busy']: return
        if not messagebox.askyesno('HTB Hub - Duyệt chạy tool gốc', 'Hãy kiểm tra đợt chấm, môn, Excel đối chiếu và chế độ tự lưu trong tool. Bạn cho phép thực hiện lô xử lý phiếu đang cấu hình trên Vietschool?'):
            return
        k = key.get().strip(); m = model.get().strip(); addr = address.get().strip(); selected_provider = provider.get()
        u = username.get().strip(); pw = password.get()
        auto_single = auto_single_var.get(); def_code = default_code_var.get().strip()
        roster_file = official_path.get().strip()
        code_file = codes_path.get().strip()
        chosen_subject = subject_var.get().strip()
        if chosen_subject == 'TẤT CẢ MÔN (tự nhận diện)': chosen_subject = ''
        manual = manual_var.get()
        audit_every_sheet = audit_all_var.get()
        near_one_digit = near_var.get()
        try:
            official_students = load_roster(roster_file) if roster_file else []
            if roster_file and not official_students:
                messagebox.showwarning('Danh sách học sinh đang trống', 'File Excel được chọn chưa có học sinh.')
        except Exception as e:
            messagebox.showerror('Danh sách HS', short_error(e)); return
        try:
            exam_catalog = load_exam_codes(code_file) if code_file else None
        except Exception as e:
            messagebox.showerror('Danh sách mã đề', short_error(e)); return
        if not official_students and exam_catalog is None:
            messagebox.showerror('Cần Excel học sinh hoặc Mã đề', 'Phải tải danh sách HS chính thức (SBD, Họ và tên, Lớp) và/hoặc danh sách Mã đề mẫu trước khi chạy.')
            return
        if selected_provider == 'Gemini' and not k:
            selected_provider = NO_AI_LABEL
        try: retain_login(u, pw)
        except Exception as e: messagebox.showerror('Lưu đăng nhập', short_error(e)); return
        if selected_provider == 'Gemini':
            if not k: messagebox.showwarning('Thiếu key', 'Nhập API key hoặc chuyển sang chế độ "Không dùng AI".'); return
            try: save_api_key(k)
            except Exception as e: messagebox.showerror('Lưu API key', short_error(e)); return
        def work():
            actual, _ = ensure_chrome(addr, control, lambda s: emit('log', s))
            emit('address', actual)
            emit('clear', None)
            browser = Browser(control); state['browser'] = browser; emit('log', 'Đang kết nối Chrome…'); browser.connect(actual)
            browser.login(u, pw, lambda s: emit('log', s))
            if not browser.grid_bound:
                try: browser.bind_grid(timeout=5)
                except Exception:
                    emit('log', 'Đã đăng nhập. Chọn Chấm bài giấy → Chấm bài, đợt chấm và Lọc: Tất cả; rồi bấm CHẠY HÀNG LOẠT.'); return
            output = ROOT / 'ket_qua' / datetime.now().strftime('%Y%m%d_%H%M%S_%f'); state['output'] = output
            def chrome_edit_fallback(old, candidates, top_image, code):
                return browser.wait_for_chrome_edit(old.get('file', ''), candidates, code, lambda s: emit('log', s))
            analyzer = make_analyzer(selected_provider, k, m, control, lambda s: emit('log', s),
                prompt_user=chrome_edit_fallback if manual else None,
                auto_single_match=auto_single, default_code=def_code, exam_catalog=exam_catalog, selected_subject=chosen_subject)
            eff_key = k or load_api_key()
            if isinstance(analyzer, NoAI) and eff_key:
                try:
                    analyzer.handwriting_ai = Gemini(eff_key, '' if m == 'no-ai' else m, control, lambda s: emit('log', s))
                except Exception:
                    analyzer.handwriting_ai = None
            from sbd_excel_only import ExcelSBDRunner
            ExcelSBDRunner(browser, analyzer, emit, control, output, max_records,
                official_roster=official_students, audit_all=audit_every_sheet,
                exam_catalog=exam_catalog, selected_subject=chosen_subject,
                nearest_one_digit=near_one_digit).run()
        run_thread(work)

    start = ttk.Button(bar, text='▶ LỌC LỖI & SỬA SBD / MÃ ĐỀ', command=lambda: start_run(0)); start.pack(side='left', padx=4)
    ttk.Button(bar, text='Thử 1 phiếu LỖI', command=lambda: start_run(1)).pack(side='left', padx=4)

    def check_xem_only():
        if state['busy']: return
        addr = address.get().strip()
        def work():
            actual, _ = ensure_chrome(addr, control, lambda s: emit('log', s)); emit('address', actual)
            b = Browser(control); state['browser'] = b; b.connect(actual)
            if not b.grid_bound: b.bind_grid()
            all_sheets = b.scan()
            state['cached_webrows'] = all_sheets
            if not all_sheets: raise Fatal('Bảng VietSchool chưa có phiếu để kiểm tra Xem.')
            row = next((r for r in all_sheets if issues(r)), all_sheets[0])
            emit('log', 'KIỂM TRA NÚT XEM (KHÔNG DÙNG AI): ' + row['file'])
            b.open(row['file'])
            emit('log', 'THÀNH CÔNG: đã mở đúng phiếu ' + row['file'] + '; không sửa và không lưu.')
            b.delay(1.2)
            b.close()
            emit('log', 'Đã đóng phiếu thử. Có thể chạy hàng loạt.')
        run_thread(work)

    ttk.Button(bar, text='Kiểm tra bấm Xem (không AI)', command=check_xem_only).pack(side='left', padx=4)

    def pause_run():
        if not state['busy']: return
        if pause.is_set(): pause.clear(); emit('log', 'Tiếp tục.')
        else: pause.set(); emit('log', 'Tạm dừng ở bước tiếp theo.')
    ttk.Button(bar, text='Tạm dừng / Tiếp tục', command=pause_run).pack(side='left', padx=4)
    ttk.Button(bar, text='Dừng', command=lambda: stop.set()).pack(side='left', padx=4)

    def test_key():
        k = key.get().strip(); m = model.get().strip(); selected_provider = provider.get()
        if selected_provider == 'Gemini':
            try: save_api_key(k)
            except Exception as e: messagebox.showerror('Lưu API key', short_error(e)); return
        def work():
            api = make_analyzer(selected_provider, k, m, control, lambda s: emit('log', s)); selected = api.test(); emit('model', selected); emit('log', 'Chế độ đọc/đối chiếu sẵn sàng: ' + selected); emit('done', None)
        run_thread(work)
    test = ttk.Button(bar, text='Kiểm tra chế độ / AI', command=test_key); test.pack(side='left', padx=4)

    def diagnostics():
        addr = address.get().strip()
        def work():
            actual, opened = ensure_chrome(addr, control, lambda s: emit('log', s)); emit('address', actual)
            if opened: emit('log', 'Đã mở Chrome. Chọn đợt chấm rồi bấm Xuất chẩn đoán lại.'); return
            b = Browser(control); b.connect(actual); p = ROOT / 'chan_doan_giao_dien.json'; p.write_text(json.dumps(b.diagnostic(), ensure_ascii=False, indent=2), encoding='utf-8'); emit('log', 'Đã xuất ' + str(p)); emit('done', None)
        run_thread(work)
    diag = ttk.Button(bar, text='Xuất chẩn đoán', command=diagnostics); diag.pack(side='left', padx=4)

    def results():
        p = state['output'] or ROOT / 'ket_qua'; p.mkdir(exist_ok=True, parents=True)
        if os.name == 'nt': os.startfile(p)
    ttk.Button(bar, text='Mở báo cáo', command=results).pack(side='left', padx=4)

    summary = tk.StringVar(value='Nạp Excel học sinh & Mã đề mẫu; có thể Chọn Đợt chấm, Tìm kiếm theo Tên + Lớp, Tìm Trùng Tên / HS Mất Điểm, hoặc chạy LỌC LỖI & SỬA SBD / MÃ ĐỀ.')
    ttk.Label(root, textvariable=summary, foreground='#17618f', wraplength=1200).pack(fill='x', padx=16, pady=2)

    frame = ttk.Frame(root); frame.pack(fill='both', expand=True, padx=14)
    cols = ('file', 'reason', 'sbd', 'code', 'name', 'class', 'status', 'note')
    tree = ttk.Treeview(frame, columns=cols, show='headings')
    for c, t, w in [('file', 'Ảnh phiếu / Dòng', 210), ('reason', 'Phân loại / Lỗi', 150), ('sbd', 'SBD đề xuất / hiện tại', 110), ('code', 'Mã đề', 70), ('name', 'Họ tên', 190), ('class', 'Lớp', 75), ('status', 'Kết quả / Điểm', 140), ('note', 'Ghi chú & Gợi ý phiếu nghi vấn', 380)]:
        tree.heading(c, text=t); tree.column(c, width=w, minwidth=60)
    ys = ttk.Scrollbar(frame, orient='vertical', command=tree.yview); xs = ttk.Scrollbar(frame, orient='horizontal', command=tree.xview)
    tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
    tree.grid(row=0, column=0, sticky='nsew'); ys.grid(row=0, column=1, sticky='ns'); xs.grid(row=1, column=0, sticky='ew')
    frame.rowconfigure(0, weight=1); frame.columnconfigure(0, weight=1)

    def open_selected_sheet_on_chrome(_event=None):
        if state['busy']: return
        sel = tree.selection()
        if not sel:
            messagebox.showinfo('Mở Xem phiếu', 'Hãy chọn một dòng phiếu trong bảng kết quả bên dưới trước.')
            return
        row_id = sel[0]
        rec = state['active_records_by_id'].get(row_id, {})
        target_file = str(rec.get('target_file') or rec.get('old', {}).get('file') or row_id).strip()
        if not target_file or target_file.startswith('['):
            messagebox.showwarning('Chưa có file ảnh trực tiếp', 'Dòng này là học sinh chưa có bài và chưa tìm thấy file ảnh nghi vấn cụ thể.')
            return
        addr = address.get().strip()
        def work():
            actual, _ = ensure_chrome(addr, control, lambda s: emit('log', s)); emit('address', actual)
            b = Browser(control)
            state['browser'] = b
            b.connect(actual)
            b.bind_grid()
            if not b.grid_bound: b.bind_grid()
            emit('log', f'Đang nhảy tới dòng {target_file} và mở cửa sổ Xem trên Chrome…')
            b.open(target_file)
            prop = rec.get('proposal', {})
            emit('log', f"Đã mở Xem phiếu {target_file} trên Chrome! (Gợi ý SBD: {prop.get('sbd','')} — {prop.get('name','')} {prop.get('class','')}).")
        run_thread(work)

    def apply_selected_suggestion():
        if state['busy']: return
        sel = tree.selection()
        if not sel:
            messagebox.showinfo('Điền SBD gợi ý', 'Hãy chọn một dòng phiếu có SBD gợi ý trong bảng trước.')
            return
        row_id = sel[0]
        rec = state['active_records_by_id'].get(row_id, {})
        target_file = str(rec.get('target_file') or rec.get('old', {}).get('file') or row_id).strip()
        prop = rec.get('proposal', {})
        new_sbd = str(prop.get('sbd') or '').strip()
        if not target_file or target_file.startswith('[') or not number(new_sbd, 8, 8):
            messagebox.showwarning('Thiếu thông tin', 'Dòng đang chọn chưa có file ảnh phiếu hoặc SBD 8 chữ số hợp lệ để điền.')
            return
        addr = address.get().strip()
        def work():
            actual, _ = ensure_chrome(addr, control, lambda s: emit('log', s)); emit('address', actual)
            b = Browser(control)
            state['browser'] = b
            b.connect(actual)
            b.bind_grid()
            if not b.grid_bound: b.bind_grid()
            emit('log', f'Đang mở phiếu {target_file} và điền SBD {new_sbd} ({prop.get("name","")})…')
            b.open(target_file)
            b.write_sbd_only({'sbd': new_sbd, 'code': str(prop.get('code') or '')}, lambda *a: None)
            b.close()
            rec['status'] = 'Đã điền & lưu SBD'
            emit('record', rec)
            emit('log', f'Đã điền SBD {new_sbd} ({prop.get("name","")}) và bấm Lưu cho phiếu {target_file}!')
        run_thread(work)

    tree.bind('<Double-1>', open_selected_sheet_on_chrome)
    ttk.Button(row_search, text='👁 Mở Xem phiếu chọn', command=open_selected_sheet_on_chrome).pack(side='left', padx=4)
    ttk.Button(row_search, text='✏️ Điền SBD gợi ý & Lưu', command=apply_selected_suggestion).pack(side='left', padx=4)

    logs = scrolledtext.ScrolledText(root, height=6, font=('Consolas', 10)); logs.pack(fill='x', padx=14, pady=6)

    def poll():
        try:
            while True:
                kind, data = events.get_nowait()
                if kind == 'log':
                    logs.insert('end', datetime.now().strftime('%H:%M:%S') + ' ' + str(data) + '\n'); logs.see('end')
                    summary.set(' '.join(str(data).split())[:240])
                elif kind == 'clear':
                    state['active_records_by_id'].clear()
                    for iid in tree.get_children(): tree.delete(iid)
                elif kind == 'address':
                    address.set(data)
                elif kind == 'model':
                    model.set(data)
                elif kind == 'batches':
                    batches, cur = data
                    batch_combo.configure(values=batches)
                    if cur: batch_var.set(cur)
                elif kind in ('records', 'record'):
                    for r in (data if kind == 'records' else [data]):
                        state['active_records_by_id'][r['file']] = r
                        vals = (r['file'], ', '.join(r['reason']), r['proposal'].get('sbd', ''), r['proposal'].get('code', ''), r['proposal'].get('name', ''), r['proposal'].get('class', ''), r['status'], r['note'])
                        if tree.exists(r['file']): tree.item(r['file'], values=vals)
                        else: tree.insert('', 'end', iid=r['file'], values=vals)
                        if kind == 'record' or str(r.get('status', '')).startswith('Đang '):
                            try: tree.see(r['file']); tree.selection_set(r['file'])
                            except Exception: pass
                elif kind == 'idle':
                    state['busy'] = False; start.configure(state='normal'); test.configure(state='normal'); diag.configure(state='normal')
        except queue.Empty:
            pass
        root.after(100, poll)

    def close_app():
        if state['busy']:
            stop.set(); summary.set('Đang dừng. Chờ trạng thái dừng rồi đóng cửa sổ.'); return
        root.destroy()
    root.protocol('WM_DELETE_WINDOW', close_app); poll(); root.mainloop()


if __name__ == '__main__':
    if '--api-worker' in sys.argv:
        http_worker()
    else:
        main()
