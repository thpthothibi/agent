# -*- coding: utf-8 -*-
"""One-pass SBD & Exam Code (Mã đề) mode. Source of truth is the user's local Excel roster
and (optionally) the official Exam Code Excel/CSV file (MAU_DANH_SACH_MA_DE.xlsx).
"""
import csv
import os
import re
from pathlib import Path
from dataclasses import asdict
from datetime import datetime
from phieu_vision import consistent_with_mask, read_handwriting_ocr
from sbd_candidate_filter import select_sbd_anomalies
from vietschool_sbd_agent import (
    Runner,Record,Review,Fatal,StopRun,NoAI,TemporaryGeminiUnavailable,
    blank,number,norm,class_key,same_class,issues,read_bubbles,short_error,
    independent_sbd_only_proposal,_edit_distance_le1,
)


def _is_exc_type(exc, *names):
    return isinstance(exc, tuple(globals()[n] for n in names if n in globals())) or type(exc).__name__ in names


def _is_no_ai(ai):
    return ai is None or isinstance(ai, NoAI) or type(ai).__name__ == 'NoAI'


def _names_match_fuzzy(name_a, name_b):
    na = norm(name_a)
    nb = norm(name_b)
    if not na or not nb:
        return False
    if na == nb:
        return True
    ta = na.split()
    tb = nb.split()
    if len(ta) >= 2 and len(ta) == len(tb):
        if ta[0] == tb[0] and ta[-1] == tb[-1]:
            if all(x == y or (len(x.rstrip('.')) == 1 and y.startswith(x.rstrip('.'))) or (len(y.rstrip('.')) == 1 and x.startswith(y.rstrip('.')))
                   for x, y in zip(ta[1:-1], tb[1:-1])):
                return True
        if len(na) >= 8 and len(nb) >= 8 and ta[0] == tb[0]:
            if na == nb or _edit_distance_le1(na, nb):
                return True
            if len(na) == len(nb) and sum(c1 != c2 for c1, c2 in zip(na, nb)) == 1:
                return True
    return False


def extract_handwriting(a, b=None, official_roster=()):
    if not isinstance(a, dict):
        return None
    if b is None:
        hw_name = str(a.get('name') or '').strip() if not blank(a.get('name')) else ''
        hw_class = str(a.get('class') or '').strip() if not blank(a.get('class')) else ''
        raw_sbd = re.sub(r'[\s\-\.|]+', '', str(a.get('sbd') or '').strip())
        hw_sbd = raw_sbd if number(raw_sbd, 4, 12) else ''
        raw_sbd_pat = str(a.get('sbd_pattern') or '').strip()
        if not raw_sbd_pat and 5 <= len(raw_sbd) <= 7 and raw_sbd.isdigit():
            raw_sbd_pat = raw_sbd
        raw_bub = str(a.get('sbd_bubbles') or '').strip()
        hw_bub = raw_bub if len(raw_bub) == 8 and any(c.isdigit() for c in raw_bub) else ''
        raw_code = re.sub(r'[\s\-\.|]+', '', str(a.get('code') or '').strip())
        hw_code = raw_code if number(raw_code, 2, 6) else ''
        raw_cbub = str(a.get('code_bubbles') or '').strip()
        hw_cbub = raw_cbub if 3 <= len(raw_cbub) <= 6 and any(c.isdigit() for c in raw_cbub) else ''
        if hw_name or hw_sbd or raw_sbd_pat or hw_bub or hw_code or hw_cbub:
            return {
                'name': hw_name, 'class': hw_class, 'sbd': hw_sbd, 'sbd_pattern': raw_sbd_pat,
                'sbd_bubbles': hw_bub, 'code': hw_code, 'code_bubbles': hw_cbub,
                'source': a.get('source', 'single-vision')
            }
        return None
    if not isinstance(b, dict):
        return extract_handwriting(a, None, official_roster=official_roster)
    name_a = str(a.get('name') or '').strip()
    name_b = str(b.get('name') or '').strip()
    hw_name = ''
    if norm(name_a) and _names_match_fuzzy(name_a, name_b):
        if official_roster and any(norm(st.get('name')) == norm(name_b) for st in official_roster) and not any(norm(st.get('name')) == norm(name_a) for st in official_roster):
            hw_name = name_b
        else:
            hw_name = name_a
    elif official_roster:
        for cand_nm, other_nm in ((name_a, name_b), (name_b, name_a)):
            if norm(cand_nm) and not norm(other_nm):
                if any(norm(st.get('name')) == norm(cand_nm) for st in official_roster):
                    hw_name = cand_nm
                    break
    cls_a = str(a.get('class') or '').strip()
    cls_b = str(b.get('class') or '').strip()
    hw_class = cls_a if (cls_a and cls_b and same_class(cls_a, cls_b)) else (cls_a or cls_b if hw_name else '')
    sbd_a = re.sub(r'[\s\-\.|]+', '', str(a.get('sbd') or '').strip())
    sbd_b = re.sub(r'[\s\-\.|]+', '', str(b.get('sbd') or '').strip())
    hw_sbd = sbd_a if (number(sbd_a, 4, 12) and sbd_a == sbd_b) else (sbd_a if number(sbd_a, 8, 8) and not sbd_b and hw_name else '')
    if not hw_sbd and official_roster:
        roster_sbds = {str(st.get('sbd') or '').strip() for st in official_roster}
        for sa, sb in ((sbd_a, sbd_b), (sbd_b, sbd_a)):
            if number(sa, 8, 8) and sa in roster_sbds and (not sb or sb not in roster_sbds):
                hw_sbd = sa
                break
    bub_a = str(a.get('sbd_bubbles') or '').strip()
    bub_b = str(b.get('sbd_bubbles') or '').strip()
    hw_bub = ''
    if len(bub_a) == 8 and len(bub_b) == 8:
        merged = ''.join(ca if ca == cb and ca.isdigit() else (ca if ca.isdigit() and cb == '?' else (cb if cb.isdigit() and ca == '?' else '?'))
                         for ca, cb in zip(bub_a, bub_b))
        if any(c.isdigit() for c in merged):
            hw_bub = merged
    elif len(bub_a) == 8 and any(c.isdigit() for c in bub_a):
        hw_bub = bub_a
    elif len(bub_b) == 8 and any(c.isdigit() for c in bub_b):
        hw_bub = bub_b
    code_a = re.sub(r'[\s\-\.|]+', '', str(a.get('code') or '').strip())
    code_b = re.sub(r'[\s\-\.|]+', '', str(b.get('code') or '').strip())
    hw_code = code_a if (number(code_a, 2, 6) and code_a == code_b) else ''
    cbub_a = str(a.get('code_bubbles') or '').strip()
    cbub_b = str(b.get('code_bubbles') or '').strip()
    hw_cbub = cbub_a if (cbub_a and cbub_a == cbub_b) else (cbub_a or cbub_b)
    if hw_name or hw_sbd or hw_bub or hw_code or hw_cbub:
        return {
            'name': hw_name, 'class': hw_class, 'sbd': hw_sbd, 'sbd_pattern': '',
            'sbd_bubbles': hw_bub, 'code': hw_code, 'code_bubbles': hw_cbub, 'source': '2-pass-vision'
        }
    return None


def _bubble_agreement_count(sbd, mask):
    if not sbd or len(sbd) != len(mask) or not sbd.isdigit():
        return 0, 0, len(mask)
    definite = sum(len(d) == 1 and int(v) == d[0] for v, d in zip(sbd, mask))
    compatible = sum(not d or int(v) in d for v, d in zip(sbd, mask))
    conflicting = sum(bool(d) and int(v) not in d for v, d in zip(sbd, mask))
    return definite, compatible, conflicting


def _expand_old_sbd_pattern(old_sbd):
    raw = str(old_sbd or '').strip()
    if not raw:
        return ''
    if len(raw) == 8 and all(c.isdigit() or c in ('?', '*', '_', ' ', '@') for c in raw):
        return ''.join(c if c.isdigit() else '?' for c in raw)
    if raw.isdigit() and 5 <= len(raw) <= 7 and raw.startswith(('10', '11', '12', '20', '0')):
        return raw.ljust(8, '?')
    norm_raw = ''.join('?' if c in ('?', '*', '_', '@') else c for c in raw)
    if ' ' in norm_raw and len(norm_raw) < 8 and all(c.isdigit() or c in (' ', '?') for c in norm_raw):
        parts = norm_raw.split(' ')
        if len(parts) == 2 and parts[0] and parts[1] and (len(parts[0]) + len(parts[1]) >= 4):
            gap = 8 - len(parts[0]) - len(parts[1])
            if 1 <= gap <= 4:
                return parts[0] + ('?' * gap) + parts[1]
    return ''


def _expand_old_code_pattern(old_code, target_len=4):
    raw = str(old_code or '').strip()
    if not raw:
        return ''
    if len(raw) == target_len and all(c.isdigit() or c in ('?', '*', '_', ' ', '@') for c in raw):
        return ''.join(c if c.isdigit() else '?' for c in raw)
    if ' ' in raw and len(raw) < target_len and all(c.isdigit() or c in (' ', '?', '@') for c in raw):
        parts = raw.split(' ')
        if len(parts) == 2 and parts[0] and parts[1]:
            gap = target_len - len(parts[0]) - len(parts[1])
            if 1 <= gap <= target_len - 2:
                return ''.join(c if c.isdigit() else '?' for c in (parts[0] + ('?' * gap) + parts[1]))
    return ''


def _subsequence_code_matches(old_code, valid_codes):
    raw = str(old_code or '').strip()
    if not raw or not valid_codes:
        return []
    if ' ' in raw and all(c.isdigit() or c == ' ' for c in raw):
        tokens = [t for t in raw.split(' ') if t]
        if len(tokens) >= 2:
            regex_pat = '^[0-9]*' + '[0-9]+'.join(re.escape(t) for t in tokens) + '[0-9]*$'
            return [c for c in valid_codes if re.match(regex_pat, c)]
    if raw.isdigit() and 1 <= len(raw) < max((len(c) for c in valid_codes), default=4):
        substr_m = [c for c in valid_codes if raw in c]
        if len(substr_m) > 1:
            pref_m = [c for c in valid_codes if c.startswith(raw)]
            if len(pref_m) == 1:
                return pref_m
        return substr_m
    return []


def _fallback_mask_from_old_sbd(old_sbd):
    pat = _expand_old_sbd_pattern(old_sbd)
    if len(pat) == 8 and sum(c.isdigit() for c in pat) >= 4:
        mask = [[int(c)] if c.isdigit() else [] for c in pat]
        return {'sbd': pat, 'code': '????', 'masks': {'sbd': mask, 'code': [[], [], [], []]}, 'source': 'omr-pattern'}
    return None


def _find_students_by_written_name(hw_name, hw_class, old_class, official):
    if not norm(hw_name):
        return []
    exact = [st for st in official if norm(st.get('name')) == norm(hw_name)]
    if not blank(hw_class):
        cls_exact = [st for st in exact if same_class(st.get('class'), hw_class)]
        if cls_exact or exact:
            exact = cls_exact
    elif not blank(old_class):
        cls_exact = [st for st in exact if same_class(st.get('class'), old_class)]
        if cls_exact:
            exact = cls_exact
    if exact:
        return exact

    fuzzy = [st for st in official if _names_match_fuzzy(hw_name, st.get('name', ''))]
    if not blank(hw_class):
        fuzzy = [st for st in fuzzy if same_class(st.get('class'), hw_class)]
    elif not blank(old_class):
        cls_fuzzy = [st for st in fuzzy if same_class(st.get('class'), old_class)]
        if cls_fuzzy:
            fuzzy = cls_fuzzy
    return fuzzy


def rank_sbd_candidates(old, bubbles, official, webrows=(), handwriting=None, limit=5):
    if not official:
        return []
    old_sbd = str(old.get('sbd') or '').strip()
    eff_bubbles = bubbles if (isinstance(bubbles, dict) and len(bubbles.get('masks', {}).get('sbd', ())) == 8) else _fallback_mask_from_old_sbd(old_sbd)
    mask = eff_bubbles.get('masks', {}).get('sbd', []) if isinstance(eff_bubbles, dict) else []
    bubble_sbd = str((eff_bubbles or {}).get('sbd') or '').strip()

    assigned_sbds = {
        str(r.get('sbd') or '').strip()
        for r in (webrows or ())
        if r.get('file') != old.get('file') and not blank(r.get('name')) and str(r.get('sbd') or '').strip()
    }

    hw = handwriting if isinstance(handwriting, dict) else {}
    hw_sbd = str(hw.get('sbd') or '').strip()
    hw_pat = str(hw.get('sbd_pattern') or '').strip()
    hw_name = str(hw.get('name') or '').strip()
    hw_cls = str(hw.get('class') or '').strip()

    scored = []
    seen_sbds = set()
    for st in official:
        sbd_val = str(st.get('sbd') or '').strip()
        nm = str(st.get('name') or '').strip()
        cls = str(st.get('class') or '').strip()
        if len(sbd_val) != 8 or not sbd_val.isdigit() or sbd_val in seen_sbds:
            continue
        seen_sbds.add(sbd_val)
        is_unassigned = (sbd_val not in assigned_sbds)

        def_m, comp_m, conf_m = _bubble_agreement_count(sbd_val, mask) if len(mask) == 8 else (0, 0, 8)
        suffix3_match = (len(bubble_sbd) == 8 and bubble_sbd[:2] == sbd_val[:2] and bubble_sbd[5:8] == sbd_val[5:8])
        suffix2_match = (len(bubble_sbd) == 8 and bubble_sbd[:2] == sbd_val[:2] and sum(a == b for a, b in zip(bubble_sbd[5:8], sbd_val[5:8])) >= 2)
        hw_sbd_match = (len(hw_sbd) == 8 and sum(a == b for a, b in zip(hw_sbd, sbd_val)) >= 6) or (bool(hw_pat) and hw_pat in sbd_val)
        hw_name_match = bool(hw_name and (_names_match_fuzzy(hw_name, nm) or norm(hw_name) in norm(nm)))
        hw_cls_match = bool(hw_cls and same_class(hw_cls, cls))

        if def_m < 4 and not suffix3_match and not hw_sbd_match and not hw_name_match:
            continue

        tags = []
        if hw_name_match:
            tags.append('khớp tên viết tay')
        if hw_sbd_match:
            tags.append('khớp SBD viết tay')
        if suffix3_match:
            tags.append(f'khớp mã số HS #{sbd_val[5:8]}')
        tags.append(f'khớp {def_m}/8 cột')
        if not is_unassigned:
            tags.append('đã có bài')

        sort_key = (
            1 if is_unassigned else 0,
            1 if hw_name_match else 0,
            1 if hw_sbd_match else 0,
            1 if suffix3_match else 0,
            def_m,
            -conf_m,
            1 if suffix2_match else 0,
            1 if hw_cls_match else 0,
        )
        scored.append((sort_key, {
            'sbd': sbd_val,
            'name': nm,
            'class': cls,
            'matched_cols': def_m,
            'unassigned': is_unassigned,
            'tag': ', '.join(tags),
        }))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [x[1] for x in scored[:limit]]


def sbd_evidence(old, bubbles, official, webrows=(), handwriting=None):
    if not official:
        return 'review', None, 'Chưa tải danh sách HS chính thức từ Excel.'

    by_sbd = {}
    by_person = {}
    for st in official:
        sbd = str(st.get('sbd') or '').strip()
        nm = str(st.get('name') or '').strip()
        cls = str(st.get('class') or '').strip()
        if not sbd or not nm or not cls:
            continue
        by_sbd.setdefault(sbd, []).append({'sbd': sbd, 'name': nm, 'class': cls})
        by_person.setdefault((norm(nm), class_key(cls)), []).append({'sbd': sbd, 'name': nm, 'class': cls})

    old_sbd = str(old.get('sbd') or '').strip()
    old_name = str(old.get('name') or '').strip()
    old_cls = str(old.get('class') or '').strip()
    old_code = str(old.get('code') or '').strip()

    eff_bubbles = bubbles if (isinstance(bubbles, dict) and len(bubbles.get('masks', {}).get('sbd', ())) == 8) else _fallback_mask_from_old_sbd(old_sbd)
    mask = eff_bubbles.get('masks', {}).get('sbd', []) if isinstance(eff_bubbles, dict) else []
    bubble_sbd = str((eff_bubbles or {}).get('sbd') or '').strip()

    hw = handwriting if isinstance(handwriting, dict) else {}
    hw_name = str(hw.get('name') or '').strip()
    hw_class = str(hw.get('class') or '').strip()
    hw_sbd = str(hw.get('sbd') or '').strip()
    hw_sbd_pat = str(hw.get('sbd_pattern') or '').strip()
    hw_bub = str(hw.get('sbd_bubbles') or '').strip()

    for pat_src in (hw_bub, _expand_old_sbd_pattern(hw_sbd_pat)):
        if len(pat_src) == 8 and any(c.isdigit() for c in pat_src):
            if len(mask) != 8:
                mask = [[int(c)] if c.isdigit() else [] for c in pat_src]
                bubble_sbd = ''.join(c if c.isdigit() else '?' for c in pat_src)
                eff_bubbles = {'sbd': bubble_sbd, 'code': old_code or '????', 'masks': {'sbd': mask, 'code': [[], [], [], []]}}
            elif sum(len(d) == 1 for d in mask) < 6:
                merged_mask = [list(d) if d else ([int(c)] if c.isdigit() else []) for d, c in zip(mask, pat_src)]
                mask = merged_mask
                bubble_sbd = ''.join(str(d[0]) if len(d) == 1 else '?' for d in mask)
                eff_bubbles = {**(eff_bubbles or {}), 'sbd': bubble_sbd, 'masks': {**(eff_bubbles or {}).get('masks', {}), 'sbd': mask}}

    other_sbd_counts = {}
    assigned_sbds = set()
    for r in webrows:
        if r.get('file') == old.get('file'):
            continue
        rs = str(r.get('sbd') or '').strip()
        if rs:
            other_sbd_counts[rs] = other_sbd_counts.get(rs, 0) + 1
            if not blank(r.get('name')):
                assigned_sbds.add(rs)

    duplicate_old_sbd = bool(old_sbd and other_sbd_counts.get(old_sbd, 0) >= 1)

    if hw_name or number(hw_sbd, 8, 8):
        name_candidates = _find_students_by_written_name(hw_name, hw_class, old_cls, official) if hw_name else []
        distinct_name_sbds = {str(st['sbd']).strip() for st in name_candidates}

        if len(distinct_name_sbds) == 1:
            st = name_candidates[0]
            cand_sbd = str(st['sbd']).strip()
            if cand_sbd not in assigned_sbds or cand_sbd == old_sbd:
                def_m, comp_m, _ = _bubble_agreement_count(cand_sbd, mask) if len(mask) == 8 else (0, 0, 0)
                if cand_sbd == old_sbd and not blank(old_name) and norm(old_name) == norm(st['name']) and same_class(old_cls, st['class']) and not duplicate_old_sbd:
                    return 'ok', None, f"SBD {cand_sbd} đã khớp tên viết tay và danh sách Excel ({st['name']} - {st['class']})."
                return ('write',
                    {'sbd': cand_sbd, 'code': old_code, 'name': st['name'], 'class': st['class']},
                    f"Đọc tên viết tay trên phiếu '{hw_name}' khớp duy nhất HS Excel: {cand_sbd} — {st['name']} ({st['class']})"
                    + (f" (khớp {def_m}/8 cột ô tô SBD)." if len(mask) == 8 else "."))

        elif len(distinct_name_sbds) > 1:
            filtered = []
            for st in name_candidates:
                csbd = str(st['sbd']).strip()
                if csbd in assigned_sbds and csbd != old_sbd:
                    continue
                if number(hw_sbd, 8, 8) and csbd == hw_sbd:
                    filtered.append((9, 9, st))
                    continue
                if len(mask) == 8:
                    def_m, comp_m, conf_m = _bubble_agreement_count(csbd, mask)
                    if conf_m == 0 and def_m >= 5:
                        filtered.append((def_m, comp_m, st))
                    elif def_m >= 6:
                        filtered.append((def_m, comp_m, st))
            if filtered:
                filtered.sort(key=lambda x: (x[0], x[1]), reverse=True)
                best_score = (filtered[0][0], filtered[0][1])
                top_matches = [x[2] for x in filtered if (x[0], x[1]) == best_score]
                if len({str(x['sbd']).strip() for x in top_matches}) == 1:
                    st = top_matches[0]
                    cand_sbd = str(st['sbd']).strip()
                    if len(mask) != 8 or consistent_with_mask(cand_sbd, mask, min_known=6, max_unknown=2):
                        return ('write',
                            {'sbd': cand_sbd, 'code': old_code, 'name': st['name'], 'class': st['class']},
                            f"Tên viết tay '{hw_name}' trùng trong lớp nhưng ô tô/SBD viết tay khớp duy nhất: {cand_sbd} — {st['name']} ({st['class']}).")

        if not distinct_name_sbds and number(hw_sbd, 8, 8) and hw_sbd in by_sbd:
            sbd_group = by_sbd[hw_sbd]
            owners = {(norm(x['name']), class_key(x['class'])) for x in sbd_group}
            if len(owners) == 1 and (hw_sbd not in assigned_sbds or hw_sbd == old_sbd):
                st = sbd_group[0]
                if blank(hw_name) or _names_match_fuzzy(hw_name, st['name']):
                    if blank(old_name) or duplicate_old_sbd or norm(old_name) == norm(st['name']):
                        return ('write',
                            {'sbd': hw_sbd, 'code': old_code, 'name': st['name'], 'class': st['class']},
                            f"Đọc SBD viết tay trên phiếu ({hw_sbd}) khớp duy nhất HS Excel: {st['name']} ({st['class']}).")

        if not distinct_name_sbds and number(hw_sbd, 8, 8) and hw_sbd not in by_sbd:
            hw_near = []
            for sbd_val, group in by_sbd.items():
                if len(sbd_val) != 8 or sbd_val in assigned_sbds:
                    continue
                if len({(norm(x['name']), class_key(x['class'])) for x in group}) != 1:
                    continue
                if sum(a == b for a, b in zip(hw_sbd, sbd_val)) == 7:
                    def_m, _, _ = _bubble_agreement_count(sbd_val, mask) if len(mask) == 8 else (6, 6, 0)
                    if def_m >= 5:
                        hw_near.append(group[0])
            if len({x['sbd'] for x in hw_near}) == 1:
                st = hw_near[0]
                return ('write',
                    {'sbd': st['sbd'], 'code': old_code, 'name': st['name'], 'class': st['class']},
                    f"Kết hợp SBD viết tay ({hw_sbd}) và ô tô SBD khớp duy nhất HS chưa có bài trong Excel: {st['sbd']} — {st['name']} ({st['class']}).")

    if len(mask) == 8:
        if number(bubble_sbd, 8, 8):
            matched = by_sbd.get(bubble_sbd, [])
            owners = {(norm(x['name']), class_key(x['class'])) for x in matched}
            if len(owners) == 1:
                student = matched[0]
                if not blank(old_name) and not duplicate_old_sbd and norm(old_name) != norm(student['name']):
                    if old_sbd and old_sbd != bubble_sbd and old_sbd in by_sbd:
                        old_owners = {norm(x['name']) for x in by_sbd[old_sbd]}
                        if norm(old_name) in old_owners and bubble_sbd not in assigned_sbds:
                            return ('write',
                                {'sbd': bubble_sbd, 'code': old_code, 'name': student['name'], 'class': student['class']},
                                f"Ô tô SBD trên ảnh là {bubble_sbd} ({student['name']} - {student['class']}); "
                                f"tên hiển thị cũ '{old_name}' là do VietSchool tự gán theo SBD cũ {old_sbd}.")
                    return ('review', None,
                        f"SBD tô trên ảnh là {bubble_sbd} ({student['name']} - {student['class']}) "
                        f"nhưng VietSchool đang hiển thị '{old_name}' ({old_cls}). Cần kiểm tra thủ công.")
                if not blank(old_cls) and not duplicate_old_sbd and not same_class(old_cls, student['class']):
                    return ('review', None,
                        f"SBD tô trên ảnh là {bubble_sbd} thuộc lớp {student['class']}, "
                        f"không khớp lớp {old_cls} trên VietSchool.")
                if bubble_sbd == old_sbd:
                    person_key = (norm(student['name']), class_key(student['class']))
                    if len(by_person.get(person_key, [])) > 1:
                        return ('ok', None,
                            f"SBD {bubble_sbd} trùng khớp 8/8 ô tô và thuộc {student['name']} ({student['class']}); "
                            "giữ nguyên, nhưng lớp có học sinh trùng họ tên nên được ghi vào báo cáo đối chiếu.")
                    if blank(old_name):
                        if duplicate_old_sbd:
                            return ('review', None,
                                f"SBD {bubble_sbd} đang bị trùng ở nhiều phiếu trên bảng VietSchool; cần kiểm tra phiếu tô nhầm.")
                        return ('write',
                            {'sbd': bubble_sbd, 'code': old_code, 'name': student['name'], 'class': student['class']},
                            f"SBD {bubble_sbd} khớp 8/8 ô tô và Excel ({student['name']} - {student['class']}); "
                            "Thiếu họ tên trên VietSchool nên lưu lại đúng SBD này để cập nhật học sinh.")
                    if duplicate_old_sbd:
                        return ('ok', None,
                            f"SBD {bubble_sbd} khớp 8/8 ô tô của {student['name']} ({student['class']}); giữ nguyên phiếu đúng này.")
                    return 'ok', None, f"SBD {bubble_sbd} đã khớp 8/8 ô tô và danh sách Excel."
                if bubble_sbd in assigned_sbds:
                    return ('review', None,
                        f"Ô tô SBD {bubble_sbd} ({student['name']}) trùng với một phiếu khác đã có trên bảng.")
                return ('write',
                    {'sbd': bubble_sbd, 'code': old_code, 'name': student['name'], 'class': student['class']},
                    f"Ô tô SBD 8/8 xác định duy nhất {bubble_sbd} — {student['name']} ({student['class']}).")

        if not blank(old_name) and not blank(old_cls) and not duplicate_old_sbd:
            person_matches = by_person.get((norm(old_name), class_key(old_cls)), [])
            if len(person_matches) == 1:
                st = person_matches[0]
                target_sbd = st['sbd']
                def_m, comp_m, conf_m = _bubble_agreement_count(target_sbd, mask)
                if target_sbd not in assigned_sbds and ((conf_m == 0 and def_m >= 5) or def_m >= 7):
                    if target_sbd != old_sbd:
                        return ('write',
                            {'sbd': target_sbd, 'code': old_code, 'name': st['name'], 'class': st['class']},
                            f"Họ tên '{st['name']}' ({st['class']}) và ô tô SBD ({def_m}/8 cột) khớp duy nhất SBD {target_sbd} trong Excel.")

        if duplicate_old_sbd and not blank(old_name):
            old_for_prop = {**old, 'name': '', 'class': ''}
        else:
            old_for_prop = old
        prop = independent_sbd_only_proposal(old_for_prop, eff_bubbles, official, webrows)
        if prop:
            if duplicate_old_sbd and prop['sbd'] == old_sbd:
                return ('review', None,
                    f"Phiếu trùng SBD {old_sbd}; cần kiểm tra thêm tên viết tay trên ảnh.")
            return ('write',
                {'sbd': prop['sbd'], 'code': old_code, 'name': prop['name'], 'class': prop['class']},
                prop.get('evidence') or f"Ô tô SBD khớp duy nhất HS Excel: {prop['sbd']} — {prop['name']} ({prop['class']}).")

        if sum(len(d) == 1 for d in mask) == 5 and (blank(old_name) or duplicate_old_sbd):
            unassigned_5 = []
            for sbd_val, group in by_sbd.items():
                if len(sbd_val) != 8 or sbd_val in assigned_sbds or sbd_val == old_sbd:
                    continue
                if len({(norm(x['name']), class_key(x['class'])) for x in group}) != 1:
                    continue
                if consistent_with_mask(sbd_val, mask, min_known=5, max_unknown=3):
                    unassigned_5.append(group[0])
            if len({x['sbd'] for x in unassigned_5}) == 1:
                st = unassigned_5[0]
                return ('write',
                    {'sbd': st['sbd'], 'code': old_code, 'name': st['name'], 'class': st['class']},
                    f"Ô tô SBD ({bubble_sbd}) khớp duy nhất 1 học sinh chưa có bài trong Excel: {st['sbd']} — {st['name']} ({st['class']}).")

        if (blank(old_name) or duplicate_old_sbd) and sum(len(d) == 1 for d in mask) >= 7:
            near_unassigned = []
            for sbd_val, group in by_sbd.items():
                if len(sbd_val) != 8 or sbd_val in assigned_sbds or sbd_val == old_sbd:
                    continue
                owners = {(norm(x['name']), class_key(x['class'])) for x in group}
                if len(owners) != 1:
                    continue
                def_m, comp_m, conf_m = _bubble_agreement_count(sbd_val, mask)
                if def_m >= 7 and conf_m <= 1 and (def_m + (8 - sum(bool(d) for d in mask))) >= 7:
                    near_unassigned.append((def_m, group[0]))
            distinct_near = {x[1]['sbd']: x[1] for x in near_unassigned}
            if len(distinct_near) == 1:
                st = next(iter(distinct_near.values()))
                cand_sbd = st['sbd']
                return ('write',
                    {'sbd': cand_sbd, 'code': old_code, 'name': st['name'], 'class': st['class']},
                    f"Ô tô SBD ({bubble_sbd}) khớp 7/8 cột với duy nhất 1 học sinh chưa có bài trong Excel (học sinh tô nhầm 1 cột): "
                    f"{cand_sbd} — {st['name']} ({st['class']}).")

        if (blank(old_name) or duplicate_old_sbd) and len(bubble_sbd) == 8 and bubble_sbd not in by_sbd:
            prefix2 = bubble_sbd[:2]
            suffix3 = bubble_sbd[5:8]
            if prefix2.isdigit() and suffix3.isdigit():
                all_suffix_matches = [
                    group[0] for sbd_val, group in by_sbd.items()
                    if len(sbd_val) == 8 and sbd_val[:2] == prefix2 and sbd_val[5:8] == suffix3
                    and len({(norm(x['name']), class_key(x['class'])) for x in group}) == 1
                ]
                if len(all_suffix_matches) == 1:
                    st = all_suffix_matches[0]
                    cand_sbd = st['sbd']
                    if cand_sbd not in assigned_sbds and cand_sbd != old_sbd:
                        return ('write',
                            {'sbd': cand_sbd, 'code': old_code, 'name': st['name'], 'class': st['class']},
                            f"Khớp mã khối ({prefix2}) + mã số HS duy nhất toàn khối ({suffix3}) trong Excel (học sinh tô nhầm cột mã lớp/phòng): "
                            f"{cand_sbd} — {st['name']} ({st['class']}).")

            if prefix2.isdigit() and bubble_sbd.isdigit():
                near_6_unassigned = []
                for sbd_val, group in by_sbd.items():
                    if len(sbd_val) != 8 or sbd_val in assigned_sbds or sbd_val == old_sbd:
                        continue
                    if sbd_val[:2] != prefix2:
                        continue
                    if len({(norm(x['name']), class_key(x['class'])) for x in group}) != 1:
                        continue
                    def_m, _, _ = _bubble_agreement_count(sbd_val, mask)
                    same_cls_code = (sbd_val[2:5] == bubble_sbd[2:5])
                    suffix_sim = sum(a == b for a, b in zip(sbd_val[5:8], bubble_sbd[5:8]))
                    if def_m == 6 and (same_cls_code or suffix_sim >= 2):
                        near_6_unassigned.append(group[0])
                if len({x['sbd'] for x in near_6_unassigned}) == 1:
                    st = near_6_unassigned[0]
                    cand_sbd = st['sbd']
                    return ('write',
                        {'sbd': cand_sbd, 'code': old_code, 'name': st['name'], 'class': st['class']},
                        f"Tự động gợi ý & điền SBD {cand_sbd} — {st['name']} ({st['class']}) "
                        f"(khớp duy nhất 6/8 cột ô tô + mã lớp/mã số HS trong nhóm HS chưa có bài; SBD tô ban đầu: {bubble_sbd}).")

    ranked_cands = rank_sbd_candidates(old, bubbles, official, webrows=webrows, handwriting=handwriting, limit=4)
    sug_suffix = ''
    if ranked_cands:
        items = [f"{c['sbd']} - {c['name']} ({c['class']}) [{c['tag']}]" for c in ranked_cands]
        sug_suffix = ' Gợi ý SBD gần nhất: ' + '; '.join(items) + '.'

    if duplicate_old_sbd:
        return 'review', None, 'Trùng SBD ở nhiều phiếu VietSchool; cần đối chiếu ảnh và Excel trước khi kết luận.' + sug_suffix

    return 'review', None, 'SBD không khớp duy nhất danh sách Excel (có thể tô sai nhiều ô, trùng SBD, hoặc tên/lớp mâu thuẫn). Không tự đoán.' + sug_suffix


def code_evidence(old, bubbles, exam_catalog, webrows=(), selected_subject='', handwriting=None, nearest_one_digit=True):
    old_code = str(old.get('code') or '').strip()
    if exam_catalog is None:
        return 'ok', old_code, '', {'current': old_code, 'candidate': old_code, 'method': 'disabled', 'codes': []}

    if hasattr(exam_catalog, 'resolve_batch_codes'):
        sub_key, valid_codes, scope_reason = exam_catalog.resolve_batch_codes(old, webrows, selected_subject)
    else:
        sub_key, valid_codes, scope_reason = exam_catalog.valid_codes(old, selected_subject)

    sub_label = exam_catalog.labels.get(sub_key, sub_key or 'Đợt chấm hiện tại') if hasattr(exam_catalog, 'labels') else (sub_key or '')
    active_codes = sorted({
        str(r.get('code') or '').strip()
        for r in (webrows or ())
        if not blank(r.get('score')) and str(r.get('code') or '').strip() in set(valid_codes)
    })

    b_mask = list((bubbles or {}).get('masks', {}).get('code', [])) if isinstance(bubbles, dict) else []
    b_str = str((bubbles or {}).get('code') or '').strip() if isinstance(bubbles, dict) else ''

    target_len = max((len(c) for c in valid_codes), default=4) if valid_codes else 4
    omr_pat = _expand_old_code_pattern(old_code, target_len=target_len)
    if len(b_mask) == target_len and len(omr_pat) == target_len:
        merged_m = [list(d) if d else ([int(c)] if c.isdigit() else []) for d, c in zip(b_mask, omr_pat)]
        b_mask = merged_m
        b_str = ''.join(str(d[0]) if len(d) == 1 else '?' for d in b_mask)
    elif len(b_mask) != target_len and len(omr_pat) == target_len:
        b_mask = [[int(c)] if c.isdigit() else [] for c in omr_pat]
        b_str = omr_pat

    hw = handwriting if isinstance(handwriting, dict) else {}
    hw_code = str(hw.get('code') or '').strip()
    hw_cbub = str(hw.get('code_bubbles') or '').strip()
    if len(hw_cbub) == target_len and any(c.isdigit() for c in hw_cbub):
        if len(b_mask) != target_len:
            b_mask = [[int(c)] if c.isdigit() else [] for c in hw_cbub]
            b_str = ''.join(c if c.isdigit() else '?' for c in hw_cbub)
        else:
            b_mask = [list(d) if d else ([int(c)] if c.isdigit() else []) for d, c in zip(b_mask, hw_cbub)]
            b_str = ''.join(str(d[0]) if len(d) == 1 else '?' for d in b_mask)

    advice = {
        'subject': sub_label,
        'codes': valid_codes,
        'current': old_code,
        'bubble': b_str,
        'candidate': '',
        'reason': scope_reason,
        'evidence': '',
        'handwritten': hw_code,
        'method': '',
        'distance': None,
        'ranked': [],
    }

    if not valid_codes:
        msg = scope_reason or 'Chưa xác định được danh sách mã đề mẫu cho phiếu này.'
        advice['reason'] = msg
        return 'review', None, msg, advice

    if old_code in valid_codes:
        if hw_code in valid_codes and hw_code != old_code and blank(old.get('score')):
            advice['candidate'] = hw_code
            advice['method'] = 'handwritten_override'
            advice['evidence'] = f"Mã đề viết tay ({hw_code}) thuộc danh sách mẫu (thay cho mã {old_code} đang thiếu điểm)."
            return 'write', hw_code, advice['evidence'], advice
        advice['candidate'] = old_code
        advice['method'] = 'already_valid'
        advice['evidence'] = f"Mã đề {old_code} đã hợp lệ trong danh sách mẫu."
        return 'ok', old_code, advice['evidence'], advice

    if b_str and b_str.isdigit() and b_str in valid_codes:
        advice['candidate'] = b_str
        advice['method'] = 'exact_bubble'
        advice['evidence'] = f"Ô tô mã đề trên ảnh ({b_str}) khớp chính xác danh sách mã đề mẫu."
        return 'write', b_str, advice['evidence'], advice

    if hw_code and hw_code in valid_codes:
        advice['candidate'] = hw_code
        advice['method'] = 'handwritten'
        advice['evidence'] = f"Mã đề viết tay trên phiếu ({hw_code}) khớp danh sách mã đề mẫu."
        return 'write', hw_code, advice['evidence'], advice

    if len(b_mask) == target_len and any(bool(d) for d in b_mask):
        mask_matches = [
            c for c in valid_codes
            if len(c) == target_len and all(not d or int(ch) in d for ch, d in zip(c, b_mask))
        ]
        if len(mask_matches) > 1 and active_codes:
            active_sub = [c for c in mask_matches if c in active_codes]
            if len(active_sub) == 1:
                mask_matches = active_sub
        if len(mask_matches) == 1:
            chosen = mask_matches[0]
            advice['candidate'] = chosen
            advice['method'] = 'partial_mask_unique'
            advice['evidence'] = f"Tự động gợi ý & điền mã đề {chosen} (khớp duy nhất các cột ô tô '{b_str}' với danh sách mẫu)."
            return 'write', chosen, advice['evidence'], advice

    subseq_matches = _subsequence_code_matches(old_code, valid_codes)
    if len(subseq_matches) > 1 and active_codes:
        active_sub = [c for c in subseq_matches if c in active_codes]
        if len(active_sub) == 1:
            subseq_matches = active_sub
    if len(subseq_matches) == 1:
        chosen = subseq_matches[0]
        advice['candidate'] = chosen
        advice['method'] = 'subsequence_unique'
        advice['evidence'] = f"Tự động gợi ý & điền mã đề {chosen} (khôi phục từ mã khuyết '{old_code}' khớp duy nhất danh sách mẫu)."
        return 'write', chosen, advice['evidence'], advice

    if nearest_one_digit:
        for probe in (b_str, old_code):
            if probe and probe.isdigit() and len(probe) == target_len:
                same_len = [c for c in valid_codes if len(c) == target_len]
                if same_len:
                    ranked = sorted((sum(a != b for a, b in zip(probe, c)), c) for c in same_len)
                    advice['ranked'] = ranked[:5]
                    advice['distance'] = ranked[0][0]
                    dist1 = [c for d, c in ranked if d == 1]
                    if len(dist1) > 1 and active_codes:
                        active_d1 = [c for c in dist1 if c in active_codes]
                        if len(active_d1) == 1:
                            dist1 = active_d1
                    if len(dist1) == 1:
                        chosen = dist1[0]
                        advice['candidate'] = chosen
                        advice['method'] = 'nearest_one_digit'
                        advice['evidence'] = (
                            f"Tự động gợi ý & điền mã đề {chosen} (khớp {target_len-1}/{target_len} cột với duy nhất 1 mã đề trong danh sách mẫu; "
                            f"học sinh tô nhầm 1 ô từ {probe})."
                        )
                        return 'write', chosen, advice['evidence'], advice

        if len(b_mask) == target_len and sum(bool(d) for d in b_mask) >= target_len - 1:
            near_mask = []
            for c in valid_codes:
                if len(c) != target_len:
                    continue
                def_m, comp_m, conf_m = _bubble_agreement_count(c, b_mask)
                if comp_m >= target_len - 1 and conf_m <= 1 and def_m >= target_len - 1:
                    near_mask.append(c)
            if len(near_mask) > 1 and active_codes:
                active_nm = [c for c in near_mask if c in active_codes]
                if len(active_nm) == 1:
                    near_mask = active_nm
            if len(near_mask) == 1:
                chosen = near_mask[0]
                advice['candidate'] = chosen
                advice['method'] = 'nearest_mask_one_digit'
                advice['evidence'] = f"Tự động gợi ý & điền mã đề {chosen} (khớp {target_len-1}/{target_len} cột ô tô trên ảnh với duy nhất 1 mã đề mẫu)."
                return 'write', chosen, advice['evidence'], advice

    if len(valid_codes) == 1:
        chosen = valid_codes[0]
        advice['candidate'] = chosen
        advice['method'] = 'single_official_code'
        advice['evidence'] = f"Tự động điền mã đề duy nhất trong danh sách mẫu: {chosen}."
        return 'write', chosen, advice['evidence'], advice

    suggestions = []
    if subseq_matches:
        suggestions = subseq_matches[:6]
        advice['ranked'] = [(1, c) for c in suggestions]
    elif not advice['ranked'] and valid_codes:
        probe_digits = ''.join(c for c in (b_str or old_code) if c.isdigit())
        if probe_digits:
            ranked = sorted(
                (len(c) - sum(ch in c for ch in set(probe_digits)), c)
                for c in valid_codes
            )
            advice['ranked'] = ranked[:5]
            suggestions = [c for _, c in ranked[:5]]
        else:
            suggestions = valid_codes[:6]
    else:
        suggestions = [c for _, c in advice['ranked'][:5]]

    sug_text = ', '.join(suggestions) if suggestions else ', '.join(valid_codes[:8])
    msg = f"Mã đề '{old_code or b_str or '(trống)'}' chưa khớp duy nhất 1 mã đề mẫu. Gợi ý mã đề gần nhất: {sug_text}."
    advice['reason'] = msg
    return 'review', None, msg, advice


class ExcelSBDRunner(Runner):
    def report(self):
        sbd_advice_map = getattr(self, 'sbd_advice', {})
        with (self.output/'bao_cao_sbd.csv').open('w',newline='',encoding='utf-8-sig') as f:
            writer=csv.writer(f)
            writer.writerow(['Ảnh phiếu','Lý do chọn phiếu','SBD VietSchool ban đầu','SBD Excel đề xuất',
                'Họ tên Excel','Lớp Excel','Mã đề ban đầu','Mã đề đề xuất / giữ nguyên','Điểm','Trạng thái','Bằng chứng / nguyên nhân'])
            def text(v):
                value=str(v if v is not None else '')
                return "'"+value if value.startswith(('=','+','-','@')) or re.fullmatch(r'0\d+',value) else value
            for r in self.records:
                prop_code = r.proposal.get('code') or r.old.get('code')
                after_score = r.after.get('score') if r.after and not blank(r.after.get('score')) else r.old.get('score')
                writer.writerow([text(x) for x in (r.file,'; '.join(r.reason),r.old.get('sbd'),r.proposal.get('sbd'),
                    r.proposal.get('name'),r.proposal.get('class'),r.old.get('code'),prop_code,
                    after_score,r.status,r.note)])

        with (self.output/'goi_y_sbd.csv').open('w',newline='',encoding='utf-8-sig') as f:
            writer=csv.writer(f)
            writer.writerow([
                'Ảnh phiếu','SBD VietSchool ban đầu','SBD trên ô tô (8 cột)',
                'SBD viết tay đọc trên phiếu','Họ tên viết tay đọc trên phiếu','Lớp đọc trên phiếu',
                'SBD đề xuất điền','Họ tên HS đề xuất (Excel)','Lớp HS đề xuất (Excel)',
                'Trạng thái xử lý','Số cột khớp (/8)','Danh sách gợi ý HS gần nhất (ưu tiên HS chưa có bài)',
                'Căn cứ / ghi chú chi tiết'
            ])
            for r in self.records:
                sh = sbd_advice_map.get(r.file, {})
                writer.writerow([
                    r.file,
                    r.old.get('sbd',''),
                    sh.get('bubble',''),
                    sh.get('hw_sbd',''),
                    sh.get('hw_name',''),
                    sh.get('hw_class',''),
                    r.proposal.get('sbd',''),
                    r.proposal.get('name',''),
                    r.proposal.get('class',''),
                    r.status,
                    sh.get('matched_cols',''),
                    '; '.join(sh.get('ranked_text',[])),
                    r.note,
                ])

        if self.exam_catalog is not None:
            with (self.output/'goi_y_ma_de.csv').open('w',newline='',encoding='utf-8-sig') as f:
                writer=csv.writer(f)
                writer.writerow(['Ảnh phiếu','Môn / Phạm vi','Mã đề VietSchool','Mã đề trên ô tô','Các mã đề mẫu',
                    'Mã đề đề xuất','Căn cứ / gợi ý','Trạng thái xử lý','Mã viết tay','Cách đối chiếu','Số vị trí lệch','Các mã gần nhất'])
                for r in self.records:
                    hint=self.code_advice.get(r.file,{})
                    writer.writerow([
                        r.file, hint.get('subject',''), r.old.get('code',''), hint.get('bubble',''),
                        ', '.join(hint.get('codes',[])), hint.get('candidate',''),
                        hint.get('evidence','') or hint.get('reason',''), r.status, hint.get('handwritten',''),
                        hint.get('method',''), hint.get('distance','') if hint.get('distance') is not None else '',
                        ', '.join(f'{code}: {dist} vị trí' for dist,code in hint.get('ranked',[]))
                    ])

    def _verify_fields(self,file,proposal,old,modal_verified=None,wrote_sbd=True,wrote_code=False):
        self.browser.close()
        if hasattr(self.browser,'locate_visible') or hasattr(self.browser,'reload_grading_table'):
            value=None
            if hasattr(self.browser,'locate_visible'):
                value=self.browser.locate_visible(file)
            elif hasattr(self.browser,'locate'):
                value=self.browser.locate(file)
            value=dict(value or {})
            if modal_verified:
                if wrote_sbd and str(value.get('sbd') or '').strip()!=str(proposal['sbd']) and str(modal_verified.get('sbd') or '').strip()==str(proposal['sbd']):
                    value['sbd']=proposal['sbd']
                    if blank(value.get('name')):
                        value['name']=modal_verified.get('name') or proposal.get('name','')
                    if blank(value.get('class')):
                        value['class']=modal_verified.get('class') or proposal.get('class','')
                if wrote_code and str(value.get('code') or '').strip()!=str(proposal['code']) and str(modal_verified.get('code') or '').strip()==str(proposal['code']):
                    value['code']=proposal['code']
                if 'code' not in value:
                    value['code']=proposal.get('code') if wrote_code else old.get('code','')
                if 'score' not in value:
                    value['score']=old.get('score','')
        else:
            value=self.browser.verify(file,proposal)

        if wrote_sbd and str(value.get('sbd') or '').strip()!=str(proposal['sbd']):
            raise Review('Sau khi lưu, SBD chưa khớp Excel; chưa xác minh được lưu.')
        if wrote_code:
            if str(value.get('code') or '').strip()!=str(proposal['code']):
                raise Review('Sau khi lưu, Mã đề chưa khớp mã đề xuất; chưa xác minh được lưu.')
        else:
            if str(value.get('code') or '').strip()!=str(old.get('code') or '').strip():
                raise Fatal('Mã đề thay đổi bất thường sau lưu SBD! Dừng để kiểm tra, không sửa phiếu khác.')
            if str(value.get('score') or '').strip()!=str(old.get('score') or '').strip():
                raise Fatal('Điểm thay đổi bất thường sau lưu SBD! Dừng để kiểm tra, không sửa phiếu khác.')
        if wrote_sbd and proposal.get('name') and (norm(value.get('name'))!=norm(proposal['name']) or not same_class(value.get('class'),proposal['class'])):
            raise Review('SBD đã lưu nhưng họ tên/lớp VietSchool chưa đối chiếu được với Excel.')
        return value

    def _verify_only_sbd(self,file,proposal,old,modal_verified=None):
        return self._verify_fields(file,proposal,old,modal_verified=modal_verified,wrote_sbd=True,wrote_code=False)

    def _unassigned_sbds(self, old, webrows):
        assigned = {
            str(r.get('sbd') or '').strip()
            for r in (webrows or ())
            if r.get('file') != old.get('file') and not blank(r.get('name')) and str(r.get('sbd') or '').strip()
        }
        return {
            str(st.get('sbd') or '').strip()
            for st in (self.official_roster or ())
            if str(st.get('sbd') or '').strip() and str(st.get('sbd') or '').strip() not in assigned
        }

    def _candidate_students_for_sheet(self, old, bubbles, webrows):
        assigned = {
            str(r.get('sbd') or '').strip()
            for r in webrows
            if r.get('file') != old.get('file') and not blank(r.get('name')) and str(r.get('sbd') or '').strip()
        }
        old_sbd = str(old.get('sbd') or '').strip()
        mask = bubbles.get('masks', {}).get('sbd', []) if isinstance(bubbles, dict) else []
        candidates = []
        for st in self.official_roster:
            s = str(st.get('sbd') or '').strip()
            if not s or (s in assigned and s != old_sbd):
                continue
            if len(mask) == 8 and sum(bool(d) for d in mask) >= 3:
                def_m, comp_m, _ = _bubble_agreement_count(s, mask)
                if comp_m >= 5 or def_m >= 4:
                    candidates.append(st)
            else:
                candidates.append(st)
        return candidates[:80] if len(candidates) <= 80 else []

    def _read_handwriting_for_sheet(self, r, full, top, bubbles, webrows, ai_reader, is_primary_ai):
        unassigned = self._unassigned_sbds(r.old, webrows)
        try:
            ocr_hw = read_handwriting_ocr(top, self.official_roster, bubbles=bubbles, unassigned_sbds=unassigned)
        except TypeError:
            ocr_hw = read_handwriting_ocr(top, self.official_roster)
        if ocr_hw:
            self.event('handwriting_ocr', ocr_hw)
            dec, _, _ = sbd_evidence(r.old, bubbles, self.official_roster, webrows, handwriting=ocr_hw) if self.official_roster else ('ok', None, '')
            if dec in ('write', 'ok'):
                return ocr_hw

        if ai_reader is None:
            return ocr_hw

        if not getattr(self, '_hw_model_checked', False):
            selected = ai_reader.test()
            self._hw_model_checked = True
            self.emit('model', selected)

        cands = self._candidate_students_for_sheet(r.old, bubbles, webrows) if self.official_roster else []
        if hasattr(ai_reader, 'read_handwriting_for_sbd') and not is_primary_ai:
            raw_hw = ai_reader.read_handwriting_for_sbd(full, top, candidates=cands)
            self.control()
            hw = extract_handwriting(raw_hw, None, official_roster=self.official_roster)
            self.event('handwriting_read_fast', {'raw': raw_hw, 'extracted': hw})
            return hw or ocr_hw

        img1, img2 = (ai_reader.prepare_images(full, top) if hasattr(ai_reader, 'prepare_images') else (full, top))
        a = ai_reader.read(img1); self.control()
        b = ai_reader.read(img2); self.control()
        hw = extract_handwriting(a, b, official_roster=self.official_roster)
        self.event('handwriting_read', {'first': a, 'second': b, 'extracted': hw})
        return hw or ocr_hw

    def run(self):
        try:
            self.control()
            self.sbd_advice = {}
            if not self.official_roster and self.exam_catalog is None:
                raise Fatal('Phải tải Excel HS chính thức có SBD, Họ và tên, Lớp (hoặc file Excel Mã đề). Không tự đoán từ HS thiếu bài.')
            students={(x['sbd'],norm(x['name']),class_key(x['class'])) for x in self.official_roster}
            if self.exam_catalog is not None:
                total_codes = len(self.exam_catalog.all_codes)
                self.emit('log',f'CHẾ ĐỘ SỬA SBD & MÃ ĐỀ: đã nạp {len(students)} HS Excel và {total_codes} mã đề mẫu.')
            else:
                self.emit('log',f'CHỈ SỬA SBD: đã nạp {len(students)} học sinh từ Excel. Mã đề và điểm giữ nguyên.')
            if hasattr(self.browser,'close_any_viewer'):
                self.browser.close_any_viewer()
            webrows=self.browser.scan()
            matches,summary=select_sbd_anomalies(
                webrows,self.official_roster,include_excel_mismatches=self.audit_all,
                exam_catalog=self.exam_catalog,selected_subject=self.selected_subject)
            if self.max_records:matches=matches[:self.max_records]
            self.records=[Record(x['file'],dict(x),list(reasons)) for x,reasons in matches]
            self.event('scan',{'total':len(webrows),'selected':len(matches),
                'skipped_normal':summary['skipped'], 'excel_students':len(students),
                'reasons':summary['by_reason']})
            self.checkpoint();self.report()
            with (self.output/'danh_sach_phieu_can_xem.csv').open('w',newline='',encoding='utf-8-sig') as f:
                writer=csv.writer(f)
                writer.writerow(['Ảnh phiếu','Họ tên VietSchool','Lớp VietSchool','SBD VietSchool','Mã đề VietSchool','Lý do chọn'])
                def safe(v):
                    v=str(v if v is not None else '')
                    return "'"+v if v.startswith(('=','+','-','@')) else v
                for r in self.records:
                    writer.writerow([safe(v) for v in (r.file,r.old.get('name'),r.old.get('class'),
                        r.old.get('sbd'),r.old.get('code'),'; '.join(r.reason))])
            self.emit('log',f'Quét {len(webrows)} phiếu; phát hiện {summary["selected"]} phiếu lỗi SBD/Mã đề. '
                     f'BỎ QUA {summary["skipped"]} phiếu bình thường. '
                     f'Sẽ BẤM XEM đúng {len(matches)} phiếu cần đối chiếu (giữ nguyên vị trí cuộn, không cuộn lại từ đầu trang).')
            if not matches:
                self.emit('log','Không phát hiện phiếu nào thuộc nhóm lỗi SBD/Mã đề. Không mở/sửa phiếu nào.')
            self._hw_model_checked=False
            is_primary_ai = (self.ai is not None and not _is_no_ai(self.ai) and hasattr(self.ai, 'read'))
            fallback_hw_ai = getattr(self.ai, 'handwriting_ai', None) if not is_primary_ai else None
            outage_streak=0
            for i,r in enumerate(self.records,1):
                self.active=r
                self.control()
                if i==1 or i%5==0:self.emit('log',f'Đang xử lý phiếu lỗi {i}/{len(self.records)}: {r.file}')
                try:
                    r.status='Đang mở phiếu';self.checkpoint()
                    self.browser.open(r.file)
                    if hasattr(self.browser,'read_modal_fields'):
                        mf=self.browser.read_modal_fields() or {}
                        if blank(r.old.get('sbd')) and mf.get('sbd'):r.old['sbd']=mf['sbd']
                        if blank(r.old.get('code')) and mf.get('code'):r.old['code']=mf['code']
                        if blank(r.old.get('name')) and mf.get('name'):r.old['name']=mf['name']
                        if blank(r.old.get('class')) and mf.get('class'):r.old['class']=mf['class']

                    full,top=self.browser.image()
                    bubbles=None
                    try:
                        bubbles=read_bubbles(full)
                        self.event('sbd_bubble',{
                            'sbd':bubbles.get('sbd'),
                            'code':bubbles.get('code'),
                            'mask':bubbles.get('masks',{}).get('sbd'),
                            'code_mask':bubbles.get('masks',{}).get('code'),
                        })
                    except Exception as exc:
                        if _is_exc_type(exc, 'Fatal', 'StopRun'):
                            raise
                        self.event('bubble_unavailable',{'reason':short_error(exc)})

                    omr_pat = _expand_old_sbd_pattern(r.old.get('sbd'))
                    if isinstance(bubbles, dict) and len(omr_pat) == 8:
                        b_mask = bubbles.get('masks', {}).get('sbd', [])
                        if len(b_mask) == 8 and sum(len(d) == 1 for d in b_mask) < 6:
                            merged_m = [list(d) if d else ([int(c)] if c.isdigit() else []) for d, c in zip(b_mask, omr_pat)]
                            merged_s = ''.join(str(d[0]) if len(d) == 1 else '?' for d in merged_m)
                            bubbles = {**bubbles, 'sbd': merged_s, 'masks': {**bubbles.get('masks', {}), 'sbd': merged_m}}

                    handwriting=None
                    if is_primary_ai:
                        handwriting=self._read_handwriting_for_sheet(r,full,top,bubbles,webrows,self.ai,True)
                        outage_streak=0

                    if self.official_roster:
                        sbd_dec,sbd_p,sbd_why=sbd_evidence(r.old,bubbles,self.official_roster,webrows,handwriting=handwriting)
                        if sbd_dec=='review' and not is_primary_ai:
                            handwriting=self._read_handwriting_for_sheet(r,full,top,bubbles,webrows,fallback_hw_ai,False)
                            if handwriting:
                                sbd_dec,sbd_p,sbd_why=sbd_evidence(r.old,bubbles,self.official_roster,webrows,handwriting=handwriting)
                    else:
                        sbd_dec='ok'
                        sbd_p=None
                        sbd_why='Giữ nguyên SBD.'

                    ranked_sbd = rank_sbd_candidates(r.old, bubbles, self.official_roster, webrows=webrows, handwriting=handwriting, limit=5) if self.official_roster else []
                    eff_b_sbd = str((bubbles or {}).get('sbd') or _expand_old_sbd_pattern(r.old.get('sbd')) or '')
                    eff_mask = (bubbles or {}).get('masks', {}).get('sbd', []) if isinstance(bubbles, dict) else []
                    matched_cols_str = ''
                    if sbd_p and sbd_p.get('sbd') and len(eff_mask) == 8:
                        dm, _, _ = _bubble_agreement_count(sbd_p['sbd'], eff_mask)
                        matched_cols_str = f'{dm}/8'
                    elif ranked_sbd:
                        matched_cols_str = f"{ranked_sbd[0]['matched_cols']}/8"
                    self.sbd_advice[r.file] = {
                        'bubble': eff_b_sbd,
                        'hw_sbd': str((handwriting or {}).get('sbd') or (handwriting or {}).get('sbd_pattern') or ''),
                        'hw_name': str((handwriting or {}).get('name') or ''),
                        'hw_class': str((handwriting or {}).get('class') or ''),
                        'matched_cols': matched_cols_str,
                        'ranked_text': [f"{c['sbd']} - {c['name']} ({c['class']}) [{c['tag']}]" for c in ranked_sbd],
                    }

                    if self.exam_catalog is not None:
                        code_dec,code_val,code_why,code_hint=code_evidence(
                            r.old,bubbles,self.exam_catalog,webrows,
                            selected_subject=self.selected_subject,
                            handwriting=handwriting,
                            nearest_one_digit=self.nearest_one_digit)
                        if code_dec=='review' and not is_primary_ai and handwriting is None:
                            handwriting=self._read_handwriting_for_sheet(r,full,top,bubbles,webrows,fallback_hw_ai,False)
                            if handwriting:
                                code_dec,code_val,code_why,code_hint=code_evidence(
                                    r.old,bubbles,self.exam_catalog,webrows,
                                    selected_subject=self.selected_subject,
                                    handwriting=handwriting,
                                    nearest_one_digit=self.nearest_one_digit)
                        self.code_advice[r.file]=code_hint
                    else:
                        code_dec='keep'
                        code_val=str(r.old.get('code') or '').strip()
                        code_why=''

                    if sbd_dec=='review' and callable(getattr(self.ai,'prompt_user',None)):
                        user_choice=self.ai.prompt_user(r.old,ranked_sbd,top,str(code_val or r.old.get('code') or '').strip())
                        self.control()
                        if isinstance(user_choice,dict):
                            if user_choice.get('action')=='stop':
                                raise StopRun()
                            if user_choice.get('action')=='apply':
                                chosen_sbd=str(user_choice.get('sbd') or '').strip()
                                matched=[st for st in self.official_roster if str(st.get('sbd') or '').strip()==chosen_sbd]
                                owners={(norm(st['name']),class_key(st['class'])) for st in matched}
                                if len(owners)==1:
                                    st=matched[0]
                                    sbd_dec='write'
                                    sbd_p={'sbd':chosen_sbd,'name':st['name'],'class':st['class'],'code':str(r.old.get('code') or '').strip()}
                                    sbd_why=f"Người dùng xác nhận trực tiếp trên cửa sổ Xem, khớp duy nhất Excel: {chosen_sbd} — {st['name']} ({st['class']})."
                                chosen_code=str(user_choice.get('code') or '').strip()
                                if self.exam_catalog is not None and chosen_code and chosen_code in self.exam_catalog.all_codes:
                                    code_dec='write'
                                    code_val=chosen_code
                                    code_why=f"Người dùng xác nhận Mã đề {chosen_code}."

                    wrote_sbd = (sbd_dec == 'write' and sbd_p is not None)
                    wrote_code = (self.exam_catalog is not None and code_dec == 'write' and bool(code_val))

                    if not wrote_sbd and not wrote_code:
                        notes = [x for x in (sbd_why, code_why) if x]
                        combined_note = ' | '.join(notes)
                        if sbd_dec == 'ok' and code_dec in ('ok', 'keep'):
                            if blank(r.old.get('name')) and self.official_roster:
                                r.status='Cần kiểm tra'
                                r.note=combined_note+' Nhưng VietSchool còn thiếu họ tên; SBD hiện đúng nên không sửa số theo suy đoán.'
                            else:
                                r.status='SBD & Mã đề đã đúng' if self.exam_catalog is not None else 'SBD đã đúng'
                                r.note=combined_note
                        else:
                            r.status='Cần kiểm tra'
                            r.note=combined_note
                            self.event('review',{'reason':r.note})
                        self.browser.close()
                        continue

                    final_sbd = sbd_p['sbd'] if wrote_sbd else str(r.old.get('sbd') or '').strip()
                    final_name = sbd_p['name'] if wrote_sbd else str(r.old.get('name') or '').strip()
                    final_cls = sbd_p['class'] if wrote_sbd else str(r.old.get('class') or '').strip()
                    final_code = str(code_val).strip() if wrote_code else str(r.old.get('code') or '').strip()
                    p = {'sbd': final_sbd, 'code': final_code, 'name': final_name, 'class': final_cls}
                    r.proposal = p

                    self.event('before_write',{
                        'old_sbd':r.old.get('sbd'),'new_sbd':final_sbd,
                        'old_code':r.old.get('code'),'new_code':final_code,
                        'wrote_sbd':wrote_sbd,'wrote_code':wrote_code,
                        'source':'Excel học sinh / Mã đề mẫu + ảnh phiếu'
                    })
                    r.status='Đang lưu SBD & Mã đề' if (wrote_sbd and wrote_code) else ('Đang lưu Mã đề' if wrote_code else 'Đang lưu SBD')
                    self.checkpoint()

                    if wrote_sbd and wrote_code:
                        self.browser.write(p, self.event)
                    elif wrote_code and not wrote_sbd:
                        if hasattr(self.browser,'write_code_only'):
                            self.browser.write_code_only(p, self.event)
                        else:
                            self.browser.write(p, self.event)
                    else:
                        if hasattr(self.browser,'write_sbd_only'):
                            self.browser.write_sbd_only(p, self.event)
                        else:
                            self.browser.write(p, self.event)

                    modal_verified=self.browser.read_modal_fields() if hasattr(self.browser,'read_modal_fields') else None
                    if not modal_verified or (wrote_sbd and not modal_verified.get('sbd')) or (wrote_code and not modal_verified.get('code')):
                        modal_verified={'sbd':p['sbd'],'name':p['name'],'class':p['class'],'code':p['code']}
                    r.status='Đang xác minh SBD';self.checkpoint()
                    r.after=self._verify_fields(r.file,p,r.old,modal_verified=modal_verified,wrote_sbd=wrote_sbd,wrote_code=wrote_code)

                    if wrote_sbd and wrote_code:
                        r.status='Đã xác minh SBD & Mã đề'
                        r.note=f"{sbd_why} | {code_why} Đã lưu và xác minh cả SBD và Mã đề."
                    elif wrote_code:
                        r.status='Đã xác minh Mã đề' if sbd_dec=='ok' else 'Đã sửa Mã đề (cần kiểm tra SBD)'
                        r.note=(f"{code_why} | {sbd_why}" if sbd_dec!='ok' else f"{code_why} Đã lưu và xác minh Mã đề.")
                    else:
                        r.status='Đã xác minh SBD'
                        if self.exam_catalog is None:
                            r.note=sbd_why+' Đã lưu và xác minh; mã đề và điểm không đổi.'
                        else:
                            r.note=f"{sbd_why} | {code_why}"
                    self.event('verified',{'sbd':p['sbd'],'code':p['code'],'wrote_sbd':wrote_sbd,'wrote_code':wrote_code})
                    webrows=[r.after if x['file']==r.file else x for x in webrows]
                except Exception as exc:
                    if _is_exc_type(exc, 'StopRun', 'Fatal'):
                        raise
                    if _is_exc_type(exc, 'TemporaryGeminiUnavailable'):
                        outage_streak+=1
                        if outage_streak>=3:
                            r.status='Cần kiểm tra';r.note=short_error(exc)
                            self.browser.close()
                            raise Fatal('Gemini quá tải liên tiếp trên 3 phiếu. Đã lưu tiến độ và dừng an toàn.')
                    else:
                        outage_streak=0
                    r.status='Cần kiểm tra';r.note=short_error(exc)
                    self.event('review',{'reason':r.note})
                    self.browser.close()
                finally:
                    self.checkpoint();self.report()
            self.active=None
            fixed=sum(r.status.startswith('Đã xác minh') or r.status.startswith('Đã sửa') for r in self.records)
            passed=sum(r.status in ('SBD đã đúng','SBD & Mã đề đã đúng') for r in self.records)
            review=sum(r.status=='Cần kiểm tra' for r in self.records)
            self.event('complete',{'total':len(self.records),'fixed':fixed,'unchanged':passed,'review':review})
            self.emit('log',f'HOÀN TẤT {len(self.records)} phiếu nghi lỗi: {fixed} đã sửa+xác minh; {passed} đã đúng; {review} cần kiểm tra. Báo cáo: {self.output}/bao_cao_sbd.csv & goi_y_sbd.csv')
        except Exception as exc:
            if _is_exc_type(exc, 'StopRun'):
                if self.active and self.active.status.startswith('Đang '):self.active.status='Dừng giữa chừng - cần xác minh'
                self.event('stopped',{})
                self.emit('log','Dừng theo yêu cầu. Xem báo cáo trước khi chạy lại.')
            else:
                if self.active and self.active.status.startswith('Đang '):self.active.status='Chưa xác minh'
                self.event('aborted',{'reason':short_error(exc)})
                self.emit('log','Dừng an toàn: '+short_error(exc))
        finally:
            self.checkpoint();self.report();self.emit('done',str(self.output))


def patch():
    import vietschool_sbd_agent as app
    app.Runner = ExcelSBDRunner
