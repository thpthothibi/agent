# -*- coding: utf-8 -*-
"""Offline optical reader for the printed multiple-choice SBD / exam-code grids,
with adaptive faint-bubble ('tô mờ') recovery and local header/box OCR for
handwritten SBD, Student Name, Class, and Exam Code.
"""
from __future__ import annotations
from io import BytesIO
import math
import os
import re
import subprocess
import tempfile
from statistics import median


def _cluster_1d(samples, tolerance):
    groups = []
    for item in sorted(samples, key=lambda z: z[0]):
        if groups and abs(item[0] - median(v[0] for v in groups[-1])) <= tolerance:
            groups[-1].append(item)
        else:
            groups.append([item])
    return groups


def _best_ten_row_window(yvals, median_radius):
    if len(yvals) < 7:
        return None
    best = None
    max_len = min(10, len(yvals))
    for length in range(max_len, 6, -1):
        for start in range(len(yvals) - length + 1):
            sub = yvals[start:start + length]
            diffs = [b - a for a, b in zip(sub, sub[1:])]
            if len(diffs) < 6:
                continue
            ystep = median(diffs)
            if not (1.5 * median_radius < ystep < 8 * median_radius):
                continue
            regular = sum(abs(d - ystep) < max(5, ystep * 0.24) for d in diffs)
            if regular < max(5, len(diffs) - 1):
                continue
            col_start = median(sub[i] - i * ystep for i in range(min(4, len(sub))))
            score = (len(sub), regular, -col_start)
            if best is None or score > best[0]:
                best = (score, sub, ystep, col_start, len(sub))
        if best is not None:
            break
    if best is None:
        return None
    _, sub, ystep, col_start, support = best
    return {'ys': sub, 'step_y': ystep, 'start': col_start, 'support': support}


def _grid_candidates(circles, width):
    if not circles:
        return []
    median_radius = median(c[2] for c in circles)
    clusters = _cluster_1d([(c[0], c[1], c[2]) for c in circles], max(4, median_radius * 0.78))
    columns = []
    for members in clusters:
        ys = _cluster_1d([(p[1], p[0], p[2]) for p in members], max(4, median_radius * .82))
        if len(ys) < 7:
            continue
        yvals = [median(p[0] for p in group) for group in ys]
        win = _best_ten_row_window(yvals, median_radius)
        if not win:
            continue
        columns.append({'x': median(m[0] for m in members), **win})
    columns.sort(key=lambda x: x['x'])
    results = []
    for total_cols in (12, 11):
        code_cols = total_cols - 8
        for start in range(len(columns) - total_cols + 1):
            group = columns[start:start + total_cols]
            dxs = [group[i + 1]['x'] - group[i]['x'] for i in list(range(7)) + list(range(8, 8 + code_cols - 1))]
            dx = median(dxs)
            if not (1.35 * median_radius < dx < 8.5 * median_radius):
                continue
            if any(abs(d - dx) > dx * .25 for d in dxs):
                continue
            gap = group[8]['x'] - group[7]['x']
            if not (1.25 * dx < gap < 5.5 * dx):
                continue
            steps = [g['step_y'] for g in group]
            dy = median(steps)
            if any(abs(d - dy) > dy * .26 for d in steps):
                continue
            starts = [g['start'] for g in group]
            top = median(starts)
            if max(abs(t - top) for t in starts) > dy * 2.2:
                continue
            support = sum(g['support'] for g in group)
            results.append((support, top, [g['x'] for g in group], dy, dx))
        if results:
            return sorted(results, key=lambda x: (-x[0], x[1]))

    for start in range(len(columns) - 7):
        group = columns[start:start + 8]
        dxs = [group[i + 1]['x'] - group[i]['x'] for i in range(7)]
        dx = median(dxs)
        if not (1.35 * median_radius < dx < 8.5 * median_radius):
            continue
        if any(abs(d - dx) > dx * .25 for d in dxs):
            continue
        steps = [g['step_y'] for g in group]
        dy = median(steps)
        if any(abs(d - dy) > dy * .26 for d in steps):
            continue
        starts = [g['start'] for g in group]
        top = median(starts)
        if max(abs(t - top) for t in starts) > dy * 2.2:
            continue
        support = sum(g['support'] for g in group)
        results.append((support, top, [g['x'] for g in group], dy, dx))
    return sorted(results, key=lambda x: (-x[0], x[1]))


def _decode_region(bgr):
    import cv2
    import numpy as np
    h0, w0 = bgr.shape[:2]
    max_side = max(w0, h0)
    scale = min(1.0, 1900 / max_side)
    if scale < 1:
        bgr = cv2.resize(bgr, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    b_ch, g_ch, r_ch = cv2.split(bgr)
    max_ch = np.maximum(np.maximum(b_ch, g_ch), r_ch)
    min_ch = np.minimum(np.minimum(b_ch, g_ch), r_ch)
    sat_diff = max_ch.astype(np.int16) - min_ch.astype(np.int16)
    effective_gray = np.where((max_ch > 165) & (sat_diff > 75), max_ch, gray)
    blurred = cv2.GaussianBlur(gray, (5, 5), 1.2)
    h, w = gray.shape
    radius_low = max(3, round(w * .0036))
    radius_high = max(radius_low + 4, round(w * .0135))

    candidates = []
    coords = []
    for p1, p2 in ((96, 24), (80, 19), (70, 16)):
        circles = cv2.HoughCircles(blurred, cv2.HOUGH_GRADIENT, dp=1.25,
            minDist=max(10, round(w * .010)), param1=p1, param2=p2,
            minRadius=radius_low, maxRadius=radius_high)
        if circles is None:
            continue
        coords = [(float(x), float(y), float(r)) for x, y, r in circles[0]]
        candidates = _grid_candidates(coords, w)
        if candidates:
            break
    if not coords:
        raise ValueError('Không xác định được các vòng tròn ô tô trong ảnh')
    if not candidates:
        raise ValueError('Chưa định vị chính xác bảng 8 cột SBD và 4 cột mã đề')

    support, top, xs, dy, dx = candidates[0]
    relevant = [(cy, cx) for cx, cy, cr in coords if any(abs(cx - x) < max(6, dx * .25) for x in xs)]
    trials = sorted(set(round(y) for y, x in relevant))
    def grid_fit(t):
        matches = 0
        for k in range(10):
            target = t + k * dy
            matches += sum(1 for x in xs if any(abs(cy - target) < max(4, dy * .18) and abs(cx - x) < max(5, dx * .22) for cy, cx in relevant))
        return matches
    top = max(trials, key=lambda y: (grid_fit(y), -y)) if trials else top
    min_required = int(6.5 * len(xs)) if len(xs) < 12 else 82
    if grid_fit(top) < min_required:
        raise ValueError('Không đủ 10 hàng và 12 cột ô tô để đọc an toàn')
    r = median(c[2] for c in coords)
    mask_radius = max(2, round(r * .52))
    offsets = [(u, v) for v in range(-mask_radius, mask_radius + 1) for u in range(-mask_radius, mask_radius + 1)
               if u * u + v * v <= mask_radius * mask_radius]
    digit_sets = []; scores = []
    for col, x in enumerate(xs):
        percents = []
        faint_percents = []
        means = []
        for row in range(10):
            y = top + row * dy
            pixels = [int(effective_gray[round(y) + v, round(x) + u]) for u, v in offsets
                if 0 <= round(y) + v < h and 0 <= round(x) + u < w]
            if pixels:
                frac = sum(z < 150 for z in pixels) / len(pixels)
                faint_frac = sum(z < 190 for z in pixels) / len(pixels)
                mean_val = sum(pixels) / len(pixels)
            else:
                frac = 0.0; faint_frac = 0.0; mean_val = 255.0
            percents.append(frac)
            faint_percents.append(faint_frac)
            means.append(mean_val)

        strong = [k for k, p in enumerate(percents) if p >= .58]
        weak = [k for k, p in enumerate(percents) if .20 <= p < .58]
        col_scores = [round(p, 2) for p in percents]

        if strong or len(weak) > 1:
            digit_sets.append(strong + weak)
        elif len(weak) == 1:
            k = weak[0]
            second_p = sorted(percents, reverse=True)[1]
            if percents[k] >= second_p + 0.08:
                digit_sets.append([k])
                col_scores[k] = max(col_scores[k], 0.58)
            else:
                digit_sets.append([])
        else:
            col_bg = median(sorted(means)[2:])
            drops = [max(0.0, col_bg - m) for m in means]
            best_k = max(range(10), key=lambda idx: drops[idx])
            sorted_drops = sorted(drops, reverse=True)
            second_drop = sorted_drops[1]
            second_faint = sorted(faint_percents, reverse=True)[1]
            if ((drops[best_k] >= 13.0 and drops[best_k] >= second_drop * 1.55 and drops[best_k] - second_drop >= 6.5)
                    or (faint_percents[best_k] >= 0.36 and faint_percents[best_k] >= second_faint + 0.18 and drops[best_k] >= 9.0)):
                digit_sets.append([best_k])
                col_scores[best_k] = max(col_scores[best_k], 0.58)
            else:
                digit_sets.append([])
        scores.append(col_scores)

    while len(digit_sets) < 12:
        digit_sets.append([])
        scores.append([0.0] * 10)
    masks = {'sbd': digit_sets[:8], 'code': digit_sets[8:12]}
    fields = {k: ''.join(str(ds[0]) if len(ds) == 1 and scores[(0 if k == 'sbd' else 8) + i][ds[0]] >= .58 else '?'
                         for i, ds in enumerate(masks[k])) for k in ('sbd', 'code')}
    return {'sbd': fields['sbd'], 'code': fields['code'], 'masks': masks,
        'confidence': {'sbd': sum(ch.isdigit() for ch in fields['sbd']),
                       'code': sum(ch.isdigit() for ch in fields['code'])},
        'details': {'width': w, 'height': h, 'top': round(top), 'step': round(dy, 1),
                    'dx': round(dx, 1), 'x': [round(t) for t in xs],
                    'support': support, 'scores': scores},
        'method': 'Vòng tròn tô: đọc cục bộ (hỗ trợ nhận diện ô tô mờ)'}


def _decode(raw):
    import cv2
    import numpy as np
    arr = np.frombuffer(raw, dtype=np.uint8)
    bgr = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if bgr is None:
        raise ValueError('Không mở được ảnh phiếu')
    h0, w0 = bgr.shape[:2]
    if h0 > w0 * 1.12:
        for ratio in (0.48, 0.58):
            try:
                header_crop = bgr[:int(h0 * ratio), :]
                return _decode_region(header_crop)
            except Exception:
                pass
    return _decode_region(bgr)


def read_bubbles(raw: bytes):
    return _decode(raw)


def consistent_with_mask(value,mask,min_known=0,max_unknown=99):
    if not value or len(value)!=len(mask) or not value.isdigit():return False
    definite=sum(len(d)==1 for d in mask)
    unknown=sum(len(d)!=1 for d in mask)
    return definite>=min_known and unknown<=max_unknown and all(not d or int(v) in d for v,d in zip(value,mask))


def match_official(bubbles, roster, old, used_sbd=()):
    mask=bubbles.get('masks',{}).get('sbd',[])
    code=bubbles.get('code','')
    if not code.isdigit() or len(code)!=4 or len(mask)!=8:return None
    known=sum(ch.isdigit() for ch in bubbles.get('sbd',''))
    if known<6 or 8-known>2:return None
    candidates=[]
    for st in roster:
        s=str(st.get('sbd','')).strip();nm=str(st.get('name','')).strip();cl=str(st.get('class','')).strip()
        if not nm or not cl or s in used_sbd or not consistent_with_mask(s,mask,min_known=6,max_unknown=2):continue
        if old.get('name') and old['name'].strip() and _clean_name(old['name'])!=_clean_name(nm):continue
        if old.get('class') and old['class'].strip() and not _same_class(old['class'],cl):continue
        candidates.append({'sbd':s,'code':code,'name':nm,'class':cl})
    distinct={(s['sbd'], _clean_name(s['name']),s['class']) for s in candidates}
    return candidates[0] if len(distinct)==1 else None


def _clean_name(v):
    import unicodedata
    s=unicodedata.normalize('NFD',str(v).upper()).replace('Đ','D')
    return ' '.join(''.join(c for c in s if unicodedata.category(c)!='Mn').split())


def _same_class(a,b):
    def k(x):
        match=re.fullmatch(r'(\d{2})([A-Z]+)0*(\d+)',_clean_name(x).replace(' ',''))
        return tuple(match.groups()[:2])+(int(match[3]),) if match else _clean_name(x)
    return bool(a and b and k(a)==k(b))


def _strip_box_borders(gray_crop):
    import cv2
    import numpy as np
    if gray_crop is None or gray_crop.size == 0:
        return gray_crop
    up = cv2.resize(gray_crop, None, fx=2.4, fy=2.4, interpolation=cv2.INTER_CUBIC)
    h, w = up.shape[:2]
    inv = cv2.adaptiveThreshold(up, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                cv2.THRESH_BINARY_INV, 25, 10)
    h_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(25, w // 5), 1))
    v_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(18, round(h * 0.72))))
    h_lines = cv2.morphologyEx(inv, cv2.MORPH_OPEN, h_kernel)
    v_lines = cv2.morphologyEx(inv, cv2.MORPH_OPEN, v_kernel)
    borders = cv2.dilate(cv2.bitwise_or(h_lines, v_lines), np.ones((2, 2), np.uint8), iterations=1)
    cleaned_inv = cv2.bitwise_and(inv, cv2.bitwise_not(borders))
    return 255 - cleaned_inv


def prepare_ocr_header_image(raw_top: bytes, bubbles=None):
    try:
        import cv2
        import numpy as np
        arr = np.frombuffer(raw_top, dtype=np.uint8)
        bgr = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if bgr is None:
            return raw_top
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape[:2]
        details = (bubbles or {}).get('details') if isinstance(bubbles, dict) else None

        strips = []
        if details and details.get('x') and details.get('width'):
            scale_x = w / float(details['width'])
            xs = [x * scale_x for x in details['x']]
            top = float(details.get('top', h * 0.25)) * scale_x
            dy = float(details.get('step', max(14.0, h * 0.035))) * scale_x
            dx = float(details.get('dx') or (xs[1] - xs[0] if len(xs) > 1 else dy)) * scale_x

            masked = gray.copy()
            gx1 = max(0, int(round(xs[0] - 0.65 * dx)))
            gy1 = max(0, int(round(top - 0.52 * dy)))
            gy2 = min(h, int(round(top + 9.65 * dy)))
            masked[gy1:gy2, gx1:w] = 255
            header_bottom = min(h, max(gy2, int(h * 0.48)))
            info_crop = masked[:header_bottom, :]
            strips.append(info_crop)

            by1 = max(0, int(round(top - 2.55 * dy)))
            by2 = max(by1 + 8, int(round(top - 0.52 * dy)))
            sx1 = max(0, int(round(xs[0] - 0.62 * dx)))
            sx2 = min(w, int(round(xs[min(7, len(xs) - 1)] + 0.62 * dx)))
            if by2 > by1 + 6 and sx2 > sx1 + 20:
                sbd_box_strip = _strip_box_borders(gray[by1:by2, sx1:sx2])
                strips.append(sbd_box_strip)

            if len(xs) >= 11:
                cx1 = max(0, int(round(xs[8] - 0.62 * dx)))
                cx2 = min(w, int(round(xs[-1] + 0.62 * dx)))
                if by2 > by1 + 6 and cx2 > cx1 + 12:
                    code_box_strip = _strip_box_borders(gray[by1:by2, cx1:cx2])
                    strips.append(code_box_strip)
        else:
            masked = gray[:max(180, int(h * 0.45)), :].copy()
            mh, mw = masked.shape[:2]
            masked[int(mh * 0.36):, int(mw * 0.45):] = 255
            strips.append(masked)

        target_w = max(s.shape[1] for s in strips) if strips else w
        padded_strips = []
        for s in strips:
            sh, sw = s.shape[:2]
            pad_right = max(0, target_w - sw)
            padded = cv2.copyMakeBorder(s, 12, 12, 12, pad_right + 12, cv2.BORDER_CONSTANT, value=255)
            padded_strips.append(padded)

        composite = np.vstack(padded_strips) if len(padded_strips) > 1 else padded_strips[0]
        ok, enc = cv2.imencode('.png', composite)
        return enc.tobytes() if ok else raw_top
    except Exception:
        return raw_top


def _normalize_ocr_digits(token: str) -> str:
    cleaned = re.sub(r'(?i)\b(so\s*bao\s*danh|sbd|ma\s*de\s*thi|ma\s*de|lop|phong\s*thi|phong)\b\s*[:\.]?', ' ', token)
    cleaned = re.sub(r'[|\-_/.]+', ' ', cleaned)
    table = str.maketrans({
        'O': '0', 'o': '0', 'Q': '0',
        'I': '1', 'l': '1', '!': '1',
        'Z': '2', 'z': '2',
        'S': '5', '$': '5',
        'G': '6',
        'B': '8',
    })
    return cleaned.translate(table)


def parse_ocr_handwriting_text(text: str, official_roster=(), unassigned_sbds=None):
    if not text or not text.strip():
        return None
    norm_text = _clean_name(text)
    if not norm_text:
        return None

    found_name = ''
    found_cls = ''
    found_sbd = ''
    found_sbd_pattern = ''
    found_code = ''

    roster_sbds = {str(st.get('sbd') or '').strip() for st in (official_roster or ()) if st.get('sbd')}
    unassigned_set = set(unassigned_sbds) if unassigned_sbds is not None else roster_sbds

    sbd_candidates = []
    for m in re.finditer(r'(?<!\d)(\d{8})(?!\d)', norm_text):
        sbd_candidates.append(m.group(1))

    for raw_line in text.splitlines():
        cleaned_line = _normalize_ocr_digits(raw_line.strip())
        for m in re.finditer(r'(?<!\d)([0-9](?:[\s]*[0-9]){4,7})(?!\d)', cleaned_line):
            digits_only = re.sub(r'[^0-9]', '', m.group(1))
            if len(digits_only) == 8:
                sbd_candidates.append(digits_only)
            elif 5 <= len(digits_only) <= 7 and digits_only.startswith(('10', '11', '12', '20', '0')):
                if not found_sbd_pattern or len(digits_only) > len(found_sbd_pattern):
                    found_sbd_pattern = digits_only

    if sbd_candidates:
        in_unassigned = [s for s in sbd_candidates if s in unassigned_set]
        in_roster = [s for s in sbd_candidates if s in roster_sbds]
        if len(set(in_unassigned)) == 1:
            found_sbd = in_unassigned[0]
        elif len(set(in_roster)) == 1:
            found_sbd = in_roster[0]
        elif len(set(sbd_candidates)) == 1:
            found_sbd = sbd_candidates[0]
        else:
            pref = [s for s in sbd_candidates if s.startswith(('10', '11', '12', '20', '0'))]
            if len(set(pref)) == 1:
                found_sbd = pref[0]

    if official_roster:
        matched_names = []
        for st in official_roster:
            nm = str(st.get('name') or '').strip()
            cn = _clean_name(nm)
            if len(cn.split()) >= 2 and re.search(r'(^|\b)' + re.escape(cn) + r'(\b|$)', norm_text):
                matched_names.append((st, nm))
        distinct_norms = {_clean_name(nm) for _, nm in matched_names}
        if len(distinct_norms) == 1:
            found_name = matched_names[0][1]
        elif not matched_names:
            ocr_words = set(norm_text.split())
            token_hits = []
            for st in official_roster:
                nm = str(st.get('name') or '').strip()
                cn = _clean_name(nm)
                toks = cn.split()
                if len(toks) < 3:
                    continue
                if toks[-1] in ocr_words and sum(t in ocr_words for t in toks) >= max(3, len(toks) - 1):
                    pat = r'\b' + r'\b.{0,18}\b'.join(re.escape(t) for t in toks if t in ocr_words) + r'\b'
                    if re.search(pat, norm_text):
                        is_unassigned = 1 if str(st.get('sbd') or '').strip() in unassigned_set else 0
                        token_hits.append((is_unassigned, sum(t in ocr_words for t in toks), nm))
            if token_hits:
                token_hits.sort(key=lambda x: (x[0], x[1]), reverse=True)
                top_score = (token_hits[0][0], token_hits[0][1])
                top_names = {_clean_name(x[2]): x[2] for x in token_hits if (x[0], x[1]) == top_score}
                if len(top_names) == 1:
                    found_name = next(iter(top_names.values()))

    cls_matches = re.findall(r'\b(1[012]\s*[A-Z]\s*0?\d{1,2})\b', norm_text)
    if len(set(c.replace(' ', '') for c in cls_matches)) == 1:
        found_cls = cls_matches[0].replace(' ', '')

    for m in re.finditer(r'(?<!\d)(\d{4})(?!\d)', norm_text):
        c4 = m.group(1)
        if found_sbd and c4 in found_sbd:
            continue
        if c4 not in ('2024', '2025', '2026', '2027'):
            found_code = c4
            break

    if found_name or found_sbd or found_sbd_pattern or found_code:
        return {
            'name': found_name,
            'class': found_cls,
            'sbd': found_sbd,
            'sbd_pattern': found_sbd_pattern,
            'sbd_bubbles': '',
            'code': found_code,
            'source': 'local-ocr',
        }
    return None


def read_handwriting_ocr(raw_top: bytes, official_roster=(), bubbles=None, unassigned_sbds=None):
    if not raw_top or len(raw_top) < 256 or not (raw_top.startswith(b'\x89PNG') or raw_top.startswith(b'\xff\xd8')):
        return None
    prepared_bytes = prepare_ocr_header_image(raw_top, bubbles=bubbles)
    text = ''
    try:
        import pytesseract
        from PIL import Image
        im = Image.open(BytesIO(prepared_bytes))
        text = pytesseract.image_to_string(im, lang='vie+eng', timeout=3) or ''
    except Exception:
        pass
    if not text and os.name == 'nt':
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tf:
                tf.write(prepared_bytes)
                tmp_path = tf.name
            ps_script = (
                "Add-Type -AssemblyName System.Runtime.WindowsRuntime; "
                "$null = [Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]; "
                "$null = [Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]; "
                "$null = [Windows.Graphics.Imaging.BitmapDecoder,Windows.Foundation,ContentType=WindowsRuntime]; "
                "$null = [Windows.Globalization.Language,Windows.Foundation,ContentType=WindowsRuntime]; "
                "function Await($op,$t){$m=[System.WindowsRuntimeSystemExtensions].GetMethods()|?{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.IsGenericMethod}|select -First 1; $task=$m.MakeGenericMethod($t).Invoke($null,@($op)); $task.Wait(2500)|Out-Null; return $task.Result}; "
                f"$f=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync('{tmp_path}')) ([Windows.Storage.StorageFile]); "
                "$s=Await ($f.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream]); "
                "$d=Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($s)) ([Windows.Graphics.Imaging.BitmapDecoder]); "
                "$b=Await ($d.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap]); "
                "$e=$null; "
                "foreach($tag in @('vi-VN','vi','en-US')){"
                "  try{$lang=New-Object Windows.Globalization.Language($tag); if([Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($lang)){$e=[Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang); if($e){break}}}catch{}"
                "}; "
                "if(-not $e){$e=[Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()}; "
                "if($e){$r=Await ($e.RecognizeAsync($b)) ([Windows.Media.Ocr.OcrResult]); foreach($line in $r.Lines){Write-Output $line.Text}}"
            )
            res = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', ps_script],
                capture_output=True, text=True, timeout=4, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            if res.returncode == 0 and res.stdout:
                text = res.stdout.strip()
        except Exception:
            pass
        finally:
            if tmp_path:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
    return parse_ocr_handwriting_text(text, official_roster=official_roster, unassigned_sbds=unassigned_sbds)
