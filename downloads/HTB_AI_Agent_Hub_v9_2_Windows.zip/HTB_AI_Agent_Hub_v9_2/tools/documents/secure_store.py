"""Windows DPAPI: secrets are encrypted for the current Windows user."""
import ctypes
import json
import os
from pathlib import Path

def data_dir():
    base=Path(os.environ.get('LOCALAPPDATA',Path.home()/'.local'/'share'))
    result=base/'HTB_VanBanAgent'
    result.mkdir(parents=True,exist_ok=True)
    return result

def _crypt(payload,decrypt=False):
    if os.name!='nt':
        raise RuntimeError('Lưu thông tin đăng nhập có bảo vệ chỉ hỗ trợ Windows. Có thể nhập tài khoản cho từng phiên.')
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_ubyte))]
    buf=ctypes.create_string_buffer(payload)
    source=Blob(len(payload),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)))
    output=Blob()
    crypt=ctypes.WinDLL('crypt32',use_last_error=True)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.LocalFree.argtypes=[ctypes.c_void_p]
    kernel.LocalFree.restype=ctypes.c_void_p
    if decrypt:
        fn=crypt.CryptUnprotectData
        fn.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
        fn.restype=wintypes.BOOL
        ok=fn(ctypes.byref(source),None,None,None,None,1,ctypes.byref(output))
    else:
        fn=crypt.CryptProtectData
        fn.argtypes=[ctypes.POINTER(Blob),wintypes.LPCWSTR,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
        fn.restype=wintypes.BOOL
        ok=fn(ctypes.byref(source),'HTB VanBanAgent',None,None,None,1,ctypes.byref(output))
    if not ok:raise RuntimeError('Windows không giải mã/mã hóa được tài khoản. Hãy lưu lại trên đúng tài khoản Windows này.')
    try:return ctypes.string_at(output.pbData,output.cbData)
    finally:kernel.LocalFree(ctypes.cast(output.pbData,ctypes.c_void_p))

class CredentialStore:
    def __init__(self,folder=None):self.path=Path(folder or data_dir())/'login.dpapi'
    def exists(self):return self.path.is_file()
    def save(self,username,password):
        if not username or not password:raise RuntimeError('Nhập đủ tên đăng nhập và mật khẩu trước khi lưu.')
        payload=json.dumps({'username':username,'password':password},ensure_ascii=False).encode('utf-8')
        encrypted=_crypt(payload)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        temp=self.path.with_suffix('.tmp')
        temp.write_bytes(encrypted)
        temp.replace(self.path)
    def load(self):
        if not self.exists():return None
        try:
            data=json.loads(_crypt(self.path.read_bytes(),True).decode('utf-8'))
            if not isinstance(data.get('username'),str) or not isinstance(data.get('password'),str):raise ValueError()
            return data
        except (ValueError,UnicodeError):raise RuntimeError('Thông tin đăng nhập lưu trên máy bị lỗi. Xóa và lưu lại.')
    def forget(self):self.path.unlink(missing_ok=True)
