import hashlib
import json
import sqlite3
import tempfile
import uuid
from datetime import date,datetime
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from repository import identity,fingerprint
from analysis_engine import hint,STATES
from excel_export import HEADERS
from workspace_repo import TASK_STATES,PRIORITIES,now

def create_backup(repo,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        db_path=Path(tmp)/'documents.sqlite3'
        src=repo.connect();dest=sqlite3.connect(db_path)
        try:src.backup(dest)
        finally:dest.close();src.close()
        raw=db_path.read_bytes()
        manifest={'format':'htb-vanban-backup','version':3,'created':now(),
          'sha256':hashlib.sha256(raw).hexdigest(),'documents':len(repo.all()),'tasks':len(repo.tasks()),
          'contains_credentials':False}
        stage=path.with_suffix('.tmp.zip')
        with ZipFile(stage,'w',ZIP_DEFLATED) as z:
            z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
            z.writestr('documents.sqlite3',raw)
        stage.replace(path)
    repo.audit('Tạo bản sao lưu','',path.name)
    return manifest

def _text(value,max_length=2000000):
    if not isinstance(value,str) or len(value)>max_length:raise RuntimeError('Bản sao lưu có trường dữ liệu không hợp lệ/quá dài.')
    return value

def read_backup(path):
    path=Path(path)
    if path.stat().st_size>100000000:raise RuntimeError('Bản sao lưu vượt giới hạn 100 MB.')
    try:
        with ZipFile(path) as z:
            if sorted(z.namelist())!=['documents.sqlite3','manifest.json']:raise RuntimeError('Chọn đúng ZIP sao lưu v3 của tool.')
            if z.getinfo('manifest.json').file_size>10000 or z.getinfo('documents.sqlite3').file_size>150000000:raise RuntimeError('Nội dung sao lưu vượt giới hạn.')
            manifest=json.loads(z.read('manifest.json'))
            raw=z.read('documents.sqlite3')
        if manifest.get('format')!='htb-vanban-backup' or manifest.get('version')!=3:raise RuntimeError('Định dạng sao lưu chưa hỗ trợ.')
        if manifest.get('sha256')!=hashlib.sha256(raw).hexdigest():raise RuntimeError('Bản sao lưu không khớp mã kiểm tra, có thể bị hỏng.')
        with tempfile.TemporaryDirectory() as tmp:
            db_path=Path(tmp)/'restore.sqlite3';db_path.write_bytes(raw)
            db=sqlite3.connect(db_path.as_uri()+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row
            try:
                if db.execute('PRAGMA quick_check').fetchone()[0]!='ok':raise RuntimeError('Cơ sở dữ liệu sao lưu bị lỗi.')
                tables={r['name'] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if not {'documents','tasks','history','attachments'}<=tables:raise RuntimeError('Thiếu bảng dữ liệu bắt buộc.')
                docs=[dict(r) for r in db.execute('SELECT * FROM documents LIMIT 100001')]
                tasks=[dict(r) for r in db.execute('SELECT * FROM tasks LIMIT 100001')]
                history=[dict(r) for r in db.execute('SELECT * FROM history LIMIT 200001')]
                attachments=[dict(r) for r in db.execute('SELECT * FROM attachments LIMIT 100001')]
            finally:db.close()
        if len(docs)>100000 or len(tasks)>100000 or len(history)>200000 or len(attachments)>100000:raise RuntimeError('Bản sao lưu vượt số bản ghi hỗ trợ.')
        doc_ids=set()
        for r in docs:
            source=json.loads(_text(r['source']))
            if not isinstance(source,dict) or any(not isinstance(source.get(k,''),str) for k in HEADERS):raise RuntimeError('Dữ liệu nguồn trong sao lưu không hợp lệ.')
            if r['id']!=identity(source):raise RuntimeError('Mã hồ sơ sao lưu không khớp dữ liệu nguồn.')
            if r['local_status'] not in STATES:raise RuntimeError('Trạng thái văn bản trong sao lưu không hợp lệ.')
            if r['due_confirmed']:date.fromisoformat(r['due_confirmed'])
            for k in ['id','first_seen','last_seen','owner','notes','ai_draft','content']:_text(r[k])
            r['fingerprint']=fingerprint(source);r['analysis']=json.dumps(hint(source),ensure_ascii=False)
            doc_ids.add(r['id'])
        for t in tasks:
            if t['doc_id'] not in doc_ids or t['status'] not in TASK_STATES or t['priority'] not in PRIORITIES:raise RuntimeError('Đầu việc trong bản sao lưu không hợp lệ.')
            uuid.UUID(hex=t['id'])
            for k in ['title','owner','due','notes','created_at','updated_at','completed_at']:_text(t[k])
            if not t['title'].strip():raise RuntimeError('Đầu việc không có tiêu đề.')
            if t['due']:date.fromisoformat(t['due'])
            if t['completed_at']:datetime.fromisoformat(t['completed_at'])
        for h in history:
            if h['doc_id'] not in doc_ids:raise RuntimeError('Lịch sử không có hồ sơ nguồn.')
            _text(h['time']);source=json.loads(_text(h['source']))
            if not isinstance(source,dict):raise RuntimeError('Lịch sử nguồn bị lỗi.')
        for a in attachments:
            if a['doc_id'] not in doc_ids:raise RuntimeError('Tệp nội dung thiếu hồ sơ nguồn.')
            for k in ['id','filename','sha256','content','imported_at']:_text(a[k])
        return {'manifest':manifest,'documents':docs,'tasks':tasks,'history':history,'attachments':attachments}
    except RuntimeError:raise
    except Exception:raise RuntimeError('Không đọc được bản sao lưu; chưa thay đổi dữ liệu hiện tại.')

def restore_merge(repo,path):
    payload=read_backup(path) # validate everything before writing
    added_docs=set();added_tasks=0;skipped=0
    with repo.connect() as db:
        for r in payload['documents']:
            if db.execute('SELECT 1 FROM documents WHERE id=?',(r['id'],)).fetchone():
                skipped+=1;continue
            columns=['id','source','fingerprint','analysis','first_seen','last_seen','local_status','owner','due_confirmed','notes','ai_draft','content']
            db.execute('INSERT INTO documents('+','.join(columns)+') VALUES('+','.join('?' for _ in columns)+')',[r[k] for k in columns])
            added_docs.add(r['id'])
        for t in payload['tasks']:
            if db.execute('SELECT 1 FROM tasks WHERE id=?',(t['id'],)).fetchone():continue
            columns=['id','doc_id','title','owner','due','status','priority','notes','created_at','updated_at','completed_at']
            db.execute('INSERT INTO tasks('+','.join(columns)+') VALUES('+','.join('?' for _ in columns)+')',[t[k] for k in columns]);added_tasks+=1
        for h in payload['history']:
            if h['doc_id'] in added_docs:db.execute('INSERT INTO history VALUES(?,?,?)',(h['doc_id'],h['time'],h['source']))
        for a in payload['attachments']:
            # Keep current consolidated text for existing documents untouched.
            if a['doc_id'] in added_docs:
                db.execute('INSERT OR IGNORE INTO attachments VALUES(?,?,?,?,?,?)',[a[k] for k in ['id','doc_id','filename','sha256','content','imported_at']])
        db.execute('INSERT INTO audit(time,action,target,detail) VALUES(?,?,?,?)',(now(),'Khôi phục bổ sung','',f'{len(added_docs)} văn bản; {added_tasks} đầu việc'))
    return {'Văn bản được thêm':len(added_docs),'Đầu việc được thêm':added_tasks,'Hồ sơ đã có được giữ nguyên':skipped}
