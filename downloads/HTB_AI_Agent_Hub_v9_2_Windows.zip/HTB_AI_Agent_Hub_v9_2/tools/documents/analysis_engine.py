"""Explainable local hints. Hints do not confirm facts not present in the source."""
import re
import unicodedata
from datetime import date,datetime
from collections import Counter

RULES={
 'CNTT – Chuyển đổi số':['công nghệ thông tin','chuyển đổi số','học bạ số','ký số','trí tuệ nhân tạo','cơ sở dữ liệu','số hóa'],
 'Chuyên môn – Kiểm tra':['kiểm tra','thi tốt nghiệp','chuyên môn','dạy học','chương trình','tuyển sinh','học sinh giỏi'],
 'Tổ chức – Nhân sự':['tuyển dụng','cán bộ','viên chức','nhân sự','bổ nhiệm','biên chế','vị trí việc làm'],
 'Tài chính – Cơ sở vật chất':['kinh phí','tài chính','học phí','ngân sách','mua sắm','cơ sở vật chất','tài sản'],
 'Học sinh – An toàn':['bạo lực học đường','xâm hại','an toàn','y tế','bảo hiểm','phòng chống','phòng, chống','an ninh'],
 'Thi đua – Khen thưởng':['thi đua','khen thưởng','giải thưởng','võ trường toản'],
 'Hội họp – Tập huấn':['giấy mời','hội nghị','hội thảo','tập huấn','bồi dưỡng','cuộc họp'],
}
STATES=['Chưa lập việc','Cần xem xét','Đang thực hiện','Hoàn thành','Không phát sinh việc']

def normalize(s):
    return ''.join(c for c in unicodedata.normalize('NFD',s.lower().replace('đ','d')) if not unicodedata.combining(c))

def hint(row):
    text=row.get('Trích yếu','')
    lowered=text.casefold()
    categories=[name for name,words in RULES.items() if any(w in lowered for w in words)]
    urgent='Chưa xác định'
    if re.search(r'\bhỏa tốc\b',lowered):urgent='Có từ khóa hỏa tốc — cần kiểm tra'
    elif re.search(r'\bkhẩn\b',lowered):urgent='Có từ khóa khẩn — cần kiểm tra'
    # Require an explicit deadline marker; a meeting date alone is not a due date.
    dates=[]
    for match in re.finditer(r'(?:hạn(?:\s+(?:chót|cuối|gửi|nộp))?|chậm nhất|trước ngày|trước|hoàn thành trước)\s*(?::|là)?\s*(?:ngày\s*)?(\d{1,2}[/.\-]\d{1,2}[/.\-]\d{4})',lowered):
        try:
            d=datetime.strptime(re.sub(r'[.\-]','/',match.group(1)),'%d/%m/%Y').date()
            dates.append(d.isoformat())
        except ValueError:pass
    due=dates[0] if len(set(dates))==1 else ''
    if dates:
        reason='Có dấu hiệu hạn trong trích yếu; cần xác nhận trong văn bản gốc.' if due else 'Có nhiều mốc hạn, cần chọn thủ công.'
    else:reason='Chưa thấy hạn rõ trong trích yếu; cần xem văn bản gốc.'
    if re.search(r'\b(báo cáo|gửi|nộp|triển khai|thực hiện|rà soát|đăng ký|tham dự)\b',lowered):
        task='Xem văn bản gốc và xác nhận nhiệm vụ, người phụ trách, hạn xử lý.'
    else:task='Đọc, phân loại và xác định có cần lập công việc.'
    return {'category':'; '.join(categories) or 'Chưa phân loại','priority':urgent,'due_hint':due,'due_reason':reason,'suggested_task':task}

def due_label(item,today=None):
    today=today or date.today()
    if item.get('local_status') in ['Hoàn thành','Không phát sinh việc']:return 'Đã khép việc nội bộ'
    value=item.get('due_confirmed','')
    if not value:return 'Chưa xác nhận hạn'
    try:d=date.fromisoformat(value)
    except ValueError:return 'Ngày không hợp lệ'
    diff=(d-today).days
    if diff<0:return 'Quá hạn nội bộ'
    if diff==0:return 'Đến hạn hôm nay'
    if diff<=3:return 'Sắp hạn (3 ngày)'
    return 'Còn hạn'

def related(query,rows,limit=10):
    tokens=set(re.findall(r'\w+',normalize(query)))
    if not tokens:return []
    output=[]
    for row in rows:
        hay=normalize(' '.join(row.get(k,'') for k in ['Số ký hiệu','Trích yếu','Đơn vị ban hành']))
        words=set(re.findall(r'\w+',hay))
        score=len(tokens & words)/len(tokens)
        if normalize(query) in hay:score+=1
        if score:output.append((score,row))
    output.sort(key=lambda x:(-x[0],x[1].get('Số ký hiệu','')))
    return [r for _,r in output[:limit]]

def summary(rows):
    stats=Counter(due_label(r) for r in rows)
    return {'Tổng văn bản':len(rows),'Cần xem xét/đang làm':sum(r.get('local_status') in ['Cần xem xét','Đang thực hiện'] for r in rows),
      'Quá hạn nội bộ':stats['Quá hạn nội bộ'],'Hạn hôm nay':stats['Đến hạn hôm nay'],'Sắp hạn 3 ngày':stats['Sắp hạn (3 ngày)']}
