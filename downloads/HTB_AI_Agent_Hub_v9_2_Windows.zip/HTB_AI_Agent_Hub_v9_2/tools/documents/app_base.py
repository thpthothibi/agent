import os
import queue
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from datetime import datetime,date
from pathlib import Path
from secure_store import data_dir,CredentialStore
from workspace_repo import WorkspaceRepository as Repository
from analysis_engine import STATES,due_label,related,summary,normalize
from browser_agent import parse_date
from v3_worker import V3Worker as AgentWorker
from local_ai import MODES

ROOT=Path(__file__).resolve().parent

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('HTB • AI Agent văn bản v3.0')
        self.geometry('1240x880');self.minsize(1040,760)
        self.configure(bg='#eef4fc')
        style=ttk.Style(self);style.theme_use('clam')
        style.configure('TFrame',background='#eef4fc')
        style.configure('TLabel',background='#eef4fc',font=('Segoe UI',10))
        style.configure('TCheckbutton',background='#eef4fc',font=('Segoe UI',10))
        style.configure('TButton',font=('Segoe UI',10),padding=7)
        style.configure('TNotebook.Tab',font=('Segoe UI',10,'bold'),padding=(16,9))
        style.configure('Treeview',rowheight=29,font=('Segoe UI',10))
        style.configure('Treeview.Heading',font=('Segoe UI',10,'bold'))
        self.repo=Repository(data_dir()/'documents.sqlite3')
        self.events=queue.Queue();self.worker=AgentWorker(self.events,self.repo)
        self.worker.start();self.busy=False;self.buttons=[];self.selected_id=None;self.rows=[];self.visible_ids=[]
        outer=ttk.Frame(self,padding=16);outer.pack(fill='both',expand=True)
        ttk.Label(outer,text='AI AGENT VĂN BẢN • THPT HỒ THỊ BI',font=('Segoe UI',19,'bold'),foreground='#1954a5').pack(anchor='w')
        ttk.Label(outer,text='Thu thập • Phân loại • Theo dõi công việc • Dự thảo với AI cục bộ').pack(anchor='w',pady=(4,12))
        self.notebook=ttk.Notebook(outer);self.notebook.pack(fill='both',expand=True)
        self.collect_tab=ttk.Frame(self.notebook,padding=18)
        self.archive_tab=ttk.Frame(self.notebook,padding=12)
        self.ai_tab=ttk.Frame(self.notebook,padding=16)
        self.log_tab=ttk.Frame(self.notebook,padding=12)
        for label,tab in [('1. Đăng nhập & thu thập',self.collect_tab),('2. Kho & công việc',self.archive_tab),('3. Trợ lý AI',self.ai_tab),('4. Nhật ký',self.log_tab)]:self.notebook.add(tab,text=label)
        self.make_collect();self.make_archive();self.make_ai();self.make_log()
        self.status=tk.StringVar(value='Sẵn sàng')
        ttk.Label(outer,textvariable=self.status,foreground='#1954a5').pack(anchor='w',pady=(10,0))
        self.refresh();self.after(150,self.poll);self.protocol('WM_DELETE_WINDOW',self.close)

    def button(self,parent,text,command,**pack):
        b=ttk.Button(parent,text=text,command=command);b.pack(**pack);self.buttons.append(b);return b

    def field(self,parent,label,variable,width=24,show=None):
        frame=ttk.Frame(parent);frame.pack(side='left',padx=(0,14),fill='x')
        ttk.Label(frame,text=label).pack(anchor='w')
        e=ttk.Entry(frame,textvariable=variable,width=width,show=show or '')
        e.pack(fill='x');return e

    def make_collect(self):
        tab=self.collect_tab
        ttk.Label(tab,text='Đăng nhập tự động',font=('Segoe UI',13,'bold'),foreground='#1954a5').pack(anchor='w')
        self.username=tk.StringVar();self.password=tk.StringVar();self.auto_login=tk.BooleanVar(value=True)
        row=ttk.Frame(tab);row.pack(fill='x',pady=8)
        self.field(row,'Tên truy cập',self.username,32)
        self.field(row,'Mật khẩu (ẩn)',self.password,32,show='•')
        ttk.Checkbutton(row,text='Tự động đăng nhập',variable=self.auto_login).pack(side='left',padx=5,pady=(18,0))
        row=ttk.Frame(tab);row.pack(fill='x',pady=4)
        self.button(row,'Lưu đăng nhập trên Windows',lambda:self.send('save_login'),side='left',padx=(0,8))
        self.button(row,'Xóa đăng nhập đã lưu',lambda:self.send('forget_login'),side='left')
        saved='Đã có thông tin đăng nhập được bảo vệ trên máy.' if CredentialStore().exists() else 'Chưa lưu tài khoản. Nhập để dùng cho phiên này hoặc bấm Lưu đăng nhập.'
        self.login_note=tk.StringVar(value=saved)
        ttk.Label(tab,textvariable=self.login_note,foreground='#54718f').pack(anchor='w',pady=5)
        ttk.Label(tab,text='Mật khẩu chỉ được lưu khi bấm Lưu; Windows bảo vệ theo tài khoản đang sử dụng. OTP/CAPTCHA cần thao tác trực tiếp.').pack(anchor='w',pady=(0,14))
        ttk.Separator(tab).pack(fill='x',pady=4)
        self.current=tk.BooleanVar(value=False);self.all_search=tk.BooleanVar(value=True)
        ttk.Checkbutton(tab,text='Dùng danh sách Đã xử lý đang mở (bỏ chọn menu)',variable=self.current).pack(anchor='w',pady=(12,5))
        ttk.Checkbutton(tab,text='Bấm Tìm kiếm trống để tìm ngoài phạm vi 30 ngày mặc định',variable=self.all_search).pack(anchor='w')
        ttk.Label(tab,text='Bộ lọc dưới áp dụng sau khi tải; điều kiện năm/ngày trên website vẫn có hiệu lực.',foreground='#805b00').pack(anchor='w',pady=(12,2))
        row=ttk.Frame(tab);row.pack(fill='x',pady=6)
        self.start_date=tk.StringVar();self.end_date=tk.StringVar();self.keyword=tk.StringVar();self.date_field=tk.StringVar(value='Ngày đến')
        self.field(row,'Từ ngày (dd/mm/yyyy)',self.start_date,19);self.field(row,'Đến ngày',self.end_date,19)
        box=ttk.Frame(row);box.pack(side='left',padx=(0,14))
        ttk.Label(box,text='Lọc theo').pack(anchor='w');ttk.Combobox(box,textvariable=self.date_field,values=['Ngày đến','Ngày văn bản'],state='readonly',width=18).pack()
        self.field(row,'Từ khóa trích yếu',self.keyword,32)
        row=ttk.Frame(tab);row.pack(fill='x',pady=7)
        ttk.Label(row,text='Thư mục kết quả:').pack(side='left')
        self.folder=tk.StringVar(value=str(ROOT/'Ket_qua'))
        ttk.Entry(row,textvariable=self.folder).pack(side='left',fill='x',expand=True,padx=9)
        ttk.Button(row,text='Chọn…',command=self.choose_folder).pack(side='left')
        row=ttk.Frame(tab);row.pack(fill='x',pady=7)
        self.max_pages=tk.StringVar(value='500');self.next_css=tk.StringVar()
        self.field(row,'Giới hạn số trang',self.max_pages,14)
        self.field(row,'CSS nút Trang sau — để trống để tự nhận',self.next_css,65)
        bar=ttk.Frame(tab);bar.pack(fill='x',pady=16)
        self.button(bar,'1. Mở trang & đăng nhập',lambda:self.send('open'),side='left',padx=(0,9))
        self.button(bar,'2. Tổng hợp → phân tích → Excel',lambda:self.send('collect'),side='left',padx=(0,9))
        self.button(bar,'Xuất lại lượt vừa lấy',lambda:self.send('export'),side='left',padx=(0,9))
        ttk.Button(bar,text='Dừng',command=self.worker.stop_flag.set).pack(side='left')
        row=ttk.Frame(tab);row.pack(fill='x',pady=4)
        self.button(row,'Nạp JSON của v1/v2',self.import_json,side='left',padx=(0,8))
        ttk.Button(row,text='Mở thư mục kết quả',command=self.open_folder).pack(side='left')
        ttk.Label(tab,text='Mỗi trang được lưu JSON. Kết quả được thêm vào kho nội bộ để tìm kiếm và theo dõi lâu dài.\nTool không sửa trạng thái, chuyển xử lý hoặc gửi văn bản trên website.',foreground='#54718f').pack(anchor='w',pady=15)

    def make_archive(self):
        tab=self.archive_tab
        self.dashboard=tk.StringVar()
        ttk.Label(tab,textvariable=self.dashboard,font=('Segoe UI',11,'bold'),foreground='#1954a5').pack(anchor='w',pady=(0,9))
        row=ttk.Frame(tab);row.pack(fill='x')
        self.search=tk.StringVar();self.state_filter=tk.StringVar(value='Tất cả trạng thái');self.category_filter=tk.StringVar(value='Tất cả nhóm');self.due_filter=tk.StringVar(value='Tất cả hạn')
        ttk.Entry(row,textvariable=self.search,width=32).pack(side='left',padx=(0,7))
        self.cat_box=ttk.Combobox(row,textvariable=self.category_filter,values=['Tất cả nhóm'],width=26,state='readonly');self.cat_box.pack(side='left',padx=(0,7))
        ttk.Combobox(row,textvariable=self.state_filter,values=['Tất cả trạng thái']+STATES,width=23,state='readonly').pack(side='left',padx=(0,7))
        ttk.Combobox(row,textvariable=self.due_filter,values=['Tất cả hạn','Quá hạn nội bộ','Đến hạn hôm nay','Sắp hạn (3 ngày)','Chưa xác nhận hạn','Đã khép việc nội bộ','Còn hạn'],width=23,state='readonly').pack(side='left',padx=(0,7))
        ttk.Button(row,text='Lọc',command=self.refresh).pack(side='left')
        self.search.trace_add('write',lambda *args:self.refresh())
        for var in [self.state_filter,self.category_filter,self.due_filter]:var.trace_add('write',lambda *args:self.refresh())
        grid=ttk.Frame(tab);grid.pack(fill='both',expand=True,pady=9)
        columns=('num','date','subject','group','status','due')
        self.tree=ttk.Treeview(grid,columns=columns,show='headings',selectmode='extended',height=9)
        for key,title,width in zip(columns,['Số ký hiệu','Ngày VB','Trích yếu','Nhóm gợi ý','Trạng thái nội bộ','Hạn xác nhận'],[170,95,350,200,145,115]):
            self.tree.heading(key,text=title);self.tree.column(key,width=width,minwidth=75)
        ys=ttk.Scrollbar(grid,orient='vertical',command=self.tree.yview);xs=ttk.Scrollbar(grid,orient='horizontal',command=self.tree.xview)
        self.tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set)
        self.tree.grid(row=0,column=0,sticky='nsew');ys.grid(row=0,column=1,sticky='ns');xs.grid(row=1,column=0,sticky='ew')
        grid.rowconfigure(0,weight=1);grid.columnconfigure(0,weight=1)
        self.tree.bind('<<TreeviewSelect>>',self.select_document)
        self.detail=tk.Text(tab,height=5,wrap='word',font=('Segoe UI',10),state='disabled');self.detail.pack(fill='x',pady=(0,7))
        row=ttk.Frame(tab);row.pack(fill='x')
        self.local_status=tk.StringVar(value=STATES[0]);self.owner=tk.StringVar();self.due=tk.StringVar()
        box=ttk.Frame(row);box.pack(side='left',padx=(0,12))
        ttk.Label(box,text='Trạng thái công việc nội bộ').pack(anchor='w')
        ttk.Combobox(box,textvariable=self.local_status,values=STATES,state='readonly',width=24).pack()
        self.field(row,'Người phụ trách (nội bộ)',self.owner,28);self.field(row,'Hạn đã xác nhận (dd/mm/yyyy)',self.due,28)
        ttk.Label(tab,text='Ghi chú công việc:').pack(anchor='w',pady=(6,1))
        self.notes=tk.Text(tab,height=3,wrap='word',font=('Segoe UI',10));self.notes.pack(fill='x')
        row=ttk.Frame(tab);row.pack(fill='x',pady=(9,0))
        self.button(row,'Lưu công việc nội bộ',self.save_task,side='left',padx=(0,7))
        self.button(row,'Tìm văn bản liên quan',self.find_related,side='left',padx=(0,7))
        self.button(row,'Xem lịch sử thay đổi',self.show_history,side='left',padx=(0,7))
        self.button(row,'Xuất các dòng đang lọc',self.export_archive,side='left')

    def make_ai(self):
        tab=self.ai_tab
        ttk.Label(tab,text='AI cục bộ — phân tích và dự thảo',font=('Segoe UI',13,'bold'),foreground='#1954a5').pack(anchor='w')
        ttk.Label(tab,text='Chọn 1–10 dòng tại Kho & công việc, sau đó chọn chức năng. AI dùng Ollama chạy trên máy này.').pack(anchor='w',pady=7)
        row=ttk.Frame(tab);row.pack(fill='x',pady=5)
        self.model=tk.StringVar();self.mode=tk.StringVar(value=next(iter(MODES)))
        ttk.Label(row,text='Mô hình đã cài:').pack(side='left')
        self.model_box=ttk.Combobox(row,textvariable=self.model,width=28);self.model_box.pack(side='left',padx=8)
        self.button(row,'Đọc danh sách mô hình',lambda:self.send('models'),side='left',padx=(0,15))
        ttk.Combobox(row,textvariable=self.mode,values=list(MODES),state='readonly',width=32).pack(side='left')
        row=ttk.Frame(tab);row.pack(fill='x',pady=9)
        self.button(row,'Nạp nội dung PDF / Word / TXT',self.read_file,side='left',padx=(0,8))
        self.button(row,'Phân tích / tạo dự thảo',self.ai_generate,side='left',padx=(0,8))
        ttk.Button(row,text='Lưu dự thảo TXT',command=self.save_draft).pack(side='left')
        ttk.Label(tab,text='Chưa nạp tệp: AI chỉ có trích yếu. Nạp tệp không tự chạy AI. PDF scan cần OCR trước.\nMỗi nguồn dùng tối đa 12.000 ký tự đầu; AI không tự sửa dữ liệu hay gửi văn bản.',foreground='#805b00').pack(anchor='w',pady=7)
        self.ai_output=tk.Text(tab,wrap='word',font=('Segoe UI',11),padx=12,pady=12)
        self.ai_output.pack(fill='both',expand=True)
        self.ai_output.insert('1.0','DỰ THẢO — CẦN RÀ SOÁT\n\n1. Cài và mở Ollama nếu muốn dùng AI cục bộ.\n2. Cài một mô hình phù hợp với cấu hình máy.\n3. Bấm Đọc danh sách mô hình, chọn mô hình đã cài.\n4. Chọn văn bản trong kho và chạy chức năng AI.\n\nThu thập, kho văn bản, gợi ý theo từ khóa, theo dõi việc và xuất Excel hoạt động khi chưa có Ollama.')

    def make_log(self):
        self.logbox=tk.Text(self.log_tab,wrap='word',font=('Consolas',10),state='disabled')
        self.logbox.pack(fill='both',expand=True)

    def options(self):
        start=parse_date(self.start_date.get());end=parse_date(self.end_date.get())
        if start and end and start>end:raise ValueError('Ngày bắt đầu phải trước hoặc bằng ngày kết thúc.')
        count=int(self.max_pages.get())
        if not 1<=count<=10000:raise ValueError('Giới hạn trang từ 1 đến 10000.')
        if not self.folder.get().strip():raise ValueError('Chọn thư mục kết quả.')
        return {'current':self.current.get(),'all_search':self.all_search.get(),'start':self.start_date.get().strip(),'end':self.end_date.get().strip(),
          'date_field':self.date_field.get(),'keyword':self.keyword.get().strip(),'folder':self.folder.get().strip(),'max_pages':count,'next_css':self.next_css.get().strip()}

    def send(self,cmd,extra=None):
        if self.busy:return
        try:
            args=self.options() if cmd in ['collect','export'] else {}
            if cmd in ['open','collect','save_login']:
                args.update(username=self.username.get().strip(),password=self.password.get(),auto_login=self.auto_login.get())
            if cmd=='save_login' and (not args['username'] or not args['password']):raise ValueError('Nhập đủ tên truy cập và mật khẩu trước khi lưu.')
            if extra:args.update(extra)
        except ValueError as e:
            self.error(str(e) if 'does not match' not in str(e) else 'Nhập ngày theo dd/mm/yyyy.');return
        self.busy=True
        for b in self.buttons:b.configure(state='disabled')
        self.status.set('Đang thực hiện… xem tab Nhật ký để theo dõi.')
        self.worker.commands.put((cmd,args))
        if cmd in ['open','collect','save_login','forget_login']:self.password.set('')
        if cmd=='forget_login':self.username.set('')

    def choose_folder(self):
        path=filedialog.askdirectory()
        if path:self.folder.set(path)
    def open_folder(self):
        path=Path(self.folder.get());path.mkdir(parents=True,exist_ok=True)
        if os.name=='nt':os.startfile(str(path))

    def import_json(self):
        path=filedialog.askopenfilename(filetypes=[('Kết quả JSON','*.json')])
        if path:self.send('import_json',{'path':path})

    def refresh(self):
        if not hasattr(self,'tree'):return
        selected=self.tree.selection()
        self.rows=self.repo.all()
        stats=summary(self.rows)
        self.dashboard.set('  •  '.join(f'{k}: {v}' for k,v in stats.items()))
        categories=sorted({c.strip() for r in self.rows for c in r['analysis']['category'].split(';')})
        self.cat_box.configure(values=['Tất cả nhóm']+categories)
        query=normalize(self.search.get().strip())
        self.tree.delete(*self.tree.get_children());self.visible_ids=[]
        for r in self.rows:
            if query and query not in normalize(' '.join(r.get(k,'') for k in ['Số ký hiệu','Trích yếu','Đơn vị ban hành','notes','owner','content'])):continue
            if self.category_filter.get()!='Tất cả nhóm' and self.category_filter.get() not in [c.strip() for c in r['analysis']['category'].split(';')]:continue
            if self.state_filter.get()!='Tất cả trạng thái' and r['local_status']!=self.state_filter.get():continue
            if self.due_filter.get()!='Tất cả hạn' and due_label(r)!=self.due_filter.get():continue
            self.visible_ids.append(r['id'])
            shown_due=date.fromisoformat(r['due_confirmed']).strftime('%d/%m/%Y') if r['due_confirmed'] else ''
            self.tree.insert('', 'end',iid=r['id'],values=[r.get('Số ký hiệu',''),r.get('Ngày văn bản',''),r.get('Trích yếu',''),r['analysis']['category'],r['local_status'],shown_due])
        keep=[i for i in selected if self.tree.exists(i)]
        if keep:self.tree.selection_set(keep)
        else:self.selected_id=None

    def select_document(self,event=None):
        selection=self.tree.selection()
        if not selection:return
        doc=self.repo.get(selection[0])
        if doc is None:return
        self.selected_id=doc['id'];a=doc['analysis']
        due=date.fromisoformat(a['due_hint']).strftime('%d/%m/%Y') if a['due_hint'] else 'Chưa xác định'
        text=(f'{doc.get("Số ký hiệu","")} • {doc.get("Ngày văn bản","")} • {doc.get("Đơn vị ban hành","")}\n'
          f'{doc.get("Trích yếu","")}\nGợi ý: {a["category"]} | {a["priority"]}\n'
          f'Hạn gợi ý (chưa xác nhận): {due}. {a["due_reason"]}\n'
          f'{due_label(doc)} • Nội dung tệp đã nạp: {len(doc["content"]):,} ký tự • Đang chọn {len(selection)} văn bản.')
        self.detail.configure(state='normal');self.detail.delete('1.0','end');self.detail.insert('1.0',text);self.detail.configure(state='disabled')
        self.local_status.set(doc['local_status']);self.owner.set(doc['owner'])
        self.due.set(date.fromisoformat(doc['due_confirmed']).strftime('%d/%m/%Y') if doc['due_confirmed'] else '')
        self.notes.delete('1.0','end');self.notes.insert('1.0',doc['notes'])
        if len(selection)==1 and doc['ai_draft']:
            self.ai_output.delete('1.0','end');self.ai_output.insert('1.0',doc['ai_draft'])

    def one_selection(self):
        ids=self.tree.selection()
        if len(ids)!=1:self.error('Chọn đúng một văn bản trong tab Kho & công việc.');return None
        return ids[0]

    def save_task(self):
        doc_id=self.one_selection()
        if not doc_id:return
        try:
            d=parse_date(self.due.get())
            self.repo.update(doc_id,local_status=self.local_status.get(),owner=self.owner.get().strip(),due_confirmed=d.isoformat() if d else '',notes=self.notes.get('1.0','end-1c'))
            self.refresh();self.status.set('Đã lưu công việc trong tool. Hạn xác nhận được dùng để cảnh báo tại đây.')
        except ValueError:self.error('Nhập hạn theo dd/mm/yyyy, hoặc để trống nếu chưa xác nhận.')

    def find_related(self):
        doc_id=self.one_selection()
        if not doc_id:return
        row=self.repo.get(doc_id)
        matches=related(row.get('Trích yếu',''),[r for r in self.rows if r['id']!=doc_id],10)
        text='Tìm theo độ trùng từ khóa của trích yếu; không xác định quan hệ pháp lý.\n\n'
        text+='\n\n'.join(r.get('Số ký hiệu','')+' • '+r.get('Ngày văn bản','')+'\n'+r.get('Trích yếu','') for r in matches) or 'Chưa thấy văn bản liên quan.'
        self.show_text('Văn bản có từ khóa liên quan',text)

    def show_history(self):
        doc_id=self.one_selection()
        if not doc_id:return
        history=self.repo.history(doc_id)
        text='\n\n'.join(x['time']+'\n'+x['source'].get('Trích yếu','') for x in history)
        self.show_text('Phiên bản nguồn trước đây',text or 'Chưa có thay đổi nội dung nguồn được ghi nhận cho hồ sơ này.')

    def show_text(self,title,text):
        window=tk.Toplevel(self);window.title(title);window.geometry('880x540')
        box=tk.Text(window,wrap='word',font=('Segoe UI',11),padx=12,pady=12);box.pack(fill='both',expand=True);box.insert('1.0',text);box.configure(state='disabled')

    def export_archive(self):
        if not self.visible_ids:self.error('Không có dòng nào trong bộ lọc hiện tại.');return
        self.send('archive_export',{'folder':self.folder.get().strip(),'start':'','end':'','date_field':'Ngày đến','keyword':'','ids':list(self.visible_ids)})

    def read_file(self):
        doc_id=self.one_selection()
        if not doc_id:return
        path=filedialog.askopenfilename(filetypes=[('Nội dung văn bản','*.pdf *.docx *.txt *.md')])
        if path:self.send('read_file',{'id':doc_id,'path':path})

    def ai_generate(self):
        ids=list(self.tree.selection())
        if not ids:self.error('Chọn văn bản trong tab Kho & công việc trước.');return
        self.send('ai',{'ids':ids,'model':self.model.get(),'mode':self.mode.get()})

    def save_draft(self):
        content=self.ai_output.get('1.0','end-1c')
        if not content.strip():return
        path=filedialog.asksaveasfilename(defaultextension='.txt',initialfile='Du_thao_van_ban.txt',filetypes=[('Văn bản UTF-8','*.txt')])
        if path:
            try:Path(path).write_text(content,encoding='utf-8-sig');self.status.set('Đã lưu dự thảo TXT.')
            except OSError:self.error('Không ghi được tệp. Chọn thư mục khác.')

    def error(self,text):messagebox.showerror('Cần kiểm tra',text)

    def poll(self):
        while not self.events.empty():
            kind,data=self.events.get()
            if kind=='log':
                self.logbox.configure(state='normal');self.logbox.insert('end',f'[{datetime.now():%H:%M:%S}] {data}\n');self.logbox.see('end');self.logbox.configure(state='disabled')
            elif kind=='progress':self.status.set(f'Đã đọc {data[0]} trang • {data[1]} văn bản')
            elif kind=='refresh':self.refresh()
            elif kind=='models':
                self.model_box.configure(values=data)
                if data:self.model.set(data[0])
                self.status.set(f'Tìm thấy {len(data)} mô hình cục bộ.' if data else 'Ollama chưa có mô hình. Cài mô hình rồi đọc lại danh sách.')
            elif kind=='ai_result':
                self.ai_output.delete('1.0','end');self.ai_output.insert('1.0',data);self.status.set('Đã tạo dự thảo. Rà soát nội dung và nguồn trước khi sử dụng.')
            elif kind=='saved':
                self.status.set(f'Đã xuất {data[2]} văn bản • {data[1]}')
                messagebox.showinfo('Đã xuất Excel',f'{data[1]}\n\n{data[0]}\n\nKiểm tra sheet Thông tin lần chạy trước khi dùng báo cáo.')
            elif kind=='error':self.status.set('Cần kiểm tra • xem Nhật ký');self.error(data)
            elif hasattr(self,'handle_event') and self.handle_event(kind,data):pass
            elif kind=='idle':
                self.busy=False
                for b in self.buttons:b.configure(state='normal')
                self.login_note.set('Có thông tin đăng nhập được bảo vệ trên máy.' if CredentialStore().exists() else 'Chưa lưu tài khoản. Có thể nhập cho phiên này hoặc đăng nhập trực tiếp trên trình duyệt.')
        self.after(150,self.poll)

    def close(self):
        self.worker.stop_flag.set();self.worker.commands.put(('quit',{}));self.password.set('');self.destroy()


