# HTB AI Agent văn bản v3.0

Nâng cấp tiếp từ v2, giữ đăng nhập tự động, thu thập Quản lý văn bản đến → Đã xử lý, kho văn bản, phân loại gợi ý, theo dõi hồ sơ và AI Ollama cục bộ. Bổ sung quản lý nhiều đầu việc, báo cáo theo kỳ, mẫu cột Excel, nạp nhiều tệp có đối chiếu, sao lưu/khôi phục và nhật ký nội bộ.

## Cài đặt / cập nhật

1. Đóng bản tool đang chạy. Giải nén ZIP v3 vào thư mục mới có quyền ghi.
2. Nếu chưa có: cài Python 3.11+ và Python Launcher, bật Add Python to PATH.
3. Chạy **CAI_DAT.bat**, sau đó **CHAY_TOOL.bat**.

Kho và thông tin đăng nhập được giữ ở `%LOCALAPPDATA%\HTB_VanBanAgent`, nên v3 đọc lại dữ liệu v2 khi cùng tài khoản Windows. Các bảng mới được tạo bổ sung, không xóa bảng cũ. Trước khi cập nhật, nên đóng tool rồi sao chép tệp `documents.sqlite3` ra một nơi an toàn. Không mở đồng thời nhiều phiên v2/v3 khi chỉnh dữ liệu.

Bản này vẫn là mã nguồn Python, chưa phải EXE độc lập. Không có tài khoản, mật khẩu hay dữ liệu thật đóng gói sẵn. Hướng dẫn các tính năng nền có trong **HUONG_DAN_TINH_NANG_NEN_V2.md**; những thay đổi v3 dưới đây được ưu tiên nếu có khác biệt.

## 1. Quản lý nhiều đầu việc cho một văn bản

1. Chọn một văn bản tại **Kho & công việc**.
2. Mở tab **Đầu việc**, bấm **Tạo từ văn bản đang chọn**. Cũng có thể chọn văn bản nguồn trực tiếp từ danh sách.
3. Nhập công việc, người phụ trách, hạn đã xác nhận `dd/mm/yyyy`, ưu tiên, trạng thái và ghi chú/kết quả.
4. Bấm **Lưu đầu việc**. Có thể lặp lại để tạo nhiều đầu việc cho cùng một văn bản.
5. Chọn một việc trong bảng để sửa; bấm **Đánh dấu hoàn thành** để ghi thời điểm hoàn thành.

Trạng thái: Chưa làm, Đang làm, Hoàn thành, Tạm dừng, Hủy. Việc hoàn thành/hủy không cảnh báo quá hạn. Tạm dừng vẫn cảnh báo theo hạn đã đặt. Bỏ trống hạn nếu chưa xác nhận, không tự dùng hạn do AI gợi ý.

Cảnh báo quá hạn/hôm nay/sắp hạn được hiển thị trong bảng và làm mới khi tool đang mở. Đây không phải thông báo chạy nền khi đóng tool, không gửi email/Zalo và không tạo việc trên website.

**Đầu việc chi tiết tách khỏi trạng thái hồ sơ v2.** Hoàn thành một đầu việc không tự đánh dấu toàn bộ văn bản là hoàn thành; ngược lại, đánh dấu hồ sơ hoàn thành không tự đóng các đầu việc. Bạn có thể có nhiều việc độc lập cho một văn bản.

Có thể tìm theo nội dung, người phụ trách, số ký hiệu, ghi chú; lọc trạng thái/hạn. Bấm tiêu đề cột để sắp xếp. Không xóa hẳn đầu việc; dùng trạng thái Hủy để giữ dấu vết.

## 2. Báo cáo tuần / tháng / khoảng ngày

Mở tab **Báo cáo**, chọn Tuần này (thứ Hai–Chủ nhật), Tháng này, Tháng trước hoặc nhập khoảng ngày tùy chọn. Chọn thống kê văn bản theo Ngày đến hoặc Ngày văn bản.

Báo cáo có các phần riêng:

| Nội dung | Cách tính |
|---|---|
| Văn bản trong kỳ | Ngày đã chọn nằm trong khoảng báo cáo, gồm cả ngày đầu/cuối |
| Việc có hạn trong kỳ | Hạn đã xác nhận nằm trong khoảng, có thể gồm việc đã hoàn thành/hủy |
| Việc hoàn thành trong kỳ | Hiện có trạng thái Hoàn thành, thời điểm đánh dấu hoàn thành trong khoảng |
| Việc đang mở/quá hạn hiện tại | Toàn kho tại thời điểm xuất, không tái hiện tồn đọng lịch sử cuối kỳ |

Khi mở lại một việc đã hoàn thành, thời điểm hoàn thành hiện tại được xóa. Nếu hoàn thành lần nữa, báo cáo tính theo lần mới. Nhật ký vẫn ghi các lần đổi trạng thái.

Tiêu đề và chân trang/ghi chú bạn nhập được ghi trong sheet **Thông tin lần chạy**, không phải đầu trang/chân trang in của Excel. Dữ liệu Excel được giữ dạng bảng để dễ lọc.

## 3. Mẫu cột Excel tùy chọn

Trong tab Báo cáo:

- Chọn cột bên trái, bấm Thêm; chọn cột bên phải để Bỏ, Lên hoặc Xuống.
- Bấm **Lưu mẫu cột** để giữ cấu hình cho lần sau.
- Bấm **Xuất báo cáo kỳ + mẫu cột**. Sheet **Mẫu cột tùy chọn** có các cột và thứ tự bạn chọn, cùng các sheet báo cáo chuẩn.

Đây là cấu hình cột của tool, chưa hỗ trợ tải lên một file mẫu Excel bất kỳ để điền đúng từng ô. Cấu hình mẫu không chứa mật khẩu. Báo cáo được xuất vào thư mục kết quả chọn ở tab đầu.

Excel của lượt thu thập/xuất kho v3 có thêm sheet **Đầu việc chi tiết** (tổng cộng 8 sheet). Báo cáo kỳ có 8 sheet theo nội dung báo cáo, không dùng bố cục 8 sheet của lượt thu thập.

## 4. Nạp nhiều PDF / Word / TXT có đối chiếu

Tại **Tệp & sao lưu**, chọn nhiều tệp. Tool chỉ lập bảng đối chiếu trước, chưa đọc nội dung vào kho.

- Tên tệp bắt đầu bằng toàn bộ số ký hiệu được gợi ý ghép theo các cụm chữ/số. Ví dụ số `11932/GM-SGDĐT` có thể khớp tệp `11932_GM_SGDDT_Giay_moi.pdf`.
- Không tự ghép chỉ vì trùng một phần số: `12` không khớp `112`.
- Nếu nhiều hồ sơ cùng số ký hiệu hoặc không khớp, dòng tệp để chưa gán.
- Chọn dòng tệp, chọn văn bản trong danh sách và bấm **Gán văn bản** để sửa. Có thể gán nhiều tệp vào cùng một văn bản.
- Kiểm tra bảng rồi bấm **Nạp các dòng đã gán**. Các dòng chưa gán được bỏ qua; kết quả chỉ rõ tệp thành công, trùng, lỗi hoặc bị bỏ qua.
- Nút **Dừng nạp** dừng trước tệp kế tiếp. Tệp đang đọc có thể cần thêm thời gian. Chạy lại sẽ bỏ qua nội dung tệp trùng theo mã SHA-256 trong cùng hồ sơ.

Nội dung nhiều tệp được ghép kèm tên tệp vào hồ sơ để tìm kiếm và dùng AI. Nội dung đã nạp ở v2 được giữ lại khi thêm tệp v3. Tool lưu **chữ trích xuất và tên tệp**, không sao chép tệp PDF/Word gốc vào kho; bạn cần giữ tệp gốc riêng.

Giới hạn kế thừa: mỗi tệp tối đa 25 MB; PDF có lớp chữ tối đa 200 trang; DOCX, TXT/MD UTF-8; không hỗ trợ DOC cũ/PDF ảnh chưa OCR. Mỗi hồ sơ tối đa 200.000 ký tự nội dung tổng hợp. AI vẫn chỉ dùng tối đa 12.000 ký tự đầu mỗi hồ sơ và ghi cảnh báo khi cắt, không bảo đảm đọc đủ toàn bộ các tệp dài.

Nạp tệp **không tự chạy AI**. Nếu một tệp lỗi, các tệp khác vẫn tiếp tục và có kết quả riêng. Sau khi nạp, chọn văn bản trong kho để xem tổng ký tự; nút **Tệp của văn bản đang chọn** xem danh mục tệp v3 đã nạp.

## 5. Sao lưu và khôi phục bổ sung

**Tạo ZIP sao lưu** tạo bản chụp SQLite nhất quán kèm thời điểm và mã SHA-256 kiểm tra tính toàn vẹn. ZIP không chứa `login.dpapi`, mật khẩu, cookie trình duyệt, tệp gốc PDF/Word hay file Excel đã xuất. Bản ZIP chứa dữ liệu văn bản và công việc, chưa được mã hóa; cất ở nơi phù hợp.

Để khôi phục:

1. Chọn ZIP sao lưu v3 bằng **Chọn bản sao và xem trước**.
2. Tool kiểm tra định dạng, mã kiểm tra, cơ sở dữ liệu và cấu trúc. Xem số văn bản/đầu việc dự kiến thêm.
3. Bấm **Khôi phục bổ sung bản đã chọn**. Tool sao lưu kho hiện tại vào thư mục `Ket_qua/Sao_luu` (hoặc thư mục kết quả bạn đã chọn) trước khi nhập.

Khôi phục bổ sung **chỉ thêm** văn bản và đầu việc chưa có. Hồ sơ/đầu việc đã có được giữ nguyên, không thay nội dung hay ghi chú bằng bản cũ. Lịch sử nguồn, dự thảo và các tệp chữ của hồ sơ mới được đưa vào cùng hồ sơ đó. Với hồ sơ đã có, nội dung/tệp chữ hiện tại được giữ; đầu việc còn thiếu có thể được thêm.

Không nhập lại nhật ký cũ hoặc lịch sử các lượt thu thập trong thao tác khôi phục bổ sung. Các dữ liệu đó vẫn nằm trong bản chụp SQLite gốc trong ZIP nếu cần phục hồi kỹ thuật riêng. Cấu hình mẫu cột và thông tin đăng nhập không được khôi phục bằng tính năng này.

Bản sao v1/v2 dạng JSON vẫn dùng **Nạp JSON của v1/v2** ở tab đầu; không chọn JSON ở chức năng ZIP sao lưu.

## 6. Nhật ký nội bộ và sắp xếp

Tab Đầu việc có **Xem nhật ký nội bộ**, hiển thị tối đa 500 sự kiện mới nhất về lưu công việc, cập nhật hồ sơ nội bộ, nạp tệp, xuất báo cáo, sao lưu và khôi phục. Đây là nhật ký sử dụng trong một máy, không phải log kiểm toán có chữ ký số hay chống sửa.

Bảng kho văn bản và đầu việc có thể sắp xếp bằng tiêu đề cột. Bảng kho chỉ thay đổi thứ tự hiển thị, không đổi dữ liệu nguồn.

## 7. Phạm vi kiểm thử

Kiểm thử tự động dùng kho SQLite tạm, văn bản giả lập, tệp TXT/DOCX giả và đọc lại Excel. Bao gồm nhiều việc/hồ sơ, thời điểm hoàn thành, kỳ báo cáo, thứ tự cột, đối chiếu tên tệp, chống trùng tệp, giữ nội dung v2, sao lưu nhất quán, từ chối ZIP hỏng và khôi phục bổ sung không ghi đè.

Chưa chạy tài khoản website thật, chưa kiểm thử giao diện native/DPAPI trên máy Windows thực tế hoặc mô hình Ollama thật. Bộ thu thập và đăng nhập kế thừa v2, vẫn cần đối chiếu số lượng, phân trang và điều kiện tìm kiếm ở lần chạy thật đầu tiên.
