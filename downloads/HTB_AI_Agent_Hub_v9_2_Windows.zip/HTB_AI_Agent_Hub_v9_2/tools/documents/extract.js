() => {
  const clean = s => (s || '').replace(/\s+/g, ' ').trim();
  const norm = s => clean(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').toLowerCase();
  const visible = e => !!(e.getClientRects().length) && getComputedStyle(e).visibility !== 'hidden';
  const aliases = {'so den':'Số đến','so ky hieu':'Số ký hiệu','so, ky hieu':'Số ký hiệu','trich yeu':'Trích yếu','hinh thuc':'Hình thức','ngay van ban':'Ngày văn bản','ngay den':'Ngày đến','don vi ban hanh':'Đơn vị ban hành','xlc':'XLC'};
  const header = text => aliases[norm(text).replace(/[▲▼↕◆]/g,'').trim()] || null;
  const tables = [...document.querySelectorAll('table')].filter(visible);
  const candidates = [];
  for (const table of tables) {
    let hr = [...table.querySelectorAll('tr')].find(r => [...r.children].filter(e=>header(e.innerText)).length >= 3);
    let hs = hr ? [...hr.children].map(e=>header(e.innerText)) : [];
    if (!hs.includes('Trích yếu')) {
      const container = table.closest('.datagrid-view,.x-grid,.ui-jqgrid,.dataTables_wrapper');
      if (container) {
        const heads = [...container.querySelectorAll('tr')].find(r => [...r.children].filter(e=>header(e.innerText)).length >= 3);
        if(heads) hs = [...heads.children].map(e=>header(e.innerText));
      }
    }
    if (!hs.includes('Trích yếu') || !hs.includes('Số ký hiệu')) continue;
    const records = [];
    for (const tr of table.querySelectorAll('tr')) {
      if (!visible(tr) || tr === hr) continue;
      const cells = [...tr.children].filter(e=>/^(TD|TH)$/.test(e.tagName));
      if (cells.length !== hs.length || cells.filter(e=>header(e.innerText)).length>=3) continue;
      const row = {};
      cells.forEach((cell,i)=>{if(hs[i]) row[hs[i]]=clean(cell.innerText);});
      if (!row['Trích yếu'] || !row['Số ký hiệu']) continue;
      records.push(row);
    }
    candidates.push({records, columns:hs.filter(Boolean)});
  }
  candidates.sort((a,b)=>b.records.length-a.records.length);
  const result = candidates[0] || {records:[],columns:[]};
  result.empty = /không có dữ liệu|không tìm thấy.*văn bản|không có bản ghi/i.test(document.body.innerText);
  result.login = !!document.querySelector('input[type=password]') && [...document.querySelectorAll('input[type=password]')].some(visible);
  return result;
}
