import json
from pathlib import Path
from reports import CUSTOM_FIELDS
from secure_store import data_dir

DEFAULT_FIELDS=['STT','Số ký hiệu','Ngày văn bản','Trích yếu','Đơn vị ban hành','Phụ trách nội bộ','Hạn xác nhận']

def load_preferences():
    try:
        data=json.loads((data_dir()/'export_preferences.json').read_text(encoding='utf-8'))
        fields=data.get('fields')
        if not isinstance(fields,list) or not fields or len(set(fields))!=len(fields) or any(f not in CUSTOM_FIELDS for f in fields):raise ValueError()
        if not isinstance(data.get('title',''),str) or not isinstance(data.get('footer',''),str):raise ValueError()
        return data
    except (OSError,ValueError,TypeError):return {'fields':DEFAULT_FIELDS[:],'title':'BÁO CÁO CÔNG TÁC VĂN THƯ','footer':''}

def save_preferences(fields,title,footer):
    if not fields or any(f not in CUSTOM_FIELDS for f in fields) or len(set(fields))!=len(fields):raise ValueError('Chọn ít nhất một cột hợp lệ.')
    path=data_dir()/'export_preferences.json';temp=path.with_suffix('.tmp')
    temp.write_text(json.dumps({'fields':fields,'title':title[:1000],'footer':footer[:5000]},ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(path)
