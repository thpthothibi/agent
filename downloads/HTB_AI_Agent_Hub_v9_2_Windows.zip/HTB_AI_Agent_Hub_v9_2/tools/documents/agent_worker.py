import json
import re
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
from browser_agent import Worker,parse_date,filter_records,URL
from excel_export import export_xlsx
from secure_store import CredentialStore
from repository import identity
from analysis_engine import due_label,summary
from local_ai import generate,models,read_content

class AgentWorker(Worker):
    def __init__(self,events,repo):
        super().__init__(events)
        self.repo=repo
        self.credentials=CredentialStore()
        self.session_login=None
        self.auto_login=True
        self.archive_run=None
        self.engine=None
        self.requested_username=''

    @staticmethod
    def friendly(e):
        if isinstance(e,ValueError):return 'Dữ liệu đầu vào chưa hợp lệ. Kiểm tra ngày, mẫu cột và văn bản được chọn.'
        return Worker.friendly(e)

    def run(self):
        while True:
            cmd,args=self.commands.get()
            try:
                if cmd=='quit':break
                if cmd=='save_login':
                    self.credentials.save(args['username'],args['password'])
                    self.session_login=dict(args)
                    self.emit('log','Đã lưu tài khoản bằng cơ chế bảo vệ của tài khoản Windows hiện tại.')
                elif cmd=='forget_login':
                    self.credentials.forget();self.session_login=None
                    self.emit('log','Đã xóa thông tin đăng nhập được tool lưu trên máy.')
                elif cmd=='open':
                    self.stop_flag.clear()
                    self.set_login(args)
                    self.open_browser()
                    if self.auto_login:self.ensure_login()
                elif cmd=='collect':
                    self.stop_flag.clear()
                    self.set_login(args)
                    if not self.page or self.page.is_closed():self.open_browser()
                    self.ensure_login()
                    self.collect(args)
                elif hasattr(self,'handle_extra') and self.handle_extra(cmd,args):pass
                elif cmd=='export':self.export(args)
                elif cmd=='archive_export':self.export_archive(args)
                elif cmd=='import_json':self.import_json(args)
                elif cmd=='models':self.emit('models',models())
                elif cmd=='ai':
                    rows=[self.repo.get(i) for i in args['ids']]
                    if any(r is None for r in rows):raise RuntimeError('Một văn bản đã chọn không còn trong kho.')
                    answer=generate(args['model'],args['mode'],rows)
                    # Keep per-document drafts only when one source is selected.
                    if len(rows)==1:self.repo.update(rows[0]['id'],ai_draft=answer)
                    self.emit('ai_result',answer)
                    self.emit('refresh',None)
                elif cmd=='read_file':
                    text=read_content(args['path'])
                    self.repo.update(args['id'],content=text)
                    self.emit('log',f'Đã nạp {len(text):,} ký tự vào văn bản đã chọn; chưa gửi sang AI.')
                    self.emit('refresh',None)
            except Exception as e:
                message=self.friendly(e)
                self.log('Có lỗi: '+message)
                if cmd=='collect' and self.rows:
                    self.meta['Kết quả']='CHƯA ĐẦY ĐỦ — có lỗi trong lúc thu thập'
                    try:
                        self.checkpoint();self.export(args)
                    except Exception:self.log('Chưa xuất được Excel; kiểm tra JSON của lần thu thập trong thư mục kết quả.')
                self.emit('error',message)
            finally:
                # Remove passwords from the queue payload as soon as a command completes.
                if isinstance(args,dict):args.pop('password',None)
                self.emit('idle',None)
        if self.browser:
            try:self.browser.close()
            except Exception:pass
        if self.engine:
            try:self.engine.stop()
            except Exception:pass
        self.session_login=None

    def set_login(self,args):
        self.auto_login=args.get('auto_login',True)
        self.requested_username=args.get('username','').strip()
        if args.get('password'):
            self.session_login={'username':args.get('username','').strip(),'password':args['password']}
        elif args.get('username') and self.session_login and args['username']!=self.session_login['username']:
            self.session_login=None

    def open_browser(self):
        if self.engine is None:
            try:from playwright.sync_api import sync_playwright
            except ImportError:raise RuntimeError('Chạy CAI_DAT.bat trước để cài thư viện trình duyệt.')
            self.engine=sync_playwright().start();self.p=self.engine
        super().open_browser()

    @staticmethod
    def valid_origin(url):
        try:
            p=urlparse(url)
            return p.scheme=='https' and p.hostname=='qlvb.hcmict.com.vn' and p.port in [None,443] and not p.username and not p.password
        except ValueError:return False

    def login_frame(self):
        if not self.valid_origin(self.page.url):
            raise RuntimeError('Trang hiện tại không đúng địa chỉ đăng nhập đã cấu hình. Tool dừng để bảo vệ tài khoản.')
        for f in self.frames():
            if not self.valid_origin(f.url):continue
            p=f.locator('#passWord')
            if p.count() and p.is_visible():return f
        return None

    def signed_in(self):
        for f in self.frames():
            menu=f.get_by_text(re.compile(r'^Quản lý văn bản đến\s*(\(\d+\))?$'))
            for i in range(menu.count()):
                if menu.nth(i).is_visible():return True
        return False

    def ensure_login(self):
        frame=self.login_frame()
        if frame is None:
            if self.signed_in():return
            raise RuntimeError('Chưa xác nhận được phiên đăng nhập. Kiểm tra trang trên trình duyệt rồi thử lại.')
        if not self.auto_login:raise RuntimeError('Bạn đã chọn đăng nhập thủ công. Đăng nhập trên trình duyệt rồi bấm Tổng hợp.')
        login=self.session_login or self.credentials.load()
        if not login or not login.get('username') or not login.get('password'):
            raise RuntimeError('Nhập tài khoản/mật khẩu ở tab Đăng nhập, hoặc đăng nhập trực tiếp trên trình duyệt.')
        if self.requested_username and login['username']!=self.requested_username:
            raise RuntimeError('Tên truy cập đang nhập khác tài khoản đã lưu. Nhập mật khẩu tương ứng, hoặc để trống cả hai ô để dùng tài khoản đã lưu.')
        self.session_login=login
        captcha=frame.locator('#txtMaXacNhan')
        if captcha.count() and captcha.is_visible():
            raise RuntimeError('Website yêu cầu mã xác nhận/OTP. Hãy hoàn tất trực tiếp trên trình duyệt rồi bấm Tổng hợp; tool không tự vượt bước xác minh.')
        self.log('Đang đăng nhập vào hệ thống quản lý văn bản…')
        # Explicit selectors inspected on the public sign-in page; never fill arbitrary forms.
        if not self.valid_origin(frame.url):raise RuntimeError('Địa chỉ đăng nhập đã thay đổi.')
        frame.locator('#userName').fill(login['username'])
        if not self.valid_origin(frame.url):raise RuntimeError('Địa chỉ đăng nhập đã thay đổi.')
        frame.locator('#passWord').fill(login['password'])
        if not self.valid_origin(frame.url):raise RuntimeError('Địa chỉ đăng nhập đã thay đổi.')
        frame.locator('#submitBtn').click()
        deadline=time.monotonic()+35
        while time.monotonic()<deadline:
            if self.stop_flag.is_set():raise RuntimeError('Đã dừng đăng nhập.')
            if not self.valid_origin(self.page.url):raise RuntimeError('Website chuyển sang địa chỉ khác; kiểm tra trực tiếp trên trình duyệt.')
            if self.signed_in():
                self.log('Đã xác nhận đăng nhập thành công qua menu Quản lý văn bản đến.')
                return
            f=self.login_frame()
            if f:
                verify=f.locator('#txtMaXacNhan')
                if verify.count() and verify.is_visible():raise RuntimeError('Website yêu cầu mã xác nhận/OTP. Hoàn tất trên trình duyệt rồi bấm Tổng hợp.')
                body=f.locator('body').inner_text()
                if re.search(r'(sai|không đúng|không chính xác).{0,45}(mật khẩu|tài khoản)|đăng nhập thất bại|tài khoản.{0,30}(khóa|không tồn tại)',body,re.I):
                    raise RuntimeError('Website báo đăng nhập chưa thành công. Kiểm tra tài khoản/mật khẩu; tool không tự thử lại liên tục.')
            self.page.wait_for_timeout(350)
        raise RuntimeError('Chưa xác nhận được đăng nhập sau 35 giây. Kiểm tra thông báo trên website; tool chưa thử lại mật khẩu.')

    def export(self,options):
        if not self.rows:raise RuntimeError('Chưa có dữ liệu để xuất.')
        if self.archive_run!=self.run_id:
            counts=self.repo.ingest(self.rows,self.run_id,self.meta)
            self.archive_run=self.run_id
            self.meta.update({'So sánh kho nội bộ':'; '.join(f'{k}: {v}' for k,v in counts.items())})
            self.log(self.meta['So sánh kho nội bộ'])
            self.emit('refresh',None)
        selected,unknown=filter_records(self.rows,parse_date(options['start']),parse_date(options['end']),options['date_field'],options['keyword'])
        ids={identity(r) for r in selected}
        enriched=[r for r in self.repo.all() if r['id'] in ids]
        meta=dict(self.meta)
        meta.update({'Số văn bản xuất':len(selected),'Lọc ngày':f'{options["date_field"]}: {options["start"] or "không"} → {options["end"] or "không"}',
          'Từ khóa':options['keyword'],'Loại do ngày không hợp lệ':unknown,
          'Phân tích':'Gợi ý theo từ khóa từ trích yếu; hạn chỉ được cảnh báo sau khi người dùng xác nhận; không phản ánh kết quả xử lý trên website.'})
        output=Path(options['folder']);output.mkdir(parents=True,exist_ok=True)
        path=output/(self.run_id+'_Agent_'+datetime.now().strftime('%H%M%S_%f')+'.xlsx')
        export_xlsx(path,selected,meta,self.extra_sheets(enriched,self.repo.changes(self.run_id)))
        self.log('Đã xuất Excel và cập nhật kho văn bản nội bộ.')
        self.emit('saved',(str(path),meta.get('Kết quả','Đã xuất'),len(selected)))

    def extra_sheets(self,rows,changes=()):
        analysis=[['Số ký hiệu','Trích yếu','Nhóm gợi ý','Ưu tiên gợi ý','Hạn gợi ý (chưa xác nhận)','Căn cứ hạn','Việc gợi ý']]
        tasks=[['Số ký hiệu','Trích yếu','Trạng thái nội bộ','Phụ trách nội bộ','Hạn đã xác nhận','Cảnh báo nội bộ','Ghi chú']]
        for r in rows:
            a=r['analysis']
            analysis.append([r.get('Số ký hiệu',''),r.get('Trích yếu',''),a['category'],a['priority'],a['due_hint'],a['due_reason'],a['suggested_task']])
            tasks.append([r.get('Số ký hiệu',''),r.get('Trích yếu',''),r['local_status'],r['owner'],r['due_confirmed'],due_label(r),r['notes']])
        stats=[['Chỉ số','Số lượng']]+[[k,str(v)] for k,v in summary(rows).items()]
        change_rows=[['Số ký hiệu','Ngày văn bản','Loại thay đổi','Trích yếu']]+[[r.get('Số ký hiệu',''),r.get('Ngày văn bản',''),r['kind'],r.get('Trích yếu','')] for r in changes]
        return [('Phân tích gợi ý',analysis,[27,85,35,35,25,65,75],1),('Theo dõi công việc',tasks,[27,80,25,28,22,30,70],1),('Tổng quan',stats,[40,20],None),('Mới và cập nhật',change_rows,[27,20,22,100],3)]

    def export_archive(self,options):
        rows=self.repo.all()
        if 'ids' in options:
            wanted=set(options['ids'])
            rows=[r for r in rows if r['id'] in wanted]
        rows,unknown=filter_records(rows,parse_date(options['start']),parse_date(options['end']),options['date_field'],options['keyword'])
        if not rows:raise RuntimeError('Kho nội bộ chưa có văn bản phù hợp với bộ lọc.')
        folder=Path(options['folder']);folder.mkdir(parents=True,exist_ok=True)
        path=folder/('Kho_van_ban_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.xlsx')
        meta={'Nguồn':'Kho văn bản đã thu thập/nhập JSON trên máy','Kết quả':'Xuất từ kho nội bộ; không xác nhận đã lấy đủ website',
          'Số văn bản xuất':len(rows),'Loại vì ngày không hợp lệ':unknown,'Từ khóa':options['keyword'],
          'Bộ lọc ngày':f'{options["date_field"]}: {options["start"] or "không"} → {options["end"] or "không"}',
          'Lưu ý':'Hạn gợi ý cần xác minh. Trạng thái, phụ trách và hạn xác nhận chỉ được lưu trong tool.'}
        export_xlsx(path,rows,meta,self.extra_sheets(rows))
        self.emit('saved',(str(path),meta['Kết quả'],len(rows)))

    def import_json(self,args):
        path=Path(args['path'])
        if path.stat().st_size>50_000_000:raise RuntimeError('JSON vượt 50 MB.')
        try:data=json.loads(path.read_text(encoding='utf-8-sig'))
        except (ValueError,UnicodeError):raise RuntimeError('Tệp JSON không hợp lệ.')
        rows=data.get('records') if isinstance(data,dict) else None
        if not isinstance(rows,list) or not rows or len(rows)>100000:raise RuntimeError('Chọn JSON kết quả của tool (có records, từ 1 đến 100.000 dòng).')
        from excel_export import HEADERS
        for r in rows:
            if not isinstance(r,dict) or not r.get('Số ký hiệu') or not r.get('Trích yếu') or any(not isinstance(r.get(k,''),str) for k in HEADERS):
                raise RuntimeError('JSON có dòng thiếu/sai cấu trúc văn bản. Chưa nhập dữ liệu.')
        self.rows=rows
        self.meta=data.get('metadata',{}) if isinstance(data.get('metadata'),dict) else {}
        self.meta['Kết quả']='Nạp từ JSON; phạm vi theo lần thu thập nguồn'
        self.run_id='Nhap_JSON_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        counts=self.repo.ingest(rows,self.run_id,self.meta);self.archive_run=self.run_id
        self.log('Đã khôi phục JSON: '+'; '.join(f'{k}: {v}' for k,v in counts.items()))
        self.emit('refresh',None)
