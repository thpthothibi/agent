"""Portable XLSX export using the Python standard library (no Office required)."""
import math
from pathlib import Path
from xml.sax.saxutils import escape
from zipfile import ZipFile, ZIP_DEFLATED

HEADERS = ['Số đến', 'Số ký hiệu', 'Trích yếu', 'Hình thức', 'Ngày văn bản', 'Ngày đến', 'Đơn vị ban hành', 'XLC']

def col(n):
    s = ''
    while n:
        n, m = divmod(n-1, 26)
        s = chr(65+m)+s
    return s

def safe(v):
    return ''.join(c for c in str(v or '') if c in '\t\n\r' or ord(c) >= 32)[:32767]

def sheet_xml(rows, widths, wrap_index=None):
    parts = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
      '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>',
      '<cols>'+''.join(f'<col min="{i}" max="{i}" width="{w}" customWidth="1"/>' for i,w in enumerate(widths,1))+'</cols><sheetData>']
    for i, row in enumerate(rows, 1):
        h = 28 if i == 1 else 32
        if i > 1 and wrap_index is not None:
            h = min(240, max(32, math.ceil(len(str(row[wrap_index])) / (widths[wrap_index]-4))*16+10))
        parts.append(f'<row r="{i}" ht="{h}" customHeight="1">')
        for j, v in enumerate(row, 1):
            style = 1 if i == 1 else (2 if i%2 == 0 else 3)
            # Inline strings keep identifiers, leading zeroes and formula-looking text literal.
            parts.append(f'<c r="{col(j)}{i}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{escape(safe(v))}</t></is></c>')
        parts.append('</row>')
    parts.append(f'</sheetData><autoFilter ref="A1:{col(len(widths))}{len(rows)}"/><pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.2" footer="0.2"/><pageSetup orientation="landscape" paperSize="9" fitToWidth="1" fitToHeight="0"/></worksheet>')
    return ''.join(parts)

def export_xlsx(path, records, meta, extra_sheets=None):
    full = [['STT']+HEADERS+['Trang nguồn']]
    short = [['STT', 'Số ký hiệu', 'Ngày văn bản', 'Trích yếu']]
    for i,r in enumerate(records,1):
        full.append([str(i)]+[r.get(k,'') for k in HEADERS]+[str(r.get('_page',''))])
        short.append([str(i),r.get('Số ký hiệu',''),r.get('Ngày văn bản',''),r.get('Trích yếu','')])
    sheets = [('Trích yếu', short, [7,27,18,110],3),('Dữ liệu đầy đủ', full,[7,12,27,85,20,18,18,40,26,12],3),('Thông tin lần chạy',[['Nội dung','Giá trị']]+[[k,str(v)] for k,v in meta.items()],[35,110],1)]
    sheets.extend(extra_sheets or [])
    count=len(sheets)
    ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    styles=f'''<styleSheet xmlns="{ns}"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF3265C8"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF0F6FF"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'''
    path=Path(path)
    temp=path.with_suffix('.tmp.xlsx')
    with ZipFile(temp,'w',ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,count+1))+'</Types>')
        z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml',f'<workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+''.join(f'<sheet name="{name}" sheetId="{i}" r:id="rId{i}"/>' for i,(name,*_) in enumerate(sheets,1))+'</sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,count+1))+f'<Relationship Id="rId{count+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr('xl/styles.xml',styles)
        for i,(_,rows,widths,wrap) in enumerate(sheets,1):
            z.writestr(f'xl/worksheets/sheet{i}.xml',sheet_xml(rows,widths,wrap))
    temp.replace(path)
    return path
