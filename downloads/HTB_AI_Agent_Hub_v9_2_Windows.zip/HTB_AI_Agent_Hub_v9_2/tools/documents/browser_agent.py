import json
import os
import queue
import re
import threading
import time
from datetime import datetime
from pathlib import Path
from excel_export import export_xlsx, HEADERS

ROOT = Path(__file__).resolve().parent
URL = 'https://qlvb.hcmict.com.vn/qlvbdh/main?lang=vi'
EXTRACT = (ROOT/'extract.js').read_text(encoding='utf-8')

def record_key(r):
    # Include both dates and issuing body; never collapse by subject alone.
    return tuple(r.get(k,'') for k in HEADERS)

def parse_date(s):
    if not s.strip(): return None
    return datetime.strptime(s.strip(),'%d/%m/%Y').date()

def filter_records(rows, start, end, field, keyword):
    selected=[]
    unknown=0
    for r in rows:
        if keyword.casefold() not in r.get('Trích yếu','').casefold(): continue
        if start or end:
            try: d=parse_date(r.get(field,''))
            except ValueError: d=None
            if d is None:
                unknown+=1
                continue
            if start and d<start or end and d>end: continue
        selected.append(r)
    return selected,unknown

class Worker(threading.Thread):
    def __init__(self,events):
        super().__init__(daemon=True)
        self.events=events
        self.commands=queue.Queue()
        self.stop_flag=threading.Event()
        self.page=None
        self.context=None
        self.browser=None
        self.rows=[]
        self.meta={}
        self.output=ROOT/'Ket_qua'

    def emit(self,kind,data): self.events.put((kind,data))
    def log(self,s): self.emit('log',s)

    def run(self):
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                self.p=p
                while True:
                    cmd,args=self.commands.get()
                    try:
                        if cmd=='quit': break
                        if cmd=='open': self.open_browser()
                        elif cmd=='collect': self.collect(args)
                        elif cmd=='export': self.export(args)
                    except Exception as e:
                        # Avoid logging browser URLs, form values, cookies, or raw HTML.
                        self.log('Có lỗi: '+type(e).__name__+'. '+self.friendly(e))
                        if cmd=='collect' and self.rows:
                            self.meta['Kết quả']='CHƯA ĐẦY ĐỦ — có lỗi trong lúc thu thập'
                            self.checkpoint()
                            try: self.export(args)
                            except Exception: self.log('Chưa xuất được Excel. Dữ liệu đã lấy còn trong tệp JSON của lần chạy.')
                        self.emit('error',self.friendly(e))
                    finally: self.emit('idle',None)
                if self.browser: self.browser.close()
        except ImportError:
            self.emit('error','Chưa cài thư viện. Đóng tool và chạy CAI_DAT.bat trước.')

    @staticmethod
    def friendly(e):
        if isinstance(e,RuntimeError): return str(e)
        if isinstance(e,PermissionError): return 'Không ghi được tệp. Đóng Excel đang mở hoặc chọn thư mục khác.'
        return 'Kiểm tra cửa sổ trình duyệt và mạng. Có thể mở đúng danh sách Đã xử lý rồi chạy lại.'

    def open_browser(self):
        if self.page and not self.page.is_closed():
            self.page.bring_to_front()
            self.log('Trình duyệt đang mở. Bạn có thể đăng nhập hoặc kiểm tra danh sách.')
            return
        if self.browser:
            try: self.browser.close()
            except Exception: pass
        self.browser=self.p.chromium.launch(headless=False)
        # Ephemeral context: credentials/session are not written into the tool folder.
        self.context=self.browser.new_context(viewport={'width':1450,'height':900},locale='vi-VN',accept_downloads=False)
        self.page=self.context.new_page()
        self.page.set_default_timeout(12000)
        self.page.goto(URL,wait_until='domcontentloaded',timeout=60000)
        self.log('Đã mở trang quản lý văn bản. Đang kiểm tra trạng thái đăng nhập.')

    def frames(self):
        # Only inspect this service's frames, never unrelated embedded origins.
        from urllib.parse import urlparse
        return [f for f in self.page.frames if urlparse(f.url).hostname=='qlvb.hcmict.com.vn']

    def click_text(self,pattern):
        for f in self.frames():
            loc=f.get_by_text(pattern,exact=False)
            for i in range(min(loc.count(),30)):
                el=loc.nth(i)
                if el.is_visible():
                    el.click()
                    return True
        return False

    def snapshot(self):
        best=None
        for f in self.frames():
            try:
                result=f.evaluate(EXTRACT)
                if result.get('login'): raise RuntimeError('Bạn cần đăng nhập trực tiếp trên trình duyệt trước khi tổng hợp.')
                if result['columns'] and (best is None or len(result['records'])>len(best[1]['records'])):
                    best=(f,result)
            except RuntimeError: raise
            except Exception: continue
        return best

    def wait_rows(self,previous=None,timeout=45):
        deadline=time.monotonic()+timeout
        stable=None
        stable_since=0
        while time.monotonic()<deadline:
            if self.stop_flag.is_set(): return None
            snap=self.snapshot()
            if snap and (snap[1]['records'] or snap[1].get('empty')):
                signature=tuple(record_key(r) for r in snap[1]['records'])
                if signature != previous:
                    if signature!=stable:
                        stable=signature
                        stable_since=time.monotonic()
                    elif time.monotonic()-stable_since>=1.5: return snap
            self.page.wait_for_timeout(300)
        raise RuntimeError('Danh sách chưa tải xong hoặc không đổi trang sau 45 giây. Tool dừng để tránh báo đủ sai; dữ liệu đã lấy được giữ lại.')

    def navigate(self,options):
        if not self.page or self.page.is_closed(): raise RuntimeError('Bấm 1. Mở trang và đăng nhập trước.')
        self.snapshot()  # detects the visible login form
        if not options['current']:
            self.log('Đang chọn Quản lý văn bản đến → Đã xử lý…')
            # Click the exact menu label, with an optional count.
            if not self.click_text(re.compile(r'^Quản lý văn bản đến\s*(\(\d+\))?$')):
                raise RuntimeError('Không tìm thấy menu Quản lý văn bản đến. Mở đúng mục trên trình duyệt rồi tích Dùng danh sách đang mở.')
            self.page.wait_for_timeout(700)
            if not self.click_text(re.compile(r'^Đã xử lý$')):
                # The parent may already have been expanded and the first click closed it.
                self.click_text(re.compile(r'^Quản lý văn bản đến\s*(\(\d+\))?$'))
                self.page.wait_for_timeout(400)
                if not self.click_text(re.compile(r'^Đã xử lý$')):
                    raise RuntimeError('Chưa chọn được Đã xử lý. Mở đúng mục rồi tích Dùng danh sách đang mở.')
        self.wait_rows()
        if options['all_search']:
            self.log('Đang thực hiện Tìm kiếm với từ khóa trống để mở rộng phạm vi theo hướng dẫn trên trang…')
            found=False
            for f in self.frames():
                loc=f.get_by_placeholder(re.compile('Nhập từ khoá|Nhập từ khóa',re.I))
                for i in range(loc.count()):
                    if loc.nth(i).is_visible():
                        loc.nth(i).fill('')
                        found=True
            if not found:
                raise RuntimeError('Chưa nhận diện ô tìm kiếm. Hãy tự Tìm kiếm trên website, bỏ chọn Tìm kiếm toàn bộ, rồi chạy với danh sách đang mở.')
            if not self.click_text(re.compile(r'^Tìm kiếm$')):
                raise RuntimeError('Không tìm thấy nút Tìm kiếm. Hãy tìm kiếm thủ công rồi chạy với danh sách đang mở.')
            self.page.wait_for_timeout(1600)
            self.wait_rows()

    def next_control(self,frame,selector=''):
        selectors=[selector] if selector else [
            '.pagination-next', '.ui-pg-button:has(.ui-icon-seek-next)',
            '.paginate_button.next', '.page-item.next',
            '[aria-label="Next"]','[aria-label="Trang sau"]',
            '[title="Next Page"]','[title="Trang sau"]','[title="Trang tiếp"]',
            'a[rel="next"]', '.x-tbar-page-next',
        ]
        seen=set()
        found=[]
        for sel in selectors:
            if not sel: continue
            loc=frame.locator(sel)
            for i in range(loc.count()):
                el=loc.nth(i)
                if not el.is_visible(): continue
                identity=el.evaluate('(e)=>e.outerHTML')
                if identity in seen: continue
                seen.add(identity)
                disabled=el.evaluate("e=>!!e.closest('.disabled,.ui-state-disabled,.l-btn-disabled,.x-item-disabled,[aria-disabled=true]') || e.hasAttribute('disabled')")
                found.append((el,disabled))
        if not found and not selector:
            loc=frame.get_by_text(re.compile(r'^(Trang sau|Trang tiếp|Tiếp|Next|›|»|>)$',re.I))
            for i in range(loc.count()):
                el=loc.nth(i)
                if el.is_visible():
                    disabled=el.evaluate("e=>!!e.closest('.disabled,.ui-state-disabled,.l-btn-disabled,[aria-disabled=true]') || e.hasAttribute('disabled')")
                    found.append((el,disabled))
        enabled=[el for el,disabled in found if not disabled]
        if len(enabled)>1:
            raise RuntimeError('Có nhiều nút Trang sau, chưa xác định được nút của bảng văn bản. Chỉ định CSS nút Trang sau ở phần nâng cao.')
        if enabled: return enabled[0],'next'
        if found: return None,'end'
        return None,'unknown'

    def checkpoint(self):
        self.output.mkdir(parents=True,exist_ok=True)
        target=self.output/(self.run_id+'.json')
        temp=target.with_suffix('.tmp')
        temp.write_text(json.dumps({'metadata':self.meta,'records':self.rows},ensure_ascii=False,indent=2),encoding='utf-8')
        temp.replace(target)

    def collect(self,options):
        self.stop_flag.clear()
        self.rows=[]
        self.navigate(options)
        if self.stop_flag.is_set():
            self.log('Đã dừng trước khi thu thập.')
            return
        self.output=Path(options['folder'])
        self.run_id='Van_ban_den_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        self.rows=[]
        self.meta={'Nguồn':URL,'Danh sách':'Quản lý văn bản đến → Đã xử lý',
          'Thời điểm':datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
          'Phạm vi website':'Đã bấm Tìm kiếm trống; cần đối chiếu bộ lọc năm/ngày trên website' if options['all_search'] else 'Giữ bộ lọc của danh sách đang mở (mặc định website có thể chỉ 30 ngày)',
          'Kết quả':'ĐANG THU THẬP'}
        seen=set()
        signatures=set()
        snap=self.wait_rows()
        for page_no in range(1,options['max_pages']+1):
            if self.stop_flag.is_set():
                self.meta['Kết quả']='CHƯA ĐẦY ĐỦ — người dùng dừng'
                break
            if snap is None: break
            frame,data=snap
            signature=tuple(record_key(r) for r in data['records'])
            if signature in signatures:
                self.meta['Kết quả']='CHƯA ĐẦY ĐỦ — trang bị lặp'
                break
            signatures.add(signature)
            for row in data['records']:
                key=record_key(row)
                if key not in seen:
                    seen.add(key)
                    self.rows.append(dict(row,_page=page_no))
            self.meta['Số trang đã đọc']=page_no
            self.meta['Số văn bản đã lấy']=len(self.rows)
            self.checkpoint()
            self.emit('progress',(page_no,len(self.rows)))
            self.log(f'Trang {page_no}: {len(data["records"])} văn bản; tổng {len(self.rows)} văn bản không trùng.')
            button,status=self.next_control(frame,options['next_css'])
            if status=='unknown':
                self.meta['Kết quả']='CẦN KIỂM TRA — không nhận diện nút phân trang; chỉ xuất các trang đã đọc'
                break
            if status=='end':
                self.meta['Kết quả']='Đã đến cuối danh sách theo bộ lọc hiện tại của website'
                break
            if page_no==options['max_pages']:
                self.meta['Kết quả']='CHƯA ĐẦY ĐỦ — đạt giới hạn số trang'
                break
            button.click()
            snap=self.wait_rows(previous=signature)
        if self.stop_flag.is_set(): self.meta['Kết quả']='CHƯA ĐẦY ĐỦ — người dùng dừng'
        self.checkpoint()
        if not self.rows: raise RuntimeError('Không lấy được văn bản nào. Kiểm tra danh sách và bộ lọc trên website.')
        self.export(options)

    def export(self,options):
        if not self.rows: raise RuntimeError('Chưa có dữ liệu để xuất.')
        selected,unknown=filter_records(self.rows,parse_date(options['start']),parse_date(options['end']),options['date_field'],options['keyword'])
        meta=dict(self.meta)
        meta.update({'Lọc tại tool':f'{options["date_field"]}: {options["start"] or "không giới hạn"} → {options["end"] or "không giới hạn"}; từ khóa: {options["keyword"] or "không"}',
          'Số văn bản xuất Excel':len(selected),'Bỏ qua vì ngày trống/sai định dạng':unknown,
          'Lưu ý':'Trích yếu nguyên văn từ danh sách; không tóm tắt nội dung tệp đính kèm. Kiểm tra tổng số trên website trước khi dùng báo cáo.'})
        output=Path(options['folder'])
        output.mkdir(parents=True,exist_ok=True)
        path=output/(self.run_id+'_'+datetime.now().strftime('%H%M%S')+'.xlsx')
        export_xlsx(path,selected,meta)
        self.log(meta['Kết quả'])
        self.log(f'Đã xuất {len(selected)} văn bản ra Excel.')
        if unknown: self.log(f'{unknown} văn bản không có ngày hợp lệ đã bị loại theo bộ lọc. Bỏ lọc ngày để xem đầy đủ.')
        self.emit('saved',(str(path),meta['Kết quả'],len(selected)))

