@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 echo Can cai Python 3.11 tro len tu https://www.python.org/downloads/windows/
 echo Khi cai, chon Add python.exe to PATH. Sau do chay lai file nay.
 pause
 exit /b 1
)
py -3 -m venv .venv
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m playwright install chromium
if errorlevel 1 goto fail
echo Cai dat thanh cong. Mo CHAY_TOOL.bat de su dung.
pause
exit /b 0
:fail
echo Cai dat chua thanh cong. Kiem tra ket noi mang va Python.
pause
exit /b 1
