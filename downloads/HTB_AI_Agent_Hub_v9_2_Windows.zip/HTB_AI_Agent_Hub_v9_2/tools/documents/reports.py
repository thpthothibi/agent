import calendar
from collections import Counter
from datetime import date,datetime,timedelta
from pathlib import Path
from analysis_engine import due_label
from workspace_repo import task_alert
from excel_export import export_xlsx,HEADERS

CUSTOM_FIELDS=['STT']+HEADERS+['Nhóm gợi ý','Trạng thái nội bộ','Phụ trách nội bộ','Hạn xác nhận','Ghi chú']

def period(mode,today=None):
    today=today or date.today()
    if mode=='Tuần này':
        start=today-timedelta(days=today.weekday());return start,start+timedelta(days=6)
    if mode=='Tháng này':return today.replace(day=1),today.replace(day=calendar.monthrange(today.year,today.month)[1])
    if mode=='Tháng trước':
        end=today.replace(day=1)-timedelta(days=1);return end.replace(day=1),end
    return None,None

def date_value(value):
    try:return datetime.strptime(value.strip(),'%d/%m/%Y').date()
    except (ValueError,AttributeError):return None

def task_sheet(tasks,name='Đầu việc chi tiết'):
    rows=[['Số ký hiệu','Công việc','Phụ trách','Hạn đã xác nhận','Trạng thái','Ưu tiên','Cảnh báo hiện tại','Hoàn thành lúc','Ghi chú']]
    for t in tasks:
        rows.append([t['number'],t['title'],t['owner'],t['due'],t['status'],t['priority'],task_alert(t),t['completed_at'],t['notes']])
    return name,rows,[25,85,28,22,22,18,25,28,65],1

def report_data(documents,tasks,start,end,field='Ngày đến'):
    if not start or not end or start>end:raise ValueError('Chọn khoảng thời gian hợp lệ.')
    selected=[];unknown=0
    for r in documents:
        d=date_value(r.get(field,''))
        if d is None:unknown+=1
        elif start<=d<=end:selected.append(r)
    due_tasks=[t for t in tasks if t['due'] and start<=date.fromisoformat(t['due'])<=end]
    done=[t for t in tasks if t['status']=='Hoàn thành' and t['completed_at'] and start<=date.fromisoformat(t['completed_at'][:10])<=end]
    # Backlog is as of export time, including tasks without a due date.
    backlog=[t for t in tasks if t['status'] not in ['Hoàn thành','Hủy']]
    return selected,due_tasks,done,backlog,unknown

def custom_sheet(documents,fields):
    if not fields or any(f not in CUSTOM_FIELDS for f in fields) or len(set(fields))!=len(fields):raise ValueError('Mẫu cột không hợp lệ.')
    rows=[fields]
    for i,r in enumerate(documents,1):
        extra={'STT':str(i),'Nhóm gợi ý':r['analysis']['category'],'Trạng thái nội bộ':r['local_status'],
          'Phụ trách nội bộ':r['owner'],'Hạn xác nhận':r['due_confirmed'],'Ghi chú':r['notes']}
        rows.append([extra.get(f,r.get(f,'')) for f in fields])
    widths=[85 if f=='Trích yếu' else 55 if f=='Ghi chú' else 32 if f in ['Đơn vị ban hành','Nhóm gợi ý'] else 24 for f in fields]
    return 'Mẫu cột tùy chọn',rows,widths,fields.index('Trích yếu') if 'Trích yếu' in fields else None

def export_report(repo,folder,start,end,field,title,footer,fields):
    docs,tasks=repo.all(),repo.tasks()
    selected,due,done,backlog,unknown=report_data(docs,tasks,start,end,field)
    groups=Counter(r['analysis']['category'] for r in selected)
    stats=[['Chỉ số','Giá trị'],['Văn bản trong kỳ',str(len(selected))],['Đầu việc có hạn trong kỳ',str(len(due))],
      ['Đầu việc hoàn thành trong kỳ',str(len(done))],['Đầu việc đang mở hiện tại (toàn kho)',str(len(backlog))],['Quá hạn hiện tại (toàn kho)',str(sum(task_alert(t)=='Quá hạn' for t in backlog))]]
    stats +=[['Nhóm: '+k,str(v)] for k,v in groups.items()]
    meta={'Tiêu đề':title,'Kỳ báo cáo':f'{start:%d/%m/%Y} → {end:%d/%m/%Y}','Lọc văn bản theo':field,
      'Kết quả':'Báo cáo từ kho nội bộ, không xác nhận toàn bộ website','Thời điểm xuất':datetime.now().isoformat(timespec='seconds'),
      'Văn bản không có ngày hợp lệ (toàn kho)':unknown,'Chân trang/ghi chú':footer,
      'Cách đếm':'Văn bản theo ngày đã chọn; việc đến hạn theo hạn đã xác nhận; hoàn thành theo thời điểm bấm hoàn thành. Tồn đọng/quá hạn là hiện tại toàn kho, không tái hiện lịch sử cuối kỳ.'}
    out=Path(folder);out.mkdir(parents=True,exist_ok=True)
    path=out/('Bao_cao_van_thu_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.xlsx')
    extras=[('Thống kê kỳ',stats,[60,30],None),task_sheet(due,'Việc có hạn trong kỳ'),task_sheet(done,'Việc hoàn thành trong kỳ'),task_sheet(backlog,'Việc đang mở hiện tại'),custom_sheet(selected,fields)]
    export_xlsx(path,selected,meta,extras)
    return path,len(selected)
