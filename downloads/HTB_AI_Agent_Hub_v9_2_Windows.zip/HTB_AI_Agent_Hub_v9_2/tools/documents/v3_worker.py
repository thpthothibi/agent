from datetime import datetime
from pathlib import Path
from agent_worker import AgentWorker
from browser_agent import parse_date
from batch_tools import import_files
from reports import export_report,task_sheet
from backup_tools import create_backup,restore_merge,read_backup

class V3Worker(AgentWorker):
    def extra_sheets(self,rows,changes=()):
        sheets=super().extra_sheets(rows,changes)
        doc_ids={r['id'] for r in rows}
        sheets.append(task_sheet([t for t in self.repo.tasks() if t['doc_id'] in doc_ids]))
        return sheets
    def handle_extra(self,cmd,args):
        if cmd=='report':
            path,count=export_report(self.repo,args['folder'],parse_date(args['start']),parse_date(args['end']),args['field'],args['title'],args['footer'],args['fields'])
            self.repo.audit('Xuất báo cáo kỳ','',args['start']+' → '+args['end'])
            self.emit('saved',(str(path),'Báo cáo từ kho nội bộ',count))
        elif cmd in ['batch_files','read_file']:
            self.stop_flag.clear()
            plan=args['plan'] if cmd=='batch_files' else [{'path':args['path'],'doc_id':args['id']}]
            results=import_files(self.repo,plan,self.stop_flag,lambda name,status:self.log(name+': '+status))
            self.emit('batch_result',results);self.emit('refresh',None)
        elif cmd=='backup':
            manifest=create_backup(self.repo,args['path'])
            self.log('Đã sao lưu kho và đầu việc, không chứa mật khẩu đăng nhập.')
            self.emit('notice',f'Đã sao lưu {manifest["documents"]} văn bản và {manifest["tasks"]} đầu việc.\n{args["path"]}')
        elif cmd=='backup_preview':
            preview=read_backup(args['path'])
            current={d['id'] for d in self.repo.all()}
            current_tasks={t['id'] for t in self.repo.tasks()}
            self.emit('backup_preview',{'path':args['path'],'documents':sum(r['id'] not in current for r in preview['documents']),
              'tasks':sum(t['id'] not in current_tasks for t in preview['tasks']),'existing':sum(r['id'] in current for r in preview['documents'])})
        elif cmd=='restore':
            # Make a safety copy before merging any new records.
            out=Path(args['safety_folder']);out.mkdir(parents=True,exist_ok=True)
            safety=out/('Truoc_khoi_phuc_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.zip')
            create_backup(self.repo,safety)
            result=restore_merge(self.repo,args['path'])
            self.emit('refresh',None)
            self.emit('notice','\n'.join(f'{k}: {v}' for k,v in result.items())+'\n\nĐã giữ bản sao trước khôi phục tại:\n'+str(safety))
        else:return False
        return True
