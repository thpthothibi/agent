import hashlib
import json
import sqlite3
from datetime import datetime
from pathlib import Path
from analysis_engine import hint
from excel_export import HEADERS

def fingerprint(row):
    return hashlib.sha256(json.dumps([row.get(k,'') for k in HEADERS],ensure_ascii=False).encode()).hexdigest()

def identity(row):
    # Never merge two incoming registrations on document number alone.
    values=[row.get(k,'').strip() for k in ['Số đến','Số ký hiệu','Ngày văn bản','Ngày đến','Đơn vị ban hành']]
    if not values[1]:raise ValueError('Thiếu số ký hiệu; không thể lập hồ sơ văn bản.')
    return hashlib.sha256(json.dumps(values,ensure_ascii=False).encode()).hexdigest()

class Repository:
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS documents(
              id TEXT PRIMARY KEY, source TEXT NOT NULL, fingerprint TEXT NOT NULL,
              analysis TEXT NOT NULL, first_seen TEXT NOT NULL,last_seen TEXT NOT NULL,
              local_status TEXT NOT NULL DEFAULT 'Chưa lập việc',owner TEXT NOT NULL DEFAULT '',
              due_confirmed TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',
              ai_draft TEXT NOT NULL DEFAULT '', content TEXT NOT NULL DEFAULT '');
            CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY,time TEXT NOT NULL,metadata TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS changes(run_id TEXT NOT NULL,doc_id TEXT NOT NULL,kind TEXT NOT NULL,
              PRIMARY KEY(run_id,doc_id));
            CREATE TABLE IF NOT EXISTS history(doc_id TEXT NOT NULL,time TEXT NOT NULL,source TEXT NOT NULL);
            ''')
    def connect(self):
        db=sqlite3.connect(self.path,timeout=15);db.row_factory=sqlite3.Row
        return db
    def ingest(self,records,run_id,meta):
        now=datetime.now().isoformat(timespec='seconds')
        counts={'Mới':0,'Cập nhật':0,'Đã có':0}
        unique={}
        for r in records:
            key=identity(r)
            h=fingerprint(r)
            if key in unique and unique[key]!=h:
                raise RuntimeError('Cùng một hồ sơ có hai nội dung khác nhau trong lượt tải. Giữ JSON để đối chiếu và tải lại khi danh sách ổn định; chưa gộp vào kho.')
            unique[key]=h
        seen=set()
        with self.connect() as db:
            db.execute('INSERT OR REPLACE INTO runs VALUES(?,?,?)',(run_id,now,json.dumps(meta,ensure_ascii=False)))
            for r in records:
                doc_id=identity(r)
                if doc_id in seen:continue
                seen.add(doc_id)
                original=db.execute('SELECT fingerprint,source FROM documents WHERE id=?',(doc_id,)).fetchone()
                src=json.dumps({k:r.get(k,'') for k in HEADERS},ensure_ascii=False)
                h=fingerprint(r);analysis=json.dumps(hint(r),ensure_ascii=False)
                if original:
                    kind='Đã có' if original['fingerprint']==h else 'Cập nhật'
                    if kind=='Cập nhật':db.execute('INSERT INTO history VALUES(?,?,?)',(doc_id,now,original['source']))
                    db.execute('UPDATE documents SET source=?,fingerprint=?,analysis=?,last_seen=? WHERE id=?',(src,h,analysis,now,doc_id))
                else:
                    kind='Mới'
                    db.execute('INSERT INTO documents(id,source,fingerprint,analysis,first_seen,last_seen) VALUES(?,?,?,?,?,?)',(doc_id,src,h,analysis,now,now))
                db.execute('INSERT OR REPLACE INTO changes VALUES(?,?,?)',(run_id,doc_id,kind))
                counts[kind]+=1
        return counts
    @staticmethod
    def decode(row):
        r=dict(row);source=json.loads(r.pop('source'));source.update(r)
        source['analysis']=json.loads(source['analysis'])
        return source
    def all(self):
        with self.connect() as db:return [self.decode(r) for r in db.execute('SELECT * FROM documents ORDER BY last_seen DESC,id')]
    def get(self,doc_id):
        with self.connect() as db:r=db.execute('SELECT * FROM documents WHERE id=?',(doc_id,)).fetchone()
        return self.decode(r) if r else None
    def update(self,doc_id,**fields):
        allowed={'local_status','owner','due_confirmed','notes','ai_draft','content'}
        if not fields or not set(fields)<=allowed:raise ValueError('Trường dữ liệu nội bộ không hợp lệ.')
        from analysis_engine import STATES
        from datetime import date
        if 'local_status' in fields and fields['local_status'] not in STATES:raise ValueError('Trạng thái không hợp lệ.')
        if fields.get('due_confirmed'):date.fromisoformat(fields['due_confirmed'])
        with self.connect() as db:
            db.execute('UPDATE documents SET '+','.join(f'{k}=?' for k in fields)+' WHERE id=?',list(fields.values())+[doc_id])
    def changes(self,run_id):
        with self.connect() as db:
            rows=db.execute('SELECT d.*,c.kind FROM documents d JOIN changes c ON c.doc_id=d.id WHERE c.run_id=?',(run_id,)).fetchall()
            return [self.decode(r) for r in rows]
    def history(self,doc_id):
        with self.connect() as db:
            return [{'time':r['time'],'source':json.loads(r['source'])} for r in db.execute('SELECT time,source FROM history WHERE doc_id=? ORDER BY rowid DESC',(doc_id,))]
