import json
import uuid
from datetime import date,datetime
from repository import Repository

TASK_STATES=['Chưa làm','Đang làm','Hoàn thành','Tạm dừng','Hủy']
PRIORITIES=['Bình thường','Ưu tiên','Khẩn']

def now():return datetime.now().isoformat(timespec='seconds')

def task_alert(task,today=None):
    if task['status'] in ['Hoàn thành','Hủy']:return 'Đã khép việc'
    if not task['due']:return 'Chưa đặt hạn'
    delta=(date.fromisoformat(task['due'])-(today or date.today())).days
    if delta<0:return 'Quá hạn'
    if delta==0:return 'Hôm nay'
    if delta<=3:return 'Sắp hạn (3 ngày)'
    return 'Còn hạn'

class WorkspaceRepository(Repository):
    def __init__(self,path):
        super().__init__(path)
        with self.connect() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS tasks(
              id TEXT PRIMARY KEY,doc_id TEXT NOT NULL,title TEXT NOT NULL,
              owner TEXT NOT NULL DEFAULT '',due TEXT NOT NULL DEFAULT '',
              status TEXT NOT NULL DEFAULT 'Chưa làm',priority TEXT NOT NULL DEFAULT 'Bình thường',
              notes TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
              completed_at TEXT NOT NULL DEFAULT '');
            CREATE INDEX IF NOT EXISTS task_doc ON tasks(doc_id);
            CREATE TABLE IF NOT EXISTS audit(
              id INTEGER PRIMARY KEY AUTOINCREMENT,time TEXT NOT NULL,action TEXT NOT NULL,
              target TEXT NOT NULL,detail TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS attachments(
              id TEXT PRIMARY KEY,doc_id TEXT NOT NULL,filename TEXT NOT NULL,
              sha256 TEXT NOT NULL,content TEXT NOT NULL,imported_at TEXT NOT NULL,
              UNIQUE(doc_id,sha256));
            ''')
    def audit(self,action,target='',detail=''):
        with self.connect() as db:db.execute('INSERT INTO audit(time,action,target,detail) VALUES(?,?,?,?)',(now(),action,target,detail))
    def update(self,doc_id,**fields):
        super().update(doc_id,**fields)
        self.audit('Cập nhật hồ sơ nội bộ',doc_id,', '.join(sorted(fields)))
    def audit_rows(self,limit=500):
        with self.connect() as db:return [dict(r) for r in db.execute('SELECT time,action,target,detail FROM audit ORDER BY id DESC LIMIT ?',(limit,))]
    def save_task(self,doc_id,title,owner='',due='',status='Chưa làm',priority='Bình thường',notes='',task_id=None):
        if not self.get(doc_id):raise ValueError('Chọn văn bản nguồn còn trong kho.')
        if not title.strip():raise ValueError('Nhập nội dung công việc.')
        if status not in TASK_STATES or priority not in PRIORITIES:raise ValueError('Trạng thái/ưu tiên không hợp lệ.')
        if due:date.fromisoformat(due)
        if len(title)>1000 or len(notes)>30000:raise ValueError('Nội dung công việc quá dài.')
        timestamp=now()
        with self.connect() as db:
            original=db.execute('SELECT * FROM tasks WHERE id=?',(task_id,)).fetchone() if task_id else None
            if task_id and not original:raise ValueError('Đầu việc không còn trong kho.')
            if original:
                completed=original['completed_at'] if original['status']=='Hoàn thành' and status=='Hoàn thành' else (timestamp if status=='Hoàn thành' else '')
                db.execute('UPDATE tasks SET doc_id=?,title=?,owner=?,due=?,status=?,priority=?,notes=?,updated_at=?,completed_at=? WHERE id=?',
                  (doc_id,title.strip(),owner.strip(),due,status,priority,notes,timestamp,completed,task_id))
            else:
                task_id=uuid.uuid4().hex
                db.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?,?,?)',(task_id,doc_id,title.strip(),owner.strip(),due,status,priority,notes,timestamp,timestamp,timestamp if status=='Hoàn thành' else ''))
            db.execute('INSERT INTO audit(time,action,target,detail) VALUES(?,?,?,?)',(timestamp,'Lưu đầu việc',task_id,status))
        return task_id
    def tasks(self):
        with self.connect() as db:
            rows=db.execute('SELECT t.*,d.source FROM tasks t JOIN documents d ON d.id=t.doc_id ORDER BY CASE WHEN t.due="" THEN 1 ELSE 0 END,t.due,t.created_at').fetchall()
        result=[]
        for r in rows:
            item=dict(r);source=json.loads(item.pop('source'));item['number']=source.get('Số ký hiệu','');item['subject']=source.get('Trích yếu','')
            result.append(item)
        return result
    def add_attachment(self,doc_id,filename,digest,content):
        if not self.get(doc_id):raise ValueError('Văn bản nguồn không còn.')
        if not content.strip() or len(content)>200000:raise ValueError('Nội dung tệp trống hoặc quá dài.')
        with self.connect() as db:
            existing=db.execute('SELECT id FROM attachments WHERE doc_id=? AND sha256=?',(doc_id,digest)).fetchone()
            if existing:return False
            # The content field is the consolidated text used by search and AI.
            parts=db.execute('SELECT filename,content FROM attachments WHERE doc_id=? ORDER BY imported_at,id',(doc_id,)).fetchall()
            original=db.execute('SELECT content FROM documents WHERE id=?',(doc_id,)).fetchone()['content']
            if not parts and original==content:
                db.execute('INSERT INTO attachments VALUES(?,?,?,?,?,?)',(uuid.uuid4().hex,doc_id,filename,digest,content,now()))
                db.execute('INSERT INTO audit(time,action,target,detail) VALUES(?,?,?,?)',(now(),'Ghi nhận tệp cùng nội dung đã có',doc_id,filename))
                return True
            if not parts and original.strip():
                # Preserve a file imported by v2 before adding the first v3 attachment.
                import hashlib
                db.execute('INSERT INTO attachments VALUES(?,?,?,?,?,?)',(uuid.uuid4().hex,doc_id,'Nội dung đã nạp trước v3',hashlib.sha256(original.encode()).hexdigest(),original,now()))
                parts=[{'filename':'Nội dung đã nạp trước v3','content':original}]
            all_parts=list(parts)+[{'filename':filename,'content':content}]
            combined='\n\n'.join('--- '+p['filename']+' ---\n'+p['content'] for p in all_parts)
            if len(combined)>200000:raise ValueError('Tổng nội dung văn bản vượt 200.000 ký tự; chưa thêm tệp.')
            db.execute('INSERT INTO attachments VALUES(?,?,?,?,?,?)',(uuid.uuid4().hex,doc_id,filename,digest,content,now()))
            db.execute('UPDATE documents SET content=? WHERE id=?',(combined,doc_id))
            db.execute('INSERT INTO audit(time,action,target,detail) VALUES(?,?,?,?)',(now(),'Nạp tệp nội dung',doc_id,filename))
        return True
    def attachments(self,doc_id):
        with self.connect() as db:return [dict(r) for r in db.execute('SELECT id,filename,sha256,imported_at,length(content) AS characters FROM attachments WHERE doc_id=? ORDER BY imported_at,id',(doc_id,))]
