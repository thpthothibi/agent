import hashlib
import re
from pathlib import Path
from analysis_engine import normalize
from local_ai import read_content

def tokens(s):return re.findall(r'[a-z0-9]+',normalize(s))

def plan_files(paths,documents):
    result=[]
    for path in paths:
        file_tokens=tokens(Path(path).stem)
        matches=[]
        for doc in documents:
            key=tokens(doc.get('Số ký hiệu',''))
            # Entire leading identifier must match as tokens, never match 12 inside 112.
            if key and file_tokens[:len(key)]==key:matches.append(doc)
        ids={d['id'] for d in matches}
        result.append({'path':str(path),'doc_id':next(iter(ids)) if len(ids)==1 else '',
          'number':matches[0].get('Số ký hiệu','') if len(ids)==1 else '',
          'status':'Khớp duy nhất — cần kiểm tra' if len(ids)==1 else ('Nhiều hồ sơ cùng số — cần gán tay' if ids else 'Chưa khớp — cần gán tay')})
    return result

def import_files(repo,plan,stop=None,progress=None):
    results=[]
    for item in plan:
        if stop and stop.is_set():break
        path=Path(item['path'])
        if not item.get('doc_id'):
            results.append((path.name,'Bỏ qua — chưa gán văn bản'));continue
        try:
            if not path.is_file():raise RuntimeError('Tệp không còn tồn tại.')
            if path.stat().st_size>25000000:raise RuntimeError('Tệp vượt 25 MB.')
            content=read_content(path)
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            added=repo.add_attachment(item['doc_id'],path.name,digest,content)
            status='Đã nạp' if added else 'Đã có — bỏ qua tệp trùng'
        except (RuntimeError,ValueError) as e:status='Lỗi: '+str(e)
        except Exception:status='Lỗi đọc tệp; kiểm tra định dạng, quyền truy cập hoặc mật khẩu.'
        results.append((path.name,status))
        if progress:progress(path.name,status)
    return results
