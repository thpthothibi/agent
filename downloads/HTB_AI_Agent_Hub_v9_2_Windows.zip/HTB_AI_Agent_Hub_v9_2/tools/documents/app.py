import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from datetime import date,datetime
from pathlib import Path
from app_base import App as BaseApp
from workspace_repo import TASK_STATES,PRIORITIES,task_alert
from reports import period,CUSTOM_FIELDS
from browser_agent import parse_date
from batch_tools import plan_files
from preferences import load_preferences,save_preferences

class App(BaseApp):
    def __init__(self):
        super().__init__()
        self.title('HTB • AI Agent văn bản v3.0')
        self.geometry('1320x920');self.minsize(1100,800)
        self.task_id=None;self.plan=[];self.restore_path=None
        self.docs_map=[];self.file_docs_map=[]
        self.tasks_tab=ttk.Frame(self.notebook,padding=12)
        self.reports_tab=ttk.Frame(self.notebook,padding=16)
        self.files_tab=ttk.Frame(self.notebook,padding=14)
        for name,tab in [('5. Đầu việc',self.tasks_tab),('6. Báo cáo',self.reports_tab),('7. Tệp & sao lưu',self.files_tab)]:self.notebook.add(tab,text=name)
        self.make_tasks();self.make_reports();self.make_files();self.refresh()
        for col in self.tree['columns']:
            self.tree.heading(col,command=lambda c=col:self.sort_tree(self.tree,c))
        self.after(60000,self.refresh_reminders)

    def make_tasks(self):
        tab=self.tasks_tab
        ttk.Label(tab,text='Một văn bản có thể có nhiều đầu việc — chỉ quản lý nội bộ trong tool.',foreground='#1954a5',font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(0,8))
        row=ttk.Frame(tab);row.pack(fill='x')
        self.task_search=tk.StringVar();self.task_state_filter=tk.StringVar(value='Tất cả');self.task_due_filter=tk.StringVar(value='Tất cả hạn')
        ttk.Label(row,text='Tìm việc/phụ trách:').pack(side='left')
        ttk.Entry(row,textvariable=self.task_search,width=35).pack(side='left',padx=8)
        ttk.Combobox(row,textvariable=self.task_state_filter,values=['Tất cả']+TASK_STATES,state='readonly',width=20).pack(side='left',padx=6)
        ttk.Combobox(row,textvariable=self.task_due_filter,values=['Tất cả hạn','Quá hạn','Hôm nay','Sắp hạn (3 ngày)','Chưa đặt hạn','Còn hạn','Đã khép việc'],state='readonly',width=23).pack(side='left',padx=6)
        ttk.Button(row,text='Lọc',command=self.refresh_tasks).pack(side='left')
        self.task_summary=tk.StringVar();ttk.Label(tab,textvariable=self.task_summary,foreground='#1954a5').pack(anchor='w',pady=6)
        grid=ttk.Frame(tab);grid.pack(fill='both',expand=True)
        columns=['number','title','owner','due','status','priority','alert']
        self.task_tree=ttk.Treeview(grid,columns=columns,show='headings',selectmode='browse',height=9)
        for c,label,w in zip(columns,['Văn bản','Công việc','Phụ trách','Hạn','Trạng thái','Ưu tiên','Cảnh báo'],[170,340,160,110,120,100,150]):
            self.task_tree.heading(c,text=label,command=lambda key=c:self.sort_tree(self.task_tree,key));self.task_tree.column(c,width=w,minwidth=75)
        self.task_tree.grid(row=0,column=0,sticky='nsew')
        scroll=ttk.Scrollbar(grid,orient='vertical',command=self.task_tree.yview);scroll.grid(row=0,column=1,sticky='ns')
        self.task_tree.configure(yscrollcommand=scroll.set)
        sx=ttk.Scrollbar(grid,orient='horizontal',command=self.task_tree.xview);sx.grid(row=1,column=0,sticky='ew');self.task_tree.configure(xscrollcommand=sx.set)
        grid.rowconfigure(0,weight=1);grid.columnconfigure(0,weight=1)
        self.task_tree.bind('<<TreeviewSelect>>',self.select_task)
        self.task_form_title=tk.StringVar(value='Thêm đầu việc mới')
        ttk.Label(tab,textvariable=self.task_form_title,font=('Segoe UI',11,'bold')).pack(anchor='w',pady=(10,4))
        ttk.Label(tab,text='Văn bản nguồn:').pack(anchor='w')
        self.task_doc=ttk.Combobox(tab,state='readonly');self.task_doc.pack(fill='x',pady=(0,5))
        self.task_title=tk.StringVar();self.task_owner=tk.StringVar();self.task_due=tk.StringVar();self.task_state=tk.StringVar(value=TASK_STATES[0]);self.task_priority=tk.StringVar(value=PRIORITIES[0])
        row=ttk.Frame(tab);row.pack(fill='x')
        self.field(row,'Nội dung công việc',self.task_title,72);self.field(row,'Người phụ trách',self.task_owner,28)
        row=ttk.Frame(tab);row.pack(fill='x',pady=6)
        self.field(row,'Hạn đã xác nhận (dd/mm/yyyy)',self.task_due,26)
        for label,var,values in [('Trạng thái',self.task_state,TASK_STATES),('Ưu tiên',self.task_priority,PRIORITIES)]:
            f=ttk.Frame(row);f.pack(side='left',padx=12)
            ttk.Label(f,text=label).pack(anchor='w');ttk.Combobox(f,textvariable=var,values=values,state='readonly',width=22).pack()
        ttk.Label(tab,text='Ghi chú / kết quả thực hiện:').pack(anchor='w')
        self.task_notes=tk.Text(tab,height=3,wrap='word',font=('Segoe UI',10));self.task_notes.pack(fill='x')
        row=ttk.Frame(tab);row.pack(fill='x',pady=10)
        self.button(row,'Tạo từ văn bản đang chọn',self.new_task,side='left',padx=(0,8))
        self.button(row,'Lưu đầu việc',self.save_detailed_task,side='left',padx=(0,8))
        self.button(row,'Đánh dấu hoàn thành',self.complete_task,side='left',padx=(0,8))
        self.button(row,'Xem nhật ký nội bộ',self.show_audit,side='left')
        for var in [self.task_search,self.task_state_filter,self.task_due_filter]:var.trace_add('write',lambda *args:self.refresh_tasks())

    def make_reports(self):
        pref=load_preferences();tab=self.reports_tab
        ttk.Label(tab,text='Báo cáo văn thư và mẫu cột Excel',font=('Segoe UI',13,'bold'),foreground='#1954a5').pack(anchor='w')
        row=ttk.Frame(tab);row.pack(fill='x',pady=12)
        self.report_mode=tk.StringVar(value='Tháng này');self.report_start=tk.StringVar();self.report_end=tk.StringVar();self.report_field=tk.StringVar(value='Ngày đến')
        f=ttk.Frame(row);f.pack(side='left',padx=(0,14))
        ttk.Label(f,text='Kỳ báo cáo').pack(anchor='w')
        cb=ttk.Combobox(f,textvariable=self.report_mode,values=['Tuần này','Tháng này','Tháng trước','Tùy chọn'],state='readonly',width=19);cb.pack();cb.bind('<<ComboboxSelected>>',self.set_period)
        self.field(row,'Từ ngày (dd/mm/yyyy)',self.report_start,20);self.field(row,'Đến ngày',self.report_end,20)
        f=ttk.Frame(row);f.pack(side='left')
        ttk.Label(f,text='Ngày thống kê văn bản').pack(anchor='w');ttk.Combobox(f,textvariable=self.report_field,values=['Ngày đến','Ngày văn bản'],state='readonly',width=22).pack()
        self.set_period()
        self.report_title=tk.StringVar(value=pref['title']);self.report_footer=tk.StringVar(value=pref['footer'])
        row=ttk.Frame(tab);row.pack(fill='x',pady=7)
        self.field(row,'Tiêu đề báo cáo (ghi trong sheet thông tin)',self.report_title,100)
        row=ttk.Frame(tab);row.pack(fill='x',pady=7)
        self.field(row,'Chân trang / ghi chú (ghi trong sheet thông tin)',self.report_footer,100)
        ttk.Label(tab,text='Mẫu cột tùy chọn: thêm/bớt và sắp xếp thứ tự cột cho sheet riêng.',foreground='#1954a5').pack(anchor='w',pady=(12,5))
        lists=ttk.Frame(tab);lists.pack(fill='both',expand=True)
        left=ttk.Frame(lists);left.pack(side='left',fill='both',expand=True)
        ttk.Label(left,text='Các cột có thể chọn').pack(anchor='w')
        self.available_cols=tk.Listbox(left,exportselection=False,selectmode='extended',height=13,font=('Segoe UI',11));self.available_cols.pack(fill='both',expand=True)
        for value in CUSTOM_FIELDS:self.available_cols.insert('end',value)
        middle=ttk.Frame(lists);middle.pack(side='left',padx=16)
        ttk.Button(middle,text='Thêm →',command=self.add_columns).pack(pady=7)
        ttk.Button(middle,text='← Bỏ',command=self.remove_columns).pack(pady=7)
        ttk.Button(middle,text='Lên',command=lambda:self.move_column(-1)).pack(pady=7)
        ttk.Button(middle,text='Xuống',command=lambda:self.move_column(1)).pack(pady=7)
        right=ttk.Frame(lists);right.pack(side='left',fill='both',expand=True)
        ttk.Label(right,text='Cột xuất ra theo thứ tự').pack(anchor='w')
        self.selected_cols=tk.Listbox(right,exportselection=False,selectmode='extended',height=13,font=('Segoe UI',11));self.selected_cols.pack(fill='both',expand=True)
        for value in pref['fields']:self.selected_cols.insert('end',value)
        row=ttk.Frame(tab);row.pack(fill='x',pady=15)
        self.button(row,'Lưu mẫu cột',self.save_report_template,side='left',padx=(0,9))
        self.button(row,'Xuất báo cáo kỳ + mẫu cột',self.run_report,side='left',padx=(0,9))
        ttk.Label(tab,text='Xuất vào thư mục kết quả tại tab Đăng nhập & thu thập.\nViệc hoàn thành được tính theo thời điểm đánh dấu hoàn thành; tồn đọng là hiện tại toàn kho, không phải cuối kỳ lịch sử.',foreground='#805b00').pack(anchor='w',pady=6)

    def make_files(self):
        tab=self.files_tab
        ttk.Label(tab,text='Nạp nhiều tệp và đối chiếu văn bản nguồn',font=('Segoe UI',13,'bold'),foreground='#1954a5').pack(anchor='w')
        ttk.Label(tab,text='Tên tệp bắt đầu bằng số ký hiệu được gợi ý ghép. Kiểm tra bảng và gán lại trước khi nạp. Chưa gọi AI khi nạp tệp.').pack(anchor='w',pady=7)
        row=ttk.Frame(tab);row.pack(fill='x',pady=5)
        self.button(row,'Chọn nhiều PDF / Word / TXT',self.choose_batch,side='left',padx=(0,8))
        self.button(row,'Nạp các dòng đã gán',self.run_batch,side='left',padx=(0,8))
        ttk.Button(row,text='Dừng nạp sau tệp hiện tại',command=self.worker.stop_flag.set).pack(side='left')
        self.plan_tree=ttk.Treeview(tab,columns=['file','number','status'],show='headings',selectmode='extended',height=9)
        for col,title,width in [('file','Tệp',440),('number','Văn bản nguồn',260),('status','Tình trạng',420)]:self.plan_tree.heading(col,text=title);self.plan_tree.column(col,width=width)
        self.plan_tree.pack(fill='both',expand=True,pady=9)
        ttk.Label(tab,text='Gán lại các dòng đang chọn vào văn bản:').pack(anchor='w')
        row=ttk.Frame(tab);row.pack(fill='x',pady=6)
        self.file_doc=ttk.Combobox(row,state='readonly');self.file_doc.pack(side='left',fill='x',expand=True,padx=(0,9))
        self.button(row,'Gán văn bản',self.assign_batch,side='left',padx=(0,8))
        self.button(row,'Bỏ gán',self.unassign_batch,side='left',padx=(0,8))
        self.button(row,'Tệp của văn bản đang chọn',self.show_attachments,side='left')
        ttk.Separator(tab).pack(fill='x',pady=16)
        ttk.Label(tab,text='Sao lưu và khôi phục bổ sung',font=('Segoe UI',13,'bold'),foreground='#1954a5').pack(anchor='w')
        ttk.Label(tab,text='Bản sao lưu gồm kho, nội dung đã nạp, dự thảo và đầu việc; không chứa mật khẩu.\nKhôi phục chỉ thêm hồ sơ/đầu việc còn thiếu, giữ nguyên dữ liệu đã có; có bản sao an toàn trước khi nhập.').pack(anchor='w',pady=8)
        row=ttk.Frame(tab);row.pack(fill='x',pady=5)
        self.button(row,'Tạo ZIP sao lưu',self.backup,side='left',padx=(0,8))
        self.button(row,'Chọn bản sao và xem trước',self.preview_restore,side='left',padx=(0,8))
        self.button(row,'Khôi phục bổ sung bản đã chọn',self.restore,side='left')
        self.restore_note=tk.StringVar(value='Chưa chọn bản sao lưu.')
        ttk.Label(tab,textvariable=self.restore_note,foreground='#805b00',wraplength=1120).pack(anchor='w',pady=9)

    def refresh(self):
        super().refresh()
        if hasattr(self,'task_tree'):
            docs=self.repo.all();old_doc=self.docs_map[self.task_doc.current()] if 0<=self.task_doc.current()<len(self.docs_map) else None
            old_file=self.file_docs_map[self.file_doc.current()] if 0<=self.file_doc.current()<len(self.file_docs_map) else None
            self.docs_map=[d['id'] for d in docs];self.file_docs_map=self.docs_map[:]
            labels=[f'{d.get("Số ký hiệu","")} | {d.get("Ngày văn bản","")} | Số đến {d.get("Số đến","")} | {d.get("Đơn vị ban hành","")}' for d in docs]
            self.task_doc.configure(values=labels);self.file_doc.configure(values=labels)
            if old_doc in self.docs_map:self.task_doc.current(self.docs_map.index(old_doc))
            if old_file in self.file_docs_map:self.file_doc.current(self.file_docs_map.index(old_file))
            self.refresh_tasks()

    def refresh_tasks(self):
        if not hasattr(self,'task_tree'):return
        from analysis_engine import normalize
        rows=self.repo.tasks();keep=self.task_tree.selection()
        self.task_tree.delete(*self.task_tree.get_children())
        q=normalize(self.task_search.get().strip())
        for t in rows:
            if q and q not in normalize(' '.join(t[k] for k in ['title','owner','number','notes'])):continue
            if self.task_state_filter.get()!='Tất cả' and t['status']!=self.task_state_filter.get():continue
            if self.task_due_filter.get()!='Tất cả hạn' and task_alert(t)!=self.task_due_filter.get():continue
            due=date.fromisoformat(t['due']).strftime('%d/%m/%Y') if t['due'] else ''
            self.task_tree.insert('','end',iid=t['id'],values=[t['number'],t['title'],t['owner'],due,t['status'],t['priority'],task_alert(t)])
        self.task_summary.set(f'Toàn kho: {len(rows)} đầu việc • Quá hạn: {sum(task_alert(t)=="Quá hạn" for t in rows)} • Hôm nay: {sum(task_alert(t)=="Hôm nay" for t in rows)} • Đang hiển thị: {len(self.task_tree.get_children())}')
        selected=[i for i in keep if self.task_tree.exists(i)]
        if selected:self.task_tree.selection_set(selected)

    def new_task(self):
        self.task_id=None;self.task_form_title.set('Thêm đầu việc mới')
        self.task_tree.selection_remove(self.task_tree.selection())
        self.task_title.set('');self.task_owner.set('');self.task_due.set('');self.task_state.set(TASK_STATES[0]);self.task_priority.set(PRIORITIES[0]);self.task_notes.delete('1.0','end')
        ids=self.tree.selection()
        if len(ids)==1 and ids[0] in self.docs_map:self.task_doc.current(self.docs_map.index(ids[0]))
        self.notebook.select(self.tasks_tab)

    def select_task(self,event=None):
        ids=self.task_tree.selection()
        if len(ids)!=1:return
        task=next((t for t in self.repo.tasks() if t['id']==ids[0]),None)
        if not task:return
        self.task_id=task['id'];self.task_form_title.set('Đang sửa đầu việc: '+task['title'])
        if task['doc_id'] in self.docs_map:self.task_doc.current(self.docs_map.index(task['doc_id']))
        self.task_title.set(task['title']);self.task_owner.set(task['owner']);self.task_due.set(date.fromisoformat(task['due']).strftime('%d/%m/%Y') if task['due'] else '')
        self.task_state.set(task['status']);self.task_priority.set(task['priority']);self.task_notes.delete('1.0','end');self.task_notes.insert('1.0',task['notes'])

    def save_detailed_task(self):
        index=self.task_doc.current()
        if index<0 or index>=len(self.docs_map):self.error('Chọn văn bản nguồn cho đầu việc.');return
        try:
            due=parse_date(self.task_due.get())
            self.task_id=self.repo.save_task(self.docs_map[index],self.task_title.get(),self.task_owner.get(),due.isoformat() if due else '',self.task_state.get(),self.task_priority.get(),self.task_notes.get('1.0','end-1c'),self.task_id)
            self.refresh_tasks();self.task_tree.selection_set(self.task_id);self.status.set('Đã lưu đầu việc nội bộ; không gửi giao việc lên website.')
        except ValueError as e:self.error(str(e) if 'does not match' not in str(e) else 'Hạn cần theo dd/mm/yyyy.')

    def complete_task(self):
        if not self.task_id:self.error('Chọn đầu việc đã lưu để đánh dấu hoàn thành.');return
        self.task_state.set('Hoàn thành');self.save_detailed_task()

    def show_audit(self):
        rows=self.repo.audit_rows()
        self.show_text('Nhật ký nội bộ (500 sự kiện mới nhất)','\n\n'.join(r['time']+' | '+r['action']+' | '+r['detail'] for r in rows) or 'Chưa có sự kiện.')

    def set_period(self,event=None):
        start,end=period(self.report_mode.get())
        if start:self.report_start.set(start.strftime('%d/%m/%Y'));self.report_end.set(end.strftime('%d/%m/%Y'))

    def add_columns(self):
        chosen=list(self.selected_cols.get(0,'end'))
        for i in self.available_cols.curselection():
            value=self.available_cols.get(i)
            if value not in chosen:self.selected_cols.insert('end',value);chosen.append(value)
    def remove_columns(self):
        for i in reversed(self.selected_cols.curselection()):self.selected_cols.delete(i)
    def move_column(self,step):
        selection=self.selected_cols.curselection()
        if len(selection)!=1:return
        i=selection[0];target=i+step
        if not 0<=target<self.selected_cols.size():return
        value=self.selected_cols.get(i);self.selected_cols.delete(i);self.selected_cols.insert(target,value);self.selected_cols.selection_set(target)
    def save_report_template(self):
        try:save_preferences(list(self.selected_cols.get(0,'end')),self.report_title.get(),self.report_footer.get());self.status.set('Đã lưu mẫu cột và thông tin báo cáo trên máy.')
        except ValueError as e:self.error(str(e))
    def run_report(self):
        try:
            start=parse_date(self.report_start.get());end=parse_date(self.report_end.get())
            fields=list(self.selected_cols.get(0,'end'))
            if not start or not end or start>end:raise ValueError('Chọn khoảng ngày báo cáo hợp lệ.')
            if not fields:raise ValueError('Chọn ít nhất một cột cho mẫu xuất.')
            if not self.folder.get().strip():raise ValueError('Chọn thư mục kết quả ở tab đầu.')
        except ValueError:self.error('Kiểm tra khoảng ngày dd/mm/yyyy, thư mục kết quả và mẫu cột.');return
        self.send('report',{'folder':self.folder.get().strip(),'start':self.report_start.get(),'end':self.report_end.get(),'field':self.report_field.get(),'title':self.report_title.get(),'footer':self.report_footer.get(),'fields':fields})

    def choose_batch(self):
        paths=filedialog.askopenfilenames(filetypes=[('Nội dung văn bản','*.pdf *.docx *.txt *.md')])
        if not paths:return
        self.plan=plan_files(paths,self.repo.all());self.render_plan()
    def render_plan(self):
        self.plan_tree.delete(*self.plan_tree.get_children())
        for i,item in enumerate(self.plan):self.plan_tree.insert('','end',iid=str(i),values=[Path(item['path']).name,item.get('number',''),item['status']])
    def assign_batch(self):
        index=self.file_doc.current()
        if index<0 or index>=len(self.file_docs_map):self.error('Chọn văn bản để gán.');return
        ids=self.plan_tree.selection()
        if not ids:self.error('Chọn dòng tệp trong bảng đối chiếu.');return
        doc=self.repo.get(self.file_docs_map[index])
        for i in ids:self.plan[int(i)].update(doc_id=doc['id'],number=doc.get('Số ký hiệu',''),status='Đã gán tay — sẵn sàng nạp')
        self.render_plan()
    def unassign_batch(self):
        for i in self.plan_tree.selection():self.plan[int(i)].update(doc_id='',number='',status='Chưa gán — sẽ bỏ qua')
        self.render_plan()
    def run_batch(self):
        if not any(i.get('doc_id') for i in self.plan):self.error('Chọn tệp và đối chiếu/gán văn bản nguồn trước.');return
        self.send('batch_files',{'plan':[dict(i) for i in self.plan]})
    def show_attachments(self):
        doc_id=self.one_selection()
        if not doc_id:return
        items=self.repo.attachments(doc_id)
        self.show_text('Nội dung đã nạp cho văn bản','\n\n'.join(f'{a["filename"]}\n{a["characters"]:,} ký tự • {a["imported_at"]}' for a in items) or 'Chưa có tệp được quản lý ở v3; nội dung nạp ở v2 vẫn có trong hồ sơ nếu đã nạp.')

    def backup(self):
        path=filedialog.asksaveasfilename(defaultextension='.zip',initialfile='HTB_Sao_luu_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip',filetypes=[('Bản sao lưu HTB','*.zip')])
        if path:self.send('backup',{'path':path})
    def preview_restore(self):
        path=filedialog.askopenfilename(filetypes=[('Bản sao lưu HTB v3','*.zip')])
        if path:
            self.restore_path=None;self.restore_note.set('Đang kiểm tra bản sao…');self.send('backup_preview',{'path':path})
    def restore(self):
        if not self.restore_path:self.error('Chọn bản sao và xem trước thành công trước khi khôi phục.');return
        folder=self.folder.get().strip()
        if not folder:self.error('Chọn thư mục kết quả cho bản sao an toàn.');return
        self.send('restore',{'path':self.restore_path,'safety_folder':str(Path(folder)/'Sao_luu')})

    def handle_event(self,kind,data):
        if kind=='batch_result':
            self.show_text('Kết quả nạp tệp','\n'.join(name+': '+status for name,status in data) or 'Đã dừng trước khi nạp tệp.')
            self.status.set('Đã xử lý lô tệp. Kiểm tra các dòng lỗi/bỏ qua trong kết quả.')
        elif kind=='notice':messagebox.showinfo('Hoàn tất',data);self.status.set('Đã hoàn tất thao tác.')
        elif kind=='backup_preview':
            self.restore_path=data['path'];self.restore_note.set(f'Có thể thêm {data["documents"]} văn bản và {data["tasks"]} đầu việc; giữ nguyên {data["existing"]} hồ sơ đã có.\nBản được chọn: '+data['path'])
        else:return False
        return True

    def refresh_reminders(self):
        if not self.busy:
            rows=self.repo.tasks()
            # Refresh only displayed alerts; do not replace an editor's unsaved form.
            for task in rows:
                if self.task_tree.exists(task['id']):self.task_tree.set(task['id'],'alert',task_alert(task))
            self.task_summary.set(f'Toàn kho: {len(rows)} đầu việc • Quá hạn: {sum(task_alert(t)=="Quá hạn" for t in rows)} • Hôm nay: {sum(task_alert(t)=="Hôm nay" for t in rows)} • Đang hiển thị: {len(self.task_tree.get_children())}')
        self.after(60000,self.refresh_reminders)

    @staticmethod
    def sort_tree(tree,column):
        rows=[(tree.set(i,column),i) for i in tree.get_children('')]
        reverse=getattr(tree,'sort_reverse',False)
        def key(item):
            value=item[0]
            try:return (0,datetime.strptime(value,'%d/%m/%Y').isoformat())
            except ValueError:return (1,value.casefold())
        rows.sort(key=key,reverse=reverse)
        for i,(_,item) in enumerate(rows):tree.move(item,'',i)
        tree.sort_reverse=not reverse

if __name__=='__main__':App().mainloop()
