# HTB – AI Agent văn bản v2.0

Phần mềm chạy trên Windows 10/11 cho THPT Hồ Thị Bi, nâng cấp từ tool tổng hợp trích yếu v1. Chạy **CAI_DAT.bat** lại để bổ sung thư viện mới, sau đó chạy **CHAY_TOOL.bat**. Cần Python 3.11+ và mạng để cài thư viện/trình duyệt. Đây là gói mã nguồn chạy bằng Python, chưa phải EXE độc lập.

## 1. Đăng nhập tự động

Tại tab **Đăng nhập & thu thập**:

1. Nhập tên truy cập và mật khẩu; giữ tích **Tự động đăng nhập**.
2. Bấm **Mở trang & đăng nhập**. Tool mở Chromium riêng và điền đúng biểu mẫu tại `https://qlvb.hcmict.com.vn`.
3. Tool chỉ báo thành công khi thấy menu **Quản lý văn bản đến**. Nếu sai mật khẩu, hết thời gian hoặc cần OTP/CAPTCHA, tool dừng để bạn kiểm tra trên trình duyệt; không thử mật khẩu liên tục.
4. Bấm **Tổng hợp → phân tích → Excel**. Nếu chưa mở trình duyệt, nút này sẽ mở trang và thực hiện đăng nhập trước.

Nếu muốn lần sau không nhập lại, bấm **Lưu đăng nhập trên Windows**. Tool dùng Windows DPAPI để mã hóa theo tài khoản Windows hiện tại, không ghi mật khẩu dạng chữ trong cấu hình. Tệp mã hóa được lưu tại `%LOCALAPPDATA%\HTB_VanBanAgent\login.dpapi`. Người dùng Windows hiện tại vẫn có khả năng giải mã; không dùng trên tài khoản Windows dùng chung nếu cần tách quyền.

Để trống ô tài khoản/mật khẩu khi muốn dùng thông tin đã lưu. Nếu nhập mật khẩu mới, tool dùng thông tin mới trong phiên; bấm Lưu để thay thế thông tin lưu lâu dài. Nút **Xóa đăng nhập đã lưu** xóa tệp mã hóa và thông tin trong phiên tool, không đăng xuất hay đổi mật khẩu trên website. Đóng trình duyệt nếu cần kết thúc phiên đang đăng nhập. Mật khẩu không được đưa vào nhật ký, Excel hay JSON.

Có thể bỏ tích Tự động đăng nhập để đăng nhập thủ công trên cửa sổ Chromium. Trình duyệt dùng phiên tạm, không lưu hồ sơ/cookie ra thư mục tool. Nếu phiên hết hạn trong lúc đang đọc nhiều trang, tool dừng và lưu phần đã lấy; chạy lại từ trang đầu sau khi đăng nhập để tránh bỏ sót. Chưa tự phục hồi chính xác vị trí phân trang sau khi hết phiên.

Tool giữ tài khoản đang đăng nhập của cửa sổ Chromium, không tự đăng xuất để đổi người dùng. Muốn đổi tài khoản, đóng cửa sổ trình duyệt do tool mở, nhập thông tin mới rồi bấm Mở trang & đăng nhập.

## 2. Thu thập và xuất Excel

Tool chọn **Quản lý văn bản đến → Đã xử lý**, có tùy chọn bấm **Tìm kiếm** trống theo hướng dẫn trên website để mở rộng ngoài 30 ngày mặc định, đọc bảng và sang trang tiếp.

- Bộ lọc ngày và từ khóa trên tool áp dụng **sau khi tải**.
- Điều kiện năm, sổ và ngày trên website vẫn có thể giới hạn kết quả.
- Mỗi trang có tệp JSON cập nhật để giữ phần đã đọc khi lỗi.
- Dữ liệu được lưu vào kho SQLite nội bộ. Thu thập lại không tạo bản trùng với cùng số đến, số ký hiệu, ngày văn bản, ngày đến và đơn vị ban hành.
- Trích yếu/hình thức/XLC thay đổi trong cùng hồ sơ được ghi lịch sử. Nếu các trường nhận diện thay đổi thì tạo hồ sơ riêng để tránh gộp nhầm.
- Nếu không nhận diện được phân trang, đạt giới hạn, có trang lặp hay lỗi mạng, báo cáo ghi rõ **chưa đầy đủ/cần kiểm tra**.

Luôn đối chiếu tổng số và trang đầu/cuối với website trước khi dùng báo cáo chính thức. “Đến cuối danh sách” chỉ xác nhận cuối kết quả trong bộ lọc hiện tại.

Nếu menu/bảng chưa nhận diện được, tự mở đúng mục **Đã xử lý**, tìm kiếm và về trang đầu; tích **Dùng danh sách đang mở**, bỏ tích **Bấm Tìm kiếm trống**, rồi chạy lại. Ô CSS nút Trang sau dành cho người biết selector thực tế, thường để trống.

## 3. Kho văn bản và công việc

Tại tab **Kho & công việc**, bạn có thể:

- Tra cứu không phân biệt dấu theo số ký hiệu, trích yếu, cơ quan ban hành, người phụ trách, ghi chú và nội dung tệp đã nạp.
- Lọc theo nhóm, trạng thái công việc, quá hạn, hạn hôm nay hoặc sắp hạn 3 ngày.
- Chọn một dòng để đọc trích yếu đầy đủ, gợi ý phân loại, mức ưu tiên và hạn có dấu hiệu trong nguồn.
- Ghi người phụ trách, hạn **đã xác nhận**, ghi chú và trạng thái công việc nội bộ.
- Tìm các văn bản có từ khóa liên quan và xem các phiên bản trích yếu trước đây.
- Xuất **các dòng đang lọc** ra Excel.

Gợi ý phân loại dùng quy tắc từ khóa, không phải kết quả mô hình AI. Có các nhóm CNTT/chuyển đổi số, chuyên môn, nhân sự, tài chính/CSVC, học sinh/an toàn, thi đua và hội họp. Một văn bản có thể thuộc nhiều nhóm. Ưu tiên dựa vào từ khóa “khẩn”, “hỏa tốc” trong trích yếu, không suy từ màu chữ trên trang.

**Hạn gợi ý chưa được dùng để báo quá hạn.** Tool chỉ nhận mốc có từ chỉ hạn đi kèm ngày đầy đủ năm, không coi ngày họp là hạn nộp. Bạn cần xem văn bản gốc và nhập hạn xác nhận. Cảnh báo tính theo ngày của máy. Đây là công việc trong tool, tách khỏi trạng thái “Đã xử lý” trên website.

Các trạng thái nội bộ: Chưa lập việc, Cần xem xét, Đang thực hiện, Hoàn thành, Không phát sinh việc. Việc gõ tên người phụ trách chỉ lưu nội bộ; không gửi giao việc/thông báo cho người đó.

Kho dữ liệu: `%LOCALAPPDATA%\HTB_VanBanAgent\documents.sqlite3`. Kho không được mã hóa toàn bộ; cần bảo vệ tài khoản Windows và sao lưu phù hợp. Khi đổi thư mục cài hoặc cập nhật phiên bản, kho vẫn được giữ vì nằm riêng theo người dùng Windows. Muốn sao lưu kho, đóng tool trước rồi sao chép tệp SQLite. Không sao chép login.dpapi sang máy khác để dùng mật khẩu: DPAPI gắn với tài khoản Windows.

Nút **Nạp JSON của v1/v2** nhập lại bản JSON đã xuất trước đây, không cần đăng nhập website. Đây là khôi phục dữ liệu đã đọc, không tự tiếp tục trang web ở vị trí đang dở.

## 4. Trợ lý AI cục bộ

AI là phần tùy chọn, dùng Ollama tại `127.0.0.1:11434`. Bạn cần tự cài Ollama và mô hình phù hợp cấu hình máy trước. Bản này không kèm mô hình, không tự tải mô hình và chưa tích hợp API ChatGPT/Gemini. Trên máy ít RAM hoặc không có GPU, tốc độ/mô hình dùng được có thể bị giới hạn.

1. Chọn 1–10 dòng tại tab Kho & công việc. Giữ Ctrl để chọn nhiều dòng.
2. Sang tab Trợ lý AI, bấm **Đọc danh sách mô hình** rồi chọn mô hình đã cài.
3. Nếu cần toàn văn: chọn đúng một dòng trong kho, bấm **Nạp nội dung PDF / Word / TXT**, chọn tệp tải về từ website. Tool không tự mở chi tiết/tải đính kèm trong bản này.
4. Chọn **Phân tích nhiệm vụ**, **Dự thảo triển khai**, **Dự thảo báo cáo** hoặc **Tổng hợp các văn bản chọn**, rồi bấm **Phân tích / tạo dự thảo**.
5. Rà soát bản thảo, có thể sửa trực tiếp và bấm **Lưu dự thảo TXT**. Khi AI xử lý một văn bản, kết quả ban đầu cũng được lưu trong hồ sơ để xem lại; phần sửa tay tại ô dự thảo cần lưu TXT, chưa tự ghi đè vào kho.

Nạp tệp chỉ đọc nội dung vào kho, chưa chạy AI. Chỉ khi bấm nút chạy, tool gửi các nguồn đã chọn tới dịch vụ Ollama trên chính máy, không gọi API AI đám mây. Giới hạn: tệp 25 MB, PDF tối đa 200 trang có lớp chữ, DOCX/TXT/MD; chưa OCR PDF scan, chưa đọc DOC cũ. Nội dung dài hơn 200.000 ký tự cần chia tệp. Mỗi nguồn gửi AI tối đa **12.000 ký tự đầu**, tổng tối đa **45.000 ký tự JSON** cho một lượt; kết quả ghi rõ nếu bị cắt.

Nếu chưa nạp toàn văn, AI chỉ phân tích **trích yếu** và phải nói rõ phạm vi đó. Dự thảo có thể sai; kiểm tra nhiệm vụ, đối tượng, số liệu, ngày hạn và căn cứ trước khi dùng. Nội dung AI không tự đổi hạn xác nhận, trạng thái hay phụ trách. Dự thảo báo cáo để trống những số liệu chưa có, không tự tạo minh chứng.

## 5. Các sheet Excel

| Sheet | Nội dung |
|---|---|
| Trích yếu | STT, số ký hiệu, ngày văn bản, trích yếu nguyên văn |
| Dữ liệu đầy đủ | Các cột nguồn giống v1 và trang nguồn khi có |
| Thông tin lần chạy | Phạm vi, bộ lọc, số trang, trạng thái hoàn tất |
| Phân tích gợi ý | Nhóm, ưu tiên, hạn gợi ý, căn cứ, việc cần xem xét |
| Theo dõi công việc | Trạng thái nội bộ, người phụ trách, hạn xác nhận, cảnh báo, ghi chú |
| Tổng quan | Thống kê trong phạm vi xuất |
| Mới và cập nhật | Văn bản mới, cập nhật hoặc đã có của lượt thu thập; để trống khi xuất toàn kho |

Số ký hiệu được ghi dạng chữ; nội dung bắt đầu bằng dấu bằng không biến thành công thức. Các bản dự thảo AI không tự đưa vào Excel nguồn.

## 6. Kiểm thử và giới hạn

Đã kiểm tra biểu mẫu đăng nhập công khai, dùng đúng các ID đã quan sát. Đã kiểm thử dữ liệu/DOM mô phỏng cho bộ thu thập; kiểm tra kho, lịch sử, công việc, hạn, bảo vệ địa chỉ đăng nhập, cấu trúc Excel và giao thức AI bằng giả lập.

**Chưa chạy đăng nhập bằng tài khoản thật, chưa xác minh phân trang sau đăng nhập, chưa kiểm thử DPAPI trên Windows hay chạy mô hình Ollama thật trong môi trường tạo tool.** Vì vậy lần chạy đầu cần kiểm tra thực tế. Nếu chưa được, gửi thông báo lỗi và ảnh bảng/phân trang, không cần gửi mật khẩu.
