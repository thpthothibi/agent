@echo off
chcp 65001 >nul
title Cai dat & Chay Ung Dung Desktop AI Agent Ky Thay Hang Loat
echo ============================================================================
echo   UNG DUNG DESKTOP AI AGENT KY THAY HANG LOAT - THPT HO THI BI
echo ============================================================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] May tinh chua cai Python.
    echo Dang chuyen sang che do Chay Ngay Tren Chrome/Edge khong can Python...
    call "%~dp01_Chay_Ngay_Tren_Windows_Khong_Can_Python.bat"
    exit /b 0
)

python -c "import playwright" >nul 2>nul
if %errorlevel% neq 0 (
    echo [*] Lan dau chay: Dang cai dat thu vien tu dong hoa Playwright...
    python -m pip install --upgrade pip playwright
    python -m playwright install chromium
)

echo [OK] Dang khoi dong giao dien Desktop AI Agent...
python "%~dp0ai_agent_ky_thay_win.py"
pause
