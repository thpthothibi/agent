@echo off
chcp 65001 >nul
title Khoi dong Chrome voi AI Agent Ky Thay Hang Loat - THPT Ho Thi Bi
echo ============================================================================
echo   AI AGENT KY THAY HANG LOAT - SO DAU BAI THPT HO THI BI
echo   (Chay truc tiep tren Windows khong can cai Python)
echo ============================================================================
echo.

set "EXT_DIR=%~dp0Tien_Ich_Chrome_Extension"
set "PROFILE_DIR=%~dp0Du_Lieu_Trinh_Duyet_SDB"
set "TARGET_URL=https://thpthothibi.github.io/sodaubai/"

:: Tim duong dan Google Chrome tren Windows
set "CHROME_PATH="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME_PATH=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME_PATH=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME_PATH=%LocalAppData%\Google\Chrome\Application\chrome.exe"

if defined CHROME_PATH (
    echo [OK] Dang mo Google Chrome tich hop san AI Agent Ky Thay...
    start "" "%CHROME_PATH%" --user-data-dir="%PROFILE_DIR%" --load-extension="%EXT_DIR%" "%TARGET_URL%"
    exit /b 0
)

:: Du phong: Dung Microsoft Edge co san tren Windows 10/11
set "EDGE_PATH="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE_PATH=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE_PATH=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if defined EDGE_PATH (
    echo [OK] Dang mo Microsoft Edge tich hop san AI Agent Ky Thay...
    start "" "%EDGE_PATH%" --user-data-dir="%PROFILE_DIR%" --load-extension="%EXT_DIR%" "%TARGET_URL%"
    exit /b 0
)

echo [!] Khong tim thay duong dan Chrome/Edge mac dinh.
echo Ban hay mo Chrome -> vao chrome://extensions -> Bat Developer mode -> Load unpacked -> chon thu muc Tien_Ich_Chrome_Extension.
pause
