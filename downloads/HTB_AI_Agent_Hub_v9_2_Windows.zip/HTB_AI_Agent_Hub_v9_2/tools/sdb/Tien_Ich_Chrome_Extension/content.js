// ==UserScript==
// @name         AI Agent Ký Thay Hàng Loạt v2.3 - SĐB THPT Hồ Thị Bi
// @namespace    https://thpthothibi.github.io/sodaubai/
// @version      2.3.0
// @description  Tự động chọn môn (có tích chọn từng môn), tạo danh sách, phân bổ PPCT thông minh (1 tiết & 2 tiết/tuần, xử lý lớp đã ký Tiết 1), tự động bỏ chọn lớp có HS vắng/ngoại lệ, cảnh báo thiếu PPCT, nhập PIN 080888 và xuất file Audit CSV.
// @author       Đào Hoàng Hải - THPT Hồ Thị Bi
// @match        https://thpthothibi.github.io/sodaubai/*
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const DEFAULT_PIN = "";
  let isRunning = false;
  let stopRequested = false;
  const auditRecords = [];

  // =========================================================================
  // 1. TIỆN ÍCH TƯƠNG TÁC DOM & CHUẨN HÓA SỰ KIỆN
  // =========================================================================
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function normalizeText(str) {
    return (str || '').replace(/\s+/g, ' ').trim();
  }

  function setNativeValue(element, value) {
    if (!element) return;
    const prototype =
      element instanceof HTMLSelectElement
        ? window.HTMLSelectElement.prototype
        : element instanceof HTMLTextAreaElement
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
    if (descriptor && descriptor.set) {
      descriptor.set.call(element, value);
    } else {
      element.value = value;
    }
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function clickElement(el) {
    if (!el) return false;
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.click();
    return true;
  }

  function setCheckboxState(cb, shouldCheck) {
    if (!cb || cb.disabled) return;
    if (cb.checked !== shouldCheck) {
      cb.click();
      if (cb.checked !== shouldCheck) {
        cb.checked = shouldCheck;
        cb.dispatchEvent(new Event('input', { bubbles: true }));
        cb.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
  }

  // =========================================================================
  // 2. BỘ ĐỊNH VỊ CÁC PHẦN TỬ TRÊN GIAO DIỆN SỔ ĐẦU BÀI
  // =========================================================================

  function findProgramSelect() {
    const exact = document.getElementById('batchProgramV704645');
    if (exact) return exact;
    const selects = Array.from(document.querySelectorAll('select'));
    for (const sel of selects) {
      const firstOptText = normalizeText(sel.options[0]?.textContent || '');
      if (
        firstOptText.includes('Chọn chương trình') ||
        firstOptText.includes('-- Chọn chương trình --')
      ) {
        return sel;
      }
    }
    const labels = Array.from(document.querySelectorAll('label, div, span'));
    for (const lbl of labels) {
      if (normalizeText(lbl.textContent).startsWith('Chương trình / môn')) {
        const container = lbl.closest('div')?.parentElement || lbl.parentElement;
        const sel = container?.querySelector('select');
        if (sel) return sel;
      }
    }
    return null;
  }

  function getCurrentWeekValue() {
    const exact = document.getElementById('batchWeekV704645');
    if (exact) return exact.value;
    const labels = Array.from(document.querySelectorAll('label, div, span'));
    for (const lbl of labels) {
      if (normalizeText(lbl.textContent).startsWith('Tuần')) {
        const inp = lbl.parentElement?.querySelector('input');
        if (inp && inp.value) return inp.value.trim();
      }
    }
    return '';
  }

  function findDefaultFallbackContentInput() {
    const inputs = Array.from(document.querySelectorAll('input[type="text"], input:not([type])'));
    for (const inp of inputs) {
      const ph = normalizeText(inp.placeholder || '');
      if (ph.includes('nội dung dự phòng') || ph.includes('KHBD')) {
        return inp;
      }
    }
    return null;
  }

  function findButtonByText(textFragment, exact = false) {
    const target = textFragment.toLowerCase();
    const buttons = Array.from(
      document.querySelectorAll('button, input[type="button"], input[type="submit"], a.btn')
    );
    for (const btn of buttons) {
      if (btn.offsetParent === null) continue;
      const txt = normalizeText(btn.textContent || btn.value).toLowerCase();
      if (exact ? txt === target : txt.includes(target)) {
        return btn;
      }
    }
    return null;
  }

  function findLessonTable() {
    const exact = document.getElementById('batchPreviewBodyV704645')?.closest('table');
    if (exact) return exact;
    const tables = Array.from(document.querySelectorAll('table'));
    for (const tbl of tables) {
      const headerText = normalizeText(tbl.querySelector('thead')?.textContent || '');
      if (
        headerText.includes('Lớp') &&
        headerText.includes('Ngày / Tiết') &&
        headerText.includes('Nội dung')
      ) {
        return tbl;
      }
    }
    return document.querySelector('table');
  }

  function findConfirmModal() {
    const exact = document.getElementById('modalBatchSignV704645');
    if (exact) return exact.classList.contains('show') ? exact : null;
    const allElements = Array.from(document.querySelectorAll('div, section, dialog'));
    for (const el of allElements) {
      if (el.offsetParent === null) continue;
      const txt = normalizeText(el.textContent);
      if (
        txt.includes('XÁC NHẬN KÝ THAY HÀNG LOẠT') &&
        txt.includes('PIN ký thay') &&
        txt.includes('XÁC NHẬN & KÝ')
      ) {
        const inputs = el.querySelectorAll('input');
        const buttons = el.querySelectorAll('button');
        if (inputs.length >= 2 && buttons.length >= 1) {
          return el;
        }
      }
    }
    return null;
  }

  // =========================================================================
  // 3. LOGIC XỬ LÝ BẢNG TIẾT HỌC THÔNG MINH (5 TÍNH NĂNG BẢO VỆ)
  // =========================================================================

  function extractClassName(row) {
    const classCell = row.cells?.[1];
    if (!classCell) return '';
    const strongEl = classCell.querySelector('strong, b, div, span');
    if (strongEl && normalizeText(strongEl.textContent)) {
      const token = normalizeText(strongEl.textContent).split(' ')[0];
      if (/^\d{2}[A-Z]\d+/i.test(token)) return token.toUpperCase();
    }
    const raw = normalizeText(classCell.textContent);
    const match = raw.match(/\b(10|11|12)[A-Z0-9]+\b/i);
    return match ? match[0].toUpperCase() : raw.split(' ')[0];
  }

  // Phân tích Ngày / Tiết để sắp xếp đúng thứ tự thời gian trong tuần
  function extractDatePeriodSortKey(row) {
    const cellText = normalizeText(row.cells?.[2]?.textContent || '');
    const dateMatch = cellText.match(/\d{4}-\d{2}-\d{2}/);
    const localDate = cellText.match(/(\d{2})[/-](\d{2})[/-](\d{4})/);
    const datePart = dateMatch ? dateMatch[0] : localDate ? `${localDate[3]}-${localDate[2]}-${localDate[1]}` : '9999-99-99';
    const sessionOrder = cellText.includes('Sáng') ? '1' : cellText.includes('Chiều') ? '2' : '3';
    const periodMatch = cellText.match(/Tiết\s*(\d+)/i);
    const periodNum = periodMatch ? periodMatch[1].padStart(2, '0') : '99';
    return `${datePart}_${sessionOrder}_${periodNum}`;
  }

  // Kiểm tra số học sinh vắng ở cột "Sĩ số / Vắng" (VD: "45 / 0" -> 0, "45 / 2" -> 2)
  function extractAbsentCount(row) {
    const attText = normalizeText(row.cells?.[6]?.textContent || '');
    const slashMatch = attText.match(/(\d+)\s*\/\s*(\d+)/);
    if (slashMatch) {
      return parseInt(slashMatch[2], 10) || 0;
    }
    if (/vắng\s*[1-9]\d*/i.test(attText)) {
      const m = attText.match(/vắng\s*(\d+)/i);
      return m ? parseInt(m[1], 10) : 1;
    }
    return 0;
  }

  // Kiểm tra xem dòng tiết học đã được ký trước đó chưa
  function isRowAlreadySigned(row) {
    const statusText = normalizeText(row.cells?.[8]?.textContent || row.textContent || '').toLowerCase();
    const cb = row.cells?.[0]?.querySelector('input[type="checkbox"]');
    if (statusText.includes('đã ký') || statusText.includes('hoàn thành')) return true;
    if (cb && cb.disabled && !statusText.includes('sẵn sàng')) return true;
    return false;
  }

  function getLessonRows() {
    const table = findLessonTable();
    if (!table) return [];
    const tbody = table.querySelector('tbody') || table;
    const rows = Array.from(tbody.querySelectorAll('tr'));
    return rows.filter((tr) => {
      const cb = tr.querySelector('input[type="checkbox"]');
      return cb && tr.cells && tr.cells.length >= 6;
    });
  }

  async function processLessonRows(options, logFn) {
    const {
      skipAbsent = true,
      excludedClasses = [],
      fallbackContent = '',
    } = options || {};

    const excludedSet = new Set(
      excludedClasses.map((c) => c.trim().toUpperCase()).filter(Boolean)
    );

    const rows = getLessonRows();
    if (rows.length === 0) {
      logFn('⚠️ Bảng chưa có dòng tiết học nào.');
      return {
        classesCount: 0,
        maxPeriods: 0,
        updatedCount: 0,
        readyCount: 0,
        skippedList: [],
        missingPpctWarning: false,
      };
    }

    // Nhóm các dòng theo từng Lớp
    const classGroups = new Map();
    for (const row of rows) {
      const className = extractClassName(row);
      if (!className) continue;
      if (!classGroups.has(className)) {
        classGroups.set(className, []);
      }
      classGroups.get(className).push(row);
    }

    // Xác định số tiết tối đa của 1 lớp trong bảng (1 tiết/tuần hay 2 tiết/tuần)
    const maxPeriodsInTable =
      classGroups.size > 0
        ? Math.max(...Array.from(classGroups.values()).map((r) => r.length))
        : 1;

    // Nếu người dùng có cấu hình Nội dung dự phòng ở mục 2 trên trang
    if (fallbackContent) {
      const pageFallbackInput = findDefaultFallbackContentInput();
      if (pageFallbackInput && pageFallbackInput.value !== fallbackContent) {
        setNativeValue(pageFallbackInput, fallbackContent);
      }
    }

    let updatedCount = 0;
    let readyCount = 0;
    let missingPpctCount = 0;
    const skippedList = [];

    for (const [className, rawClassRows] of classGroups.entries()) {
      if (stopRequested) break;

      // Sắp xếp các dòng của lớp theo đúng thứ tự Ngày / Buổi / Tiết trong tuần
      const classRows = [...rawClassRows].sort((a, b) =>
        extractDatePeriodSortKey(a).localeCompare(extractDatePeriodSortKey(b))
      );
      const periodsCount = classRows.length;

      for (let i = 0; i < periodsCount; i++) {
        const row = classRows[i];
        const rowCheckbox = row.cells[0]?.querySelector('input[type="checkbox"]');
        const periodInput = row.cells[4]?.querySelector('input');
        const contentSelect =
          row.cells[5]?.querySelector('select') || row.querySelector('select');
        const customContentInput = row.cells[5]?.querySelector('input[type="text"], input:not([type])');

        // 1. Kiểm tra điều kiện BỎ QUA (Lớp nằm trong danh sách loại trừ hoặc có HS vắng)
        const isExcludedClass = excludedSet.has(className);
        const absentCount = extractAbsentCount(row);

        if (isExcludedClass) {
          setCheckboxState(rowCheckbox, false);
          skippedList.push(`${className} (loại trừ)`);
          continue;
        }

        if (skipAbsent && absentCount > 0) {
          setCheckboxState(rowCheckbox, false);
          skippedList.push(`${className} (vắng ${absentCount})`);
          continue;
        }

        if (isRowAlreadySigned(row)) {
          continue;
        }

        // Mỗi lớp có thứ tự riêng, bao gồm cả dòng đã ký để giữ đúng tiết 2.
        // Không suy đoán tiết 2 từ ô Tiết CT có sẵn hoặc số tiết của lớp khác.
        const validOptions = contentSelect ? Array.from(contentSelect.options).filter(opt => {
          const text = normalizeText(opt.textContent);
          return !opt.disabled && opt.value !== '' && text &&
            !/chọn khbd|nhập thực tế|^[—–-]/i.test(text);
        }).sort((a, b) => {
          const number = opt => Number(normalizeText(opt.textContent).match(/(?:PPCT|tiết(?: CT)?)\s*[:#-]?\s*(\d+)/i)?.[1] ?? Infinity);
          return number(a) - number(b);
        }) : [];

        let ready = false;
        if (validOptions.length) {
          // Lớp 1 tiết -> bài đầu; lớp 2 tiết -> bài đầu, bài thứ hai.
          // Thiếu bài thứ hai thì dừng, không dùng lại bài cuối.
          const target = validOptions[i];
          if (target && !contentSelect.disabled) {
            if (contentSelect.value !== target.value) {
              setNativeValue(contentSelect, target.value);
              updatedCount++;
              await sleep(80);
            }
            ready = contentSelect.value === target.value;
          }
        } else if (fallbackContent && customContentInput && !customContentInput.disabled) {
          setNativeValue(customContentInput, fallbackContent);
          // Nội dung dự phòng chỉ dùng khi đã có Tiết CT; không tự bịa PPCT.
          ready = !!normalizeText(periodInput?.value);
          if (ready) updatedCount++;
        } else if (!contentSelect) {
          ready = !!normalizeText(customContentInput?.value) && !!normalizeText(periodInput?.value);
        }

        if (!ready) {
          setCheckboxState(rowCheckbox, false);
          missingPpctCount++;
          logFn(`⚠️ ${className}: thiếu bài KHBD cho tiết thứ ${i + 1} của lớp.`);
          continue;
        }
        setCheckboxState(rowCheckbox, true);
        if (rowCheckbox && rowCheckbox.checked && !rowCheckbox.disabled) readyCount++;

      }
    }

    if (skippedList.length > 0) {
      logFn(`🛡️ Đã tự động bỏ chọn ${skippedList.length} tiết: ${skippedList.join(', ')}`);
    }

    if (missingPpctCount > 0) {
      logFn(
        `⚠️ CẢNH BÁO: Có ${missingPpctCount} tiết chưa có KHBD/PPCT trên hệ thống (và chưa nhập Nội dung dự phòng)!`
      );
      return {
        classesCount: classGroups.size,
        maxPeriods: maxPeriodsInTable,
        updatedCount,
        readyCount: 0,
        skippedList,
        missingPpctWarning: true,
      };
    }

    if (maxPeriodsInTable >= 2) {
      logFn(
        `✅ Môn ${maxPeriodsInTable} tiết/tuần (${classGroups.size} lớp): Đã gán Tiết 1 -> mục 1, Tiết 2 -> mục 2 (${updatedCount} tiết cập nhật, ${readyCount} tiết sẵn sàng ký).`
      );
    } else {
      logFn(
        `✅ Môn 1 tiết/tuần (${classGroups.size} lớp): Đã kiểm tra ${readyCount} tiết sẵn sàng ký.`
      );
    }

    return {
      classesCount: classGroups.size,
      maxPeriods: maxPeriodsInTable,
      updatedCount,
      readyCount,
      skippedList,
      missingPpctWarning: false,
    };
  }

  // =========================================================================
  // 4. LOGIC MỞ HỘP THOẠI XÁC NHẬN, ĐIỀN PIN 080888 & KÝ THAY
  // =========================================================================

  async function confirmAndSignModal(pinCode, logFn) {
    if (stopRequested) return false;
    const signAllBtn = document.getElementById('btnBatchSignV704645') || findButtonByText('KÝ THAY TẤT CẢ TIẾT ĐÃ CHỌN');
    if (!signAllBtn) {
      logFn('❌ Không tìm thấy nút "KÝ THAY TẤT CẢ TIẾT ĐÃ CHỌN".');
      return false;
    }
    if (signAllBtn.disabled) {
      logFn('ℹ️ Nút "KÝ THAY TẤT CẢ TIẾT ĐÃ CHỌN" đang khóa.');
      return false;
    }

    const expectedCount = getLessonRows().filter(r => { const cb = r.querySelector('input[type="checkbox"]'); return cb?.checked && !cb.disabled; }).length;
    const resultBox = document.getElementById('batchResultV704645');
    const previousResult = resultBox?.innerHTML || '';
    logFn('👉 Bấm "KÝ THAY TẤT CẢ TIẾT ĐÃ CHỌN"...');
    clickElement(signAllBtn);

    let modal = null;
    for (let attempt = 0; attempt < 25; attempt++) {
      await sleep(200);
      modal = findConfirmModal();
      if (modal) break;
    }

    if (!modal) {
      logFn('⚠️ Không thấy hộp thoại xác nhận hiện ra.');
      return false;
    }

    await sleep(250);

    const pinInput =
      modal.querySelector('input[type="password"]') ||
      Array.from(modal.querySelectorAll('input')).find(
        (inp) => inp.type !== 'checkbox' && inp.type !== 'radio'
      );

    if (!pinInput) {
      logFn('❌ Không tìm thấy ô nhập mã PIN trong hộp thoại xác nhận.');
      return false;
    }

    setNativeValue(pinInput, pinCode);
    logFn('🔑 Đã nhập mã PIN.');
    await sleep(200);

    const confirmCheckbox = modal.querySelector('input[type="checkbox"]');
    if (confirmCheckbox && !confirmCheckbox.checked) {
      clickElement(confirmCheckbox);
      if (!confirmCheckbox.checked) {
        confirmCheckbox.checked = true;
        confirmCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
      }
      logFn('☑️ Đã tích ô "Tôi xác nhận..."');
      await sleep(200);
    }

    const submitBtn = Array.from(modal.querySelectorAll('button')).find((btn) =>
      normalizeText(btn.textContent).toUpperCase().includes('XÁC NHẬN & KÝ')
    );

    if (!submitBtn) {
      logFn('❌ Không tìm thấy nút "XÁC NHẬN & KÝ".');
      return false;
    }

    logFn('🚀 Bấm "XÁC NHẬN & KÝ" — đang lưu Sổ đầu bài...');
    if (stopRequested || submitBtn.disabled) return false;
    clickElement(submitBtn);

    for (let waitStep = 0; waitStep < 400; waitStep++) {
      await sleep(500);
      if (!findConfirmModal()) {
        const box = document.getElementById('batchResultV704645');
        const text = normalizeText(box?.textContent || '');
        const count = Number(text.match(/(\d+)\s+tiết thành công/i)?.[1] || 0);
        if (box && box.innerHTML !== previousResult && box.querySelector('.alert-success') && count === expectedCount) {
          logFn(`🎉 Đã xác nhận ${count} tiết ký thành công.`);
          await sleep(800);
          return true;
        }
        logFn('⚠️ Chưa xác nhận đủ số tiết ký thành công. Dừng để kiểm tra kết quả trên trang.');
        return false;
      }
    }

    logFn('⏳ Hộp thoại mở quá lâu, vui lòng kiểm tra thông báo trên màn hình.');
    return false;
  }

  // =========================================================================
  // 5. XUẤT FILE NHẬT KÝ ĐỐI CHIẾU (AUDIT LOG CSV)
  // =========================================================================

  function recordAuditEntry(entry) {
    auditRecords.push({
      timestamp: new Date().toLocaleString('vi-VN', { hour12: false }),
      week: getCurrentWeekValue() || 'Hien_tai',
      program: entry.program || '',
      classesCount: entry.classesCount || 0,
      periodsPerWeek: entry.maxPeriods || 1,
      signedCount: entry.signedCount || 0,
      skippedInfo: (entry.skippedList || []).join('; ') || 'Khong',
      status: entry.status || '',
    });
    const exportBtn = document.getElementById('htb-btn-export-csv');
    if (exportBtn) {
      exportBtn.style.display = 'block';
      exportBtn.textContent = `📥 Tải Nhật ký đối chiếu (${auditRecords.length} môn) .CSV`;
    }
  }

  function downloadAuditCsv() {
    if (auditRecords.length === 0) {
      alert('Chưa có dữ liệu nhật ký ký thay trong phiên làm việc này.');
      return;
    }
    const headers = [
      'Thời gian',
      'Tuần',
      'Chương trình / Môn',
      'Số lớp',
      'Số tiết/tuần',
      'Số tiết đã ký',
      'Các lớp bỏ qua (Vắng / Ngoại lệ)',
      'Trạng thái',
    ];
    const escapeCsv = (val) => `"${String(val ?? '').replace(/"/g, '""')}"`;
    const lines = [headers.map(escapeCsv).join(',')];
    for (const r of auditRecords) {
      lines.push(
        [
          r.timestamp,
          r.week,
          r.program,
          r.classesCount,
          r.periodsPerWeek,
          r.signedCount,
          r.skippedInfo,
          r.status,
        ]
          .map(escapeCsv)
          .join(',')
      );
    }
    // UTF-8 BOM để mở trực tiếp bằng Microsoft Excel trên Windows không lỗi font tiếng Việt
    const csvContent = '\uFEFF' + lines.join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStr = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `Nhat_Ky_Ky_Thay_SDB_Tuan_${getCurrentWeekValue() || 'HTB'}_${dateStr}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // =========================================================================
  // 6. QUY TRÌNH CHẠY THEO DANH SÁCH MÔN ĐÃ TÍCH CHỌN
  // =========================================================================

  function findLoadListButton() {
    return document.querySelector('button[onclick="xemTruocKyThayHangLoatV704645()"]') ||
      findButtonByText('Tải danh sách') || findButtonByText('Tạo danh sách');
  }

  async function waitForListIdle(logFn, timeoutMs = 70000) {
    const start = Date.now();
    let idleSince = null;
    let announced = false;
    while (Date.now() - start < timeoutMs) {
      if (stopRequested) throw new Error('Đã dừng theo yêu cầu.');
      // Lấy lại phần tử mỗi vòng vì trang có thể dựng lại giao diện.
      const button = findLoadListButton();
      const body = document.getElementById('batchPreviewBodyV704645') || findLessonTable()?.querySelector('tbody');
      const busy = !button || button.disabled || !!body?.querySelector('.spinner-border, [aria-busy="true"]') ||
        /đang tải/i.test(normalizeText(body?.textContent));
      if (busy) {
        idleSince = null;
        if (!announced) {
          logFn('⏳ Trang đang làm mới danh sách môn trước. Đang chờ nút tải mở lại...');
          announced = true;
        }
      } else {
        if (idleSince === null) idleSince = Date.now();
        // Chờ trạng thái rảnh ổn định, không đổi môn khi yêu cầu trước chưa xong.
        if (Date.now() - idleSince >= 600) return button;
      }
      await sleep(200);
    }
    throw new Error('Trang chưa tải xong sau 70 giây. Chưa gửi thêm yêu cầu tải hoặc ký.');
  }

  async function loadProgramList(value, logFn) {
    // completeBatch trên trang tự tải lại danh sách ngay sau khi đóng hộp ký.
    // Phải chờ lượt đó hoàn tất TRƯỚC khi đổi chương trình.
    await waitForListIdle(logFn);
    const select = findProgramSelect();
    if (!select) throw new Error('Không tìm thấy Chương trình / môn.');
    if (value !== undefined) setNativeValue(select, value);
    if (!select.value) throw new Error('Chưa chọn chương trình.');
    const expectedProgram = select.value;
    const expectedWeek = getCurrentWeekValue();
    const gradeSnapshot = () => Array.from(document.querySelectorAll('.batch-grade-v704645:checked')).map(x => x.value).join(',');
    const expectedGrades = gradeSnapshot();
    await sleep(300);
    const button = await waitForListIdle(logFn);
    if (findProgramSelect()?.value !== expectedProgram || getCurrentWeekValue() !== expectedWeek || gradeSnapshot() !== expectedGrades)
      throw new Error('Bộ lọc đã thay đổi trong khi chờ, dừng trước khi tải.');
    const body = document.getElementById('batchPreviewBodyV704645') || findLessonTable()?.querySelector('tbody');
    if (!body) throw new Error('Không tìm thấy bảng danh sách tiết.');
    let changed = false;
    const observer = new MutationObserver(() => { changed = true; });
    observer.observe(body, {childList: true, subtree: true, characterData: true});
    try {
      logFn('⏳ Đang tải danh sách lớp và tiết, chờ tải xong...');
      clickElement(button);
      const start = Date.now();
      let signature = '', stableSince = Date.now();
      while (Date.now() - start < 65000) {
        if (stopRequested) throw new Error('Đã dừng theo yêu cầu.');
        await sleep(200);
        if (findProgramSelect()?.value !== expectedProgram || getCurrentWeekValue() !== expectedWeek || gradeSnapshot() !== expectedGrades)
          throw new Error('Bộ lọc đã thay đổi trong khi tải, dừng ký.');
        const currentBody = document.getElementById('batchPreviewBodyV704645') || body;
        const text = normalizeText(currentBody.textContent);
        const loading = (findLoadListButton()?.disabled ?? true) || !!currentBody.querySelector('.spinner-border, [aria-busy="true"]') || /đang tải/i.test(text);
        const current = currentBody.innerHTML;
        if (loading || current !== signature) { signature = current; stableSince = Date.now(); }
        if (changed && !loading && Date.now() - stableSince >= 900) {
          if (/không có tiết phù hợp/i.test(text)) return false;
          if (/không tải|quá lâu|lựa chọn đã thay đổi|lỗi/i.test(text) && !getLessonRows().length)
            throw new Error(text);
          if (getLessonRows().length) {
            logFn(`✅ Đã tải xong ${getLessonRows().length} dòng lớp/tiết.`);
            return true;
          }
        }
      }
      throw new Error('Hết thời gian chờ tải danh sách; dừng trước khi ký.');
    } finally { observer.disconnect(); }
  }

  async function runSingleCurrentProgram(config, logFn) {
    const progSelect = findProgramSelect();
    const progName = normalizeText(progSelect?.selectedOptions[0]?.textContent || '');
    if (!await loadProgramList(undefined, logFn)) { logFn('Không có tiết phù hợp.'); return; }
    if (stopRequested) return;

    const stats = await processLessonRows(config, logFn);
    if (stats.missingPpctWarning) {
      recordAuditEntry({
        program: progName,
        ...stats,
        signedCount: 0,
        status: 'Bỏ qua (Chưa có PPCT trên hệ thống)',
      });
      return;
    }

    if (stats.readyCount === 0) {
      logFn('ℹ️ Không có tiết nào cần ký thay.');
      recordAuditEntry({
        program: progName,
        ...stats,
        signedCount: 0,
        status: 'Không có tiết cần ký',
      });
      return;
    }

    if (stopRequested) return;
    const ok = await confirmAndSignModal(config.pinCode, logFn);
    recordAuditEntry({
      program: progName,
      ...stats,
      signedCount: ok ? stats.readyCount : 0,
      status: ok ? 'Đã ký thành công' : 'Chưa hoàn tất xác nhận',
    });
  }

  async function runSelectedPrograms(config, selectedValues, logFn) {
    const progSelect = findProgramSelect();
    if (!progSelect) {
      logFn('❌ Không tìm thấy ô "Chương trình / môn". Hãy mở tab Ký thay hàng loạt.');
      return;
    }

    const createListBtn = findLoadListButton();
    if (!createListBtn) {
      logFn('❌ Không tìm thấy nút "Tạo danh sách".');
      return;
    }

    const allValidOptions = Array.from(progSelect.options).filter((opt, idx) => {
      const txt = normalizeText(opt.textContent);
      return idx > 0 && txt && !txt.includes('Chọn chương trình');
    });

    const targetOptions =
      Array.isArray(selectedValues)
        ? allValidOptions.filter(
            (opt) =>
              selectedValues.includes(opt.value) ||
              selectedValues.includes(normalizeText(opt.textContent))
          )
        : allValidOptions;

    if (targetOptions.length === 0) {
      logFn('⚠️ Bạn chưa tích chọn môn nào để chạy.');
      return;
    }

    logFn(`📋 Bắt đầu chạy tự động cho ${targetOptions.length} chương trình/môn đã chọn...`);

    for (let i = 0; i < targetOptions.length; i++) {
      if (stopRequested) {
        logFn('🛑 Đã dừng theo yêu cầu người dùng.');
        break;
      }

      const opt = targetOptions[i];
      const progName = normalizeText(opt.textContent);
      logFn(`\n==============================`);
      logFn(`▶️ [${i + 1}/${targetOptions.length}] Môn: ${progName}`);

      if (!await loadProgramList(opt.value, logFn)) {
        logFn(`⏭️ ${progName}: không có tiết phù hợp.`);
        continue;
      }

      if (stopRequested) break;

      const stats = await processLessonRows(config, logFn);
      if (stats.missingPpctWarning) {
        logFn(`⏭️ Bỏ qua môn "${progName}" do chưa có PPCT trên hệ thống.`);
        recordAuditEntry({
          program: progName,
          ...stats,
          signedCount: 0,
          status: 'Bỏ qua (Chưa có PPCT)',
        });
        continue;
      }

      if (stats.readyCount === 0) {
        logFn(`⏭️ Môn "${progName}" không còn tiết cần ký. Chuyển môn tiếp theo...`);
        recordAuditEntry({
          program: progName,
          ...stats,
          signedCount: 0,
          status: 'Không còn tiết cần ký',
        });
        continue;
      }

      await sleep(300);
      if (stopRequested) break;

      const ok = await confirmAndSignModal(config.pinCode, logFn);
      recordAuditEntry({
        program: progName,
        ...stats,
        signedCount: ok ? stats.readyCount : 0,
        status: ok ? 'Đã ký thành công' : 'Chưa hoàn tất xác nhận',
      });
      if (!ok) throw new Error('Chưa xác nhận được kết quả ký; dừng trước khi chuyển môn.');
      await sleep(800);
    }

    logFn('\n✅ HOÀN TẤT QUY TRÌNH KÝ THAY HÀNG LOẠT!');
    logFn('📊 Bạn có thể bấm nút "📥 Tải Nhật ký đối chiếu .CSV" bên dưới để lưu báo cáo.');
  }

  // =========================================================================
  // 7. GIAO DIỆN ĐIỀU KHIỂN NỔI V2.0 (FLOATING AI AGENT PANEL)
  // =========================================================================

  function buildAgentPanel() {
    const existing = document.getElementById('htb-ai-agent-panel');
    if (existing) existing.remove();

    const panel = document.createElement('div');
    panel.id = 'htb-ai-agent-panel';
    panel.style.cssText = `
      position: fixed;
      bottom: 16px;
      right: 16px;
      width: 380px;
      max-height: 92vh;
      background: #ffffff;
      border: 2px solid #1e40af;
      border-radius: 14px;
      box-shadow: 0 14px 36px rgba(15, 23, 42, 0.26);
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      z-index: 999999;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      color: #1e293b;
    `;

    panel.innerHTML = `
      <div id="htb-agent-header" style="
        background: linear-gradient(135deg, #1e3a8a, #2563eb);
        color: #ffffff;
        padding: 10px 14px;
        font-weight: 700;
        font-size: 13.5px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        user-select: none;
      ">
        <span>🤖 AI Agent Ký Thay Hàng Loạt v2.3</span>
        <button id="htb-agent-minimize" title="Thu gọn / Mở rộng" style="
          background: rgba(255,255,255,0.2);
          border: none;
          color: #fff;
          border-radius: 6px;
          padding: 2px 8px;
          cursor: pointer;
          font-weight: bold;
        ">−</button>
      </div>

      <div id="htb-agent-body" style="padding: 12px 14px; display: flex; flex-direction: column; gap: 9px; overflow-y: auto;">
        <!-- PIN & Tùy chọn bảo vệ -->
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px;">
          <label style="font-size: 12.5px; font-weight: 600; color: #334155;">PIN ký thay (6 số):</label>
          <input id="htb-agent-pin" type="text" value="${DEFAULT_PIN}" maxlength="6" style="
            width: 105px;
            padding: 4px 8px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 2px;
            text-align: center;
            color: #0f172a;
          " />
        </div>

        <!-- Danh sách môn tích chọn -->
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 10px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
            <span style="font-size: 12px; font-weight: 700; color: #1e293b;">1. Chọn môn cần ký tự động:</span>
            <button id="htb-btn-refresh-progs" style="
              background: none;
              border: none;
              color: #2563eb;
              font-size: 11px;
              font-weight: 600;
              cursor: pointer;
              padding: 0;
            ">🔄 Làm mới</button>
          </div>
          <div id="htb-program-checklist" style="display: flex; flex-direction: column; gap: 4px; max-height: 105px; overflow-y: auto; font-size: 12px;">
          </div>
        </div>

        <!-- Bộ lọc bảo vệ an toàn -->
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 10px; display: flex; flex-direction: column; gap: 6px;">
          <span style="font-size: 12px; font-weight: 700; color: #1e293b;">2. Chế độ bảo vệ chống ký nhầm:</span>

          <label style="display: flex; align-items: center; gap: 6px; font-size: 12px; color: #334155; cursor: pointer;">
            <input id="htb-chk-skip-absent" type="checkbox" checked />
            <span>Tự động bỏ chọn lớp có <b>học sinh vắng (&gt; 0)</b></span>
          </label>

          <div style="display: flex; flex-direction: column; gap: 3px;">
            <label style="font-size: 11.5px; color: #475569;">Lớp ngoại lệ cần chừa lại (VD: 10A02, 11A05):</label>
            <input id="htb-inp-excluded" type="text" placeholder="Để trống nếu ký tất cả lớp" style="
              padding: 4px 8px;
              border: 1px solid #cbd5e1;
              border-radius: 6px;
              font-size: 12px;
            " />
          </div>

          <div style="display: flex; flex-direction: column; gap: 3px;">
            <label style="font-size: 11.5px; color: #475569;">Nội dung dự phòng (nếu môn chưa có PPCT):</label>
            <input id="htb-inp-fallback" type="text" placeholder="Để trống = Cảnh báo & bỏ qua môn thiếu PPCT" style="
              padding: 4px 8px;
              border: 1px solid #cbd5e1;
              border-radius: 6px;
              font-size: 12px;
            " />
          </div>
        </div>

        <!-- Các nút hành động -->
        <div style="display: flex; flex-direction: column; gap: 6px;">
          <button id="htb-btn-run-all" style="
            background: #16a34a;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            padding: 9px 12px;
            font-weight: 700;
            font-size: 12.5px;
            cursor: pointer;
          ">⚡ KÝ TỰ ĐỘNG CÁC MÔN ĐÃ TÍCH CHỌN</button>

          <div style="display: flex; gap: 6px;">
            <button id="htb-btn-run-one" style="
              flex: 1;
              background: #2563eb;
              color: #ffffff;
              border: none;
              border-radius: 8px;
              padding: 7px 8px;
              font-weight: 600;
              font-size: 11.5px;
              cursor: pointer;
            ">🎯 Ký môn đang mở</button>

            <button id="htb-btn-fill-only" style="
              flex: 1;
              background: #0284c7;
              color: #ffffff;
              border: none;
              border-radius: 8px;
              padding: 7px 8px;
              font-weight: 600;
              font-size: 11.5px;
              cursor: pointer;
            ">📝 Chỉ điền PPCT</button>
          </div>

          <button id="htb-btn-export-csv" style="
            display: none;
            background: #4f46e5;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            padding: 7px 10px;
            font-weight: 600;
            font-size: 11.5px;
            cursor: pointer;
          ">📥 Tải Nhật ký đối chiếu (.CSV)</button>

          <button id="htb-btn-stop" style="
            display: none;
            background: #dc2626;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            padding: 7px 10px;
            font-weight: 700;
            font-size: 12px;
            cursor: pointer;
          ">🛑 DỪNG KHẨN CẤP</button>
        </div>

        <!-- Nhật ký trực tiếp -->
        <div id="htb-agent-log" style="
          background: #0f172a;
          color: #e2e8f0;
          font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
          font-size: 11px;
          padding: 8px 10px;
          border-radius: 8px;
          height: 125px;
          overflow-y: auto;
          white-space: pre-wrap;
          line-height: 1.45;
        ">Sẵn sàng (v2.3). Đã bật bảo vệ chống ký nhầm Tiết 1/2 & lọc lớp vắng.</div>
      </div>
    `;

    document.body.appendChild(panel);

    const logBox = document.getElementById('htb-agent-log');
    const pinInput = document.getElementById('htb-agent-pin');
    const chkSkipAbsent = document.getElementById('htb-chk-skip-absent');
    const inpExcluded = document.getElementById('htb-inp-excluded');
    const inpFallback = document.getElementById('htb-inp-fallback');
    const checklistEl = document.getElementById('htb-program-checklist');
    const btnRefreshProgs = document.getElementById('htb-btn-refresh-progs');
    const btnRunAll = document.getElementById('htb-btn-run-all');
    const btnRunOne = document.getElementById('htb-btn-run-one');
    const btnFillOnly = document.getElementById('htb-btn-fill-only');
    const btnExportCsv = document.getElementById('htb-btn-export-csv');
    const btnStop = document.getElementById('htb-btn-stop');
    const btnMinimize = document.getElementById('htb-agent-minimize');
    const bodyEl = document.getElementById('htb-agent-body');

    function populateProgramChecklist() {
      checklistEl.innerHTML = '';
      const progSelect = findProgramSelect();
      const defaultNames = [
        'Kỹ năng số - Kỹ năng số',
        'STEM - STEM',
        'TANC - TANC',
        'Tiếng anh bản ngữ - Tiếng Anh bản ngữ',
        'Tin học quốc tế - Tin học quốc tế',
      ];

      let items = [];
      if (progSelect && progSelect.options.length > 1) {
        items = Array.from(progSelect.options)
          .filter((opt, idx) => idx > 0 && normalizeText(opt.textContent))
          .map((opt) => ({
            value: opt.value,
            label: normalizeText(opt.textContent),
          }));
      } else {
        items = defaultNames.map((name) => ({ value: name, label: name }));
      }

      for (const item of items) {
        const lbl = document.createElement('label');
        lbl.style.cssText =
          'display: flex; align-items: center; gap: 6px; cursor: pointer; color: #334155;';
        lbl.innerHTML = `
          <input type="checkbox" class="htb-prog-cb" value="${item.value}" data-label="${item.label}" checked />
          <span>${item.label}</span>
        `;
        checklistEl.appendChild(lbl);
      }
    }

    populateProgramChecklist();
    btnRefreshProgs.addEventListener('click', populateProgramChecklist);

    function getCurrentConfig() {
      const excludedRaw = inpExcluded.value || '';
      const excludedClasses = excludedRaw
        .split(/[,;\s]+/)
        .map((s) => s.trim().toUpperCase())
        .filter(Boolean);
      return {
        pinCode: pinInput.value.trim() || DEFAULT_PIN,
        skipAbsent: chkSkipAbsent.checked,
        excludedClasses,
        fallbackContent: inpFallback.value.trim(),
      };
    }

    function getSelectedProgramValues() {
      const cbs = Array.from(checklistEl.querySelectorAll('.htb-prog-cb:checked'));
      return cbs.map((cb) => cb.value || cb.getAttribute('data-label'));
    }

    function appendLog(msg) {
      const time = new Date().toLocaleTimeString('vi-VN', { hour12: false });
      logBox.textContent += `\n[${time}] ${msg}`;
      logBox.scrollTop = logBox.scrollHeight;
    }

    function setBusyState(busy) {
      isRunning = busy;
      btnRunAll.disabled = busy;
      btnRunOne.disabled = busy;
      btnFillOnly.disabled = busy;
      btnRunAll.style.opacity = busy ? '0.6' : '1';
      btnRunOne.style.opacity = busy ? '0.6' : '1';
      btnFillOnly.style.opacity = busy ? '0.6' : '1';
      btnStop.style.display = busy ? 'block' : 'none';
    }

    btnMinimize.addEventListener('click', () => {
      const hidden = bodyEl.style.display === 'none';
      bodyEl.style.display = hidden ? 'flex' : 'none';
      btnMinimize.textContent = hidden ? '−' : '+';
    });

    btnStop.addEventListener('click', () => {
      stopRequested = true;
      appendLog('🛑 Đang yêu cầu dừng...');
    });

    btnExportCsv.addEventListener('click', downloadAuditCsv);

    btnRunAll.addEventListener('click', async () => {
      if (isRunning) return;
      populateProgramChecklistIfEmpty();
      stopRequested = false;
      logBox.textContent = '🚀 Bắt đầu chạy tự động các môn đã chọn...';
      setBusyState(true);
      try {
        const selected = getSelectedProgramValues();
        await runSelectedPrograms(getCurrentConfig(), selected, appendLog);
      } catch (err) {
        appendLog(`❌ Lỗi: ${err.message || err}`);
      } finally {
        setBusyState(false);
      }
    });

    function populateProgramChecklistIfEmpty() {
      if (checklistEl.querySelectorAll('.htb-prog-cb').length === 0) {
        populateProgramChecklist();
      }
    }

    btnRunOne.addEventListener('click', async () => {
      if (isRunning) return;
      stopRequested = false;
      logBox.textContent = '🎯 Bắt đầu xử lý môn đang mở...';
      setBusyState(true);
      try {
        await runSingleCurrentProgram(getCurrentConfig(), appendLog);
      } catch (err) {
        appendLog(`❌ Lỗi: ${err.message || err}`);
      } finally {
        setBusyState(false);
      }
    });

    btnFillOnly.addEventListener('click', async () => {
      if (isRunning) return;
      stopRequested = false;
      logBox.textContent = '📝 Đang phân bổ PPCT & lọc lớp vắng cho danh sách hiện tại...';
      setBusyState(true);
      try {
        await processLessonRows(getCurrentConfig(), appendLog);
      } catch (err) {
        appendLog(`❌ Lỗi: ${err.message || err}`);
      } finally {
        setBusyState(false);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', buildAgentPanel);
  } else {
    buildAgentPanel();
  }
})();
