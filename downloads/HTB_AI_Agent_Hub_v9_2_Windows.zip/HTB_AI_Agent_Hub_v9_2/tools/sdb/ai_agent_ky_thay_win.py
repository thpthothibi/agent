#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ỨNG DỤNG DESKTOP WINDOWS v2.3: AI AGENT KÝ THAY HÀNG LOẠT - SĐB THPT HỒ THỊ BI
Bản vá lỗi v2.3:
- Khắc phục triệt để lỗi không phản hồi khi bấm nút BƯỚC 2 / Ký môn đang mở / Chỉ điền PPCT
  (do Playwright đồng bộ yêu cầu chạy mọi lệnh trên cùng 1 luồng Worker duy nhất).
- Tự động quét tất cả các Frame (kể cả khi trang Sổ đầu bài nhúng trong thẻ <iframe>).
- Tự động chuyển sang tab "Điều hành -> Ký thay hàng loạt" nếu người dùng đang ở tab khác.
- Tích hợp đầy đủ 5 tính năng bảo vệ thực tế & Xuất nhật ký Excel (.CSV).
"""

import csv
import os
import sys
import time
import queue
import datetime
import traceback
import threading
import pathlib
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

TARGET_URL = "https://thpthothibi.github.io/sodaubai/"
DEFAULT_PIN = ""
BASE_DIR = pathlib.Path(__file__).resolve().parent
PROFILE_DIR = str(BASE_DIR / "Du_Lieu_Trinh_Duyet_SDB")
AUDIT_CSV_PATH = BASE_DIR / "Nhat_Ky_Ky_Thay_SDB.csv"


class SodaubaiAgentWinAppV21:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("AI Agent Ký Thay Hàng Loạt v2.3 - SĐB THPT Hồ Thị Bi (Windows)")
        self.root.geometry("770x690")
        self.root.minsize(720, 620)
        self.root.configure(bg="#f8fafc")

        # Hàng đợi lệnh dành cho luồng Playwright duy nhất (tránh lỗi Greenlet Thread Switching)
        self.cmd_queue = queue.Queue()
        self.stop_requested = False
        self.is_busy = False

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        # Khởi chạy luồng Worker Playwright duy nhất chạy ngầm suốt vòng đời ứng dụng
        self.worker_thread = threading.Thread(target=self._playwright_worker_loop, daemon=True)
        self.worker_thread.start()

    def _build_ui(self):
        header = tk.Frame(self.root, bg="#1e3a8a", padx=16, pady=11)
        header.pack(fill=tk.X)
        tk.Label(
            header,
            text="🤖 AI AGENT KÝ THAY HÀNG LOẠT v2.3 - THPT HỒ THỊ BI",
            font=("Segoe UI", 13, "bold"),
            fg="#ffffff",
            bg="#1e3a8a",
        ).pack(anchor="w")
        tk.Label(
            header,
            text="Đã khắc phục lỗi luồng bấm nút • Hỗ trợ đa khung (iframe) • Phân bổ Tiết 1/2 • Lọc lớp vắng • Xuất Excel",
            font=("Segoe UI", 9),
            fg="#dbeafe",
            bg="#1e3a8a",
        ).pack(anchor="w", pady=(2, 0))

        # 1. Phạm vi Tuần, Khối & Các Chương trình / Môn cần chạy
        cfg_frame = tk.LabelFrame(
            self.root,
            text=" 1. Phạm vi Tuần, Khối & Các Chương trình / Môn cần chạy ",
            font=("Segoe UI", 10, "bold"),
            bg="#ffffff",
            fg="#0f172a",
            padx=14,
            pady=8,
        )
        cfg_frame.pack(fill=tk.X, padx=14, pady=(10, 5))

        row1 = tk.Frame(cfg_frame, bg="#ffffff")
        row1.pack(fill=tk.X, pady=3)

        tk.Label(row1, text="Mã PIN ký thay (6 số):", font=("Segoe UI", 9, "bold"), bg="#ffffff").pack(side=tk.LEFT)
        self.pin_var = tk.StringVar(value=DEFAULT_PIN)
        tk.Entry(row1, textvariable=self.pin_var, font=("Segoe UI", 10, "bold"), width=9, justify="center").pack(
            side=tk.LEFT, padx=(6, 18)
        )

        tk.Label(row1, text="Tuần (trống = giữ nguyên):", font=("Segoe UI", 9), bg="#ffffff").pack(side=tk.LEFT)
        self.week_var = tk.StringVar(value="")
        tk.Entry(row1, textvariable=self.week_var, font=("Segoe UI", 10), width=6, justify="center").pack(
            side=tk.LEFT, padx=(6, 18)
        )

        tk.Label(row1, text="Khối:", font=("Segoe UI", 9, "bold"), bg="#ffffff").pack(side=tk.LEFT)
        self.k10_var = tk.BooleanVar(value=True)
        self.k11_var = tk.BooleanVar(value=True)
        self.k12_var = tk.BooleanVar(value=False)
        tk.Checkbutton(row1, text="Khối 10", variable=self.k10_var, font=("Segoe UI", 9), bg="#ffffff").pack(
            side=tk.LEFT, padx=4
        )
        tk.Checkbutton(row1, text="Khối 11", variable=self.k11_var, font=("Segoe UI", 9), bg="#ffffff").pack(
            side=tk.LEFT, padx=4
        )
        tk.Checkbutton(row1, text="Khối 12", variable=self.k12_var, font=("Segoe UI", 9), bg="#ffffff").pack(
            side=tk.LEFT, padx=4
        )

        prog_row = tk.Frame(cfg_frame, bg="#ffffff")
        prog_row.pack(fill=tk.X, pady=(6, 2))
        tk.Label(prog_row, text="Môn chạy:", font=("Segoe UI", 9, "bold"), bg="#ffffff").pack(side=tk.LEFT)

        self.prog_vars = {
            "Kỹ năng số": tk.BooleanVar(value=True),
            "STEM": tk.BooleanVar(value=True),
            "TANC": tk.BooleanVar(value=True),
            "Tiếng anh": tk.BooleanVar(value=True),
            "Tin học quốc tế": tk.BooleanVar(value=True),
        }
        for name, var in self.prog_vars.items():
            label_text = "Tiếng anh bản ngữ" if name == "Tiếng anh" else name
            tk.Checkbutton(prog_row, text=label_text, variable=var, font=("Segoe UI", 9), bg="#ffffff").pack(
                side=tk.LEFT, padx=6
            )

        # 2. Bộ lọc bảo vệ chống ký nhầm & Dự phòng thiếu KHBD
        safe_frame = tk.LabelFrame(
            self.root,
            text=" 2. Bộ lọc bảo vệ chống ký nhầm & Dự phòng thiếu KHBD ",
            font=("Segoe UI", 10, "bold"),
            bg="#ffffff",
            fg="#0f172a",
            padx=14,
            pady=8,
        )
        safe_frame.pack(fill=tk.X, padx=14, pady=5)

        srow1 = tk.Frame(safe_frame, bg="#ffffff")
        srow1.pack(fill=tk.X, pady=2)
        self.skip_absent_var = tk.BooleanVar(value=True)
        tk.Checkbutton(
            srow1,
            text="Tự động bỏ chọn lớp có học sinh vắng (cột Sĩ số / Vắng > 0) để không ghi đè thành điểm danh đủ",
            variable=self.skip_absent_var,
            font=("Segoe UI", 9, "bold"),
            fg="#1e40af",
            bg="#ffffff",
        ).pack(side=tk.LEFT)

        srow2 = tk.Frame(safe_frame, bg="#ffffff")
        srow2.pack(fill=tk.X, pady=3)
        tk.Label(
            srow2,
            text="Danh sách lớp ngoại lệ cần chừa lại (ngăn cách dấu phẩy, VD: 10A02, 11A05):",
            font=("Segoe UI", 9),
            bg="#ffffff",
        ).pack(side=tk.LEFT)
        self.excluded_classes_var = tk.StringVar(value="")
        tk.Entry(srow2, textvariable=self.excluded_classes_var, font=("Segoe UI", 9), width=28).pack(
            side=tk.LEFT, padx=(8, 0), fill=tk.X, expand=True
        )

        srow3 = tk.Frame(safe_frame, bg="#ffffff")
        srow3.pack(fill=tk.X, pady=3)
        tk.Label(
            srow3,
            text="Nội dung bài mặc định dự phòng (để trống = Tự động cảnh báo & bỏ qua môn chưa có PPCT):",
            font=("Segoe UI", 9),
            bg="#ffffff",
        ).pack(side=tk.LEFT)
        self.fallback_content_var = tk.StringVar(value="")
        tk.Entry(srow3, textvariable=self.fallback_content_var, font=("Segoe UI", 9), width=24).pack(
            side=tk.LEFT, padx=(8, 0), fill=tk.X, expand=True
        )

        # 3. Cụm nút điều khiển
        btn_frame = tk.LabelFrame(
            self.root,
            text=" 3. Điều khiển AI Agent ",
            font=("Segoe UI", 10, "bold"),
            bg="#ffffff",
            fg="#0f172a",
            padx=14,
            pady=8,
        )
        btn_frame.pack(fill=tk.X, padx=14, pady=5)

        btn_row1 = tk.Frame(btn_frame, bg="#ffffff")
        btn_row1.pack(fill=tk.X, pady=(0, 6))

        tk.Button(
            btn_row1,
            text="🌐 BƯỚC 1: Mở trang Sổ Đầu Bài (Đăng nhập 1 lần)",
            font=("Segoe UI", 9, "bold"),
            bg="#2563eb",
            fg="#ffffff",
            relief=tk.FLAT,
            padx=10,
            pady=7,
            cursor="hand2",
            command=lambda: self.enqueue_command("OPEN_BROWSER"),
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        tk.Button(
            btn_row1,
            text="⚡ BƯỚC 2: TỰ ĐỘNG KÝ CÁC MÔN ĐÃ TÍCH CHỌN",
            font=("Segoe UI", 9, "bold"),
            bg="#16a34a",
            fg="#ffffff",
            relief=tk.FLAT,
            padx=10,
            pady=7,
            cursor="hand2",
            command=lambda: self.enqueue_command("RUN_SELECTED"),
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))

        btn_row2 = tk.Frame(btn_frame, bg="#ffffff")
        btn_row2.pack(fill=tk.X)

        tk.Button(
            btn_row2,
            text="🎯 Ký môn đang mở trên web",
            font=("Segoe UI", 9, "bold"),
            bg="#0284c7",
            fg="#ffffff",
            relief=tk.FLAT,
            padx=8,
            pady=6,
            cursor="hand2",
            command=lambda: self.enqueue_command("RUN_CURRENT"),
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))

        tk.Button(
            btn_row2,
            text="📝 Chỉ điền PPCT & lọc lớp vắng",
            font=("Segoe UI", 9, "bold"),
            bg="#4f46e5",
            fg="#ffffff",
            relief=tk.FLAT,
            padx=8,
            pady=6,
            cursor="hand2",
            command=lambda: self.enqueue_command("FILL_ONLY"),
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)

        tk.Button(
            btn_row2,
            text="📂 Mở Nhật ký Excel (.CSV)",
            font=("Segoe UI", 9, "bold"),
            bg="#0d9488",
            fg="#ffffff",
            relief=tk.FLAT,
            padx=8,
            pady=6,
            cursor="hand2",
            command=self.open_audit_csv,
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)

        tk.Button(
            btn_row2,
            text="🛑 DỪNG",
            font=("Segoe UI", 9, "bold"),
            bg="#dc2626",
            fg="#ffffff",
            relief=tk.FLAT,
            padx=10,
            pady=6,
            cursor="hand2",
            command=self.request_stop,
        ).pack(side=tk.LEFT, padx=(4, 0))

        # 4. Nhật ký hoạt động
        log_frame = tk.LabelFrame(
            self.root,
            text=" 4. Nhật ký hoạt động & Đối chiếu Audit ",
            font=("Segoe UI", 10, "bold"),
            bg="#ffffff",
            fg="#0f172a",
            padx=10,
            pady=6,
        )
        log_frame.pack(fill=tk.BOTH, expand=True, padx=14, pady=(5, 10))

        self.log_box = scrolledtext.ScrolledText(
            log_frame,
            font=("Consolas", 9),
            bg="#0f172a",
            fg="#e2e8f0",
            insertbackground="#ffffff",
            relief=tk.FLAT,
            padx=8,
            pady=8,
        )
        self.log_box.pack(fill=tk.BOTH, expand=True)
        self.log("Sẵn sàng (v2.3). Bấm 'BƯỚC 1: Mở trang Sổ Đầu Bài' hoặc bấm thẳng 'BƯỚC 2' để bắt đầu.")

    def log(self, message: str):
        timestamp = time.strftime("%H:%M:%S")
        line = f"[{timestamp}] {message}\n"
        self.root.after(0, self._append_log, line)

    def _append_log(self, line: str):
        self.log_box.insert(tk.END, line)
        self.log_box.see(tk.END)

    def request_stop(self):
        self.stop_requested = True
        self.log("🛑 Đã nhận lệnh dừng từ người dùng...")

    def _snapshot_ui_config(self) -> dict:
        raw_ex = self.excluded_classes_var.get() or ""
        excluded_list = [x.strip().upper() for x in raw_ex.replace(";", ",").split(",") if x.strip()]
        selected_keywords = [k.lower() for k, var in self.prog_vars.items() if var.get()]
        return {
            "pinCode": (self.pin_var.get() or "").strip() or DEFAULT_PIN,
            "weekStr": (self.week_var.get() or "").strip(),
            "k10": bool(self.k10_var.get()),
            "k11": bool(self.k11_var.get()),
            "k12": bool(self.k12_var.get()),
            "selectedKeywords": selected_keywords,
            "skipAbsent": bool(self.skip_absent_var.get()),
            "excludedClasses": excluded_list,
            "fallbackContent": (self.fallback_content_var.get() or "").strip(),
        }

    def enqueue_command(self, cmd_name: str):
        if cmd_name in ("RUN_CURRENT", "RUN_SELECTED", "FILL_ONLY"):
            if not messagebox.askyesno("HTB Hub - Xác nhận thao tác", "Lệnh này có thể điền PPCT hoặc ký trên Sổ đầu bài. Hãy kiểm tra tuần, khối, môn và danh sách trong cửa sổ tool. Bạn xác nhận thực hiện lệnh đã chọn?", parent=self.root):
                return
        self.stop_requested = False
        cfg = self._snapshot_ui_config()
        self.log(f"⏳ Đang thực thi lệnh: {cmd_name}...")
        self.cmd_queue.put((cmd_name, cfg))

    def write_audit_log(self, week_val: str, program_name: str, stats: dict, signed_count: int, status_text: str):
        file_exists = AUDIT_CSV_PATH.exists()
        with open(AUDIT_CSV_PATH, mode="a", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(
                    [
                        "Thời gian",
                        "Tuần",
                        "Chương trình / Môn",
                        "Số lớp",
                        "Số tiết/tuần",
                        "Số tiết đã ký",
                        "Các lớp bỏ qua (Vắng / Ngoại lệ)",
                        "Trạng thái",
                    ]
                )
            writer.writerow(
                [
                    datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    week_val or "Hiện tại",
                    program_name,
                    stats.get("classes", 0),
                    stats.get("maxPeriods", 1),
                    signed_count,
                    "; ".join(stats.get("skippedList", [])) or "Không",
                    status_text,
                ]
            )

    def open_audit_csv(self):
        if not AUDIT_CSV_PATH.exists():
            messagebox.showinfo(
                "Nhật ký đối chiếu",
                f"Chưa có file nhật ký nào tại:\n{AUDIT_CSV_PATH}\n\nFile sẽ tự động được tạo sau khi bạn chạy ký thay.",
            )
            return
        try:
            os.startfile(str(AUDIT_CSV_PATH))
        except Exception as e:
            messagebox.showinfo("Đường dẫn file Nhật ký", f"File nhật ký được lưu tại:\n{AUDIT_CSV_PATH}\n({e})")

    # =========================================================================
    # LUỒNG WORKER PLAYWRIGHT DUY NHẤT (KHẮC PHỤC LỖI GREENLET THREAD)
    # =========================================================================
    def _playwright_worker_loop(self):
        pw = None
        context = None
        page = None

        while True:
            item = self.cmd_queue.get()
            if item is None:
                break
            cmd_name, cfg = item

            if cmd_name == "CLOSE":
                break

            try:
                # 1. Đảm bảo trình duyệt đã mở
                if page is None or page.is_closed():
                    from playwright.sync_api import sync_playwright

                    self.log("🌐 Đang khởi động trình duyệt Chrome (lưu phiên đăng nhập)...")
                    if pw is None:
                        pw = sync_playwright().start()

                    ext_script_path = BASE_DIR / "Tien_Ich_Chrome_Extension" / "content.js"
                    launch_args = ["--start-maximized"]

                    try:
                        context = pw.chromium.launch_persistent_context(
                            user_data_dir=PROFILE_DIR,
                            channel="chrome",
                            headless=False,
                            no_viewport=True,
                            args=launch_args,
                        )
                    except Exception:
                        context = pw.chromium.launch_persistent_context(
                            user_data_dir=PROFILE_DIR,
                            headless=False,
                            no_viewport=True,
                            args=launch_args,
                        )

                    # Tự động tiêm bảng điều khiển nổi trực tiếp vào trang web qua Init Script
                    if ext_script_path.exists():
                        try:
                            js_payload = ext_script_path.read_text(encoding="utf-8")
                            context.add_init_script(js_payload)
                        except Exception:
                            pass

                    page = context.pages[0] if context.pages else context.new_page()
                    page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=60000)

                    if ext_script_path.exists():
                        try:
                            page.evaluate(ext_script_path.read_text(encoding="utf-8"))
                        except Exception:
                            pass

                    self.log(
                        "✅ Đã mở trang Sổ đầu bài! Hãy đăng nhập (nếu lần đầu) và mở mục 'Điều hành -> Ký thay hàng loạt'."
                    )
                    if cmd_name == "OPEN_BROWSER":
                        continue

                if cmd_name == "OPEN_BROWSER":
                    self.log("ℹ️ Trình duyệt đang mở sẵn. Bạn có thể bấm BƯỚC 2 ngay!")
                    continue

                # Tìm trang đang mở Sổ đầu bài (nếu người dùng mở nhiều tab)
                for p in context.pages:
                    if "thpthothibi" in (p.url or "") or "sodaubai" in (p.url or ""):
                        page = p
                        break

                # Tìm Frame chứa giao diện Ký thay hàng loạt (hỗ trợ cả trang thường và trang nhúng <iframe>)
                target_frame = self._find_sodaubai_frame(page)
                if target_frame is None:
                    self.log(
                        "❌ Không tìm thấy giao diện 'Ký thay hàng loạt'. Hãy chắc chắn bạn đã đăng nhập và mở mục 'Điều hành -> Ký thay hàng loạt'!"
                    )
                    continue

                # Thực thi lệnh tương ứng trên đúng luồng Worker
                if cmd_name == "FILL_ONLY":
                    self._worker_fill_only(target_frame, cfg)
                elif cmd_name == "RUN_CURRENT":
                    self._worker_run_current(target_frame, cfg)
                elif cmd_name == "RUN_SELECTED":
                    self._worker_run_selected(target_frame, cfg)

            except Exception as err:
                tb_str = traceback.format_exc()
                self.log(f"❌ Lỗi khi thực thi {cmd_name}: {err}\n{tb_str}")

        # Dọn dẹp khi đóng ứng dụng
        try:
            if context:
                context.close()
            if pw:
                pw.stop()
        except Exception:
            pass

    def _find_sodaubai_frame(self, page):
        """
        Tự động chuyển sang mục 'Điều hành -> Ký thay hàng loạt' nếu đang ở tab khác,
        đồng thời quét tất cả các Frame (bao gồm cả <iframe>) để lấy đúng Frame chứa DOM.
        """
        for attempt in range(2):
            for frame in page.frames:
                try:
                    has_ui = frame.evaluate(
                        """() => {
                            const txt = (document.body?.innerText || '');
                            const selects = Array.from(document.querySelectorAll('select'));
                            const hasProgSelect = selects.some(s =>
                                Array.from(s.options).some(o =>
                                    (o.textContent || '').includes('Chọn chương trình') ||
                                    (o.textContent || '').includes('Kỹ năng số') ||
                                    (o.textContent || '').includes('STEM')
                                )
                            );
                            if (hasProgSelect) return 'READY';
                            if (txt.includes('Ký thay hàng loạt') || txt.includes('Điều hành')) return 'HAS_TAB';
                            return 'NONE';
                        }"""
                    )
                    if has_ui == "READY":
                        return frame
                    if has_ui == "HAS_TAB" and attempt == 0:
                        self.log("🔄 Đang tự động chuyển vào mục 'Điều hành -> Ký thay hàng loạt'...")
                        frame.evaluate(
                            """() => {
                                const els = Array.from(document.querySelectorAll('a, button, div, span, li'));
                                const dieuHanh = els.find(el => (el.textContent || '').trim() === 'Điều hành');
                                if (dieuHanh) dieuHanh.click();
                                setTimeout(() => {
                                    const allEls = Array.from(document.querySelectorAll('a, button, div, span, li'));
                                    const kyThayTab = allEls.find(el => (el.textContent || '').trim() === 'Ký thay hàng loạt');
                                    if (kyThayTab) kyThayTab.click();
                                }, 400);
                            }"""
                        )
                        time.sleep(1.2)
                except Exception:
                    continue

        # Dự phòng: trả về frame nào có thẻ <select> hoặc <table>
        for frame in page.frames:
            try:
                if frame.evaluate("() => document.querySelectorAll('select, table').length > 0"):
                    return frame
            except Exception:
                continue
        return page.main_frame

    def _configure_week_and_grades(self, frame, cfg: dict):
        frame.evaluate(
            """({weekStr, k10, k11, k12, fallbackStr}) => {
                const setNative = (el, val) => {
                    const desc = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
                    if (desc && desc.set) desc.set.call(el, val);
                    else el.value = val;
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                };

                if (weekStr) {
                    const labels = Array.from(document.querySelectorAll('label, div, span'));
                    for (const lbl of labels) {
                        if ((lbl.textContent || '').trim().startsWith('Tuần')) {
                            const inp = lbl.parentElement?.querySelector('input');
                            if (inp) {
                                setNative(inp, weekStr);
                                break;
                            }
                        }
                    }
                }

                if (fallbackStr) {
                    const inputs = Array.from(document.querySelectorAll('input[type="text"], input:not([type])'));
                    for (const inp of inputs) {
                        const ph = (inp.placeholder || '').trim();
                        if (ph.includes('nội dung dự phòng') || ph.includes('KHBD')) {
                            setNative(inp, fallbackStr);
                            break;
                        }
                    }
                }

                const gradeMap = { 'Khối 10': k10, 'Khối 11': k11, 'Khối 12': k12 };
                const checkboxes = Array.from(document.querySelectorAll('input[type="checkbox"]'));
                for (const cb of checkboxes) {
                    const parentTxt = (cb.parentElement?.textContent || '').trim();
                    for (const [labelName, shouldCheck] of Object.entries(gradeMap)) {
                        if (parentTxt.includes(labelName) && cb.checked !== shouldCheck) {
                            cb.click();
                        }
                    }
                }
            }""",
            {
                "weekStr": cfg["weekStr"],
                "k10": cfg["k10"],
                "k11": cfg["k11"],
                "k12": cfg["k12"],
                "fallbackStr": cfg["fallbackContent"],
            },
        )

    def _agent_eval(self, frame, expression: str, params: dict):
        source = (BASE_DIR / "Tien_Ich_Chrome_Extension" / "content.js").read_text(encoding="utf-8")
        shared = source.split("  function buildAgentPanel()", 1)[0]
        shared = shared.split("(function () {", 1)[1]
        script = "async (params) => {" + shared + "\nconst logs = []; const logFn = msg => logs.push(msg);\n" + expression + "\n}"
        result = frame.evaluate(script, params)
        for line in result.get("logs", []):
            self.log(line)
        return result

    def _load_program_list(self, frame, value=None):
        result = self._agent_eval(frame,
            "const loaded = await loadProgramList(params.value, logFn); return {loaded, logs};",
            {} if value is None else {"value": value})
        if self.stop_requested:
            return False
        return result["loaded"]

    def _assign_ppct_in_table(self, frame, cfg: dict) -> dict:
        result = self._agent_eval(frame,
            "const stats = await processLessonRows(params, logFn); return {stats, logs};", cfg)
        stats = result["stats"]
        return dict(stats, classes=stats["classesCount"], updated=stats["updatedCount"], ready=stats["readyCount"])

    def _confirm_and_sign(self, frame, pin_code: str) -> bool:
        if self.stop_requested:
            return False
        result = self._agent_eval(frame,
            "const ok = await confirmAndSignModal(params.pinCode, logFn); return {ok, logs};",
            {"pinCode": pin_code})
        return result["ok"]

    # =========================================================================
    # THỰC THI CÁC CHẾ ĐỘ TRÊN LUỒNG WORKER
    # =========================================================================
    def _worker_fill_only(self, frame, cfg: dict):
        stats = self._assign_ppct_in_table(frame, cfg)
        if stats.get("skippedList"):
            self.log(f"🛡️ Đã bỏ chọn các lớp: {', '.join(stats['skippedList'])}")
        if stats.get("missingPpctWarning"):
            self.log("⚠️ CẢNH BÁO: Môn này chưa có PPCT trên hệ thống (và chưa nhập Nội dung dự phòng)!")
            return
        self.log(
            f"✅ Đã phân bổ PPCT cho {stats['classes']} lớp (môn {stats['maxPeriods']} tiết/tuần): cập nhật {stats['updated']} tiết, sẵn sàng {stats['ready']} tiết."
        )

    def _worker_run_current(self, frame, cfg: dict):
        if not self._load_program_list(frame):
            return
        stats = self._assign_ppct_in_table(frame, cfg)
        if stats.get("skippedList"):
            self.log(f"🛡️ Đã bỏ chọn: {', '.join(stats['skippedList'])}")
        if stats.get("missingPpctWarning"):
            self.log("⚠️ CẢNH BÁO: Môn đang mở chưa có PPCT trên hệ thống -> Dừng ký để tránh lỗi!")
            self.write_audit_log(cfg["weekStr"], "Môn đang mở", stats, 0, "Bỏ qua (Chưa có PPCT)")
            return
        if stats["ready"] > 0:
            ok = self._confirm_and_sign(frame, cfg["pinCode"])
            self.write_audit_log(
                cfg["weekStr"],
                "Môn đang mở",
                stats,
                stats["ready"] if ok else 0,
                "Đã ký thành công" if ok else "Chưa hoàn tất xác nhận",
            )
        else:
            self.log("ℹ️ Bảng hiện tại chưa có tiết nào sẵn sàng để ký (hoặc bạn chưa bấm 'Tạo danh sách').")

    def _worker_run_selected(self, frame, cfg: dict):
        self._configure_week_and_grades(frame, cfg)
        selected_keywords = cfg["selectedKeywords"]
        if not selected_keywords:
            self.log("⚠️ Bạn chưa tích chọn môn nào ở mục 'Môn chạy'!")
            return

        all_programs = self._agent_eval(frame,
            "const sel = findProgramSelect(); return {programs: sel ? Array.from(sel.options).filter(o => o.value && !o.disabled).map(o => ({value:o.value, text:normalizeText(o.textContent)})) : [], logs};", {})["programs"]

        if not all_programs:
            self.log(
                "❌ Không tìm thấy ô chọn 'Chương trình / môn'. Hãy chắc chắn bạn đang ở mục 'Điều hành -> Ký thay hàng loạt'."
            )
            return

        programs = [
            p for p in all_programs if any(kw in p["text"].lower() for kw in selected_keywords)
        ]

        if not programs:
            self.log(f"⚠️ Không tìm thấy môn khớp lựa chọn. Danh sách trên web gồm: {[p['text'] for p in all_programs]}")
            return

        self.log(f"🚀 Bắt đầu chạy tự động qua {len(programs)} chương trình/môn: {[p['text'] for p in programs]}")

        for idx, prog in enumerate(programs, start=1):
            if self.stop_requested:
                self.log("🛑 Đã dừng quy trình theo yêu cầu.")
                break

            self.log("--------------------------------------------------")
            self.log(f"▶️ [{idx}/{len(programs)}] Đang chọn: {prog['text']}")

            if not self._load_program_list(frame, prog["value"]):
                self.log("Không có tiết phù hợp hoặc đã dừng.")
                if self.stop_requested:
                    break
                continue
            if self.stop_requested:
                break

            stats = self._assign_ppct_in_table(frame, cfg)
            if stats.get("skippedList"):
                self.log(f"🛡️ Đã tự động bỏ chọn: {', '.join(stats['skippedList'])}")

            if stats.get("missingPpctWarning"):
                self.log(
                    f"⚠️ CẢNH BÁO: Môn '{prog['text']}' chưa có PPCT trên hệ thống -> Tự động bỏ qua để không ký lỗi!"
                )
                self.write_audit_log(cfg["weekStr"], prog["text"], stats, 0, "Bỏ qua (Chưa có PPCT)")
                continue

            if stats["maxPeriods"] >= 2:
                self.log(
                    f"✅ Môn {stats['maxPeriods']} tiết/tuần ({stats['classes']} lớp): Đã chọn Tiết 1 -> mục 1, Tiết 2 -> mục 2 cho {stats['updated']} tiết."
                )
            else:
                self.log(
                    f"✅ Môn 1 tiết/tuần ({stats['classes']} lớp): Có {stats['ready']} tiết sẵn sàng ký."
                )

            if stats["ready"] == 0:
                self.log(f"⏭️ Môn '{prog['text']}' không còn tiết cần ký, chuyển môn tiếp theo...")
                self.write_audit_log(cfg["weekStr"], prog["text"], stats, 0, "Không còn tiết cần ký")
                continue

            time.sleep(0.4)
            ok = self._confirm_and_sign(frame, cfg["pinCode"])
            self.write_audit_log(
                cfg["weekStr"],
                prog["text"],
                stats,
                stats["ready"] if ok else 0,
                "Đã ký thành công" if ok else "Chưa hoàn tất xác nhận",
            )
            if not ok:
                self.log("Chưa xác định được kết quả ký; dừng trước khi chuyển môn.")
                return
            time.sleep(1.0)

        self.log("==================================================")
        self.log(f"🎉 ĐÃ HOÀN TẤT! Nhật ký đối chiếu đã lưu tại: {AUDIT_CSV_PATH.name}")

    def _on_close(self):
        try:
            self.cmd_queue.put(("CLOSE", {}))
        except Exception:
            pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = SodaubaiAgentWinAppV21(root)
    root.mainloop()
