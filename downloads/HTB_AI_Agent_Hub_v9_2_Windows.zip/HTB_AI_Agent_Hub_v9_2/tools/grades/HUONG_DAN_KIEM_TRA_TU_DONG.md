# HTB v2.3.1 — Nhập tất cả lớp xong mới kiểm tra

Chọn Excel như trước. Luồng tự động:
1. Nhập lần lượt tất cả nhóm lớp/môn/cột. Mỗi vùng chỉ kiểm tra đúng đích, đúng giá trị và chữ xanh xác nhận lưu; không tải lại trang để đối chiếu trong giai đoạn này.
2. Khi tất cả nhóm đã nhập xong, tải lại trang đúng một lần.
3. Tự chọn lần lượt từng nhóm và dùng chế độ chỉ đọc để đối chiếu hai lần ổn định với Excel. Giai đoạn kiểm tra không dán hoặc ghi đè điểm.
4. Xuất một CSV chung có phase (Nhập điểm/Kiểm tra cuối đợt), điểm dự kiến, điểm web và kết quả. Sai lệch ở một lớp không ngăn kiểm tra các lớp khác. Khi hoàn tất toàn bộ, báo tổng hợp sai/thiếu/chưa kiểm tra được.

Ô đã có điểm, học sinh nghỉ và tên không tìm thấy vẫn được bỏ qua khi nhập; kiểm tra cuối đợt rà soát cả các ô nguồn có điểm và báo các dòng không khớp tên. Nếu nhập/lưu phát sinh lỗi chưa xác nhận, ứng dụng dừng ngay và chưa bắt đầu kiểm tra cuối đợt. Các ô đã nhập được ghi Chờ kiểm tra cuối đợt, không báo là đã đọc lại thành công.

Vẫn cần đăng nhập lại nếu phiên hết hạn, hoặc xử lý OTP/CAPTCHA nếu VietSchool yêu cầu. Kiểm tra qua giao diện tải lại, không truy cập cơ sở dữ liệu. Chưa kiểm tra trên tài khoản VietSchool thực tế.
