"""Read and operate visible UI only. Never accesses VietSchool's internal models/API."""
DOM = r'''(a) => {
 const ROW='tr,[role="row"],.ag-row,.wj-row,.slick-row,.pq-grid-row';
 const CELL='td,th,[role="gridcell"],[role="cell"],.ag-cell,.wj-cell,.slick-cell,.pq-grid-cell';
 const norm=s=>(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim().replace(/\bkhoi\s*(10|11|12)\b/g,'khoi $1').replace(/\bhoc ky\s*([12])\b/g,'hoc ky $1');
 const text=e=>(e?.innerText||e?.textContent||'').replace(/\s+/g,' ').trim();
 const fullName=c=>[text(c[1]),text(c[2])].filter(Boolean).join(' ');
 const vis=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'};
 const cells=r=>[...r.children].filter(e=>e.matches(CELL)&&vis(e));
 const valid=c=>c.length>=5&&/^\d{1,3}$/.test(text(c[0]))&&/^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$/.test(text(c[3]));
 const leafTableCells=()=>[...document.querySelectorAll('td,th')].filter(e=>vis(e)&&!e.querySelector('td,th'));
 const painted=e=>{
   // Read only cells that are actually painted in a scroll pane, not covered clones.
   if(typeof document.elementFromPoint!=='function')return true;
   const r=e.getBoundingClientRect(),w=window.innerWidth,h=window.innerHeight;
   const left=Math.max(0,r.left),right=Math.min(w,r.right),top=Math.max(0,r.top),bottom=Math.min(h,r.bottom);
   if(right-left<2||bottom-top<2)return false;
   const hit=document.elementFromPoint((left+right)/2,(top+bottom)/2);
   return !!hit&&(e===hit||e.contains(hit));
 };
 // Intersect the cell with every clipping ancestor, not just the iframe.
 // Progrid uses overflow:hidden and a translated mCSB container for scrolling.
 const cellView=e=>{
   const r=e.getBoundingClientRect();
   let box={left:0,top:0,right:window.innerWidth,bottom:window.innerHeight},host=null;
   for(let n=e.parentElement;n&&n!==document.body;n=n.parentElement){
     const st=getComputedStyle(n),q=n.getBoundingClientRect();
     const cx=/hidden|clip|auto|scroll/.test(st.overflowX||st.overflow||'');
     const cy=/hidden|clip|auto|scroll/.test(st.overflowY||st.overflow||'');
     if(cx){box.left=Math.max(box.left,q.left);box.right=Math.min(box.right,q.right)}
     if(cy){box.top=Math.max(box.top,q.top);box.bottom=Math.min(box.bottom,q.bottom)}
     if(!host&&(cx||cy)&&q.width>=60&&q.height>=60)host=n;
   }
   const left=Math.max(box.left,r.left),right=Math.min(box.right,r.right),top=Math.max(box.top,r.top),bottom=Math.min(box.bottom,r.bottom);
   let point=null;
   if(right-left>4&&bottom-top>4){
     for(const [fx,fy] of [[.5,.5],[.25,.25],[.75,.75]]){
       const x=left+2+(right-left-4)*fx,y=top+2+(bottom-top-4)*fy;
       const hit=typeof document.elementFromPoint==='function'?document.elementFromPoint(x,y):e;
       if(hit&&(hit===e||e.contains(hit))){point={x:x-r.left,y:y-r.top};break}
     }
   }
   const delta=(low,high,start,end)=>start<low?start-low-12:end>high?end-high+12:0;
   return {point,host,box,rect:r,dx:delta(box.left,box.right,r.left,r.right),dy:delta(box.top,box.bottom,r.top,r.bottom)};
 };
 const clickProof=(b,first)=>{
   if(b.disarm)b.disarm();
   const proof={down:false,click:false,wrong:false};b.proof=proof;
   const listen=event=>{
     // Synthetic dispatchEvent does not count as an actual user-interface click.
     if(!event.isTrusted)return;
     const hit=event.target===first||first.contains(event.target);
     if(!hit)proof.wrong=true;
     if(event.type==='mousedown')proof.down=hit;
     if(event.type==='click')proof.click=hit;
   };
   document.addEventListener('mousedown',listen,true);document.addEventListener('click',listen,true);
   b.disarm=()=>{document.removeEventListener('mousedown',listen,true);document.removeEventListener('click',listen,true);b.disarm=null};
 };
 const headerCovers=(e,x)=>{
   const r=e.getBoundingClientRect();if(x<r.left+1||x>r.right-1)return false;
   if(typeof document.elementFromPoint!=='function')return true;
   const y=Math.max(0,Math.min(window.innerHeight-1,r.top+r.height/2));
   const hit=document.elementFromPoint(x,y);
   return !!hit&&(e===hit||e.contains(hit));
 };
 const orderedUnique=list=>{
   const sorted=list.slice().sort((x,y)=>x.getBoundingClientRect().left-y.getBoundingClientRect().left);
   const out=[];
   for(const c of sorted){
     const r=c.getBoundingClientRect();
     const prev=out.find(e=>{const b=e.getBoundingClientRect();return Math.abs(b.left-r.left)<1&&Math.abs(b.width-r.width)<1});
     if(!prev)out.push(c);
     else if(text(prev)!==text(c))throw Error('Hai ô bảng chồng lên nhau có nội dung khác nhau. Chờ giao diện ổn định.');
   }return out;
 };
 const dataRecords=(includeOffscreen=false)=>{
   let out=[],used=new Set();
   // EasyUI frozen columns live in a different table from editable grade cells.
   // Pair only by the same public row index inside the same datagrid view.
   for(const view of document.querySelectorAll('.datagrid-view')){
     const left=[...view.querySelectorAll('.datagrid-view1 .datagrid-body tr.datagrid-row')].filter(vis);
     const right=[...view.querySelectorAll('.datagrid-view2 .datagrid-body tr.datagrid-row')].filter(vis);
     for(const l of left){
       const rowIndex=l.getAttribute('datagrid-row-index');if(rowIndex===null)continue;
       const rr=right.filter(r=>r.getAttribute('datagrid-row-index')===rowIndex);
       if(rr.length!==1)continue;
       const c=[...cells(l),...cells(rr[0])];
       if(valid(c)){out.push({node:rr[0],cells:c,view});used.add(l);used.add(rr[0])}
     }
   }
   // Wijmo may render STT in its row-header panel, separate from the data cells.
   for(const grid of document.querySelectorAll('.wj-flexgrid')){
     const nums=[...grid.querySelectorAll('.wj-rowheaders .wj-row')].filter(vis);
     for(const r of grid.querySelectorAll('.wj-cells .wj-row')){
       if(!vis(r)||used.has(r))continue;
       const c=cells(r);if(valid(c))continue;
       if(c.length<4||!/^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$/.test(text(c[2])))continue;
       const index=r.getAttribute('aria-rowindex'),top=r.getBoundingClientRect().top;
       const matches=nums.filter(n=>index&&n.getAttribute('aria-rowindex')?n.getAttribute('aria-rowindex')===index:Math.abs(n.getBoundingClientRect().top-top)<1);
       if(matches.length!==1)continue;
       const merged=[...cells(matches[0]),...c];
       if(valid(merged)){out.push({node:r,cells:merged,view:null});used.add(r);used.add(matches[0])}
     }
   }
   // FlexGrid also renders flat, absolutely positioned cells with no row wrappers.
   // Group painted cells by their actual Y position, then align STT from row headers.
   for(const grid of document.querySelectorAll('.wj-flexgrid')){
     const body=[...grid.querySelectorAll('.wj-cells .wj-cell,[wj-part="cells"] .wj-cell,[role="gridcell"]')].filter(vis);
     const rowheads=[...grid.querySelectorAll('.wj-rowheaders .wj-cell,[wj-part="rh"] .wj-cell')].filter(vis);
     const groups=[];
     for(const c of body){
       const top=c.getBoundingClientRect().top;
       let g=groups.find(g=>Math.abs(g.top-top)<1);
       if(!g){g={top,list:[]};groups.push(g)}g.list.push(c);
     }
     for(const g of groups){
       const unique=new Map();
       for(const c of g.list){
         const ci=c.getAttribute('aria-colindex');
         const k=ci!==null?'c'+ci:'x'+Math.round(c.getBoundingClientRect().left*4);
         const old=unique.get(k);
         if(old&&text(old)!==text(c))throw Error('Các ô sao chép của Wijmo chưa đồng bộ; chờ bảng tải lại.');
         if(!old)unique.set(k,c);
       }
       let c=[...unique.values()].sort((x,y)=>{
         const xi=x.getAttribute('aria-colindex'),yi=y.getAttribute('aria-colindex');
         return xi!==null&&yi!==null?Number(xi)-Number(yi):x.getBoundingClientRect().left-y.getBoundingClientRect().left;
       });
       if(!valid(c)){
         const rh=rowheads.filter(h=>Math.abs(h.getBoundingClientRect().top-g.top)<1&&/^\d{1,3}$/.test(text(h)));
         if(rh.length!==1)continue;
         c=[rh[0],...c];
       }
       if(!valid(c))continue;
       const stt=text(c[0]),name=fullName(c),dob=text(c[3]);
       const existing=out.some(o=>text(o.cells[0])===stt&&fullName(o.cells)===name&&text(o.cells[3])===dob);
       if(!existing)out.push({node:c[4],cells:c,view:null});
       for(const cell of c){const row=cell.closest(ROW);if(row)used.add(row)}
     }
   }
   // Frozen identities and grades can have DIFFERENT row heights (e.g. 61px
   // versus 45px). Never associate these independent tables by screen Y.
   // Prefer public row IDs, otherwise require two complete DOM tables whose
   // full roster is 1..N and whose body-row counts match exactly.
   const ownRows=t=>[...t.querySelectorAll('tr')].filter(r=>r.closest('table')===t&&(t.matches('.progrid-btable')||vis(r)));
   const bodyCells=r=>[...r.children].filter(c=>c.matches('td,th')&&!c.querySelector('td,th'));
   const readRow=(node,table)=>({node,cells:table.matches('.progrid-btable')?bodyCells(node):cells(node)});
   const identityRows=t=>{
     const rows=ownRows(t).map(node=>readRow(node,t));
     if(t.matches('.progrid-btable')){
       // Progrid is two body tables with the SAME physical row slots. A row
       // missing a DOB/name must stay in place, never be filtered out and shift
       // every following score. Recognize the identity TABLE by good samples.
       const numbered=rows.filter(r=>r.cells.length===4&&/^\d{1,3}$/.test(text(r.cells[0])));
       if(!numbered.some(r=>/^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$/.test(text(r.cells[3]))&&fullName(r.cells)))return [];
       return rows; // Preserve sizing/placeholder slots until BOTH panels are paired.
     }
     return rows.filter(r=>{
       const c=r.cells;return c.length===4&&/^\d{1,3}$/.test(text(c[0]))&&
         /^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$/.test(text(c[3]))&&!!fullName(c);
     });
   };
   const scoreRows=t=>{
     const rows=ownRows(t).filter(r=>!r.closest('thead')).map(node=>readRow(node,t));
     if(t.matches('.progrid-btable'))return rows;
     return rows.filter(r=>r.cells.length&&r.cells.every(c=>c.tagName==='TD'&&!c.querySelector('td,th'))&&
       r.cells.every(c=>/^(?:\s*|\d{1,2}(?:[.,]\d{1,2})?|[Đđ]|[Cc][Đđ]|-)$/.test(text(c))));
   };
   const publicRowId=r=>{
     for(const key of ['datagrid-row-index','aria-rowindex','data-row-index','data-rowindex']){
       const value=r.getAttribute(key);if(value!==null)return key+':'+value;
     }return null;
   };
   for(const table of document.querySelectorAll('table')){
     let identities=identityRows(table);if(identities.length<2)continue;
     const anchor=identities.find(r=>r.cells.length===4&&/^\d{1,3}$/.test(text(r.cells[0])));
     if(!anchor)continue;
     let scope=table.parentElement,candidates=[];
     while(scope&&scope!==document.body){
       candidates=[...scope.querySelectorAll('table')].filter(t=>t!==table&&!t.contains(table)&&!table.contains(t)&&(!table.matches('.progrid-btable')||t.matches('.progrid-btable')))
         .map(t=>({table:t,rows:scoreRows(t)})).filter(x=>x.rows.length>=2&&
           !identityRows(x.table).length&&
           x.rows.some(r=>r.cells.length>=2&&r.cells[0].getBoundingClientRect().left>=anchor.cells[3].getBoundingClientRect().right-2));
       if(candidates.length)break;
       scope=scope.parentElement;
     }
     if(!candidates.length)continue;
     if(candidates.length!==1)throw Error('Có nhiều bảng điểm cạnh danh sách; không ghép hàng khi chưa xác định duy nhất.');
     let scores=candidates[0].rows;
     if(scores.length!==identities.length)throw Error('Hai phần danh sách/điểm lệch số hàng ('+identities.length+'/'+scores.length+'). Chưa thể đối chiếu an toàn.');
     if(table.matches('.progrid-btable')){
       const left=[],right=[];
       // Progrid includes column-sizing/empty placeholder TRs. Pair raw slots
       // first and ignore a blank slot ONLY when both sides are empty. Filtering
       // the left panel independently turns 47 physical TRs into 46 students.
       for(let slot=0;slot<identities.length;slot++){
         const l=identities[slot],r=scores[slot];
         if(l.cells.length===4&&/^\d{1,3}$/.test(text(l.cells[0]))){left.push(l);right.push(r);continue}
         if(!l.cells.some(c=>text(c))&&!r.cells.some(c=>text(c))&&!publicRowId(l.node)&&!publicRowId(r.node)){
           used.add(l.node);used.add(r.node);continue;
         }
         throw Error('Hàng '+(slot+1)+' chưa có STT hợp lệ hoặc hai phần bảng chưa đồng bộ. Không dịch hàng để ghép.');
       }
       identities=left;scores=right;
       if(!identities.length)throw Error('Bảng chưa có hàng học sinh.');
     }
     const completeRoster=identities.every((r,i)=>Number(text(r.cells[0]))===i+1);
     const width=scores[0].cells.length;
     if(scores.some(r=>r.cells.length!==width))throw Error('Bảng điểm chưa đủ các ô cột; chờ tải lại.');
     const columnLeft=scores[0].cells.map(c=>c.getBoundingClientRect().left);
     if(scores.some(r=>r.cells.some((c,j)=>Math.abs(c.getBoundingClientRect().left-columnLeft[j])>2)))
       throw Error('Vị trí cột giữa các hàng điểm không khớp; chưa kết luận điểm.');
     const leftIds=identities.map(r=>publicRowId(r.node)),rightIds=scores.map(r=>publicRowId(r.node));
     const hasIds=leftIds.some(Boolean)||rightIds.some(Boolean);
     if(!hasIds&&!completeRoster)throw Error('Chưa đọc đủ danh sách từ STT 1; không ghép hai bảng theo tọa độ khi cuộn.');
     if(hasIds&&(!leftIds.every(Boolean)||!rightIds.every(Boolean)||new Set(leftIds).size!==leftIds.length||new Set(rightIds).size!==rightIds.length))
       throw Error('Mã hàng hai phần bảng chưa đầy đủ/duy nhất.');
     for(let i=0;i<identities.length;i++){
       const identity=identities[i];
       const matches=hasIds?scores.filter((r,j)=>rightIds[j]===leftIds[i]):[scores[i]];
       if(matches.length!==1)throw Error('Không khớp mã hàng danh sách với bảng điểm.');
       const score=matches[0],c=[...identity.cells,...score.cells];
       out.push({node:score.node,cells:c,view:null,source:'html-structural'});
       used.add(identity.node);used.add(score.node);
     }
   }
   // Actual VietSchool iframe uses multiple HTML tables, not a Wijmo grid.
   // Join frozen identity and editable score panels using their rendered row positions.
   const htmlGroups=[];
   for(const c of leafTableCells().filter(c=>!c.closest('.progrid-htable')&&!used.has(c.closest(ROW))&&(includeOffscreen||painted(c)))){
     const box=c.getBoundingClientRect(),y=box.top+box.height/2;
     let g=htmlGroups.find(g=>Math.abs(g.y-y)<2);
     if(!g){g={y,list:[]};htmlGroups.push(g)}g.list.push(c);
   }
   for(const g of htmlGroups){
     const all=orderedUnique(g.list);
     const dates=all.map((c,i)=>/^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$/.test(text(c))?i:-1).filter(i=>i>=3);
     if(dates.length!==1)continue;
     const d=dates[0],dob=all[d],ho=all[d-2],ten=all[d-1];
     // A legal full name may contain one word and an empty surname cell.
     // Still require at least one real name part; both blank is not a student.
     const parts=[text(ho),text(ten)].filter(Boolean);
     if(!parts.length||parts.some(v=>!/[\p{L}]/u.test(v)))continue;
     const nums=all.slice(0,d-2).filter(c=>/^\d{1,3}$/.test(text(c))&&Number(text(c))>0&&Number(text(c))<=100);
     if(nums.length!==1)continue;
     const grades=all.slice(d+1).filter(c=>c.getBoundingClientRect().left>=dob.getBoundingClientRect().right-2);
     const c=[nums[0],ho,ten,dob,...grades];if(!valid(c))continue;
     const stt=text(c[0]),name=fullName(c),birth=text(c[3]);
     const existing=out.some(o=>text(o.cells[0])===stt&&fullName(o.cells)===name&&text(o.cells[3])===birth);
     if(!existing)out.push({node:c[4],cells:c,view:null,source:'html-geometry'});
     for(const cell of c){const row=cell.closest(ROW);if(row)used.add(row)}
   }
   for(const r of document.querySelectorAll(ROW)){
     if(used.has(r)||!vis(r))continue;const c=cells(r);
     if(valid(c))out.push({node:r,cells:c,view:null});
   }return out;
 };
 const expandDomHeaders=table=>{
   const matrix=[];
   const rr=[...table.querySelectorAll('tr')].filter(r=>r.closest('table')===table);
   for(let y=0;y<rr.length;y++){
     matrix[y]??=[];let x=0;
     for(const cell of [...rr[y].children].filter(c=>c.matches('td,th'))){
       while(matrix[y][x]!==undefined)x++;
       const value=text(cell),rs=cell.rowSpan||1,cs=cell.colSpan||1;
       for(let dy=0;dy<rs;dy++){
         matrix[y+dy]??=[];
         for(let dx=0;dx<cs;dx++)matrix[y+dy][x+dx]=value;
       }x+=cs;
     }
   }
   const width=Math.max(0,...matrix.map(r=>r.length));
   return Array.from({length:width},(_,x)=>[...new Set(matrix.map(r=>r[x]).filter(Boolean))].join(' '));
 };
 const progridHeaders=(body,width)=>{
   for(let scope=body.parentElement;scope&&scope!==document.body;scope=scope.parentElement){
     const choices=[...scope.querySelectorAll('table.progrid-htable')].map(expandDomHeaders).filter(p=>p.length===width);
     const unique=[...new Map(choices.map(p=>[JSON.stringify(p),p])).values()];
     if(unique.length===1)return unique[0];
     if(unique.length>1)return null;
   }return null;
 };
 const htmlHeaderPaths=first=>{
   if(!first)return null;
   if(first.source==='html-structural'){
     const identityTable=first.cells[0].closest('table'),scoreTable=first.cells[4]?.closest('table');
     if(identityTable?.matches('.progrid-btable')&&scoreTable?.matches('.progrid-btable')){
       const identities=progridHeaders(identityTable,4),scores=progridHeaders(scoreTable,first.cells.length-4);
       if(identities&&scores&&norm(identities[0])==='stt'&&['ho','ho dem'].includes(norm(identities[1]))&&norm(identities[2])==='ten'&&norm(identities[3])==='ngay sinh')
         return [...identities,...scores];
     }
   }
   const bodyDob=first.cells[3].getBoundingClientRect(),dobCenter=bodyDob.left+bodyDob.width/2;
   const html=leafTableCells().filter(painted);
   const dobHeaders=html.filter(c=>norm(text(c))==='ngay sinh'&&dobCenter>=c.getBoundingClientRect().left-1&&dobCenter<=c.getBoundingClientRect().right+1);
   if(dobHeaders.length===1){
     const band=dobHeaders[0].getBoundingClientRect();
     const hs=html.filter(c=>{const r=c.getBoundingClientRect();return r.top>=band.top-2&&r.bottom<=Math.max(band.bottom,first.cells[3].getBoundingClientRect().top)+2});
     const paths=first.cells.map(c=>{
       const r=c.getBoundingClientRect(),x=r.left+r.width/2;
       return [...new Set(hs.filter(h=>headerCovers(h,x))
         .sort((a,b)=>a.getBoundingClientRect().top-b.getBoundingClientRect().top).map(text).filter(Boolean))].join(' ');
     });
     if(norm(paths[0])==='stt'&&norm(paths[1])==='ho'&&norm(paths[2])==='ten'&&norm(paths[3])==='ngay sinh')return paths;
   }
   return null;
 };
 const rgb=(e,p)=>(getComputedStyle(e)[p].match(/[\d.]+/g)||[]).map(Number);
 const red=e=>[e,...e.querySelectorAll('*')].some(n=>{let c=rgb(n,'color');return c[0]>150&&c[1]<100&&c[2]<100});
 const green=e=>[e,...e.querySelectorAll('*')].some(n=>{let c=rgb(n,'color');return c[1]>65&&c[1]>c[0]*1.25&&c[1]>c[2]*1.15});
 const gray=e=>[e,...e.querySelectorAll('*')].some(n=>{let c=rgb(n,'backgroundColor');return c[0]>=190&&c[0]<250&&Math.max(...c.slice(0,3))-Math.min(...c.slice(0,3))<15&&(c.length<4||c[3]>0)});
 const locked=e=>e.matches('.locked,.readonly,.readOnly,.lockCell')||e.getAttribute('aria-readonly')==='true'||e.getAttribute('aria-disabled')==='true'||!!e.querySelector('[disabled],[readonly]');
 const retirementReason=r=>{
   const c=r.cells;
   const metadata=c.slice(1,4).flatMap(e=>[e,...e.querySelectorAll('[title],[data-status],[aria-label]')])
     .map(e=>[e.getAttribute('title'),e.getAttribute('data-status'),e.getAttribute('aria-label')].filter(Boolean).join(' ')).join(' ');
   if(/\b(da nghi hoc|nghi hoc|thoi hoc|chuyen truong|chuyen di|withdrawn|inactive)\b/.test(norm(metadata)))return 'Trạng thái nghỉ/chuyển trường trên web';
   if(c.slice(1,4).length===3&&c.slice(1,4).every(e=>e.matches('.gachCell')))return 'Họ, tên và ngày sinh có dấu nghỉ gachCell trên web';
   if(red(c[1])&&red(c[2])&&red(c[3]))return 'Họ, tên và ngày sinh đều màu đỏ';
   if(red(c[1])&&red(c[2])&&c.slice(4).some(gray))return 'Họ/tên đỏ kết hợp ô điểm xám';
   return '';
 };
 const mark=e=>{let id='vsa-'+Math.random().toString(36).slice(2);e.setAttribute('data-vsa',id);return '[data-vsa="'+id+'"]'};
 const leaves=(root,values,visible=true)=>{
   const wanted=new Set(values.map(norm));
   const all=[...root.querySelectorAll('a,button,span,div,li,label,td,th,h1,h2,h3,h4,legend,[role="treeitem"],[role="tab"],[role="menuitem"]')].filter(e=>(!visible||vis(e))&&wanted.has(norm(text(e))));
   return all.filter(e=>!all.some(x=>x!==e&&e.contains(x)));
 };
 const active=(e,stop)=>{
   for(let n=e;n&&n!==stop;n=n.parentElement){
     if(n.matches('[aria-selected="true"],.selected,.active,.is-active,.tree-node-selected,.jstree-clicked,.x-tree-selected,.k-selected,.k-state-selected,.wj-node.wj-state-selected'))return true;
     let c=rgb(n,'backgroundColor');if(c.length>=3&&c[2]>120&&c[2]>c[0]+15&&c[1]>c[0]+8&&(c.length<4||c[3]>0))return true;
   }return false;
 };
 const region=(labels,values)=>{
   for(const h of leaves(document,labels)){
     for(let n=h.parentElement;n&&n!==document.body;n=n.parentElement){
       if(n.getBoundingClientRect().width>700)break;
       const found=leaves(n,values,false);if(found.length)return n;
     }
   }return null;
 };
 const rowStamp=cell=>{
   const row=cell.closest('tr,[role="row"],.wj-row');
   return {parent:cell.parentElement,row,table:cell.closest('table'),
     rowIndex:row&&Number.isInteger(row.rowIndex)?row.rowIndex:null,
     cellIndex:Number.isInteger(cell.cellIndex)?cell.cellIndex:null};
 };
 const boundState=(e,expected)=>{
   const problems=[];
   if(!e)return {valid:false,problems:['Chưa gắn ô điểm']};
   if(!e.cell?.isConnected)problems.push('Ô điểm đã bị trang thay thế');
   const ids=e.identities||[];
   if(ids.length!==4||ids.some(c=>!c.isConnected))problems.push('Ô thông tin học sinh đã bị thay thế');
   else if(text(ids[0])!==String(expected.stt)||fullName(ids)!==expected.name||text(ids[3])!==expected.dob)problems.push('STT/họ tên/ngày sinh đã thay đổi');
   if(e.name!==expected.name||e.dob!==expected.dob)problems.push('Khác học sinh đã đối chiếu');
   if(e.cell?.isConnected){
     const now=rowStamp(e.cell),old=e.stamp;
     if(!old||now.parent!==old.parent||now.row!==old.row||now.table!==old.table)problems.push('Hàng chứa ô điểm đã thay đổi');
     else if(old.rowIndex!==null&&now.rowIndex!==old.rowIndex||old.cellIndex!==null&&now.cellIndex!==old.cellIndex)problems.push('Thứ tự hàng/cột HTML đã thay đổi');
   }
   if(ids.length===4&&ids.every(c=>c.isConnected)&&retirementReason({cells:e.cells}))problems.push('Học sinh đã nghỉ');
   return {valid:problems.length===0,problems};
 };
 if(a.op==='reset_grid_view'){
   if(!document.querySelector('table'))return 0;
   let changed=0;
   for(const e of document.querySelectorAll('div,section,main')){
     if(!vis(e))continue;
     if(e.clientWidth>=80&&e.scrollWidth>e.clientWidth+4&&e.scrollLeft){e.scrollLeft=0;changed++}
     if(e.clientHeight>=60&&e.scrollHeight>e.clientHeight+4&&e.scrollTop){e.scrollTop=0;changed++}
   }
   if(document.scrollingElement?.scrollTop)document.scrollingElement.scrollTop=0;
   return changed;
 }
 if(a.op==='reset_horizontal'){
   let changed=0;for(const e of document.querySelectorAll('div,section,main')){
     if(vis(e)&&e.clientWidth>=80&&e.clientHeight>=15&&e.scrollWidth>e.clientWidth+4&&e.scrollLeft){e.scrollLeft=0;changed++}
   }return changed;
 }
 if(a.op==='bind_column'){
   if(!Number.isInteger(a.index)||a.index<4)throw Error('Cột chưa được đối chiếu.');
   const records=dataRecords(true),entries=new Map();
   for(const expected of a.run){
     const rr=records.filter(r=>text(r.cells[0])===String(expected.stt)&&fullName(r.cells)===expected.name&&text(r.cells[3])===expected.dob);
     if(rr.length!==1)throw Error('Chưa gắn được ô điểm duy nhất của STT '+expected.stt);
     const r=rr[0],cell=r.cells[a.index];
     if(!cell||locked(cell)||text(cell)||retirementReason(r))throw Error('Ô có điểm/bị khóa/học sinh nghỉ tại STT '+expected.stt);
     entries.set(expected.stt,{cell,identities:r.cells.slice(0,4),cells:r.cells.slice(),stamp:rowStamp(cell),name:expected.name,dob:expected.dob,stt:expected.stt});
   }
   const token='bound-'+Math.random().toString(36).slice(2);
   if(window.__vsaBound?.disarm)window.__vsaBound.disarm();
   window.__vsaBound={token,url:location.href,column:a.column,entries};
   return token;
 }
 if(a.op==='bound_view'||a.op==='bound_reveal'||a.op==='bound_focus'||a.op==='bound_check'||a.op==='bound_snapshot'){
   const b=window.__vsaBound;
   if(!b||b.token!==a.token||b.url!==location.href)throw Error('Liên kết ô điểm không còn hợp lệ; cần dò lại lớp.');
   if(a.op==='bound_view'){
     const expected=a.run[0],e=b.entries.get(expected.stt),state=boundState(e,expected);
     if(!state.valid)throw Error('Chưa thể cuộn STT '+expected.stt+': '+state.problems.join('; '));
     const v=cellView(e.cell);
     if(v.point)return {ready:true,position:v.point};
     const host=v.host;
     if(!host||v.box.right-v.box.left<8||v.box.bottom-v.box.top<8)throw Error('Khung điểm không hiển thị để cuộn tới STT '+expected.stt);
     const q=host.getBoundingClientRect(),x=(v.box.left+v.box.right)/2,y=(v.box.top+v.box.bottom)/2;
     return {ready:false,selector:mark(host),position:{x:x-q.left,y:y-q.top},
       dx:Math.max(-900,Math.min(900,v.dx)),dy:Math.max(-900,Math.min(900,v.dy))};
   }
   if(a.op==='bound_reveal'){
     const e=b.entries.get(a.run[0].stt);
     const state=boundState(e,a.run[0]);
     if(!state.valid)throw Error('Chưa thể chọn STT '+a.run[0].stt+': '+state.problems.join('; '));
     // Scroll the actual score cell once. Independently centering the frozen and
     // editable panels can create different Y offsets; identity never depends on Y.
     e.cell.scrollIntoView({block:'nearest',inline:'nearest'});
     return true;
   }
   const result=[];let first=null;
   for(const expected of a.run){
     const e=b.entries.get(expected.stt),state=boundState(e,expected);
     if(!state.valid){
       if(a.op==='bound_snapshot')continue;
       throw Error('Ô điểm chưa qua đối chiếu STT '+expected.stt+': '+state.problems.join('; '));
     }
     if(a.op==='bound_snapshot'){
       result.push({stt:expected.stt,name:expected.name,dob:expected.dob,
         cells:[String(expected.stt),text(e.identities[1]),text(e.identities[2]),expected.dob,text(e.cell)],saved:[false,false,false,false,green(e.cell)]});
     }else{
       if(text(e.cell)||locked(e.cell))throw Error('Ô đã có điểm hoặc bị khóa ở STT '+expected.stt);
       if(!first)first=e.cell;
     }
   }
   if(a.op==='bound_snapshot')return {rows:result,url:location.href};
   if(!first)throw Error('Vùng dán trống.');
   if(a.op==='bound_check'){
     const proof=b.proof;
     if(b.disarm)b.disarm();
     if(document.querySelector(a.selector)!==first||!proof?.down||!proof?.click||proof.wrong)
       throw Error('Chưa ghi nhận thao tác bấm thật vào đúng ô điểm đã đối chiếu.');
     return true;
   }
   clickProof(b,first);
   return mark(first);
 }
 if(a.op==='busy'){
   const overlays=[...document.querySelectorAll('#loading,.blockUI.blockOverlay,.loading-overlay,.loading-backdrop,[aria-busy="true"]')]
     .filter(e=>vis(e)&&getComputedStyle(e).pointerEvents!=='none');
   return overlays.map(e=>({tag:e.tagName,id:e.id||'',ariaHidden:e.getAttribute('aria-hidden')}));
 }
 if(a.op==='snapshot'||a.op==='snapshot_all'){
   let rows=[],seen=new Map();
   const records=dataRecords(a.op==='snapshot_all');
   for(const r of records){
     const c=r.cells, t=c.map(text), stt=Number(t[0]);
     const reason=retirementReason(r);
     const row={stt,name:fullName(c),dob:t[3],cells:t,cellCount:c.length,inactive:!!reason,inactiveReason:reason,locks:c.map(locked),saved:c.map(green)};
     const prev=seen.get(stt);
     if(prev&&(prev.name!==row.name||prev.dob!==row.dob||JSON.stringify(prev.cells)!==JSON.stringify(row.cells)))throw Error('Các bản sao bảng không khớp ở STT '+stt);
     if(!prev){rows.push(row);seen.set(stt,row)}
   }
   return {rows:rows.sort((x,y)=>x.stt-y.stt),url:location.href,headerPaths:htmlHeaderPaths(records[0])};
 }
 if(a.op==='headers'){
   const first=dataRecords()[0];if(!first)return [];
   let scopes=[];for(let n=first.node.closest('table,[role="grid"],.ag-root,.wj-flexgrid,.pq-grid');n&&n!==document.body;n=n.parentElement){scopes.push(n);if(n.querySelectorAll('table').length>8)break}
   const results=[];
   const preferred=htmlHeaderPaths(first);
   if(preferred)return [[preferred.map(t=>({text:t,rowspan:1,colspan:1}))]];
   const wijmo=first.node.closest('.wj-flexgrid');
   if(wijmo){
     const hs=[...wijmo.querySelectorAll('.wj-colheaders .wj-cell,.wj-topleft .wj-cell,[wj-part="ch"] .wj-cell,[wj-part="tl"] .wj-cell')].filter(vis);
     const paths=first.cells.map(c=>{
       const r=c.getBoundingClientRect(),center=r.left+r.width/2;
       return [...new Set(hs.filter(h=>{const b=h.getBoundingClientRect();return center>=b.left-1&&center<=b.right+1})
         .sort((x,y)=>x.getBoundingClientRect().top-y.getBoundingClientRect().top).map(text).filter(Boolean))].join(' ');
     });
     if(paths.length&&norm(paths[0])==='stt')results.push([paths.map(t=>({text:t,rowspan:1,colspan:1}))]);
   }
   if(first.view){
     const left=[...first.view.querySelectorAll('.datagrid-view1 .datagrid-header tr')].filter(vis);
     const right=[...first.view.querySelectorAll('.datagrid-view2 .datagrid-header tr')].filter(vis);
     const merged=[];
     for(let i=0;i<Math.max(left.length,right.length);i++){
       const cc=[...(left[i]?cells(left[i]):[]),...(right[i]?cells(right[i]):[])];
       merged.push(cc.map(c=>({text:text(c),rowspan:c.rowSpan||1,colspan:c.colSpan||1})));
     }if(merged.length)results.push(merged);
   }
   for(const scope of scopes){
     const tables=scope.matches('table')?[scope]:[...scope.querySelectorAll('table')];
     for(const table of tables){
       const rr=[...table.querySelectorAll('tr')].filter(r=>{const c=cells(r);return c.length&&vis(r)&&!/^\d{1,3}$/.test(text(c[0]))&&c.some(e=>text(e))});
       if(rr.length&&rr.length<=5)results.push(rr.map(r=>cells(r).map(c=>({text:text(c),rowspan:c.rowSpan||1,colspan:c.colSpan||1}))));
     }
     const aria=[...scope.querySelectorAll('[role="row"]')].filter(r=>r.querySelector('[role="columnheader"]'));
     if(aria.length)results.push(aria.map(r=>[...r.querySelectorAll('[role="columnheader"]')].map(c=>({text:text(c),colspan:Number(c.getAttribute('aria-colspan')||1),rowspan:Number(c.getAttribute('aria-rowspan')||1)}))));
     if(results.some(raw=>raw.some(rr=>rr.some(c=>norm(c.text)==='stt'))))break;
   }return results;
 }
 if(a.op==='select'){
   const sels=[...document.querySelectorAll('select')].filter(vis);
   for(const s of sels){const opts=[...s.options].filter(o=>a.values.map(norm).includes(norm(o.text)));if(opts.length===1)return {selector:mark(s),value:opts[0].value,selected:s.value===opts[0].value};}
   return null;
 }
 if(a.op==='target'){
   let root=a.group?region(a.group,a.values):document;
   if(!root)return null;
   let candidates=leaves(root,a.values,a.includeHidden?false:true);
   if(!a.group && a.values.map(norm).includes('nhap diem')){
     const menu=candidates.filter(e=>e.closest('.dropdown-menu,[role="menu"],.wj-menu,.menu'));
     if(menu.length)candidates=menu;
   }
   if(a.branch){
     let branchRoots=[];
     for(const label of leaves(root,[a.branch],false)){
       const wn=label.closest('.wj-node');
       if(wn){
         const nested=wn.querySelector('.wj-nodelist');
         const sibling=wn.nextElementSibling;
         const children=nested||(sibling?.matches('.wj-nodelist')?sibling:null);
         if(children)branchRoots.push(children);
         continue;
       }
       for(let n=label.parentElement;n&&n!==root;n=n.parentElement){
         if(leaves(n,a.values,false).length){branchRoots.push(n);break}
       }
     }
     candidates=candidates.filter(e=>branchRoots.some(r=>r.contains(e)));
   }
   if(candidates.length!==1)return {ambiguous:candidates.length};
   let e=candidates[0], exp=e.closest('[aria-expanded]'), wn=e.closest('.wj-node');
   let toggle=null;
   if(wn?.matches('.wj-state-collapsed'))toggle=wn.querySelector('.wj-nodebutton,.wj-glyph-right');
   for(let n=e.parentElement;n&&n!==root;n=n.parentElement){const t=n.querySelector(':scope > .tree-hit.tree-collapsed,:scope > .tree-node > .tree-hit.tree-collapsed,:scope.jstree-closed > .jstree-ocl');if(t){toggle=t;break}}
   return {selector:mark(e),active:active(e,root),text:text(e),
     expanded:wn?.matches('.wj-state-collapsed')?'false':(exp?.getAttribute('aria-expanded')||(wn?'true':null)),
     expandSelector:wn?mark(wn):null,expandMode:wn?'wijmo':null,
     toggle:toggle?mark(toggle):null};
 }
 if(a.op==='year'){
   let found=leaves(document,[a.year]);return {matched:found.length===1,selector:found.length===1?mark(found[0]):null,
   current:[...document.querySelectorAll('a,button,span')].filter(e=>vis(e)&&/^\d{4}\s*[-–]\s*\d{4}$/.test(text(e))).map(e=>({text:text(e),selector:mark(e)})).filter((v,i,arr)=>arr.findIndex(x=>norm(x.text)===norm(v.text))===i)};
 }
 if(a.op==='reveal'){
   const matches=dataRecords(true).filter(r=>text(r.cells[0])===String(a.student.stt)&&fullName(r.cells)===a.student.name&&text(r.cells[3])===a.student.dob);
   if(matches.length!==1)return false;
   for(const cell of [matches[0].cells[3],matches[0].cells[4]])cell.scrollIntoView({block:'center',inline:'nearest'});
   return true;
 }
 if(a.op==='scroll_init'){
   const first=dataRecords()[0],scrolls=[];
   const add=n=>{if(!n||scrolls.includes(n))return;const r=n.getBoundingClientRect();
     if(vis(n)&&n.clientHeight>=80&&r.width>=8&&n.scrollHeight>n.clientHeight+4)scrolls.push(n)};
   // Include programmatically scrollable overflow:hidden containers and sibling
   // native scrollbar tracks used by split grids, not just ancestors of one cell.
   for(let n=first?.node.parentElement;n;n=n.parentElement)add(n);
   for(const n of document.querySelectorAll('div,section,main'))add(n);
   window.__vsaScrolls=scrolls.slice(0,12);
   window.__vsaScrollPositions=window.__vsaScrolls.map(n=>n.scrollTop);
   return window.__vsaScrolls.length;
 }
 if(a.op==='scroll'){
   const n=window.__vsaScrolls?.[a.i];if(!n||!n.isConnected)return {end:true,blocked:true};
   const before=n.scrollTop;
   n.scrollTop=a.top?0:before+Math.max(40,n.clientHeight*.6);
   const blocked=!a.top&&Math.abs(n.scrollTop-before)<1;
   return {end:blocked||n.scrollTop+n.clientHeight>=n.scrollHeight-2,blocked,top:n.scrollTop,max:Math.max(0,n.scrollHeight-n.clientHeight)};
 }
 if(a.op==='restore'){
   (window.__vsaScrolls||[]).forEach((n,i)=>{if(n.isConnected)n.scrollTop=window.__vsaScrollPositions[i]});return true;
 }
 if(a.op==='focus'||a.op==='verify_focus'){
   let first=null;
   for(const x of a.run){
     const rr=dataRecords().filter(r=>{let c=r.cells;return text(c[0])===String(x.stt)&&fullName(c)===x.name&&text(c[3])===x.dob});
     if(rr.length!==1)throw Error('Không tìm được ô duy nhất của STT '+x.stt);
     let cc=rr[0].cells,c=cc[a.index];
     if(!c||text(c)||locked(c)||retirementReason(rr[0]))throw Error('Học sinh nghỉ, ô khóa hoặc đã có điểm ở STT '+x.stt);
     if(!first)first=c;
   }
   if(a.op==='verify_focus'){
     if(document.querySelector(a.selector)!==first)throw Error('Bảng đã cuộn hoặc thay ô sau khi chọn. Không dán vào ô chưa được đối chiếu lại.');
     return true;
   }
   first.scrollIntoView({block:'center',inline:'center'});return mark(first);
 }
 if(a.op==='save'){
   const found=[...document.querySelectorAll('button,a,[role="button"]')].filter(e=>vis(e)&&(/^(lưu|lưu điểm|save)$/i.test(text(e))||/^(lưu|lưu điểm|save)$/i.test(e.title||e.getAttribute('aria-label')||'')||e.querySelector('.fa-save,.fa-floppy-o,.glyphicon-floppy-disk,.mdi-content-save')));
   return found.length===1?mark(found[0]):null;
 }
 if(a.op==='diagnostic'){
   let readable=null,error=null;try{readable=dataRecords().length}catch(e){error=String(e)}
   const stats={};for(const sel of ['table',ROW,'.wj-flexgrid','.wj-cells','.wj-cell','.wj-rowheaders','.wj-colheaders','[role="grid"]'])stats[sel]=document.querySelectorAll(sel).length;
   const shapes=[...document.querySelectorAll('.wj-cells .wj-cell,[role="gridcell"]')].filter(vis).slice(0,24).map(e=>{
     const r=e.getBoundingClientRect(),t=text(e);
     return {tag:e.tagName,classes:e.className,role:e.getAttribute('role'),ariaRow:e.getAttribute('aria-rowindex'),ariaCol:e.getAttribute('aria-colindex'),
       left:Math.round(r.left),top:Math.round(r.top),width:Math.round(r.width),height:Math.round(r.height),
       textKind:!t?'blank':/^\d{1,3}$/.test(t)?'integer':/^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$/.test(t)?'date':'text'};
   });
   const ownRowsForDiagnostic=table=>[...table.querySelectorAll('tr')].filter(r=>r.closest('table')===table).map((r,i)=>{const c=cells(r);return {slot:i+1,cells:c.length,number:c.length===4&&/^\d{1,3}$/.test(text(c[0]))?Number(text(c[0])):null,birthKind:c.length===4?(!text(c[3])?'blank':/^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$/.test(text(c[3]))?'date':'other'):null}});
   const tableShapes=[...document.querySelectorAll('table')].slice(0,20).map(table=>({
     classes:table.className,rows:table.querySelectorAll('tr').length,
     rowSlots:table.matches('.progrid-btable')?ownRowsForDiagnostic(table):undefined,
     samples:[...table.querySelectorAll('tr')].filter(r=>cells(r).length).slice(0,6).map(r=>cells(r).map(c=>{
       const t=text(c),b=c.getBoundingClientRect();return {tag:c.tagName,classes:c.className,colspan:c.colSpan||1,rowspan:c.rowSpan||1,
         left:Math.round(b.left),top:Math.round(b.top),width:Math.round(b.width),height:Math.round(b.height),
         textKind:!t?'blank':/^\d{1,3}$/.test(t)?'integer':/^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$/.test(t)?'date':'text'};
     }))
   }));
   return {url:location.origin+location.pathname,stats,dataRows:readable,error,cellShapes:shapes,tableShapes,
     navigation:[...document.querySelectorAll('.wj-nodetext,.tree-title,[role="treeitem"]')].filter(vis).map(e=>({label:text(e),normalized:norm(text(e)),classes:e.className}))
       .filter(e=>e.label.length<80&&/^(khoi\s*(10|11|12)|hoc ky\s*[12]|dgtx|thi|(?:10|11|12)[a-z]\s*0?\d+)\b/.test(e.normalized)).slice(0,100),
     clickProof:window.__vsaBound?.proof||null,
     boundCells:window.__vsaBound?[...window.__vsaBound.entries.values()].map(e=>({stt:e.stt,...boundState(e,{stt:e.stt,name:e.name,dob:e.dob}),visible:!!cellView(e.cell).point,rect:JSON.parse(JSON.stringify(e.cell.getBoundingClientRect()))})):[],
     scrollBoxes:[...document.querySelectorAll('div,section,main')].filter(e=>vis(e)&&e.clientHeight>=80&&e.scrollHeight>e.clientHeight+4).slice(0,20).map(e=>({classes:e.className,top:e.scrollTop,height:e.clientHeight,total:e.scrollHeight,overflow:getComputedStyle(e).overflowY})),
     headers:[...document.querySelectorAll('.wj-colheaders .wj-cell,.wj-topleft .wj-cell')].filter(vis).map(text).slice(0,30)};
 }
 return null;
}'''
