# Bé Bi — Linh vật HTB AI Agent

Ảnh gốc: `be_bi.png`, PNG RGBA nền trong suốt. Tạo bằng công cụ tạo ảnh tích hợp, dùng cho giao diện bộ Agent trên máy tính. Ứng dụng giữ nguyên ảnh gốc, hiển thị thu nhỏ bằng Tkinter và tạo chuyển động nhún bằng mã giao diện.

Prompt thiết kế:

Use case: stylized-concept. Asset type: transparent desktop application mascot asset. Design a single extremely cute friendly small AI helper robot for a Vietnamese school administrative application. White soft rounded toy-like body, sky blue and cobalt blue accents, oversized rounded head with glossy navy face display, two large bright cyan expressive eyes, a tiny happy smile, subtle pink cheeks, tiny blue antenna, short stubby legs and rounded arms, one little hand waving hello. Warm gentle 3D clay-toy render, tasteful modern professional cute aesthetic. Full body front view, centered, entire character visible, roughly square composition with generous transparent margin around antenna and waving hand. Soft studio lighting, no cast background plane or floor, genuine transparent alpha background. This is ONE character, ONE pose, no sprite sheet, no scene, no additional objects, no letters, no text, no logo, no watermark. Clear silhouette and readable even at 100 pixels.
