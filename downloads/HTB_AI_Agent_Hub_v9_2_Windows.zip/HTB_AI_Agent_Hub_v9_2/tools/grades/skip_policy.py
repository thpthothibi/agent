"""Explicit user-requested skip, scoped by class and full name."""
from chrome_bridge import normalize_name

SKIP_STATUS='Bỏ qua theo yêu cầu: trùng tên'
SKIP_REASON='Lớp 12A06: bỏ qua cả hai em Trần Ngọc Khánh theo yêu cầu; giữ nguyên điểm web'

def requested_skip(clazz,name):
    return normalize_name(clazz)=='12a06' and normalize_name(name)=='tran ngoc khanh'
