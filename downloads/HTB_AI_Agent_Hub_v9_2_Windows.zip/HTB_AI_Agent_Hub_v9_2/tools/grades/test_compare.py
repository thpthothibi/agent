import tempfile
import threading
import queue
import unittest
from pathlib import Path
from unittest.mock import patch
from openpyxl import load_workbook
from compare_core import compare_rows, summary, UNCHECKED
from check_worker import CheckWorker

def source(name='Winnie', value='7.5', **extra):
    return dict(student=name,TX1=value,row=2,sheet='Diem',dob='',**extra)
def web(name='Winnie', value='7,5', stt=1, **extra):
    return dict(name=name,stt=stt,dob='01/01/2010',cells=[str(stt),'',name,'01/01/2010',value],**extra)
def job(rows=None,**extra):
    return {**dict(year='2026-2027',subject='Toán',term='Học kỳ 1',column='TX1',
                **{'class':'10A01'},rows=rows or [source()]),**extra}

class CompareTests(unittest.TestCase):
    def status(self,src=None,site=None,**kw):
        return compare_rows(job([src or source()],**kw),site if site is not None else [web()],4)[0]['result']
    def test_normalized_number_and_single_name(self):
        self.assertEqual(self.status(),'Đúng')
        self.assertEqual(self.status(site=[web(value='7.50')]),'Đúng')
        self.assertEqual(self.status(source(value=0),[web(value='0')]),'Đúng')
    def test_wrong_missing_invalid(self):
        for value,expected in [('8','Sai điểm'),('','Thiếu điểm trên web'),('abc','Giá trị web không hợp lệ')]:
            self.assertEqual(self.status(site=[web(value=value)]),expected)
    def test_rating(self):
        self.assertEqual(self.status(source(value='Đ'),[web(value='Đạt')],subject='GDTC'),'Đúng')
        self.assertEqual(self.status(source(value='Đ'),[web(value='CĐ')],subject='GDTC'),'Sai điểm')
        self.assertEqual(self.status(source(value='Đ'),[web(value='Đạt')],subject='HĐTN3'),'Đúng')
    def test_order_and_accents(self):
        rows=compare_rows(job([source('Nguyễn An'),source('Winnie',value='8')]),
                          [web('Winnie','8'),web('Nguyen An','7.5',2)],4)
        self.assertEqual([r['result'] for r in rows],['Đúng','Đúng'])
    def test_blank_not_correct(self):
        self.assertEqual(self.status(source(value=None)),'Excel trống — web có điểm')
        self.assertEqual(self.status(source(value=None),[web(value='')]),'Excel trống — không kết luận')
    def test_inactive(self):
        self.assertEqual(self.status(source(inactive=True)),'Bỏ qua: học sinh nghỉ')
        self.assertEqual(self.status(site=[web(inactive=True)]),'Bỏ qua: học sinh nghỉ')
    def test_missing_extra_duplicate(self):
        self.assertEqual(self.status(site=[]),'Không tìm thấy học sinh')
        self.assertEqual(self.status(site=[web(),web(stt=2)]),UNCHECKED)
        rows=compare_rows(job(),[web(),web('An',stt=2)],4)
        self.assertEqual(rows[-1]['result'],'Web có học sinh ngoài Excel')
    def test_dob(self):
        self.assertEqual(self.status(dict(source(),dob='2010-01-01 00:00:00')),'Đúng')
        self.assertEqual(self.status(dict(source(),dob='02/01/2010')),UNCHECKED)
    def test_one_missing_birth_does_not_block_other_students(self):
        sources=[dict(source(name),dob='01/01/2010') for name in ('An','Bình','Chi')]
        site=[web('An',stt=1),web('Bình',stt=2),web('Chi',stt=3)]
        site[1]['dob']='';site[1]['cells'][3]=''
        rows=compare_rows(job(sources),site,4)
        self.assertEqual([r['result'] for r in rows],['Đúng',UNCHECKED,'Đúng'])
        self.assertEqual(rows[2]['stt'],3)

    def test_locked_and_missing_cell(self):
        self.assertEqual(self.status(site=[web(locks=[True]*5)]),'Đúng')
        short=web();short['cells']=[]
        self.assertEqual(self.status(site=[short]),UNCHECKED)
    def test_read_only_guards(self):
        w=CheckWorker('',queue.Queue(),threading.Event())
        for op in ('save','focus','bind_column','bound_focus'):
            with self.assertRaises(RuntimeError):w.dom(None,op)
        with self.assertRaises(RuntimeError):w.paste(None)
    def test_job_failure_and_success(self):
        w=CheckWorker('',queue.Queue(),threading.Event())
        w.navigate=lambda *a:None;w.prepare_grid=lambda:None
        w.grid=lambda:(None,{})
        w.headers=lambda *a:4;w.scope_is_selected=lambda *a:None;w.tick=lambda *a:None
        w.page=lambda:None
        w.collect=lambda *a:[web()]
        w.process_job(job(),1,1)
        self.assertEqual(w.audit[0]['result'],'Đúng')
        w.audit=[];w.finished=set()
        w.collect=lambda *a:(_ for _ in ()).throw(RuntimeError('Bảng lỗi'))
        w.process_job(job(),1,1)
        self.assertEqual(w.audit[0]['result'],UNCHECKED)
        self.assertIn('Bảng lỗi',w.audit[0]['reason'])
    def test_unstable_table(self):
        w=CheckWorker('',queue.Queue(),threading.Event())
        w.navigate=lambda *a:None;w.prepare_grid=lambda:None;w.grid=lambda:(None,{})
        w.headers=lambda *a:4;w.scope_is_selected=lambda *a:None;w.tick=lambda *a:None;w.page=lambda:None
        with patch.object(w,'collect',side_effect=[[web()],[web(value='9')]]):
            w.process_job(job(),1,1)
        self.assertEqual(w.audit[0]['result'],UNCHECKED)
    def test_partial_report_preserves_unchecked_and_text(self):
        with tempfile.TemporaryDirectory() as temp:
            w=CheckWorker('',queue.Queue(),threading.Event())
            w.jobs=[job([source('=NAME')])]
            with patch('check_worker.__file__',str(Path(temp)/'check_worker.py')):
                path=w.report('Dừng')
            wb=load_workbook(path)
            self.assertEqual(wb.sheetnames,['Tong_hop','Tat_ca','Can_kiem_tra'])
            rows=list(wb['Tat_ca'].values)
            self.assertEqual(rows[1][12],UNCHECKED)
            self.assertEqual(rows[1][8],"'=NAME")
            self.assertEqual(wb['Tat_ca']['I2'].data_type,'s')
            wb.close()
            self.assertNotIn('Đúng: 1',summary(w.audit))

if __name__=='__main__':unittest.main()
