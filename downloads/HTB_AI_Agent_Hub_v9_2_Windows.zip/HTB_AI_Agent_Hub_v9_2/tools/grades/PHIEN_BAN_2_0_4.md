# HTB AI Agent v2.0.4

Ghép toàn bộ vị trí hàng Progrid trước khi bỏ hàng căn trống ở cả hai bên. Đọc tiêu đề gộp rowspan/colspan từ bảng tiêu đề đúng khung và bổ sung tên cột ĐGK/ĐCK. Ghi vị trí cột đã nhận diện vào nhật ký.

Kiểm thử: 19 ca DOM mô phỏng; 108 ca Python đạt, 1 bỏ qua. Chưa thử trực tiếp trên phiên VietSchool người dùng.
Mở CHAY_HTB_AI_AGENT.bat → Đối chiếu điểm → Chọn Excel → Bắt đầu đối chiếu.
