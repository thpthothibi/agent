import io
import json
import unittest
from unittest.mock import patch
from docx import Document
from report_engine import extract, parse_openai, parse_gemini, generate, to_docx, research_prompt

class EngineTests(unittest.TestCase):
    def test_docx_order_and_export(self):
        doc = Document()
        doc.add_paragraph('Trước bảng')
        doc.add_table(rows=1, cols=1).cell(0,0).text = 'Số liệu 125'
        doc.add_paragraph('Sau bảng')
        f = io.BytesIO(); doc.save(f)
        text = extract('mau.docx', f.getvalue())
        self.assertLess(text.index('Trước'), text.index('125'))
        self.assertLess(text.index('125'), text.index('Sau'))
        exported = Document(io.BytesIO(to_docx('# Báo cáo\nNội dung\n| Việc | Số |\n|---|---|\n| Dạy | 125 |')))
        self.assertEqual(exported.tables[0].cell(1,1).text, '125')
        self.assertEqual(exported.paragraphs[0].text, 'Báo cáo')

    def test_empty_and_unsupported(self):
        for name, data in [('x.txt', b''), ('x.exe', b'abc')]:
            with self.assertRaises(ValueError): extract(name, data)

    def test_openai_citations_and_status(self):
        response = {'output':[{'type':'web_search_call'}, {'type':'message','content':[
            {'type':'output_text','text':'Kết quả [1]', 'annotations':[
                {'type':'url_citation','url':'https://example.org','title':'Nguồn','start_index':8,'end_index':11}]}]}]}
        r = parse_openai(response)
        self.assertTrue(r.searched)
        self.assertIn('https://example.org', r.text)
        with self.assertRaises(RuntimeError): parse_openai({'status':'incomplete'})

    def test_gemini_utf8_citation(self):
        text = 'Kế hoạch trường học.'
        response = {'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':text}]},
            'groundingMetadata':{'webSearchQueries':['giáo dục'],
                'groundingChunks':[{'web':{'uri':'https://example.org','title':'Nguồn'}}],
                'groundingSupports':[{'segment':{'endIndex':len(text.encode())},'groundingChunkIndices':[0]}]}}]}
        r = parse_gemini(response)
        self.assertTrue(r.text.startswith(text))
        self.assertIn('[nguồn 1]', r.text)
        self.assertTrue(r.searched)

    @patch('report_engine.post')
    def test_provider_payloads(self, post):
        post.return_value = {'output':[{'type':'message','content':[{'type':'output_text','text':'ok'}]}]}
        generate('OpenAI','fake','model','request', True)
        payload = post.call_args.args[2]
        self.assertEqual(payload['tool_choice'], 'required')
        self.assertFalse(payload['store'])
        post.return_value = {'candidates':[{'content':{'parts':[{'text':'ok'}]},'finishReason':'STOP'}]}
        generate('Gemini','fake','model','request', True)
        self.assertEqual(post.call_args.args[2]['tools'], [{'google_search':{}}])

    def test_search_does_not_include_unit(self):
        prompt = research_prompt('CNTT', 'Kế hoạch', 'SECRET INTERNAL UNIT', '2026')
        self.assertNotIn('SECRET INTERNAL UNIT', prompt)

if __name__ == '__main__': unittest.main()
