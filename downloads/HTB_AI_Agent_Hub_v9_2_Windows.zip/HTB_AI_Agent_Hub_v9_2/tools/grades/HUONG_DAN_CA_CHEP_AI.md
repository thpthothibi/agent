# Cá Chép AI — HTB AI Agent v2.1.6

Giải nén toàn bộ thư mục rồi chạy CHAY_HTB_AI_AGENT.bat trên Windows như bản trước.

- Cá chép robot vàng cam thay Bé Bi; tên trợ lý và lời chào đã đổi sang Cá Chép AI.
- Kéo nhân vật để di chuyển trong cửa sổ ứng dụng; bấm để mở trò chuyện.
- Chuột phải để bật/tắt chuyển động, về vị trí ban đầu hoặc ẩn nhân vật.
- Bấm nút Cá Chép AI ở đầu ứng dụng để hiện lại nhân vật.
- Cá chép tự bơi ngang qua lại trong cửa sổ và quay đầu ở hai mép. Kéo cá lên hoặc xuống để đổi đường bơi.
- Khi rê chuột lên cá, kéo thả hoặc mở menu tùy chỉnh, cá tạm dừng. Bấm trò chuyện sẽ tạm dừng 1,2 giây.
- Chuột phải → Tự bơi qua lại để bật/tắt. Khi thu nhỏ ứng dụng, cá ngừng bơi.
- Hoạt ảnh mới gồm 96 khung hình mỗi hướng: sóng uốn thân tăng dần về đuôi, vây chuyển động theo nhịp, thân nghiêng nhẹ; tốc độ bơi thay đổi nhẹ theo nhịp quẫy.
- Khi chạm mép, cá mất khoảng 1 giây để thu thân, đổi hướng và mở thân trở lại. Đường bơi có độ lượn lên xuống nhẹ.
- Đây là hoạt ảnh 2D từ hình cá chép robot, chưa phải mô hình cá 3D hoặc mô phỏng sinh học. Miệng chưa đồng bộ lời nói.
- Mở XEM_TRUOC_CA_BOI_60FPS.mp4 để xem mẫu chuyển động trước khi chạy ứng dụng.
- Các công cụ nhập điểm, đối chiếu, cộng điểm, SBD/phòng thi và báo cáo giữ nguyên.
- Trò chuyện sử dụng cấu hình nhà cung cấp AI/API hiện có trong ứng dụng.
- Đường dẫn du_lieu_be_bi/lich_su.json giữ nguyên để tương thích lịch sử cũ. Nếu chuyển sang thư mục giải nén mới, sao chép thư mục du_lieu_be_bi từ bản cũ sang cùng vị trí.

## Cải thiện độ mượt v2.1.6

- Mục tiêu hiển thị 60 FPS (phụ thuộc tải máy và bộ lập lịch Windows).
- 96 khung hình bơi mỗi hướng, 32 mức thu thân để quay đầu.
- Nhịp quẫy chậm hơn, giảm dao động tốc độ; cá giảm tốc gần mép và quay đầu theo đường cong chuyển động mềm.
- Không gửi lại vị trí cửa sổ khi tọa độ chưa đổi; bộ hẹn giờ bù thời gian dựng khung hình.
- Video xem trước là bản dựng mẫu 60 FPS, không phải phép đo FPS trên máy Windows của thầy.

Bản v2.4.1: tooltip chỉ dừng 1,5 giây; chuột phải → Cho cá bơi lại để khôi phục chuyển động.
