# -*- coding: utf-8 -*-
"""HTB AI Agent — desktop dashboard, v2.0 with Cá Chép AI AI chat and document assistance."""
from pathlib import Path
import os
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import webbrowser
from vietschool_agent_v2 import AutoApp as InputApp
from doi_chieu_vietschool import AutoApp as CheckApp
from report_workspace import ReportWorkspace
from mascot import FloatingMascot
from robot_chat import RobotChat
from cong_diem.app import App as SumWorkspace
from transfer_workspace import TransferWorkspace
from startup_errors import install_callback_reporting
from desktop_ui import FONT, BG, WHITE, INK, MUTED, BLUE, LINE, NAVY
from desktop_ui import label, card, button, configure, ScrollPage, build_workspace

BASE=Path(__file__).resolve().parent

class InputWorkspace(InputApp):
    def __init__(self,root,hub):build_workspace(self,root,hub)

class CheckWorkspace(CheckApp):
    def __init__(self,root,hub):build_workspace(self,root,hub,checking=True)

class Hub:
    def __init__(self,root):
        self.root=root;self.apps=[];self.path=tk.StringVar()
        install_callback_reporting(root,BASE,lambda:self.apps)
        self.file_name=tk.StringVar(value='Chưa chọn file • Hỗ trợ .xlsx')
        self.path.trace_add('write',self.update_file)
        self.compact=False;self.current=0;self.nav=[]
        self.titles=['Tổng quan','Nhập điểm VietSchool','Đối chiếu điểm','SBD & Phòng thi','Báo cáo & Kế hoạch','Trò chuyện Cá Chép AI','Cộng điểm TL + TN','Chuyển điểm vào mẫu']
        root.title('HTB AI Agent • Không gian làm việc')
        root.configure(bg=BG)
        width=min(1360,root.winfo_screenwidth()-50);height=min(900,root.winfo_screenheight()-80)
        root.geometry(f'{width}x{height}')
        root.minsize(960,660)
        configure(root)
        self.side=tk.Frame(root,bg=NAVY,width=230);self.side.pack(side='left',fill='y');self.side.pack_propagate(False)
        brand=tk.Frame(self.side,bg=NAVY,padx=20,pady=28);brand.pack(fill='x')
        label(brand,'HTB',size=27,bg=NAVY,color=WHITE,bold=True).pack(anchor='w')
        self.brand_text=label(brand,'AI AGENT  /  WORKSPACE',size=8,bg=NAVY,color='#A8C3E6',bold=True);self.brand_text.pack(anchor='w',pady=(4,0))
        self.menu_caption=label(self.side,'KHÔNG GIAN LÀM VIỆC',size=8,bg=NAVY,color='#7395BF',bold=True);self.menu_caption.pack(anchor='w',padx=20,pady=(12,14))
        self.menu_items=[('⌂','Tổng quan'),('↗','Nhập điểm'),('✓','Đối chiếu điểm'),('▦','SBD & Phòng thi'),('✎','Báo cáo & Kế hoạch'),('♡','Trò chuyện Cá Chép AI'),('+','Cộng điểm TL + TN'),('⇄','Chuyển điểm vào mẫu')]
        for i,(icon,title) in enumerate(self.menu_items):
            item=tk.Button(self.side,text=f'{icon}    {title}',command=lambda j=i:self.show(j),anchor='w',padx=18,pady=8,font=(FONT,11),fg='#BCD0E8',bg=NAVY,activebackground='#21446E',activeforeground=WHITE,relief='flat',bd=0,highlightthickness=0,cursor='hand2')
            item.pack(fill='x',padx=12,pady=2);self.nav.append(item)
        self.side_bottom=tk.Frame(self.side,bg=NAVY,padx=20,pady=22);self.side_bottom.pack(side='bottom',fill='x')
        self.report_button=tk.Button(self.side_bottom,text='↗   Thư mục báo cáo',command=self.reports,font=(FONT,10),fg='#BED1E9',bg=NAVY,activebackground='#21446E',activeforeground=WHITE,bd=0,highlightthickness=0,anchor='w',cursor='hand2');self.report_button.pack(fill='x',pady=(0,20))
        self.school=label(self.side_bottom,'THPT HỒ THỊ BI',size=9,color=WHITE,bold=True);self.school.pack(anchor='w')
        self.version=label(self.side_bottom,'Bộ công cụ nghiệp vụ  •  v2.4.1 / vá khởi động',size=8,color='#7395BF');self.version.pack(anchor='w',pady=(5,0))
        main=tk.Frame(root,bg=BG);main.pack(side='left',fill='both',expand=True)
        top=tk.Frame(main,bg=WHITE,padx=20,pady=14,highlightthickness=1,highlightbackground=LINE);top.pack(fill='x')
        tk.Button(top,text='☰',command=self.toggle_menu,bg=WHITE,fg=MUTED,font=(FONT,17),relief='flat',bd=0,highlightthickness=0,cursor='hand2').pack(side='left',padx=(0,16))
        self.breadcrumb=label(top,'Không gian làm việc  /  Tổng quan',size=10,color=MUTED);self.breadcrumb.pack(side='left')
        badge=tk.Frame(top,bg='#EDF4FF',padx=10,pady=6);badge.pack(side='right')
        label(badge,'HTB',size=10,color=BLUE,bold=True).pack()
        self.live=label(top,'●  Sẵn sàng',size=9,color='#26815A');self.live.pack(side='right',padx=18)
        self.mascot=FloatingMascot(root,initial_position=lambda:(max(0,(self.side.winfo_width()-140)//2),max(90,self.side_bottom.winfo_y()-160)))
        button(top,'Cá Chép AI ♡',self.mascot.toggle).pack(side='right',padx=8)
        self.content=tk.Frame(main,bg=BG);self.content.pack(fill='both',expand=True)
        self.mascot.content=self.content
        self.content.grid_rowconfigure(0,weight=1);self.content.grid_columnconfigure(0,weight=1)
        self.pages=[ScrollPage(self.content) for _ in range(8)]
        for page in self.pages:page.grid(row=0,column=0,sticky='nsew')
        self.home(self.pages[0].content)
        self.input=InputWorkspace(self.pages[1].content,self)
        self.check=CheckWorkspace(self.pages[2].content,self)
        self.apps=[self.input,self.check]
        self.exam(self.pages[3].content)
        self.report=ReportWorkspace(self.pages[4].content,self)
        self.apps.append(self.report)
        self.chat=RobotChat(self.pages[5].content,self)
        self.apps.append(self.chat)
        self.mascot.open_chat=lambda:self.show(5)
        self.sum_scores=SumWorkspace(self.pages[6].content,self)
        self.transfer=TransferWorkspace(self.pages[7].content,self)
        self.apps.append(self.transfer)
        self.show(0)
        self.refresh()
        root.protocol('WM_DELETE_WINDOW',self.close)

    def update_file(self,*args):
        value=self.path.get()
        self.file_name.set(Path(value).name if value else 'Chưa chọn file • Hỗ trợ .xlsx')

    def show(self,index):
        self.current=index;self.pages[index].tkraise()
        self.breadcrumb.configure(text='Không gian làm việc  /  '+self.titles[index])
        for i,item in enumerate(self.nav):
            item.configure(bg='#244B7A' if i==index else NAVY,fg=WHITE if i==index else '#BCD0E8',font=(FONT,11,'bold' if i==index else 'normal'))

    def toggle_menu(self):
        self.compact=not self.compact
        self.side.configure(width=84 if self.compact else 230)
        for item,(icon,title) in zip(self.nav,self.menu_items):
            item.configure(text=icon if self.compact else f'{icon}    {title}',anchor='center' if self.compact else 'w',padx=0 if self.compact else 18)
        for widget in (self.brand_text,self.menu_caption,self.school,self.version):
            if self.compact:widget.pack_forget()
        if not self.compact:
            self.brand_text.pack(anchor='w',pady=(4,0))
            self.menu_caption.pack(anchor='w',padx=20,pady=(12,14),before=self.nav[0])
            self.school.pack(anchor='w');self.version.pack(anchor='w',pady=(5,0))
        self.report_button.configure(text='↗' if self.compact else '↗   Thư mục báo cáo')

    def refresh(self):
        active=next((a for a in self.apps if a.busy),None)
        self.mascot.speaking=bool(self.chat.voice_process and self.chat.voice_process.poll() is None)
        self.mascot.update(bool(active),self.current,active.status.get() if active else '',time.monotonic())
        self.live.configure(text='●  Đang xử lý' if active else '●  Sẵn sàng',fg='#BC7D20' if active else '#26815A')
        folder=BASE/'bao_cao'
        count=sum(p.suffix.lower() in ('.xlsx','.csv','.docx','.md','.json') for p in folder.iterdir()) if folder.exists() else 0
        self.reports_value.set(str(count))
        self.file_state.set('Đã chọn Excel' if self.path.get() else 'Chưa chọn Excel')
        self.root.after(750,self.refresh)

    def home(self,root):
        label(root,'BẢNG ĐIỀU KHIỂN',size=9,color=BLUE,bold=True).pack(anchor='w')
        titlebar=tk.Frame(root,bg=BG);titlebar.pack(fill='x',pady=(6,18))
        label(titlebar,'Chào thầy, bắt đầu công việc nhé.',size=23,bold=True).pack(anchor='w')
        label(titlebar,'Nhập điểm, kiểm tra, tổ chức kỳ thi và soạn văn bản trong một không gian.',color=MUTED).pack(anchor='w',pady=(6,0))
        hero=tk.Frame(root,bg=NAVY,padx=24,pady=23);hero.pack(fill='x',pady=(0,18))
        label(hero,'ÍT THAO TÁC HƠN. DỄ THEO DÕI HƠN.',size=9,color='#A4C4F4',bold=True).pack(anchor='w')
        label(hero,'Sẵn sàng cho kỳ kiểm tra tiếp theo',size=21,color=WHITE,bold=True).pack(anchor='w',pady=(9,7))
        label(hero,'Chọn Excel một lần để nhập điểm và đối chiếu với VietSchool.',color='#C3D6EE',wraplength=760,justify='left').pack(anchor='w')
        actions=tk.Frame(hero,bg=NAVY);actions.pack(fill='x',pady=(18,0))
        button(actions,'Chọn file Excel  +',self.browse,True).pack(side='left')
        tk.Button(actions,text='Xem hướng dẫn  ↗',command=self.help,bg=NAVY,fg='#D2E4FF',activebackground='#21446E',activeforeground=WHITE,font=(FONT,10),bd=0,highlightthickness=0,padx=20,cursor='hand2').pack(side='left')
        status=tk.Frame(root,bg=BG);status.pack(fill='x',pady=(0,18))
        self.file_state=tk.StringVar(value='Chưa chọn Excel');self.reports_value=tk.StringVar(value='0')
        for i,(name,value,hint) in enumerate([('CHỨC NĂNG','08','Trong cùng bộ công cụ'),('FILE ĐIỂM',self.file_state,'Dùng chung nhập & đối chiếu'),('BÁO CÁO',self.reports_value,'File đã có trên máy')]):
            status.grid_columnconfigure(i,weight=1,uniform='stat')
            c=card(status,padx=16,pady=13);c.grid(row=0,column=i,sticky='nsew',padx=(0,12) if i<2 else 0)
            label(c,name,size=8,color=MUTED,bold=True).pack(anchor='w')
            if isinstance(value,tk.StringVar):tk.Label(c,textvariable=value,bg=WHITE,fg=INK,font=(FONT,17,'bold')).pack(anchor='w',pady=5)
            else:label(c,value,size=21,bold=True).pack(anchor='w',pady=3)
            label(c,hint,size=9,color=MUTED).pack(anchor='w')
        section=tk.Frame(root,bg=BG);section.pack(fill='x',pady=(0,12))
        label(section,'Thầy muốn thực hiện việc gì?',size=14,bold=True).pack(side='left')
        label(section,'8 chức năng • 1 bộ công cụ',size=9,color=MUTED).pack(side='right')
        grid=tk.Frame(root,bg=BG);grid.pack(fill='x')
        for i in range(2):grid.grid_columnconfigure(i,weight=1,uniform='cards')
        data=[('01','Nhập điểm VietSchool','Tự dò lớp, môn và học sinh từ file Excel. Theo dõi từng dòng xử lý.',1,BLUE,'#EBF2FF'),
              ('02','Đối chiếu điểm','Đọc lại điểm trên VietSchool, so sánh với Excel và xuất báo cáo.',2,'#07856C','#E8F7F1'),
              ('03','Tạo số báo danh','Giữ SBD cũ hoặc tạo mới; tùy chỉnh tiền tố và độ dài phần số.',3,'#7955C8','#F1ECFC'),
              ('04','Sắp xếp phòng thi','Chia phòng theo sĩ số, nhóm môn; xuất danh sách theo mẫu trường.',3,'#AF752B','#FFF5E5'),
              ('05','Báo cáo & Kế hoạch','Gemini và ChatGPT tìm nguồn, viết theo mẫu và rà soát; xuất Word.',4,'#2563EB','#EBF2FF'),
              ('06','Trò chuyện Cá Chép AI','Hỏi đáp bằng AI, đọc tài liệu, tìm web, lưu chat và chuyển bản thảo.',5,'#D64B8B','#FFF0F7'),
              ('07','Cộng điểm TL + TN','Dò họ tên, lớp và môn để cộng hai danh sách; kiểm tra và xuất Excel.',6,'#07856C','#E8F7F1'),
              ('08','Chuyển điểm vào mẫu','Chọn nhiều Excel nguồn, dò cột điểm, xem trước và xuất theo mẫu VietSchool.',7,'#2563EB','#EBF2FF')]
        for n,(number,title,desc,page,accent,tint) in enumerate(data):
            box=card(grid,padx=18,pady=16);box.grid(row=n//2,column=n%2,sticky='nsew',padx=(0,12) if n%2==0 else 0,pady=(0,12))
            head=tk.Frame(box,bg=WHITE);head.pack(fill='x')
            label(head,number,size=12,color=accent,bg=tint,bold=True,padx=10,pady=7).pack(side='left')
            label(head,'EXCEL / NGOẠI TUYẾN' if page in (6,7) else ('AI / VĂN BẢN' if page>=4 else ('VIETSCHOOL' if page!=3 else 'EXCEL / NGOẠI TUYẾN')),size=8,color=MUTED).pack(side='right')
            label(box,title,size=14,bold=True).pack(anchor='w',pady=(12,6))
            label(box,desc,color=MUTED,size=10,wraplength=340,justify='left',anchor='w').pack(anchor='w',fill='x')
            button(box,'Mở chức năng  →',lambda j=page:self.show(j)).pack(anchor='w',pady=(14,0))
        filebox=card(root,padx=16,pady=12);filebox.pack(fill='x',pady=(4,0))
        label(filebox,'FILE ĐANG CHỌN',size=8,color=MUTED,bold=True).pack(anchor='w')
        tk.Label(filebox,textvariable=self.file_name,bg=WHITE,fg=BLUE,font=(FONT,10),wraplength=760,justify='left').pack(anchor='w',pady=(5,0))

    def exam(self,root):
        label(root,'TỔ CHỨC KỲ THI',size=9,color=BLUE,bold=True).pack(anchor='w')
        label(root,'SBD & Phòng thi',size=25,bold=True).pack(anchor='w',pady=(7,5))
        label(root,'Từ danh sách học sinh đến bộ hồ sơ phòng thi hoàn chỉnh.',color=MUTED).pack(anchor='w',pady=(0,22))
        hero=card(root,padx=24,pady=24);hero.pack(fill='x',pady=(0,18))
        label(hero,'CHUẨN BỊ DANH SÁCH',size=9,color=BLUE,bold=True).pack(anchor='w')
        label(hero,'Một lần sắp xếp, đầy đủ hồ sơ',size=22,bold=True).pack(anchor='w',pady=(10,8))
        label(hero,'Chọn file Excel, đặt quy tắc SBD và sĩ số phòng. Xem trước, chỉnh sửa rồi xuất theo mẫu trường.',color=MUTED,wraplength=760,justify='left').pack(anchor='w')
        button(hero,'Mở công cụ SBD & Phòng thi  ↗',self.open_exam,True).pack(anchor='w',pady=(22,0))
        for step,title,desc in [('1','Chọn danh sách Excel','Giữ thứ tự đã sắp hoặc sắp theo tên, lớp, nhóm môn.'),('2','Thiết lập số báo danh & sĩ số','Giữ SBD cũ, tạo liên tục hoặc theo phòng. Đặt sĩ số riêng cho từng phòng.'),('3','Xem trước & xuất danh sách','Sửa tiêu đề, chân trang và chữ ký. Xuất Excel hoặc in thành PDF.')]:
            row=card(root,padx=18,pady=17);row.pack(fill='x',pady=(0,12))
            label(row,step,size=18,color=BLUE,bg='#EDF4FF',padx=14,pady=8,bold=True).pack(side='left',padx=(0,18))
            text=tk.Frame(row,bg=WHITE);text.pack(side='left',fill='x',expand=True)
            label(text,title,size=12,bold=True).pack(anchor='w')
            label(text,desc,color=MUTED,size=10,wraplength=680,justify='left').pack(anchor='w',pady=(5,0))
        label(root,'Mở trong trình duyệt trên máy • Dùng được ngoại tuyến • Chọn Excel riêng trong công cụ này',color=MUTED,size=9,wraplength=800,justify='left').pack(anchor='w',pady=10)

    def help(self):
        path=BASE/'HUONG_DAN.md'
        if os.name=='nt':os.startfile(str(path))
        else:webbrowser.open(path.as_uri())

    def browse(self):
        path=filedialog.askopenfilename(parent=self.root,title='Chọn file điểm Excel',filetypes=[('Excel','*.xlsx')])
        if path:self.path.set(path)
        return path

    def pick_file(self):
        path=self.path.get()
        if not path or not Path(path).is_file():path=self.browse()
        return path

    def can_start(self, app):
        if any(other is not app and other.busy for other in self.apps):
            messagebox.showinfo('Đang có tác vụ', 'Hãy dừng hoặc đợi tác vụ hiện tại kết thúc rồi chạy chức năng này.',parent=self.root)
            return False
        return True

    def released(self, app, path, deadline):
        others=[other for other in self.apps if other is not app and other.worker and other.worker.is_alive()]
        for other in others:
            if other.cancel_event:other.cancel_event.set()
        if others:
            if time.monotonic()>deadline:
                app.events.put(('error','Phiên Chrome trước chưa đóng. Hãy đóng cửa sổ Chrome Agent rồi thử lại.'))
            else:
                app.status.set('Đang đóng phiên Chrome trước để chuyển chức năng…')
                self.root.after(150,lambda:app.launch_when_ready(path,deadline))
            return False
        return True

    def open_exam(self):
        webbrowser.open((BASE/'phong_thi'/'index.html').as_uri())

    def reports(self):
        folder=BASE/'bao_cao';folder.mkdir(exist_ok=True)
        if os.name=='nt':os.startfile(str(folder))
        else:webbrowser.open(folder.as_uri())

    def close(self):
        self.chat.stop_speech()
        for app in self.apps:
            if app.cancel_event:app.cancel_event.set()
        self.root.withdraw()
        self.shutdown_deadline=time.monotonic()+8
        self.wait_close()

    def wait_close(self):
        if any(a.worker and a.worker.is_alive() for a in self.apps) and time.monotonic()<self.shutdown_deadline:
            self.root.after(150,self.wait_close)
        else:self.root.destroy()

if __name__=='__main__':
    if os.name=='nt':
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError,OSError):pass
    root=tk.Tk()
    Hub(root)
    root.mainloop()
