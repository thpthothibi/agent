import tempfile
import unittest
from pathlib import Path
from openpyxl import Workbook,load_workbook
from transfer_core import describe_file,prepare_records,export_template
from auto_core import read_jobs


class TransferExcelTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.folder=Path(self.temp.name)

    def source(self,name,rows,headers=None):
        path=self.folder/name;wb=Workbook();ws=wb.active
        ws.append(headers or ['STT','Họ','Tên','Lớp','Điểm TN'])
        for row in rows:ws.append(row)
        wb.save(path);wb.close();return path

    def test_multiple_files_and_zero_score(self):
        a=self.source('Tin 12 online.xlsx',[[1,'Nguyễn','An','12A01',0]])
        b=self.source('CNNN 12 online.xlsx',[[1,'Trần','Bình','12A11',7.25]])
        rows,issues=prepare_records([describe_file(a),describe_file(b)])
        self.assertEqual(issues,[])
        self.assertEqual([r['score'] for r in rows],['0','7.25'])
        self.assertEqual([r['subject'] for r in rows],['Tin học','Công nghệ nông nghiệp'])

    def test_duplicate_or_conflicting_names_are_all_excluded(self):
        a=self.source('Tin 12.xlsx',[[1,'Nguyễn','An','12A01',8],[2,'NGUYỄN','AN','12A01',9],[3,'Trần','Chi','12A01',7]])
        rows,issues=prepare_records([describe_file(a)])
        self.assertEqual([r['name'] for r in rows],['Trần Chi'])
        self.assertEqual(len(issues),2)

    def test_invalid_blank_and_requested_skip_are_reported(self):
        a=self.source('Tin 12.xlsx',[[1,'Trần Ngọc','Khánh','12A06',8],[2,'Nguyễn','An','12A01',11],[3,'Nguyễn','Bình','12A01',None]])
        rows,issues=prepare_records([describe_file(a)])
        self.assertEqual(rows,[]);self.assertEqual(len(issues),3)

    def test_multiple_source_scores_require_explicit_selection(self):
        a=self.source('Tin 12.xlsx',[['An','12A01',5,3]],['Họ và tên','Lớp','Điểm TN','Điểm TL'])
        spec=describe_file(a)
        with self.assertRaises(ValueError):prepare_records([spec])
        spec['score_header']='Điểm TL'
        rows,issues=prepare_records([spec],column='Cuối kỳ')
        self.assertEqual(rows[0]['score'],'3');self.assertEqual(rows[0]['column'],'Cuối kỳ')

    def test_default_class_is_only_used_when_source_is_missing(self):
        a=self.source('Tin 12.xlsx',[['Winnie',8]],['Họ và tên','Điểm TN'])
        rows,issues=prepare_records([describe_file(a)],default_class='12A02',term='HK2')
        self.assertEqual(rows[0]['class'],'12A02');self.assertEqual(rows[0]['term'],'HK2')

    def test_roundtrip_template_has_no_demo_or_double_import(self):
        a=self.source('Tin 12.xlsx',[[1,'Nguyễn','An','12A01',8.75],[2,'Trần','Bình','12A01',None]])
        rows,issues=prepare_records([describe_file(a)])
        template=Path(__file__).parent/'Mau_Nhap_Diem_VietSchool_Chrome.xlsx'
        out=export_template(rows,issues,template,self.folder/'output.xlsx')
        wb=load_workbook(out,data_only=True)
        self.assertNotIn('VI_DU',wb.sheetnames)
        self.assertEqual(wb['NHAP_DIEM']['N8'].value,8.75)
        self.assertEqual(wb['CAN_KIEM_TRA'].max_row,2);wb.close()
        jobs=read_jobs(out)
        self.assertEqual(len(jobs),1);self.assertEqual(len(jobs[0]['rows']),1)
        self.assertEqual(jobs[0]['rows'][0]['Giữa kỳ'],'8.75')

    def test_populated_template_or_overwrite_is_blocked(self):
        a=self.source('Tin 12.xlsx',[[1,'Nguyễn','An','12A01',8]])
        rows,issues=prepare_records([describe_file(a)])
        template=Path(__file__).parent/'Mau_Nhap_Diem_VietSchool_Chrome.xlsx'
        with self.assertRaises(ValueError):export_template(rows,issues,template,template)
        first=export_template(rows,issues,template,self.folder/'first.xlsx')
        with self.assertRaisesRegex(ValueError,'đã có danh sách'):export_template(rows,issues,first,self.folder/'second.xlsx')


if __name__=='__main__':unittest.main()
