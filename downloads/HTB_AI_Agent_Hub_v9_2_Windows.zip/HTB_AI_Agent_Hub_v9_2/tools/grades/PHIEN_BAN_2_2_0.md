# HTB AI Agent v2.2.0 — VietSchool v3.5 tích hợp

Đã đối chiếu với VietSchool_Agent_v3_5.zip người dùng cung cấp. Mã nhập điểm của HTB trước đó đã dựa trên v3.5. Phiên bản này tái sử dụng các mô-đun lõi v3.5 tương ứng, sửa điểm thập phân và giữ các sửa HTB mới hơn về bảng điểm chia hai phần, định vị hàng/cột và giao diện chung.

## Sửa lỗi trong ảnh

Điểm 8.75 từng bị chặn ngay lúc đọc Excel vì quy tắc tối đa một chữ số thập phân. Quy tắc này cũng có trong v3.5 gốc. Nay nhận điểm 0–10 với tối đa hai chữ số thập phân, dấu chấm hoặc phẩy: 8.75, 8,75, 7.25, 0.05. Giữ nguyên giá trị, không làm tròn. Sửa dùng chung cho nhập điểm và đối chiếu.

Nếu VietSchool từ chối hoặc làm tròn điểm, kiểm tra sau dán vẫn không xác nhận thành công khi giá trị khác Excel. Khi có lỗi, kiểm tra báo cáo và dùng Đối chiếu đọc lại. Chưa kiểm tra trên tài khoản VietSchool thực tế của thầy.

## Các hành vi giữ từ v3.5

- Chỉ dò môn có điểm trong Excel.
- Bỏ qua học sinh nghỉ, ô khóa, ô đã có điểm.
- Dò tên, bao gồm tên một từ như Winnie; tách vùng dán ở học sinh nghỉ.
- Kiểm tra đúng danh tính, hàng, cột trước khi dán; tiếp tục các ô trống ở cuối danh sách.
- Giữ sửa Progrid, cuộn tới ô đang hiển thị, kiểm tra thao tác bấm trước Control+V.

Giữ các công cụ cộng điểm, đối chiếu, SBD/phòng thi, báo cáo và Cá Chép AI của HTB v2.1.6.

## Chạy

Đóng ứng dụng và Chrome Agent cũ, giải nén toàn bộ gói mới và chạy CHAY_HTB_AI_AGENT.bat. Chọn Nhập điểm, tải Excel như trước. Muốn giữ lịch sử trò chuyện, sao chép du_lieu_be_bi từ thư mục cũ sang thư mục mới.

## Kiểm tra

Bộ unittest chạy 130 kiểm tra: 129 đạt, 1 bỏ qua vì môi trường không có Chromium. Đã kiểm tra hồi quy điểm hai số thập phân, đọc Excel, đối chiếu, nhận xét Đ/CĐ, tên Winnie, phạm vi môn và các dòng cuối. Chưa đăng nhập hoặc ghi điểm lên VietSchool thực tế.
