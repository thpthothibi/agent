# Agent Báo cáo & Kế hoạch trong đội HTB — v1.2

Mở CHAY_HTB_AI_AGENT.bat như trước, chọn **Báo cáo & Kế hoạch** ở menu trái.
Chức năng viết văn bản nằm trực tiếp trong cửa sổ tổng hợp, không chạy Streamlit riêng.

## Thiết lập lần đầu

Vào thẻ **Kết nối AI**:
- Điền OpenAI API key và/hoặc Gemini API key.
- Điền tên model đúng quyền tài khoản. Mặc định là gợi ý, có thể cần thay nếu tài khoản không có model đó.
- Có thể chỉ dùng một nhà cung cấp: chọn cùng nhà cung cấp ở cả ba vai trò.
- Không dùng mật khẩu tài khoản web thay cho API key. Kiểm tra hạn mức và phí API với nhà cung cấp.
- Khóa chỉ giữ trong bộ nhớ phiên; không ghi vào báo cáo, hồ sơ hay thư mục cấu hình. Có thể cấp qua biến môi trường OPENAI_API_KEY/GEMINI_API_KEY và OPENAI_MODEL/GEMINI_MODEL.

## Quy trình soạn

1. Chọn Báo cáo/Kế hoạch, chủ đề, đơn vị và kỳ báo cáo.
2. Chọn tài liệu mẫu có các mục cần bám theo.
3. Chọn tài liệu số liệu thực tế. Nút **Dùng Excel đang chọn** lấy Excel mà bạn đã chọn ở Tổng quan; chỉ thêm file khi bạn chủ động bấm nút này.
4. Nhập yêu cầu và ghi chú nội bộ nếu cần.
5. Chọn AI tìm nguồn, AI viết, AI rà soát. Gợi ý: Gemini tìm nguồn → OpenAI viết → Gemini rà soát. Có thể tắt tìm web hoặc rà soát.
6. Bấm **Bắt đầu soạn văn bản**. Đợi trạng thái hoàn tất.
7. Đọc thẻ Bản thảo, Nguồn tra cứu và Rà soát. Sửa trực tiếp Bản thảo; nhận xét rà soát không tự thay nội dung.
8. Lưu Word, Markdown hoặc hồ sơ JSON. Hộp lưu mặc định trỏ tới thư mục **bao_cao** chung của đội Agent. Có thể đổi thư mục lưu. JSON chỉ là hồ sơ xuất, chưa có nút nạp lại.

Mỗi lượt gọi tối đa ba yêu cầu API; không tự gửi lại khi lỗi. Nút dừng chặn bước tiếp theo, không thu hồi yêu cầu đã gửi lên nhà cung cấp. Bản thảo đã tạo vẫn còn nếu bước rà soát lỗi/dừng. Khi soạn lại sẽ hỏi trước khi thay nội dung đang sửa. Đóng chương trình sẽ mất nội dung chưa lưu.

## Tài liệu và định dạng

- Mẫu: DOCX, PDF có chữ, TXT hoặc MD.
- Dữ liệu: DOCX, PDF có chữ, XLSX, TXT/CSV UTF-8, MD.
- PDF scan và ảnh cần OCR trước; .doc/.xls cũ cần chuyển sang .docx/.xlsx.
- Excel đọc giá trị đã tính/lưu; cần mở và tính lại bằng Excel trước nếu có công thức chưa lưu kết quả.
- Giới hạn: 20 MB/tệp, 12 tệp dữ liệu, 120.000 ký tự/tệp, 180.000 ký tự tổng tài liệu, 150 trang/PDF, 10.000 dòng/Excel.
- Bám nội dung và thứ tự mục của mẫu. Chưa sao chép nguyên định dạng, logo, chữ ký, header/footer hoặc hình ảnh.
- Word xuất mới: A4, Times New Roman 13, bảng cơ bản. Có thể mở Word để chỉnh thể thức và xuất PDF.

## Dữ liệu và độ chính xác

Khi bấm soạn, chữ trích từ tài liệu được gửi tới AI viết và AI rà soát (nếu bật). Hãy bỏ dữ liệu cá nhân không cần thiết trước. Lượt tìm kiếm chỉ gửi chủ đề và kỳ báo cáo, không gửi các tệp nội bộ. Hãy kiểm tra chủ đề trước khi dùng tìm web.

AI được yêu cầu không bịa số liệu, thành tích, ngày/số văn bản, người ký; phần thiếu ghi [CẦN BỔ SUNG]. Đây là chỉ dẫn cho AI, không bảo đảm nội dung luôn đúng. Kiểm tra số liệu, nguồn gốc và hiệu lực văn bản trước khi ký ban hành. Nhận xét rà soát không phải lần kiểm chứng nguồn web độc lập.

Agent không tự điều khiển máy tính ngoài các chức năng đã có; không tự mở trang đăng nhập ChatGPT/Gemini để dùng tài khoản web. Các Agent nhập điểm/đối chiếu/SBD vẫn hoạt động theo nghiệp vụ riêng.

## Kiểm thử

Đã kiểm tra trích xuất Word, xuất Word, trích dẫn hai nhà cung cấp, luồng phân công tìm/viết/rà soát, giữ bản thảo khi rà soát lỗi, dừng giữa các bước và không đưa khóa vào hồ sơ. Các lượt API trong kiểm thử dùng dữ liệu mô phỏng. Chưa gọi API thật vì chưa có khóa người dùng; cần thử trên Windows và tài liệu mẫu thực tế.

Tài liệu tích hợp:
https://developers.openai.com/api/docs/guides/tools-web-search
https://ai.google.dev/gemini-api/docs/generate-content/google-search
