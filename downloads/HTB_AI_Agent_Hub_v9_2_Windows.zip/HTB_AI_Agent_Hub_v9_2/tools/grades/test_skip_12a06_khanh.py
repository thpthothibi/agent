import tempfile
import unittest
from pathlib import Path
from openpyxl import Workbook
from auto_core import read_jobs
from name_matching import build_plan,paste_runs
from compare_core import compare_rows
from skip_policy import SKIP_STATUS


class Skip12A06Tests(unittest.TestCase):
    def fixture(self):
        sources=[];web=[]
        for i in range(1,15):
            name='Trần Ngọc Khánh' if i in (9,10) else f'Học sinh {i}'
            dob='08/07/2009' if i==9 else '19/04/2009' if i==10 else '01/01/2009'
            sources.append(dict(student=name,row=i+1,dob=dob,**{'Giữa kỳ':'8'}))
            web.append(dict(stt=i,name=name,dob=dob,cells=[str(i),'',name,dob,'']))
        return sources,web

    def test_two_identical_names_are_both_skipped_and_ranges_do_not_shift(self):
        sources,web=self.fixture()
        plan=build_plan(sources,web,'Giữa kỳ','Toán',index=4,clazz='12A06')
        self.assertEqual([r['status'] for r in plan[8:10]],[SKIP_STATUS,SKIP_STATUS])
        self.assertTrue(all(r['value'] is None for r in plan[8:10]))
        self.assertEqual([[r['stt'] for r in run] for run in paste_runs(plan)],
                         [list(range(1,9)),list(range(11,15))])
        self.assertEqual(plan[10]['name'],'Học sinh 11')

    def test_exception_does_not_apply_to_other_classes_or_other_names(self):
        sources,web=self.fixture()
        with self.assertRaises(ValueError):build_plan(sources,web,'Giữa kỳ','Toán',index=4,clazz='12A07')
        sources[0]['student']=sources[1]['student']
        with self.assertRaises(ValueError):build_plan(sources,web,'Giữa kỳ','Toán',index=4,clazz='12A06')

    def test_excel_preflight_accepts_only_requested_duplicate(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'scores.xlsx';w=Workbook();s=w.active
            s.append(['Họ và tên','Lớp','Môn học','Học kỳ','Năm học','Giữa kỳ'])
            for name in ['Trần Ngọc Khánh','Trần Ngọc Khánh','Học sinh khác']:
                s.append([name,'12A06','Toán','HK1','2026-2027',8])
            w.save(p);jobs=read_jobs(p)
            self.assertEqual(len(jobs[0]['rows']),3)
            for row in s.iter_rows(min_row=2):row[1].value='12A07'
            w.save(p);w.close()
            with self.assertRaises(ValueError):read_jobs(p)

    def test_final_check_reports_skips_without_claiming_duplicate_points_correct(self):
        sources,web=self.fixture()
        for row in web:row['cells'][4]='8'
        job=dict(year='2026-2027',term='Học kỳ 1',subject='Toán',column='Giữa kỳ',rows=sources,**{'class':'12A06'})
        result=compare_rows(job,web,4)
        skipped=[r for r in result if r['name']=='Trần Ngọc Khánh']
        self.assertEqual([r['result'] for r in skipped],[SKIP_STATUS,SKIP_STATUS])
        self.assertTrue(all(r['actual']=='' and r['stt']=='' for r in skipped))
        self.assertEqual(sum(r['result']=='Đúng' for r in result),12)


if __name__=='__main__':unittest.main()
