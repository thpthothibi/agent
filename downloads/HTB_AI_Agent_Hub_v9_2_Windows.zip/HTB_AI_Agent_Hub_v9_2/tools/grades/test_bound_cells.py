import queue, threading, tempfile, unittest
from pathlib import Path
from unittest.mock import Mock, patch
from openpyxl import Workbook
from auto_core import inactive_excel, read_jobs
from full_auto import AutoWorker
from name_matching import build_plan
from vietschool_agent_v2 import AutoApp
import test_paste_continuation as continuation

class BoundCellTests(unittest.TestCase):
    def worker(self):
        w=AutoWorker('',queue.Queue(),threading.Event());w.page=Mock(return_value=Mock());w.tick=Mock();w.wait_idle=Mock();w.scope_is_selected=Mock();w.html_dialog=Mock()
        w.bound_token='correct-GK-cell';w.headers=Mock(side_effect=AssertionError('Do not rediscover headers after binding'))
        return w
    def run_rows(self):return [{'stt':5,'name':'Nguyễn An','dob':'01/01/2011','value':'Đ'},{'stt':6,'name':'Lê Bình','dob':'02/02/2011','value':'CĐ'}]
    def observation(self,run):
        return {'rows':[{**r,'cells':[str(r['stt']),'Họ','Tên',r['dob'],r['value']],'saved':[False]*4+[True]} for r in run]}
    def test_bound_paste_continues_without_any_header_lookup(self):
        w=self.worker();f=Mock();f.locator.return_value.bounding_box.return_value={'x':100,'y':100};run=self.run_rows()
        def dom(frame,op,**kw):
            if op=='bound_view':return {'ready':True,'position':{'x':12,'y':10}}
            if op=='bound_check':return True
            if op=='bound_focus':return 'bound-grade-td'
            if op=='bound_snapshot':return self.observation(run)
            raise AssertionError(op)
        w.dom=Mock(side_effect=dom)
        with patch('pyperclip.copy') as copy:w.paste(f,run,7,{'class':'10A06','column':'Giữa kỳ'},'ĐGTX')
        copy.assert_called_once_with('Đ\nCĐ');w.page().keyboard.press.assert_called_once_with('Control+V');w.headers.assert_not_called()
    def test_native_wheel_then_exact_mouse_click_without_locator_auto_scroll(self):
        w=self.worker();f=Mock();f.locator.return_value.bounding_box.return_value={'x':200,'y':300};run=self.run_rows()
        views=[{'ready':False,'selector':'scroll-host','position':{'x':50,'y':60},'dx':0,'dy':900},
               {'ready':True,'position':{'x':20,'y':11}}]
        def dom(frame,op,**kw):
            if op=='bound_view':return views.pop(0)
            if op=='bound_focus':return 'gk-cell'
            if op=='bound_check':return True
            if op=='bound_snapshot':return self.observation(run)
            raise AssertionError(op)
        w.dom=Mock(side_effect=dom)
        with patch('pyperclip.copy'):w.paste(f,run,7,{'class':'10A06','column':'Giữa kỳ'},'ĐGTX')
        w.page().mouse.move.assert_called_once_with(250,360)
        w.page().mouse.wheel.assert_called_once_with(0,900)
        w.page().mouse.click.assert_called_once_with(220,311)
        f.locator.return_value.click.assert_not_called();f.locator.return_value.hover.assert_not_called()
        w.page().keyboard.press.assert_called_once_with('Control+V')

    def test_changed_bound_identity_blocks_before_paste(self):
        w=self.worker();f=Mock();f.locator.return_value.bounding_box.return_value={'x':100,'y':100};run=self.run_rows()
        def dom(frame,op,**kw):
            if op=='bound_view':return {'ready':True,'position':{'x':12,'y':10}}
            if op=='bound_focus':return 'target'
            if op=='bound_check':raise RuntimeError('Wrong student')
            raise AssertionError(op)
        w.dom=Mock(side_effect=dom)
        with patch('pyperclip.copy') as copy:
            with self.assertRaisesRegex(RuntimeError,'Wrong student'):w.paste(f,run,7,{'class':'10A06','column':'Giữa kỳ'},'ĐGTX')
            copy.assert_not_called()
        w.page().keyboard.press.assert_not_called()
    def test_redraw_waits_without_header_lookup_or_duplicate_paste(self):
        w=self.worker();f=Mock();f.locator.return_value.bounding_box.return_value={'x':100,'y':100};run=self.run_rows();observations=[{'rows':[]},self.observation(run)]
        def dom(frame,op,**kw):
            if op=='bound_view':return {'ready':True,'position':{'x':12,'y':10}}
            if op=='bound_check':return True
            if op=='bound_focus':return 'target'
            if op=='bound_snapshot':return observations.pop(0)
            raise AssertionError(op)
        w.dom=Mock(side_effect=dom)
        with patch('pyperclip.copy'):w.paste(f,run,7,{'class':'10A06','column':'Giữa kỳ'},'ĐGTX')
        w.page().keyboard.press.assert_called_once_with('Control+V');w.headers.assert_not_called()
    def test_bind_excludes_retired_and_existing_scores(self):
        helper=continuation.PasteContinuationTests();w,ranges=helper.process(already_saved=True)
        bindings=[c for c in w.dom.call_args_list if len(c.args)>1 and c.args[1]=='bind_column']
        self.assertEqual(len(bindings),1)
        stts=[r['stt'] for r in bindings[0].kwargs['run']]
        self.assertEqual(stts,list(range(5,44))+list(range(45,48)))
        w.seek.assert_not_called()
    def test_explicit_retired_status_does_not_mean_daily_absence(self):
        for label in ('Nghỉ học','Đã nghỉ','Chuyển trường','Thôi học'):self.assertTrue(inactive_excel(label))
        for label in ('Đang học','Vắng','Nghỉ phép','Nghỉ buổi học',None):self.assertFalse(inactive_excel(label))
    def test_excel_status_can_skip_without_web_color(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'scores.xlsx';wb=Workbook();ws=wb.active
            ws.append(['Họ và tên','Lớp','Môn học','Học kỳ','Năm học','Giữa kỳ','Trạng thái'])
            ws.append(['Nguyễn An','10A06','GDĐP','HK1','2026-2027','Đ','Đang học'])
            ws.append(['Lê Bình','10A06','GDĐP','HK1','2026-2027','Không đánh giá','Nghỉ học'])
            wb.save(path);job=read_jobs(path)[0]
        site=[{'stt':i,'name':r['student'],'dob':'01/01/2011','cells':[str(i),'Họ','Tên','01/01/2011',''],'inactive':False} for i,r in enumerate(job['rows'],1)]
        plan=build_plan(job['rows'],site,'Giữa kỳ','GDĐP',index=4)
        self.assertEqual(plan[1]['status'],'Bỏ qua: học sinh nghỉ');self.assertEqual(plan[1]['reason'],'Đánh dấu nghỉ trong Excel')
    def test_absent_retired_excel_student_does_not_block_active_roster(self):
        excel=[{'student':'Nguyễn An','row':2,'Giữa kỳ':'Đ'},{'student':'Lê Bình','row':3,'Giữa kỳ':None,'inactive':True}]
        site=[{'stt':1,'name':'Nguyễn An','dob':'01/01/2011','cells':['1','Nguyễn','An','01/01/2011','']}]
        plan=build_plan(excel,site,'Giữa kỳ','GDĐP',index=4)
        self.assertEqual(sum(r['status']=='Sẽ dán' for r in plan),1)
        self.assertEqual(plan[-1]['status'],'Bỏ qua: không tìm thấy tên trên web')

class RosterUITests(unittest.TestCase):
    def test_structured_roster_and_verified_events_do_not_enter_text_status(self):
        app=AutoApp.__new__(AutoApp);app.events=queue.Queue();app.busy=False;app.root=Mock();app.roster=Mock();app.roster_label=Mock();app.status=Mock();app.write=Mock()
        app.roster.get_children.return_value=[];app.roster.insert.side_effect=['first','second'];app.roster.item.return_value={'values':('1','Nguyễn An','Đ','Sẽ dán')}
        app.roster.item.side_effect=lambda iid,*args,**kw:('1','Nguyễn An','Đ','Sẽ dán') if args else None
        app.events.put(('roster',{'scope':'10A06 / GDĐP / Giữa kỳ','rows':[{'stt':1,'name':'Nguyễn An','value':'Đ','old':'','status':'Sẽ dán','reason':''},{'stt':4,'name':'Lê Bình','value':None,'old':'','status':'Bỏ qua: học sinh nghỉ','reason':'Họ, tên, ngày sinh đỏ'}]}))
        app.events.put(('verified',{'stts':[1]}))
        app.poll();app.status.set.assert_not_called();app.write.assert_not_called();self.assertEqual(app.row_ids,{1:'first',4:'second'})

if __name__=='__main__':unittest.main()
