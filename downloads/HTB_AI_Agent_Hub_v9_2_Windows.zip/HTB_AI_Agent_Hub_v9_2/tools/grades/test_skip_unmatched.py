import unittest
from unittest.mock import Mock
from name_matching import build_plan,paste_runs
import test_full_roster as roster_fixture


class SkipUnmatchedTests(unittest.TestCase):
    def test_exact_match_only_and_all_missing_names_are_audited(self):
        excel=[dict(student=n,row=i+2,TX1='8') for i,n in enumerate(['An','Bình','Chi'])]
        web=[dict(name=n,stt=i+1,dob='',cells=[str(i+1),'',n,'','']) for i,n in enumerate(['An','Binh khác','Chi'])]
        plan=build_plan(excel,web,'TX1','Toán',index=4)
        runs=paste_runs(plan)
        self.assertEqual([[r['name'] for r in run] for run in runs],[['An'],['Chi']])
        self.assertEqual(plan[1]['status'],'Bỏ qua: không có trong Excel')
        self.assertEqual(plan[-1]['name'],'Bình')
        self.assertEqual(plan[-1]['status'],'Bỏ qua: không tìm thấy tên trên web')
        self.assertIsNone(plan[-1]['value'])

    def test_no_matching_name_never_produces_a_paste(self):
        plan=build_plan([dict(student='An',row=2,TX1='8')],
                        [dict(name='Bình',stt=1,dob='',cells=['1','','Bình','',''])],'TX1','Toán',index=4)
        self.assertEqual(paste_runs(plan),[])
        self.assertEqual(len(plan),2)

    def test_scans_to_scroll_end_then_returns_when_excel_name_is_absent(self):
        fixture=roster_fixture.FullRosterTests();web,excel=fixture.roster();worker=fixture.make()
        excel.append(dict(student='Không có trên web',row=99,TX1='Đ'))
        def dom(frame,op,**kwargs):
            if op=='snapshot_all':return {'rows':web}
            if op=='scroll_init':return 1
            if op=='scroll':return {'end':True}
            if op=='restore':return True
            raise AssertionError(op)
        worker.dom=Mock(side_effect=dom)
        result=worker.collect('frame',expected=excel)
        self.assertEqual(len(result),47)
        plan=build_plan(excel,result,'TX1','GDĐP',index=4)
        self.assertEqual(sum(map(len,paste_runs(plan))),45)
        self.assertEqual(plan[-1]['status'],'Bỏ qua: không tìm thấy tên trên web')


if __name__=='__main__':unittest.main()
