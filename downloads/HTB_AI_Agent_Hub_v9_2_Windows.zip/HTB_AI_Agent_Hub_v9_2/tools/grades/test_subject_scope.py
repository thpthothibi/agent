import queue, threading, tempfile, unittest
from pathlib import Path
from unittest.mock import Mock
from openpyxl import Workbook
from full_auto import AutoWorker
from auto_core import read_jobs

class SubjectScopeTests(unittest.TestCase):
    def worker(self):
        w=AutoWorker('',queue.Queue(),threading.Event())
        w.page=Mock(return_value=Mock());w.year=Mock();w.choose_class=Mock();w.expand=Mock();w.choose=Mock();w.wait_idle=Mock()
        return w
    def job(self,subject='GDĐP'):
        return {'year':'2026-2027','class':'10A06','subject':subject,'term':'Học kỳ 1'}
    def test_only_excel_subject_is_selected(self):
        w=self.worker();job=self.job();w.configure_subjects([job]);w.navigate(job)
        calls=[c for c in w.choose.call_args_list if c.kwargs.get('group')==['MÔN HỌC','MÔN']]
        self.assertEqual(len(calls),1)
        self.assertEqual(calls[0].args[0],['GDĐP','GDDP','Giáo dục địa phương'])
    def test_outside_subject_blocked_before_any_navigation(self):
        w=self.worker();w.configure_subjects([self.job()])
        with self.assertRaisesRegex(RuntimeError,'không nằm trong phạm vi Excel'):w.navigate(self.job('Toán'))
        w.year.assert_not_called();w.choose_class.assert_not_called();w.choose.assert_not_called()
    def test_two_subjects_and_aliases(self):
        w=self.worker();w.configure_subjects([self.job(),self.job('GDTC')])
        self.assertEqual(len(w.allowed_subjects),2)
        self.assertIn('Giáo dục địa phương',w.subject_values('Giáo dục địa phương'))
        self.assertIn('GDTC',w.subject_values('Giáo dục thể chất'))
        with self.assertRaises(RuntimeError):w.subject_values('Ngữ văn')
    def test_new_file_replaces_subject_scope(self):
        w=self.worker();w.configure_subjects([self.job()]);w.configure_subjects([self.job('Toán')])
        with self.assertRaises(RuntimeError):w.subject_values('GDĐP')
        self.assertEqual(w.subject_values('Toán'),['Toán'])
    def test_excel_blank_subject_grades_do_not_add_subject_jobs(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'scores.xlsx';wb=Workbook();ws=wb.active
            ws.append(['Họ và tên','Lớp','Môn học','Học kỳ','Năm học','Giữa kỳ'])
            ws.append(['Nguyễn An','10A06','GDĐP','HK1','2026-2027','Đ'])
            ws.append(['Nguyễn An','10A06','Toán','HK1','2026-2027',None])
            wb.save(p);jobs=read_jobs(p)
        self.assertEqual([j['subject'] for j in jobs],['GDĐP'])
        w=self.worker();w.configure_subjects(jobs)
        with self.assertRaises(RuntimeError):w.subject_values('Toán')
    def test_many_classes_same_subject_are_not_many_subjects(self):
        w=self.worker();w.configure_subjects([{**self.job(),'class':f'10A{i:02}'} for i in range(1,10)])
        self.assertEqual(len(w.allowed_subjects),1)

if __name__=='__main__':unittest.main()
