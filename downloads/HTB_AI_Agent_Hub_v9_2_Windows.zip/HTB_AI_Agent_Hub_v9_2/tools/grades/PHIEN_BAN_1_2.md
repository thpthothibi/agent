# Ghi chú phát hành v1.2

Bổ sung Agent Báo cáo & Kế hoạch trong menu/cửa sổ HTB tổng hợp.
Giữ các chức năng VietSchool và công cụ SBD/phòng thi của v1.1.
Cập nhật mục Tổng quan, bộ cài thư viện và hướng dẫn.

Kiểm thử: 92 ca unittest, 91 đạt, 1 bỏ qua do thiếu Chromium kiểm thử.
Đã kiểm tra cú pháp toàn bộ Python. Các lượt gọi AI kiểm thử dùng dữ liệu mô phỏng.
Chưa kiểm thử giao diện mới trên Windows, API thật hoặc VietSchool thật.

Mở CHAY_HTB_AI_AGENT.bat. Chọn Báo cáo & Kế hoạch → Kết nối AI.
Chi tiết: HUONG_DAN_BAO_CAO.md.
