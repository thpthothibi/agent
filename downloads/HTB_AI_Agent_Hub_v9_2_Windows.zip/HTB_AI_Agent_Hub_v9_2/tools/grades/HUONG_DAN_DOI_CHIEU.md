# Agent đối chiếu điểm VietSchool v1

Phát triển từ bộ đọc bảng và điều hướng của Agent nhập điểm v3.6.
Chạy riêng bằng CHAY_DOI_CHIEU.bat. Không cần khóa API AI.

## Cách dùng
1. Giải nén toàn bộ thư mục trên Windows có Python 3.10+ và Google Chrome.
2. Đóng Chrome Agent nhập điểm cũ trước khi chạy để tránh trùng hồ sơ trình duyệt.
3. Nhấp đúp CHAY_DOI_CHIEU.bat. Lần đầu chương trình cài các thư viện cần thiết.
4. Bấm CHỌN EXCEL VÀ ĐỐI CHIẾU, chọn file đầu vào dùng để nhập điểm.
5. Đăng nhập VietSchool trong cửa sổ Chrome Agent nếu được yêu cầu.
6. Để chương trình tự chọn năm học, lớp, môn, học kỳ, cột và cuộn đọc bảng.
7. Kết thúc, mở file doi_chieu_*.xlsx tại thư mục bao_cao. Đường dẫn cũng hiện trong ứng dụng.

Báo cáo có Tong_hop, Tat_ca và Can_kiem_tra. Có cả điểm Excel, điểm VietSchool, lớp, môn, học kỳ, cột điểm, sheet và dòng nguồn. Can_kiem_tra chứa mọi dòng chưa được kết luận đúng, gồm cả dòng bỏ qua. Không được coi "chạy xong" là "tất cả đều đúng".

## Phạm vi và quy tắc
- Dùng cùng cấu trúc Excel với Agent v3.6 và file mẫu kèm theo: Họ và tên, Lớp, Môn học, Học kỳ, Năm học; TX1–TX6/Giữa kỳ/Cuối kỳ.
- Chỉ kiểm tra những nhóm lớp/môn/học kỳ/cột có ít nhất một điểm nguồn. Không quét môn ngoài Excel, không quét cột hoàn toàn trống.
- So khớp tên đầy đủ sau chuẩn hóa dấu/khoảng trắng trong đúng lớp đã chọn; không dựa theo thứ tự Excel. Tên một từ như Winnie vẫn được xử lý.
- Nếu Excel có ngày sinh thì kiểm tra thêm ngày sinh. Chưa hỗ trợ ghép theo mã học sinh. Tên trùng trong Excel bị bước kiểm tra đầu vào từ chối; tên trùng web ghi chưa kiểm tra được.
- Điểm số 7,5 / 7.5 / 7.50 được coi tương đương; nhận xét Đ/CĐ và Đạt/Chưa đạt được chuẩn hóa theo môn.
- Kiểm tra ô web đã có điểm và ô khóa. Không dùng màu chữ làm bằng chứng điểm đúng.
- Ô Excel trống: ghi riêng, không tính đúng và không yêu cầu xóa điểm web.
- Học sinh nghỉ: ghi bỏ qua; học sinh không tìm thấy hoặc chỉ có trên web: ghi riêng.
- Tải lại trang trước khi kiểm tra; đọc bảng hai lần và chỉ so sánh khi ổn định. Đọc qua giao diện, không phải xác nhận trực tiếp từ cơ sở dữ liệu.
- Chỉ đọc điểm. Chặn thao tác dán/chọn ô ghi/lưu của bộ đọc. Không có nút tự sửa.
- Nếu không xác định được lớp/cột hoặc bảng lỗi, cả nhóm được ghi chưa kiểm tra được rồi thử nhóm kế tiếp. Nếu dừng giữa chừng, các nhóm còn lại ghi chưa kiểm tra được.
- Báo cáo chứa dữ liệu học sinh, lưu tại máy chạy chương trình.

## Kiểm chứng
Đã có kiểm thử tự động cho so sánh điểm, tên một từ, khác thứ tự, nhận xét,
điểm 0, ô trống, thiếu học sinh, trùng tên, khác ngày sinh, cột không đọc được,
bảng lỗi, dừng giữa chừng và báo cáo Excel.
Chưa kiểm thử trực tiếp trong tài khoản VietSchool của bạn. Nếu giao diện không đọc được,
gửi file chan_doan_giao_dien.json và báo cáo lỗi để điều chỉnh.
