import unittest
from unittest.mock import Mock
from types import SimpleNamespace
from mascot import MascotState, FloatingMascot, clamp_position


class MascotStateTests(unittest.TestCase):
    def test_idle_hints_follow_active_page(self):
        state=MascotState()
        mode,text=state.update(False,4,now=100)
        self.assertEqual(mode,'idle')
        self.assertIn('số liệu',text)

    def test_finishing_does_not_claim_success(self):
        state=MascotState()
        state.update(True,1,'Đang nhập điểm',now=10)
        mode,text=state.update(False,1,'Lỗi',now=11)
        self.assertEqual(mode,'finished')
        self.assertIn('kiểm tra',text)
        self.assertNotIn('thành công',text)
        self.assertEqual(state.update(False,1,now=21)[0],'idle')

    def test_switching_page_replaces_completion_hint(self):
        state=MascotState()
        state.update(True,1,now=10)
        state.update(False,1,now=11)
        mode,text=state.update(False,2,now=12)
        self.assertEqual(mode,'idle')
        self.assertIn('Đối chiếu',text)

    def test_busy_uses_real_progress_without_changing_task(self):
        state=MascotState()
        mode,text=state.update(True,4,'Đang tìm nguồn công khai…',now=12)
        self.assertEqual(mode,'working')
        self.assertEqual(text,'Đang tìm nguồn công khai…')

class FloatingMascotTests(unittest.TestCase):
    def make(self):
        robot=object.__new__(FloatingMascot)
        robot.position=(45,300);robot.press=None;robot.dragged=False
        robot.hide_hint=Mock();robot.sync_position=Mock();robot.say_hello=Mock()
        return robot

    def test_drag_moves_robot_without_opening_chat(self):
        robot=self.make()
        robot.drag_start(SimpleNamespace(x_root=100,y_root=200))
        robot.drag_move(SimpleNamespace(x_root=180,y_root=240))
        robot.drag_end(None)
        self.assertEqual(robot.position,(125,340))
        robot.say_hello.assert_not_called()

    def test_small_click_opens_chat_without_moving(self):
        robot=self.make()
        robot.drag_start(SimpleNamespace(x_root=100,y_root=200))
        robot.drag_move(SimpleNamespace(x_root=101,y_root=201))
        robot.drag_end(None)
        self.assertEqual(robot.position,(45,300))
        robot.say_hello.assert_called_once()

    def test_owner_minimizes_without_changing_visibility_preference(self):
        robot=self.make();robot.root=Mock();robot.frame=Mock();robot.visible=True
        robot.owner_unmapped(SimpleNamespace(widget=robot.root))
        robot.frame.withdraw.assert_called_once()
        self.assertTrue(robot.visible)

    def test_position_stays_reachable_after_resize(self):
        self.assertEqual(clamp_position(1700,900,960,660),(820,510))
        self.assertEqual(clamp_position(-50,-20,960,660),(0,0))

if __name__=='__main__':unittest.main()
