# HTB AI Agent v2.0.3

Sửa lỗi lọc mất dòng danh tính, báo 46/47 dù cả hai bảng Progrid có 47 hàng. Giữ vị trí mọi hàng, không bỏ dòng theo nội dung ngày sinh/họ tên/điểm; xử lý dữ liệu thiếu theo từng học sinh. Loại bảng tiêu đề Progrid khỏi dữ liệu.

Đã tái hiện lỗi bản cũ và kiểm chứng bản sửa qua 13 tình huống DOM mô phỏng; 106 ca Python đạt, 1 bỏ qua. Chưa kiểm tra trên tài khoản VietSchool thật.
Mở CHAY_HTB_AI_AGENT.bat → Đối chiếu điểm → chọn Excel → Bắt đầu đối chiếu.
