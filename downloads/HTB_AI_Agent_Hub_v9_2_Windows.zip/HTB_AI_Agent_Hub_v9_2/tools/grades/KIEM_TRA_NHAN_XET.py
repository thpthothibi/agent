# -*- coding: utf-8 -*-
"""Self-test: no connection to VietSchool, no student data required."""
from base_agent import grade_string, rating_mode

def test():
    for subject in ['GDĐP', 'Giáo dục địa phương', 'GDTC', 'Giáo dục thể chất',
                    'HĐTN-HN', 'HDTN HN', 'Hoạt động trải nghiệm, hướng nghiệp']:
        assert rating_mode(subject) == 'comment', subject
    for value, result in [('Đ','Đ'),('CĐ','CĐ'),('Đạt','Đ'),('Chưa đạt','CĐ')]:
        assert grade_string(value, 'comment') == result
    for value in (0,1,7.5,10,'8,5'):
        assert grade_string(value, 'score') is not None
    for value, mode in [('Đ','score'), ('CĐ','score'), (8,'comment'), (11,'score'), (-1,'score')]:
        try: grade_string(value, mode)
        except ValueError: continue
        raise AssertionError(f'Đáng lẽ bị chặn: {value!r}, {mode}')
    print('THÀNH CÔNG: Đ/CĐ hợp lệ, điểm số hợp lệ, giá trị sai bị chặn.')

if __name__ == '__main__':
    test()
