"""Execute production DOM JS against an lxml fixture via QuickJS (not a browser)."""
import json, sys
from pathlib import Path
from lxml import html
import quickjs
sys.path.insert(0,str(Path(__file__).resolve().parent))
from browser_dom import DOM
from auto_core import expand_headers,column_index
from name_matching import build_plan,paste_runs

fixture='''<html><body><div id="loading" aria-hidden="true" style="opacity:0;pointer-events:auto"></div>
<div style="width:250px"><div>LỚP HỌC</div><div class="wj-nodelist"><div class="wj-node wj-state-collapsed" aria-expanded="false"><span class="wj-nodetext">Khối 10</span></div><div class="wj-nodelist"><div class="wj-node wj-state-selected"><span class="wj-nodetext">10A06</span></div></div></div></div>
<div style="width:250px"><div>MÔN HỌC</div><ul><li><span class="tree-node-selected">GDĐP</span></li></ul></div>
<div style="width:250px"><div>ĐỢT ĐIỂM</div><ul>
<div class="wj-node" aria-expanded="true"><span class="wj-nodetext">Học kỳ 1</span></div><div class="wj-nodelist"><div class="wj-node wj-state-selected"><span class="wj-nodetext">ĐGTX</span></div><div class="wj-node"><span class="wj-nodetext">Thi</span></div></div>
<div class="wj-node" aria-expanded="true"><span class="wj-nodetext">Học kỳ 2</span></div><div class="wj-nodelist"><div class="wj-node"><span class="wj-nodetext">ĐGTX</span></div><div class="wj-node"><span class="wj-nodetext">Thi</span></div></div>
</ul></div>
<div class="datagrid-view"><div class="datagrid-view1">
<div class="datagrid-header"><table><tr><td rowspan="2">STT</td><td rowspan="2">Họ</td><td rowspan="2">Tên</td><td rowspan="2">Ngày sinh</td></tr></table></div>
<div class="datagrid-body"><table>
<tr class="datagrid-row" datagrid-row-index="0"><td>1</td><td>Nguyễn</td><td>An</td><td>22/03/2011</td></tr>
<tr class="datagrid-row" datagrid-row-index="1"><td>2</td><td style="color:rgb(255,0,0)">Hồ Quỳnh</td><td style="color:rgb(255,0,0)">Anh</td><td>22/03/2011</td></tr>
<tr class="datagrid-row" datagrid-row-index="2"><td>3</td><td>Lê</td><td>Chi</td><td>22/03/2011</td></tr>
</table></div></div><div class="datagrid-view2">
<div class="datagrid-header"><table><tr><td colspan="3">Điểm ĐGTX</td><td rowspan="2">ĐGGK</td></tr><tr><td>1</td><td>2</td><td>3</td></tr></table></div>
<div class="datagrid-body"><table>
<tr class="datagrid-row" datagrid-row-index="0"><td style="color:rgb(0,128,0)">Đ</td><td></td><td></td><td></td></tr>
<tr class="datagrid-row" datagrid-row-index="1"><td style="background-color:rgb(241,242,243)"></td><td></td><td></td><td></td></tr>
<tr class="datagrid-row" datagrid-row-index="2"><td></td><td></td><td></td><td></td></tr>
</table></div></div></div></body></html>'''
fixture=fixture[:fixture.index('<div class="datagrid-view">')]+'<div class="generic-score-container"><table class="fixed-table"><tr><td data-left="0" data-width="40" data-top="0" data-height="60" style="" rowspan="2">STT</td><td data-left="40" data-width="250" data-top="0" data-height="60" style="" rowspan="2">Họ</td><td data-left="290" data-width="100" data-top="0" data-height="60" style="" rowspan="2">Tên</td><td data-left="390" data-width="140" data-top="0" data-height="60" style="" rowspan="2">Ngày sinh</td></tr><tr><td data-left="0" data-width="40" data-top="100" data-height="45" style="" >1</td><td data-left="40" data-width="250" data-top="100" data-height="45" style="" >Nguyễn</td><td data-left="290" data-width="100" data-top="100" data-height="45" style="" >An</td><td data-left="390" data-width="140" data-top="100" data-height="45" style="" >22/03/2011</td></tr><tr><td data-left="0" data-width="40" data-top="145" data-height="45" style="" >2</td><td data-left="40" data-width="250" data-top="145" data-height="45" style="color:rgb(255,0,0)" >Hồ Quỳnh</td><td data-left="290" data-width="100" data-top="145" data-height="45" style="color:rgb(255,0,0)" >Anh</td><td data-left="390" data-width="140" data-top="145" data-height="45" style="" >22/03/2011</td></tr><tr><td data-left="0" data-width="40" data-top="190" data-height="45" style="" >3</td><td data-left="40" data-width="250" data-top="190" data-height="45" style="" >Lê</td><td data-left="290" data-width="100" data-top="190" data-height="45" style="" >Chi</td><td data-left="390" data-width="140" data-top="190" data-height="45" style="" >22/03/2011</td></tr></table><table class="score-table"><tr><td data-left="530" data-width="228" data-top="0" data-height="30" style="" colspan="3">Điểm ĐGTX</td><td data-left="758" data-width="112" data-top="0" data-height="60" style="" rowspan="2">ĐGGK</td></tr><tr><td data-left="530" data-width="76" data-top="30" data-height="30" style="" >1</td><td data-left="606" data-width="76" data-top="30" data-height="30" style="" >2</td><td data-left="682" data-width="76" data-top="30" data-height="30" style="" >3</td></tr><tr><td data-left="530" data-width="76" data-top="100" data-height="45" style="color:rgb(0,128,0)" >Đ</td><td data-left="606" data-width="76" data-top="100" data-height="45" style="" ></td><td data-left="682" data-width="76" data-top="100" data-height="45" style="" ></td><td data-left="758" data-width="112" data-top="100" data-height="45" style="" ></td></tr><tr><td data-left="530" data-width="76" data-top="145" data-height="45" style="background-color:rgb(241,242,243)" ></td><td data-left="606" data-width="76" data-top="145" data-height="45" style="" ></td><td data-left="682" data-width="76" data-top="145" data-height="45" style="" ></td><td data-left="758" data-width="112" data-top="145" data-height="45" style="" ></td></tr><tr><td data-left="530" data-width="76" data-top="190" data-height="45" style="" ></td><td data-left="606" data-width="76" data-top="190" data-height="45" style="" ></td><td data-left="682" data-width="76" data-top="190" data-height="45" style="" ></td><td data-left="758" data-width="112" data-top="190" data-height="45" style="" ></td></tr></table><table><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr></table><table><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr></table><table><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr></table><table><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr></table><table><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr></table><table><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr></table><table><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr></table><table><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr><tr><td data-left="2000" data-width="10" data-top="-1000" data-height="45" style="" ></td></tr></table></div></body></html>'
root=html.fromstring(fixture);nodes=list(root.iter());ids={e:i for i,e in enumerate(nodes)}
ctx=quickjs.Context()
def prop(i,k):
    n=nodes[i]
    if k=='children':return json.dumps([ids[x] for x in n if isinstance(x.tag,str)])
    if k=='parent':return ids.get(n.getparent(),-1)
    if k=='text':return n.text_content()
    if k=='connected':return n is root or root in n.iterancestors()
    if k=='cellIndex':
        if n.tag not in ('td','th'):return None
        return [e for e in n.getparent() if e.tag in ('td','th')].index(n)
    if k=='rowIndex':
        if n.tag!='tr':return None
        table=next((e for e in n.iterancestors() if e.tag=='table'),None)
        return list(table.iter('tr')).index(n) if table is not None else None
    if k=='next':return ids.get(n.getnext(),-1)
    return n.get(k)
def query(i,selector):return json.dumps([ids[e] for e in nodes[i].cssselect(selector) if e is not nodes[i]])
def matches(i,selector):return nodes[i] in root.cssselect(selector)
def style(i):
    vals={};chain=list(nodes[i].iterancestors())[::-1]+[nodes[i]]
    color='rgb(0,0,0)'
    for n in chain:
        v=dict(x.strip().split(':',1) for x in n.get('style','').split(';') if ':' in x)
        if 'color' in v:color=v['color'].strip()
    own=dict(x.strip().split(':',1) for x in nodes[i].get('style','').split(';') if ':' in x)
    return json.dumps({'color':color,'backgroundColor':own.get('background-color','rgba(0,0,0,0)').strip(),'display':own.get('display','block'),'visibility':'visible','overflowY':own.get('overflow-y',own.get('overflow','visible')),'overflowX':own.get('overflow-x',own.get('overflow','visible')),'pointerEvents':own.get('pointer-events','auto')})
def rect(i):
    n=nodes[i]; top=n.get('data-top')
    if top is None:
        top=next((a.get('data-top') for a in n.iterancestors() if a.get('data-top') is not None),'0')
    left=float(n.get('data-left','0'));width=float(n.get('data-width','250'));top=float(top)
    return json.dumps({'left':left,'right':left+width,'top':top,'bottom':top+float(n.get('data-height','20')),'width':width,'height':float(n.get('data-height','20'))})
ctx.add_callable('_rect',rect)
ctx.add_callable('_prop',prop);ctx.add_callable('_query',query);ctx.add_callable('_matches',matches);ctx.add_callable('_style',style)
ctx.add_callable('_set',lambda i,k,v:nodes[i].set(k,str(v)))
ctx.eval('''
const cache=new Map();const node=i=>i<0?null:(cache.has(i)?cache.get(i):(cache.set(i,new N(i)),cache.get(i)));
class N {constructor(id){this.id=id} get children(){return JSON.parse(_prop(this.id,'children')).map(node)} get parentElement(){return node(_prop(this.id,'parent'))}
 get nextElementSibling(){return node(_prop(this.id,'next'))} get isConnected(){return !!_prop(this.id,'connected')} get innerText(){return _prop(this.id,'text')}get textContent(){return this.innerText}
 querySelectorAll(s){return JSON.parse(_query(this.id,s)).map(node)} querySelector(s){return this.querySelectorAll(s)[0]||null}
 matches(s){return _matches(this.id,s)}closest(s){for(let n=this;n;n=n.parentElement)if(n.matches(s))return n;return null}
 contains(e){for(let n=e;n;n=n.parentElement)if(n===this)return true;return false}
 getAttribute(k){return _prop(this.id,k)}setAttribute(k,v){_set(this.id,k,v)}
 get rowIndex(){return _prop(this.id,'rowIndex')} get cellIndex(){return _prop(this.id,'cellIndex')} get rowSpan(){return Number(this.getAttribute('rowspan')||1)}get colSpan(){return Number(this.getAttribute('colspan')||1)}
 getBoundingClientRect(){return JSON.parse(_rect(this.id))}scrollIntoView(){}get scrollHeight(){return 20}get clientHeight(){return 20}}
const document=node(0);document.body=document.querySelector('body');const window={};
const location={href:'https://nhapdiem.truonghocviet.vn/diem',origin:'https://nhapdiem.truonghocviet.vn',pathname:'/diem'};
const getComputedStyle=e=>JSON.parse(_style(e.id));
''')
ctx.eval('''window.innerWidth=1920;window.innerHeight=1080;
document.elementFromPoint=(x,y)=>[...document.querySelectorAll('td,th')].filter(e=>{const r=e.getBoundingClientRect();return x>=r.left&&x<r.right&&y>=r.top&&y<r.bottom}).slice(-1)[0]||null;''')
ctx.eval('''
const events=new Map();
document.addEventListener=(type,fn)=>{if(!events.has(type))events.set(type,new Set());events.get(type).add(fn)};
document.removeEventListener=(type,fn)=>events.get(type)?.delete(fn);
const fixtureClick=(selector,trusted=true)=>{const target=document.querySelector(selector);for(const type of ['mousedown','click'])for(const fn of [...(events.get(type)||[])])fn({type,target,isTrusted:trusted})};
''')
ctx.eval('const productionDOM=('+DOM+');')
def run(op,**kw):return json.loads(ctx.eval('JSON.stringify(productionDOM('+json.dumps({'op':op,**kw})+'))'))
# One-word student in the real screenshot: empty surname, name Winnie.
identity=root.cssselect('table.fixed-table tr')[1]
ho,ten=list(identity)[1:3];original_ho,original_ten=ho.text,ten.text
ho.text='';ten.text='Winnie'
single=run('snapshot_all')
assert len(single['rows'])==3 and single['rows'][0]['name']=='Winnie',single
single_source=[{'student':'  Winnie  ','row':8,'Giữa kỳ':'10'},{'student':'Lê Chi','row':10,'Giữa kỳ':'7.5'}]
single_plan=build_plan(single_source,single['rows'],'Giữa kỳ','Toán',index=7)
assert [[r['stt'] for r in rr] for rr in paste_runs(single_plan)]==[[1],[3]]
one=single_plan[:1]
one_token=run('bind_column',run=one,index=7,column='Giữa kỳ')
assert run('reveal',student=one[0])
assert run('focus',run=one,index=7)
one_selector=run('bound_focus',token=one_token,run=one)
ctx.eval('fixtureClick('+json.dumps(one_selector)+');')
assert run('bound_check',token=one_token,run=one,selector=one_selector)
ten.text='Different'
try:run('bound_focus',token=one_token,run=one);raise AssertionError('Wrong one-word name was accepted')
except quickjs.JSException:pass
ten.text='Winnie'
one_score=root.cssselect(one_selector)[0];original_score,original_style=one_score.text,one_score.get('style')
one_score.text='10.0';one_score.set('style','color:rgb(0,128,0)')
from auto_core import grade_batch_state
assert grade_batch_state(run('bound_snapshot',token=one_token,run=one)['rows'],one,4)['saved']
one_score.text=original_score;one_score.set('style',original_style or '')
ten.text=''
assert len(run('snapshot_all')['rows'])==2 # Both name parts blank is still invalid.
ho.text=original_ho;ten.text=original_ten
print('PASS: empty surname + Winnie reads, matches, focuses, binds and verifies numeric grades; name changes and fully empty names remain blocked.')

s=run('snapshot');assert len(s['rows'])==3,s
assert s['rows'][1]['inactive'];assert s['rows'][0]['saved'][4];assert not s['rows'][2]['saved'][4]
headers=run('headers');paths=expand_headers(headers[0]);assert column_index(paths,'Giữa kỳ')==7,paths
source=[{'student':'Lê Chi','row':10,'Giữa kỳ':'CĐ'},{'student':'Nguyễn An','row':8,'Giữa kỳ':'Đ'}]
p=build_plan(source,s['rows'],'Giữa kỳ','GDĐP',index=7)
assert [[x['stt'] for x in batch] for batch in paste_runs(p)]==[[1],[3]]
assert run('focus',run=[p[2]],index=7).startswith('[data-vsa=')
try:run('focus',run=[p[1]],index=7);raise AssertionError('Inactive student was focused')
except quickjs.JSException:pass
assert run('target',group=['LỚP HỌC'],values=['10A06'])['active']
assert run('target',group=['MÔN HỌC'],values=['GDĐP'])['active']
t=run('target',group=['ĐỢT ĐIỂM'],values=['ĐGTX'],branch='Học kỳ 1');assert t['active'],t
t=run('target',group=['ĐỢT ĐIỂM'],values=['ĐGTX'],branch='Học kỳ 2');assert not t['active'],t
print('PASS: student mapping, merged headers, retired row, grade focus and term selection.')

assert run('target',group=['LỚP HỌC'],values=['Khối 10'])['expanded']=='false'
assert run('target',group=['LỚP HỌC'],values=['10A06'],branch='Khối 10')['active']
assert run('busy')[0]['ariaHidden']=='true'
loading=root.cssselect('#loading')[0];loading.set('style','display:none')
assert run('busy')==[]
print('PASS: geometric HTML headers, term branches and loading overlay checks.')

# Regression: plain split HTML, no grid-specific classes or role attributes.
diag=run('diagnostic')
assert diag['stats']['table']==10,diag['stats']
assert diag['stats']['tr,[role="row"],.ag-row,.wj-row,.slick-row,.pq-grid-row']==112,diag['stats']
assert diag['stats']['.wj-flexgrid']==0 and diag['dataRows']==3,diag
assert len(diag['tableShapes'])==10
selector=run('focus',run=[p[2]],index=7)
assert run('verify_focus',run=[p[2]],index=7,selector=selector)
print('PASS: plain split HTML, 10 tables / 112 rows / no Wijmo grid; v3.6 finds correct students and columns.')

# A scroll viewport can hide the third row although it exists in the HTML DOM.
ctx.eval('window.innerHeight=190;')
clipped=run('snapshot')['rows'];full=run('snapshot_all')['rows']
assert len(clipped)==2,(clipped,full)
assert len(full)==3 and full[-1]['stt']==3,full
from full_auto import AutoWorker
import queue, threading
from unittest.mock import Mock
worker=AutoWorker('',queue.Queue(),threading.Event());worker.page=Mock(return_value=Mock())
worker.dom=lambda f,op,**kw:run(op,**kw)
read=worker.collect('fixture',expected=source)
assert len(read)==3 and read[-1]['name']=='Lê Chi'
print('PASS: clipped viewport shows 2 rows, full DOM reads all 3; full-roster collection succeeds without a scrollbar.')

# Reproduce the visible-column shift after Ctrl+V: TX1 moves behind the frozen names.
ctx.eval('''window.innerHeight=1080;
document.elementFromPoint=(x,y)=>{
 const hits=[...document.querySelectorAll('td,th')].filter(e=>{const r=e.getBoundingClientRect();return x>=r.left&&x<r.right&&y>=r.top&&y<r.bottom});
 const frozen=hits.filter(e=>e.closest('table.fixed-table'));
 return frozen.slice(-1)[0]||hits.slice(-1)[0]||null;
};''')
for c in root.cssselect('table.score-table td'):
    c.set('data-left',str(float(c.get('data-left'))-76))
for tr in root.cssselect('table.score-table tr'):
    cc=list(tr)
    if len(cc)!=4 or float(cc[0].get('data-top','0'))<100:continue
    top=float(cc[0].get('data-top'))
    if top in (100,190):
        cc[-1].text='Đ' if top==100 else 'CĐ';cc[-1].set('style','color:rgb(0,128,0)')
shifted=run('snapshot')
from auto_core import column_index,grade_batch_state
assert column_index(shifted['headerPaths'],'Giữa kỳ')==6,shifted
assert len(shifted['rows'][0]['cells'])==7,shifted
assert grade_batch_state(shifted['rows'],[p[0],p[2]],6)['saved'],shifted
assert not grade_batch_state(shifted['rows'],[p[0],p[2]],7)['saved']
assert column_index(expand_headers(run('headers')[0]),'Giữa kỳ')==6
print('PASS: horizontal scroll hides TX1, GK changes 7→6, frozen header remains correct, saved grades verify without IndexError.')

# Bind the intended physical score cells once. Header discovery may then disappear.
for tr in root.cssselect('table.score-table tr'):
    cc=list(tr)
    if len(cc)==4 and float(cc[0].get('data-top','0'))>=100:
        cc[-1].text='';cc[-1].set('style','color:rgb(0,0,0)')
# Retired students remain recognizable when gray is applied on a different ancestor.
retired_identity=root.cssselect('table.fixed-table tr')[2]
list(retired_identity)[-1].set('style','color:rgb(255,0,0)')
retired_score=root.cssselect('table.score-table tr')[3]
list(retired_score)[0].set('style','')
now=run('snapshot_all')
assert now['rows'][1]['inactive']
assert 'ngày sinh' in now['rows'][1]['inactiveReason']
targets=[p[0],p[2]]
token=run('bind_column',run=targets,index=6,column='Giữa kỳ')
assert run('bound_reveal',token=token,run=targets)
selector=run('bound_focus',token=token,run=targets)
ctx.eval('fixtureClick('+json.dumps(selector)+');')
assert run('bound_check',token=token,run=targets,selector=selector)
# Actual diagnostic: Progrid hides overflow and uses a custom scroll container.
# A partly exposed cell has a clickable point although its full center is clipped.
host=root.cssselect('.generic-score-container')[0]
original_host=dict(host.attrib)
host.set('style','overflow:hidden');host.set('data-left','0');host.set('data-width','1400');host.set('data-top','100');host.set('data-height','22')
view=run('bound_view',token=token,run=[targets[0]])
assert view['ready'] and 0<view['position']['y']<22,view
selector=run('bound_focus',token=token,run=[targets[0]])
ctx.eval('fixtureClick('+json.dumps(selector)+',false);')
try:run('bound_check',token=token,run=[targets[0]],selector=selector);raise AssertionError('Synthetic click accepted')
except quickjs.JSException:pass
selector=run('bound_focus',token=token,run=[targets[0]])
wrong=run('target',group=['LỚP HỌC'],values=['10A06'])['selector']
ctx.eval('fixtureClick('+json.dumps(wrong)+');')
try:run('bound_check',token=token,run=[targets[0]],selector=selector);raise AssertionError('Wrong cell click accepted')
except quickjs.JSException:pass
selector=run('bound_focus',token=token,run=[targets[0]])
ctx.eval('fixtureClick('+json.dumps(selector)+');')
# The grid's click handler can change its scrolling layout. Trust the captured
# target event + original identity, rather than probing its old center afterward.
clicked=root.cssselect(selector)[0];original_top=clicked.get('data-top');clicked.set('data-top','1700')
assert run('bound_check',token=token,run=[targets[0]],selector=selector)
clicked.set('data-top',original_top)
host.set('data-height','501')
last=root.cssselect('table.score-table tr')[-1][-1];original_last_top=last.get('data-top');last.set('data-top','1700')
view=run('bound_view',token=token,run=[targets[1]])
assert not view['ready'] and view['dy']>0 and view['dx']==0,view
last.set('data-top','200')
assert run('bound_view',token=token,run=[targets[1]])['ready']
last.set('data-top',original_last_top)
host.attrib.clear();host.attrib.update(original_host)
# Explicit site CSS supplied in the diagnostic, independent of color rendering.
identity_cells=list(retired_identity)[1:4]
old_styles=[e.get('style') for e in identity_cells]
for e in identity_cells:e.set('style','color:rgb(0,0,0)');e.set('class','gachCell')
assert 'gachCell' in run('snapshot_all')['rows'][1]['inactiveReason']
for e,style in zip(identity_cells,old_styles):e.set('style',style or '');e.set('class','')
active_score=root.cssselect('table.score-table tr')[2][1]
active_score.set('class','lockCell')
assert any(run('snapshot_all')['rows'][0]['locks'][4:])
active_score.set('class','')
print('PASS: clipped Progrid cell, custom-scroll wheel plan, actual click target proof, wrong/synthetic click rejection, gachCell retirement and lockCell protection.')

# Hide header cells to reproduce failure to rediscover GK after scrolling.
for c in root.cssselect('td'):
    if float(c.get('data-top','0'))<100:c.set('style','display:none')
assert not run('snapshot').get('headerPaths')
for tr in root.cssselect('table.score-table tr'):
    cc=list(tr)
    if len(cc)!=4:continue
    top=float(cc[0].get('data-top','0'))
    if top in (100,190):
        cc[-1].text='Đ' if top==100 else 'CĐ';cc[-1].set('style','color:rgb(0,128,0)')
bound=run('bound_snapshot',token=token,run=targets)
assert grade_batch_state(bound['rows'],targets,4)['saved']
assert [r['stt'] for r in bound['rows']]==[1,3]
assert list(retired_score)[-1].text in (None,'')
print('PASS: bound score cells verify and continue across a retired student even when headers disappear; three red identity fields detect retirement.')

# Regression: independently scrolled frozen and grade panes no longer share Y.
for tr in root.cssselect('table.score-table tr'):
    cc=list(tr)
    if len(cc)==4 and float(cc[0].get('data-top','0'))>=100:
        cc[-1].text='';cc[-1].set('style','color:rgb(0,0,0)')
targets=[p[0],p[2]]
stable=run('bind_column',run=targets,index=6,column='Giữa kỳ')
for c in root.cssselect('table.fixed-table td'):
    if float(c.get('data-top','0'))>=100:c.set('data-top',str(float(c.get('data-top'))+13))
assert run('snapshot_all')['rows']==[] # Old Y-based correspondence has been lost.
assert run('bound_reveal',token=stable,run=targets)
selected=run('bound_focus',token=stable,run=targets)
ctx.eval('fixtureClick('+json.dumps(selected)+');')
assert run('bound_check',token=stable,run=targets,selector=selected)
for tr in root.cssselect('table.score-table tr'):
    cc=list(tr)
    if len(cc)==4 and float(cc[0].get('data-top','0')) in (100,190):
        cc[-1].text='Đ' if float(cc[0].get('data-top'))==100 else 'CĐ';cc[-1].set('style','color:rgb(0,128,0)')
assert grade_batch_state(run('bound_snapshot',token=stable,run=targets)['rows'],targets,4)['saved']
print('PASS: frozen pane shifted by 13 px, geometric roster unavailable, original bound row identities still verify correct grades.')
# The fix must still reject a real identity change or physical column move.
first_identity=root.cssselect('table.fixed-table tr')[1]
name_cell=list(first_identity)[1];original=name_cell.text;name_cell.text='Tên bị thay đổi'
try:
    run('bound_focus',token=stable,run=targets)
    raise AssertionError('Changed identity was accepted')
except quickjs.JSException as e:assert 'STT/họ tên/ngày sinh' in str(e),str(e)
name_cell.text=original
first_score=root.cssselect('table.score-table tr')[2]
gk=list(first_score)[-1];gk.text='';first_score.insert(0,gk)
try:
    run('bound_focus',token=stable,run=[targets[0]])
    raise AssertionError('Moved physical column was accepted')
except quickjs.JSException as e:assert 'Thứ tự hàng/cột' in str(e),str(e)
print('PASS: changed names and physically moved score cells are rejected before paste.')

# Navigation regression: grade labels can be joined or absent while classes exist.
grade_label=next(e for e in root.cssselect('.wj-nodetext') if e.text=='Khối 10')
grade_label.text='Khối10'
assert run('target',group=['LỚP HỌC'],values=['Khối 10']).get('selector')
assert run('target',group=['LỚP HỌC'],values=['10A06'],branch='Khối 10')['active']
grade_label.text=''
assert run('target',group=['LỚP HỌC'],values=['10A06'])['active']
term_label=next(e for e in root.cssselect('.wj-nodetext') if e.text=='Học kỳ 1')
term_label.text='Học kỳ1'
assert run('target',group=['ĐỢT ĐIỂM'],values=['Học kỳ 1']).get('selector')
assert run('target',group=['ĐỢT ĐIỂM'],values=['ĐGTX'],branch='Học kỳ 1')['active']
print('PASS: Khối10 and Học kỳ1 labels normalize correctly; visible exact class remains selectable without its grade label.')
