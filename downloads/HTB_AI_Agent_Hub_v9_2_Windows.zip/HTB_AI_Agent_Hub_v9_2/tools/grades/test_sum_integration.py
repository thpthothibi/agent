import tempfile
import unittest
from pathlib import Path
from decimal import Decimal
from openpyxl import load_workbook
from cong_diem.core import load, records, Mapping, combine, export


class SumIntegrationTests(unittest.TestCase):
    def data(self):
        base=Path(__file__).parent/'cong_diem'/'demo'
        mapping=Mapping(header=1,name=0,classroom=1,grade=2)
        a=records(load(base/'tu_luan_demo.csv')['CSV'],mapping)
        b=records(load(base/'trac_nghiem_demo.csv')['CSV'],mapping)
        return a,b,combine(a,b,2)

    def test_supplied_demo_matches_names_not_positions(self):
        a,b,rows=self.data()
        good={r['name']:r['total'] for r in rows if r['total'] is not None}
        self.assertEqual(good,{'Nguyễn Văn An':Decimal('7.50'),'Trần Thị Bình':Decimal('6.75'),'Winnie':Decimal('7.25')})
        self.assertEqual(len(rows),8)
        self.assertEqual(sum(r['total'] is None for r in rows),5)
        duplicates=[r for r in rows if r['name']=='Phạm Thị Hà']
        self.assertEqual(len(duplicates),3)
        self.assertTrue(all(r['total'] is None for r in duplicates))

    def test_export_contains_summary_issues_and_sources(self):
        a,b,rows=self.data()
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'sum.xlsx'
            export(path,rows,[('Nguon_TL','demo TL',a),('Nguon_TN','demo TN',b)])
            book=load_workbook(path)
            self.assertEqual(book.sheetnames,['Tong_hop','Can_kiem_tra','Nguon_TL','Nguon_TN'])
            self.assertEqual(book['Tong_hop']['G2'].value,7.5)
            self.assertEqual(book['Can_kiem_tra'].max_row,6)
            book.close()

    def test_embedded_widget_import_has_no_standalone_root(self):
        from cong_diem.app import App
        from tkinter import ttk
        self.assertTrue(issubclass(App,ttk.Frame))

if __name__=='__main__':unittest.main()
