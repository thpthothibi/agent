import unittest
from unittest.mock import Mock, patch
from mascot import swim_step, FloatingMascot


class CarpSwimTests(unittest.TestCase):
    def test_moves_in_both_directions(self):
        self.assertAlmostEqual(swim_step(100, 1, .1, 900)[0], 103.4)
        self.assertAlmostEqual(swim_step(100, -1, .1, 900)[0], 96.6)

    def test_turns_at_edges(self):
        self.assertEqual(swim_step(1, -1, .1, 900), (0, 1))
        self.assertEqual(swim_step(759, 1, .1, 900), (760, -1))

    def test_resize_and_delayed_timer_keep_fish_inside(self):
        self.assertEqual(swim_step(800, 1, 10, 300), (160, -1))
        self.assertEqual(swim_step(200, -1, .1, 90)[0], 0)
        self.assertAlmostEqual(swim_step(100, 1, 10, 900)[0], 105.1)

    def robot(self):
        fish=object.__new__(FloatingMascot)
        fish.visible=True;fish.animate=Mock();fish.animate.get.return_value=True
        fish.root=Mock();fish.root.winfo_ismapped.return_value=True
        fish.root.grab_current.return_value=None;fish.root.winfo_width.return_value=900
        fish.frame=Mock();fish.canvas=Mock();fish.press=None;fish.tooltip=None
        fish.swim_last=10;fish.pause_until=0;fish.swim_direction=-1
        fish.position=(100,200);fish.width=140;fish.phase=0;fish.origin=(70,75)
        fish.character=1;fish.spark=2;fish.mode='idle';fish.facing_images={-1:'left',1:'right'}
        fish.sync_position=Mock()
        return fish

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_tick_moves_and_selects_facing_image(self,clock):
        fish=self.robot();fish.tick()
        self.assertAlmostEqual(fish.position[0],96.6)
        fish.canvas.itemconfigure.assert_any_call(1,image='left')
        fish.sync_position.assert_called_once()

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_pauses_during_interaction_and_when_hidden(self,clock):
        for field,value in [('press',(1,2,3,4)),('tooltip',Mock()),('visible',False),('pause_until',22)]:
            fish=self.robot();setattr(fish,field,value);fish.tick()
            self.assertEqual(fish.position,(100,200))
            fish.sync_position.assert_not_called()
            fish.frame.after.assert_called_once()
        fish=self.robot();fish.animate.get.return_value=False;fish.tick()
        self.assertEqual(fish.position,(100,200))

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_edge_starts_gradual_turn(self,clock):
        fish=self.robot();fish.position=(.1,200)
        fish.turn_frames={-1:list(range(10)),1:list(range(10,20))}
        fish.turn_elapsed=None;fish.tick()
        self.assertEqual(fish.swim_direction,1)
        self.assertEqual(fish.turn_from,-1)
        self.assertEqual(fish.turn_elapsed,0)
        self.assertEqual(fish.position[0],0)

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_turn_holds_position_then_resumes(self,clock):
        fish=self.robot();fish.turn_from=-1;fish.swim_direction=1
        fish.turn_frames={-1:list(range(10)),1:list(range(10,20))}
        fish.turn_elapsed=.3;fish.tick()
        self.assertEqual(fish.position,(100,200))
        self.assertAlmostEqual(fish.turn_elapsed,.4)
        fish.turn_elapsed=.95;fish.swim_last=10;fish.tick()
        self.assertIsNone(fish.turn_elapsed)

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_animated_frames_advance_with_stroke(self,clock):
        fish=self.robot();fish.swim_frames={-1:list(range(100,132)),1:list(range(200,232))}
        fish.tick()
        fish.canvas.itemconfigure.assert_any_call(1,image=101)

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_timer_targets_sixty_frames_per_second(self,clock):
        fish=self.robot();fish.tick()
        self.assertLessEqual(fish.frame.after.call_args.args[0],17)
        self.assertGreater(fish.frame.after.call_args.args[0],0)

    def test_duplicate_geometry_is_not_sent(self):
        fish=self.robot();fish.root.winfo_height.return_value=600
        fish.root.winfo_rootx.return_value=10;fish.root.winfo_rooty.return_value=20
        fish.height=150
        FloatingMascot.sync_position(fish);FloatingMascot.sync_position(fish)
        fish.frame.geometry.assert_called_once()


if __name__=='__main__':unittest.main()
