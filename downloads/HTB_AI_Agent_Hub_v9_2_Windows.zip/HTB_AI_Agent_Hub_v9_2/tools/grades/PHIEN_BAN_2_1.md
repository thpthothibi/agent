# HTB AI Agent v2.1

Tích hợp tool cộng điểm TL + TN do người dùng gửi, trực tiếp trong menu và cửa sổ chính. Giữ nguyên lõi tính toán gốc và bộ đọc VietSchool v2.0.4 đã chạy đúng.

Chạy CHAY_HTB_AI_AGENT.bat → Cộng điểm TL + TN → chọn hai file, kiểm tra cột → Đối chiếu & cộng điểm → lưu Excel.

111 kiểm thử Python đạt, 1 bỏ qua. Đã thử dữ liệu mẫu và xuất Excel; chưa kiểm tra giao diện mới trên Windows.
