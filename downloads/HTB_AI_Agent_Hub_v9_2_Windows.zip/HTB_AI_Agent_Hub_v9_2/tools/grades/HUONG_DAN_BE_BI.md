# Bé Bi v2.0 — Trợ lý trong đội HTB AI Agent

## Mở và kết nối

1. Giải nén toàn bộ ZIP vào thư mục riêng, chạy **CHAY_HTB_AI_AGENT.bat**.
2. Bấm **Trò chuyện Bé Bi** ở menu trái, nút **Trò chuyện ♡** cạnh linh vật hoặc bấm vào ảnh robot.
3. Bấm **Kết nối AI** để nhập khóa API và tên model ở phần kết nối dùng chung với Agent báo cáo.
4. Chọn Gemini hoặc OpenAI và nhập câu hỏi. Bấm Gửi hoặc Ctrl+Enter.

Tài khoản API cần có quyền dùng model và hạn mức phù hợp. Không nhập mật khẩu tài khoản ChatGPT/Gemini thay API key. Khóa giữ trong bộ nhớ phiên; có thể cấp qua các biến môi trường đã hướng dẫn ở phần báo cáo. Không cần khóa API cho các thao tác mở trang, hiển thị linh vật và đọc giọng Windows.

## Khả năng đã tích hợp

- **Hội thoại AI:** hỏi đáp, giải thích nghiệp vụ, viết nội dung, đề xuất kế hoạch. Có ba phong cách: dễ thương/ngắn gọn, chuyên nghiệp/chi tiết, gia sư kiên nhẫn.
- **Tìm web:** bật tùy chọn trước khi gửi. Câu trả lời có trích dẫn khi nhà cung cấp trả nguồn. Nút **Xem nguồn web** mở danh mục nguồn và gợi ý tìm kiếm Google nếu có.
- **Đọc tài liệu:** chủ động đính kèm DOCX, PDF có chữ, XLSX, TXT/MD/CSV UTF-8. Tối đa 5 tệp, 20 MB/tệp, 100.000 ký tự tổng phần chữ cho chat. Những giới hạn trích xuất khác kế thừa từ Agent báo cáo. PDF scan cần OCR trước.
- **Nhớ cuộc trò chuyện:** trong phiên giữ tối đa 100 lượt. Mỗi câu hỏi gửi tối đa 16 lượt gần nhất, với giới hạn 60.000 ký tự lịch sử. Đây là lịch sử hội thoại có giới hạn, không phải mô hình tự huấn luyện.
- **Lưu lịch sử tùy chọn:** mặc định tắt. Bật để ghi nội dung chat vào `du_lieu_be_bi/lich_su.json` trên máy; bật lại ở lần chạy sau sẽ nạp lịch sử nếu cuộc chat đang trống. Khóa API và nội dung tệp đính kèm không được lưu vào hồ sơ chat. Nếu AI nhắc lại thông tin từ tài liệu trong câu trả lời thì thông tin đó thuộc nội dung chat và có thể được lưu.
- **Điều hướng chức năng:** nút mở Nhập điểm, Đối chiếu, Phòng thi, Báo cáo. Có thể gõ riêng một lệnh: `/tongquan`, `/nhapdiem`, `/doichieu`, `/phongthi`, `/baocao`, hoặc “mở nhập điểm”, “mở đối chiếu”, “mở phòng thi”, “mở báo cáo”. Chỉ mở đúng trang; không tự chạy tác vụ ghi điểm.
- **Chuyển sang bản thảo:** đưa câu trả lời gần nhất sang Agent báo cáo để sửa và xuất Word. Nếu đã có bản thảo sẽ hỏi trước khi thay.
- **Xuất hội thoại:** lưu Markdown hoặc Word, bao gồm các lượt chat hiện có.
- **Đọc câu trả lời:** trên Windows, bấm Đọc câu trả lời để dùng giọng SAPI đã cài. Ưu tiên giọng tiếng Việt nếu hệ thống nhận diện được; không bảo đảm giọng nữ miền Nam. Có nút Dừng đọc. Không gửi âm thanh ra dịch vụ bên ngoài. Nếu máy không có giọng phù hợp hoặc chính sách máy chặn PowerShell thì chức năng đọc có thể không hoạt động.
- **Linh vật:** chào, nhún nhẹ, hiển thị đang xử lý, đang đọc và nhắc kiểm tra kết quả khi kết thúc. Có nút tắt chuyển động/thu gọn. Ảnh robot giữ nguyên; đây chưa phải hoạt hình nhiều biểu cảm khuôn mặt.

## Cách dùng gợi ý

**Soạn báo cáo theo mẫu:** đính kèm mẫu và số liệu → hỏi Bi phân tích cấu trúc, điểm còn thiếu → bổ sung số liệu → yêu cầu soạn nội dung → Chuyển câu trả lời sang bản thảo → kiểm tra và xuất Word. Có thể dùng luồng tìm/viết/rà soát ba bước ở Agent Báo cáo & Kế hoạch khi cần.

**Lập kế hoạch công việc:** bấm Giúp lập kế hoạch hoặc nhập mục tiêu, thời hạn, nguồn lực → trao đổi với Bi để làm rõ → yêu cầu lập bảng nhiệm vụ, người phụ trách, thời gian, sản phẩm → chuyển sang bản thảo.

**Nhập/đối chiếu điểm:** yêu cầu hướng dẫn hoặc bấm mở chức năng tương ứng. Tự chọn Excel và bắt đầu tại trang tác vụ. Chat không đọc ngầm file điểm đang chọn.

## Dữ liệu, chi phí và giới hạn thực tế

- Gửi câu hỏi sẽ gửi câu hỏi, các lượt chat gần đây và tài liệu đang đính kèm cho AI đã chọn. Tài liệu vẫn được đính kèm ở lượt sau cho tới khi bấm Bỏ tài liệu. Nếu bật tìm web, mô hình có thể dùng thông tin trong câu hỏi/hội thoại/tài liệu để tạo truy vấn tìm kiếm; bỏ nội dung nội bộ trước khi dùng chế độ này.
- Tùy chọn chia sẻ ngữ cảnh mặc định tắt; khi bật chỉ gửi tên trang và trạng thái tác vụ, không tự tải file hoặc đọc màn hình.
- Lịch sử lưu trên máy là văn bản thường; ai có quyền đọc thư mục có thể đọc. Tắt lưu chỉ ngừng ghi thêm. Dùng Xóa lịch sử để xóa cả nội dung trong phiên và tệp lịch sử; các bản đã xuất riêng không bị xóa.
- Khóa nhận diện được sẽ được che khi lưu/xuất chat. Không dán mật khẩu hoặc khóa vào câu hỏi/tài liệu.
- Mỗi câu hỏi AI tương ứng một lượt API, không tự thử lại khi lỗi. Tìm web có thể tính phí riêng. Dừng nhận phản hồi không thu hồi yêu cầu đã gửi; có thể vẫn phát sinh phí. Khi yêu cầu đang chạy, đợi kết thúc trước khi khởi chạy tác vụ Agent khác.
- Chưa có nhận giọng nói từ micro, đánh thức bằng giọng nói, AI chạy ngoại tuyến, tự điều khiển mọi ứng dụng hoặc trí nhớ vô hạn. Không tự học từ mọi tệp trong máy.
- AI có thể sai. Kiểm tra nguồn, số liệu và nội dung trước khi dùng cho báo cáo hoặc công việc thật.

## Kiểm chứng bản v2.0

Đã chạy bộ unittest Python, gồm điều hướng rõ ràng, che khóa khi lưu, giới hạn lịch sử, tạo prompt, gửi/nhận qua phản hồi mô phỏng, xử lý lỗi và hủy phản hồi muộn. Đã kiểm tra cú pháp. Chưa kiểm thử trực tiếp giao diện v2.0 trên Windows, giọng Windows, API thật hoặc VietSchool thật.

Tích hợp theo tài liệu:
https://developers.openai.com/api/docs/guides/tools-web-search
https://ai.google.dev/gemini-api/docs/generate-content/google-search
