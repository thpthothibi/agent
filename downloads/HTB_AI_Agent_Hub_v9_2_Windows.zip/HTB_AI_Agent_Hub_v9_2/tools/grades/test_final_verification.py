import copy
import queue
import threading
import unittest
from unittest.mock import Mock,patch
from full_auto import AutoWorker
from check_worker import CheckWorker


class FinalVerificationTests(unittest.TestCase):
    def worker(self):
        return AutoWorker('',queue.Queue(),threading.Event())

    def jobs(self):
        return [dict(year='2026-2027',term='Học kỳ 1',subject='Toán',column='Giữa kỳ',
                     rows=[dict(student='Winnie',row=2,**{'Giữa kỳ':'8'})],**{'class':c}) for c in ['10A01','10A02']]

    def test_all_input_groups_finish_before_final_check(self):
        w=self.worker();order=[];jobs=self.jobs()
        w.process_job=Mock(side_effect=lambda j,n,t:order.append('input:'+j['class']))
        w.verify_all_jobs=Mock(side_effect=lambda js:order.append('verify:all'))
        w.process_jobs(jobs)
        self.assertEqual(order,['input:10A01','input:10A02','verify:all'])

    def test_input_failure_prevents_final_check(self):
        w=self.worker();w.process_job=Mock(side_effect=RuntimeError('Lưu chưa xác nhận'))
        w.verify_all_jobs=Mock()
        with self.assertRaises(RuntimeError):w.process_jobs(self.jobs())
        w.verify_all_jobs.assert_not_called()

    def test_input_ranges_do_not_reload_or_claim_readback(self):
        w=self.worker();w.page=Mock(return_value=Mock());w.tick=Mock()
        w.navigate=Mock();w.prepare_grid=Mock();w.scope_is_selected=Mock()
        w.grid=Mock(return_value=('frame',{}));w.headers=Mock(return_value=4)
        web=[dict(stt=i,name=f'Học sinh {i}',dob='',inactive=i==2,cells=[str(i),'',f'Học sinh {i}','',''],locks=[False]*5) for i in range(1,4)]
        w.collect=Mock(side_effect=lambda *a,**kw:copy.deepcopy(web));w.dom=Mock(return_value='binding')
        w.paste=Mock()
        job={**self.jobs()[0],'rows':[dict(student=f'Học sinh {i}',row=i,**{'Giữa kỳ':'8'}) for i in [1,3]]}
        w.process_job(job,1,2)
        self.assertEqual(w.paste.call_count,2)
        w.page().reload.assert_not_called()
        self.assertEqual(w.total,2)
        self.assertTrue(all(r['verification']=='Chờ kiểm tra cuối đợt' for r in w.audit if r['status']=='Sẽ dán'))

    def test_final_checker_reloads_once_and_checks_all_groups(self):
        w=self.worker();page=Mock();checked=[]
        def page_for(checker):return page
        def check_job(checker,job,n,total):
            checked.append(job['class']);checker.finished.add(n-1)
            row={**job,'rows':None,'name':'Winnie','stt':1,'row':2,'expected':'8','actual':'8','result':'Đúng','reason':''}
            checker.audit.append(row);checker.total+=1
            checker.events.put(('comparison',{'scope':job['class'],'rows':[row]}))
        with patch.object(CheckWorker,'page',page_for),patch.object(AutoWorker,'login_and_open'),patch.object(CheckWorker,'process_job',check_job):
            w.verify_all_jobs(self.jobs())
        page.reload.assert_called_once()
        self.assertEqual(checked,['10A01','10A02']);self.assertEqual(w.final_checked,2)
        self.assertEqual(len(w.audit),2)
        self.assertTrue(all(r['phase']=='Kiểm tra cuối đợt' for r in w.audit))

    def test_grade_mismatch_is_summarized_after_remaining_classes_checked(self):
        w=self.worker();checked=[]
        def check_job(checker,job,n,total):
            checked.append(job['class']);checker.finished.add(n-1)
            checker.audit.append({**job,'name':'Winnie','expected':'8','actual':'7' if n==1 else '8','result':'Sai điểm' if n==1 else 'Đúng','reason':''})
        with patch.object(CheckWorker,'login_and_open'),patch.object(CheckWorker,'process_job',check_job):
            with self.assertRaisesRegex(RuntimeError,'Đã kiểm tra xong'):
                w.verify_all_jobs(self.jobs())
        self.assertEqual(checked,['10A01','10A02'])
        self.assertEqual(len(w.audit),2)

    def test_refresh_failure_records_unchecked_groups(self):
        w=self.worker()
        with patch.object(CheckWorker,'login_and_open',side_effect=RuntimeError('Mất mạng')):
            with self.assertRaises(RuntimeError):w.verify_all_jobs(self.jobs())
        self.assertEqual(len(w.audit),2)
        self.assertTrue(all(r['result']=='Chưa kiểm tra được' for r in w.audit))


if __name__=='__main__':unittest.main()
