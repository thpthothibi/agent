import json
import tempfile
import unittest
from pathlib import Path
from robot_brain import local_route,redact,chat_prompt,save_history,load_history,add_turn,export_chat


class RobotBrainTests(unittest.TestCase):
    def test_only_explicit_navigation(self):
        self.assertEqual(local_route('Mở nhập điểm'),1)
        self.assertEqual(local_route('/baocao'),4)
        self.assertIsNone(local_route('Tôi cần hướng dẫn mở nhập điểm'))
        self.assertIsNone(local_route('hãy nhập toàn bộ điểm cho tôi'))
        self.assertIsNone(local_route('/baocao; xoa du lieu'))

    def test_secret_redaction(self):
        self.assertNotIn('my-secret-key',redact('Khóa: my-secret-key',['my-secret-key']))
        self.assertNotIn('sk-abcdefghijklmnopqrstuv',redact('sk-abcdefghijklmnopqrstuv'))

    def test_history_roundtrip_and_excludes_extra_fields(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'chat.json'
            save_history(path,[dict(role='user',text='secret-key-123',api_key='do-not-save')],['secret-key-123'])
            raw=path.read_text()
            self.assertNotIn('secret-key-123',raw)
            self.assertNotIn('api_key',raw)
            self.assertEqual(load_history(path)[0]['role'],'user')

    def test_bounded_history(self):
        history=[]
        for i in range(130):add_turn(history,'user',str(i))
        self.assertEqual(len(history),100)
        self.assertEqual(history[0]['text'],'30')

    def test_prompt_limits_history_and_keeps_latest(self):
        history=[dict(role='user',text=str(i)+'x'*15999) for i in range(50)]
        p=chat_prompt('Câu hỏi',history,'Trang hiện tại','Nội dung tệp','Dễ thương')
        self.assertLess(len(p),65000)
        self.assertIn('49xxx',p)
        self.assertIn('Nội dung tệp',p)
        self.assertNotIn('1xxx',p)

    def test_export_and_invalid_history(self):
        self.assertIn('Cá Chép AI',export_chat([dict(role='assistant',text='Xin chào')]))
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'chat.json';path.write_text('{}')
            with self.assertRaises(ValueError):load_history(path)

if __name__=='__main__':unittest.main()
