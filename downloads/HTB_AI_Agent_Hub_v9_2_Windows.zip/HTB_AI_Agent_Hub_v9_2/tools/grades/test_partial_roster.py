import unittest
import queue
import threading
from unittest.mock import Mock
from name_matching import build_plan,paste_runs
from full_auto import AutoWorker
from compare_core import compare_rows


class PartialRosterTests(unittest.TestCase):
    def fixture(self):
        web=[];excel=[]
        for i in range(1,48):
            name='Nguyễn Ngọc Trinh' if i==41 else f'Học sinh {i}'
            retired=i in (4,44)
            web.append(dict(stt=i,name=name,dob='01/01/2011',inactive=retired,
                            cells=[str(i),'Học sinh',str(i),'01/01/2011','','','',''],locks=[False]*8))
            if i not in (4,41,44):excel.append(dict(student=name,row=i+1,**{'Giữa kỳ':'8.75'}))
        return web,excel

    def test_47_web_44_excel_keeps_every_gap(self):
        web,excel=self.fixture();plan=build_plan(excel,web,'Giữa kỳ','Vật lí',index=7)
        self.assertEqual(len(plan),47)
        self.assertEqual(plan[3]['status'],'Bỏ qua: học sinh nghỉ')
        self.assertEqual(plan[43]['status'],'Bỏ qua: học sinh nghỉ')
        self.assertEqual(plan[40]['status'],'Bỏ qua: không có trong Excel')
        self.assertIsNone(plan[40]['value'])
        self.assertEqual([[r['stt'] for r in run] for run in paste_runs(plan)],
                         [list(range(1,4)),list(range(5,41)),[42,43],[45,46,47]])
        self.assertEqual(sum(map(len,paste_runs(plan))),44)

    def test_missing_excel_student_skips_but_duplicate_names_still_block(self):
        web,excel=self.fixture()
        excel.append(dict(student='Tên chưa có trên web',row=99,**{'Giữa kỳ':'7'}))
        result=build_plan(excel,web,'Giữa kỳ','Vật lí',index=7)
        self.assertEqual(result[-1]['status'],'Bỏ qua: không tìm thấy tên trên web')
        web,excel=self.fixture();web[40]['name']=web[39]['name']
        with self.assertRaises(ValueError):build_plan(excel,web,'Giữa kỳ','Vật lí',index=7)

    def test_web_only_rows_never_enter_clipboard_and_are_audited(self):
        web,excel=self.fixture()
        worker=AutoWorker('',queue.Queue(),threading.Event())
        worker.page=Mock(return_value=Mock());worker.tick=Mock();worker.scope_is_selected=Mock()
        worker.navigate=Mock();worker.prepare_grid=Mock();worker.grid=Mock(return_value=(None,{}))
        worker.collect=Mock(return_value=web);worker.headers=Mock(return_value=7)
        worker.dom=Mock(return_value='bound');worker.paste=Mock()
        job=dict(subject='Vật lí',column='Giữa kỳ',rows=excel,**{'class':'10A06'})
        worker.process_job(job,6,25)
        sent=[r for call in worker.paste.call_args_list for r in call.args[1]]
        self.assertEqual(len(sent),44)
        self.assertNotIn(41,[r['stt'] for r in sent])
        self.assertEqual([r['stt'] for r in sent][-3:],[45,46,47])
        missing=[r for r in worker.audit if r['result']=='Bỏ qua: không có trong Excel']
        self.assertEqual([r['name'] for r in missing],['Nguyễn Ngọc Trinh'])

    def test_comparison_still_reports_unmatched_web_student(self):
        web,excel=self.fixture()
        job=dict(subject='Vật lí',column='Giữa kỳ',rows=excel,year='2026-2027',term='Học kỳ 1',**{'class':'10A06'})
        result=compare_rows(job,web,7)
        extra=[r for r in result if r['name']=='Nguyễn Ngọc Trinh']
        self.assertEqual(extra[0]['result'],'Web có học sinh ngoài Excel')


if __name__=='__main__':unittest.main()
