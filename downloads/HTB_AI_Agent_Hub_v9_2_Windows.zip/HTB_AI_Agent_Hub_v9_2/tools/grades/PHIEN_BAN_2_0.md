# HTB AI Agent v2.0 — Bé Bi trợ lý AI

Thêm Trò chuyện Bé Bi vào menu, hỏi đáp Gemini/OpenAI, đọc tài liệu, tìm web, lịch sử tùy chọn trên máy, điều hướng chức năng, chuyển bản thảo, xuất Word/chat và đọc câu trả lời bằng giọng Windows.
Dùng chung khóa API với Agent Báo cáo & Kế hoạch. Không tự gọi API khi mở ứng dụng.
Mở CHAY_HTB_AI_AGENT.bat → Trò chuyện Bé Bi → Kết nối AI.
Hướng dẫn: HUONG_DAN_BE_BI.md.

Kiểm thử: 106 ca unittest, 105 đạt, 1 bỏ qua. Kiểm tra cú pháp đạt.
Chưa chạy thử trực tiếp giao diện v2.0, giọng Windows hoặc API/VietSchool thật.
