# HTB v2.3.0 — Tự nhập và kiểm tra sau lưu

Mỗi vùng nhập được tự lưu, xác minh chữ xanh/giá trị, tải lại trang, mở lại đúng phạm vi và đọc hai lần. Chỉ đánh dấu hoàn tất khi đúng tên, ngày sinh, STT, cột và điểm sau tải lại. Các con trỏ ô cũ được bỏ; vùng tiếp theo được gắn lại trên bảng mới. Không cần chạy riêng tab Đối chiếu cho phần vừa nhập.

Báo cáo ghi original, value, actual, verification và reason. Sai/thiếu điểm hoặc không kiểm tra được sẽ dừng, không dán lại hay ghi đè tự động. Giữ tự đăng nhập, bỏ tên không khớp, nghỉ/khóa và tự chuyển lớp.

Kiểm tra: 152 unittest, 151 đạt, một bỏ qua do chưa có Chromium. Kiểm tra mô phỏng đúng sau tải lại, điểm mất/sai, thay đổi tên/ngày sinh/STT, mất mạng, hai lần đọc không ổn định, hai vùng có học sinh nghỉ, gắn lại ô và không chuyển lớp khi xác minh thất bại đều đạt. Mô phỏng DOM/Progrid hiện có đạt. Chưa đăng nhập hoặc ghi điểm VietSchool thực tế.
