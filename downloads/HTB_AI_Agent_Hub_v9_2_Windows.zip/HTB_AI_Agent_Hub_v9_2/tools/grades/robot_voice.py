"""Optional Windows SAPI speech, no external requests or shell interpolation."""
import os
import subprocess
import tempfile
from pathlib import Path

SCRIPT = '''param([string]$TextPath)
$ErrorActionPreference = "Stop"
$voice = New-Object -ComObject SAPI.SpVoice
$voice.Rate = -1
$voice.Volume = 90
foreach ($token in $voice.GetVoices()) {
    if ($token.GetAttribute("Language") -match "(?i)(^|;)42a(;|$)") {
        $voice.Voice = $token
        break
    }
}
$text = [System.IO.File]::ReadAllText($TextPath, [System.Text.Encoding]::UTF8)
[void]$voice.Speak($text)
'''

def start_speech(text):
    if os.name != 'nt':raise RuntimeError('Đọc giọng hệ thống hiện hỗ trợ Windows.')
    directory=tempfile.TemporaryDirectory(prefix='be_bi_giong_')
    root=Path(directory.name)
    script=root/'read.ps1';content=root/'text.txt'
    script.write_text(SCRIPT,encoding='utf-8-sig')
    content.write_text(text[:20000],encoding='utf-8-sig')
    try:
        process=subprocess.Popen(['powershell.exe','-NoProfile','-NonInteractive','-STA','-ExecutionPolicy','Bypass',
                                  '-File',str(script),'-TextPath',str(content)],
                                 stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                                 creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        return process,directory
    except OSError:
        directory.cleanup()
        raise RuntimeError('Không khởi động được giọng Windows. Kiểm tra PowerShell và giọng đã cài.') from None
