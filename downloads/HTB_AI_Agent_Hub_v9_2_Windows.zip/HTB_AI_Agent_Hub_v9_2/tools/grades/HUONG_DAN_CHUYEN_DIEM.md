# Chuyển nhiều file Excel điểm vào mẫu — HTB v2.4.0

1. Giải nén và chạy CHAY_HTB_AI_AGENT.bat. Mở menu Chuyển điểm vào mẫu bên trái.
2. Bấm Thêm nhiều file Excel. Trong hộp chọn file Windows, giữ Ctrl/Shift để chọn nhiều file .xlsx; có thể bấm Thêm nhiều lần. File .xls cũ cần lưu lại thành .xlsx trước.
3. Chọn từng file trong bảng. Kiểm tra Môn (có thể tự gõ/sửa) và Cột điểm nguồn, rồi Áp dụng cho file chọn. Tin/CNNN/CNCN được gợi ý môn từ tên file; không chắc thì để trống để chọn. Nếu file có nhiều cột điểm, phải chọn cột cần lấy.
4. Chọn năm học, học kỳ và cột đích áp dụng cho lần chuyển. Nhập Lớp nếu nguồn thiếu chỉ khi file không có lớp. Với các file có sẵn cột Lớp, công cụ giữ lớp nguồn. Mặc định 2026-2027 / HK1 / Giữa kỳ là lựa chọn ban đầu; cần kiểm tra trước khi xuất.
5. Dùng mẫu VietSchool trống có sẵn hoặc Chọn mẫu trống .xlsx khác. Mẫu cần Họ và tên, Lớp, Môn học, Học kỳ, Năm học và cột đích TX1–TX6/Giữa kỳ/Cuối kỳ. Mẫu đã có danh sách học sinh sẽ bị chặn để không thay thế dữ liệu.
6. Bấm Xem trước: kiểm tra họ tên ghép từ Họ + Tên, lớp, môn, điểm và các dòng không xuất.
7. Bấm Xuất file mẫu và chọn tên lưu mới. Công cụ không ghi đè nguồn/mẫu. File xuất gồm NHAP_DIEM, NGUON_DIEM (nguồn từng dòng) và CAN_KIEM_TRA (các dòng không xuất). Tab ví dụ được loại khỏi file xuất để không bị nhập điểm minh họa.
8. Sau khi kiểm tra file, bấm Dùng file xuất để nhập điểm. Ứng dụng chỉ chuyển đến tab Nhập điểm và chọn file; thầy bấm Bắt đầu nhập điểm để chạy.

Quy tắc:
- Chỉ đọc nguồn, không sửa file gốc. Giữ giá trị nguồn đến hai chữ số thập phân, không tự làm tròn trong bước chuyển mẫu. Khi nhập lên VietSchool vẫn áp dụng quy tắc một chữ số của công cụ nhập.
- Điểm TN là trắc nghiệm: công cụ không tự cộng với tự luận hoặc tự biến thành điểm tổng. Dùng mục Cộng điểm TL + TN trước nếu cần cộng, rồi chuyển file kết quả.
- Năm học/học kỳ/cột đích chọn trên màn hình áp dụng cho toàn bộ lần chuyển, kể cả khi nguồn có cột năm học/học kỳ.
- Thiếu tên/lớp/môn, điểm trống/sai, học sinh nghỉ và nhóm trùng họ tên + lớp + môn + học kỳ + cột đều không xuất; tất cả ghi trong CAN_KIEM_TRA. Không tự chọn một điểm khi trùng/mâu thuẫn.
- Giữ ngoại lệ bỏ qua Trần Ngọc Khánh lớp 12A06 theo yêu cầu trước.
- Chưa hỗ trợ file PDF, Excel có mật khẩu hoặc tự phân tích bảng chỉ là hình ảnh.

Kiểm tra với ba file nguồn người dùng đã gửi: 622 dòng, 620 hợp lệ; hai Trần Ngọc Khánh lớp 12A06 được bỏ qua. Mẫu thử đọc lại được 17 nhóm và 620 ô bằng bộ nhập VietSchool, không lấy trùng dữ liệu từ tab ghi nguồn/báo cáo. Đây là kiểm tra chuyển đổi tệp, không phải ghi điểm lên VietSchool.
