"""Excel preflight and header resolution independent of Tk / Chrome."""
import re
from collections import defaultdict
from skip_policy import requested_skip
from openpyxl import load_workbook
from base_agent import ALIASES, COLS, grade_string, rating_mode, normalize_subject


def key(value):
    return normalize_subject(value)


def subject_aliases(subject):
    x=key(subject)
    groups=[['GDĐP','GDDP','Giáo dục địa phương'], ['GDTC','Giáo dục thể chất'],
            ['HĐTN HN','HĐTN-HN','HĐTN3','HĐTN','Hoạt động trải nghiệm hướng nghiệp'],
            ['Ngoại ngữ','Tiếng Anh','Anh văn'],['GD QP-AN','GDQP AN','Giáo dục quốc phòng an ninh']]
    for group in groups:
        if x in {key(a) for a in group}:return group
    return [subject]


def term_label(value):
    x=key(value)
    if x in ('hk1','hk 1','hoc ky 1','hoc ki 1','1'):return 'Học kỳ 1'
    if x in ('hk2','hk 2','hoc ky 2','hoc ki 2','2'):return 'Học kỳ 2'
    raise ValueError(f'Học kỳ không hợp lệ: {value!r}')


def read_jobs(path):
    wb=load_workbook(path,data_only=True,read_only=True)
    groups=defaultdict(list)
    aliases={k:{key(a) for a in v} for k,v in ALIASES.items()}
    aliases['status']={key(x) for x in ['Trạng thái','Tình trạng','Nghỉ học','Đã nghỉ','Status']}
    aliases['dob']={key(x) for x in ['Ngày sinh','Ngày tháng năm sinh']}
    try:
        for ws in wb:
            header=None; start=None
            for n,row in enumerate(ws.iter_rows(max_row=20,max_col=100,values_only=True),1):
                vals=[key(v) for v in row]
                found={k:next(i for i,v in enumerate(vals) if v in variants) for k,variants in aliases.items() if any(v in variants for v in vals)}
                if ('name' in found or {'ho','ten'}<=found.keys()) and {'class','subject','term','year'}<=found.keys():
                    header=found;start=n;break
            if not header:continue
            def get(row,k):
                i=header.get(k)
                return row[i] if i is not None and i<len(row) else None
            for n,row in enumerate(ws.iter_rows(min_row=start+1,max_col=max(header.values())+1,values_only=True),start+1):
                name=str(get(row,'name') or '').strip() or ' '.join(str(get(row,k) or '').strip() for k in ('ho','ten')).strip()
                if not name:continue
                inactive=inactive_excel(get(row,'status'))
                grades={c:None if inactive else get(row,c) for c in COLS}
                scope=[str(get(row,k) or '').strip() for k in ('year','class','subject','term')]
                if not all(scope):raise ValueError(f'{ws.title}, dòng {n}: thiếu năm học/lớp/môn/học kỳ.')
                scope[0]=scope[0].replace('–','-').replace('—','-').replace(' ','')
                if not re.fullmatch(r'\d{4}-\d{4}',scope[0]):raise ValueError(f'Dòng {n}: năm học phải có dạng 2026-2027.')
                scope[3]=term_label(scope[3]); subject=scope[2]
                mode=rating_mode(subject_aliases(subject)[-1])
                for c in COLS:
                    try:grades[c]=grade_string(grades[c],mode)
                    except ValueError as e:raise ValueError(f'{ws.title}, dòng {n}, {name}, {c}: {e}') from e
                groups[tuple(scope)].append({'student':name,'row':n,'sheet':ws.title,'dob':str(get(row,'dob') or ''),'inactive':inactive,**grades})
                if sum(map(len,groups.values()))>20000:raise ValueError('File quá 20.000 dòng có điểm. Hãy tách file.')
    finally:wb.close()
    jobs=[]
    for scope,rows in groups.items():
        grade_from_class(scope[1])
        if len(rows)>70:raise ValueError(f'{scope}: quá 70 học sinh hoặc trùng dữ liệu nhiều sheet.')
        names=[key(r['student']) for r in rows if not requested_skip(scope[1],r['student'])]
        if len(names)!=len(set(names)):raise ValueError(f'{scope}: trùng tên học sinh; cần phân biệt trước khi tự nhập.')
        for col in COLS:
            if any(r[col] is not None for r in rows):jobs.append({'year':scope[0],'class':scope[1],'subject':scope[2],'term':scope[3],'column':col,'rows':rows})
    if not jobs:raise ValueError('Không có điểm để nhập. File cần Họ và tên, Lớp, Môn học, Học kỳ, Năm học và ít nhất một cột TX1–TX6/Giữa kỳ/Cuối kỳ.')
    return jobs


def expand_headers(raw):
    matrix=[]
    for y,row in enumerate(raw):
        while len(matrix)<=y:matrix.append([])
        x=0
        for cell in row:
            while x<len(matrix[y]) and matrix[y][x] is not None:x+=1
            rs=max(1,int(cell.get('rowspan',1)));cs=max(1,int(cell.get('colspan',1)))
            if rs>10 or cs>50:raise ValueError('Tiêu đề bảng có ô gộp không hợp lệ.')
            for dy in range(rs):
                while len(matrix)<=y+dy:matrix.append([])
                while len(matrix[y+dy])<x+cs:matrix[y+dy].append(None)
                for dx in range(cs):matrix[y+dy][x+dx]=cell['text']
            x+=cs
    width=max((len(r) for r in matrix),default=0)
    return [' '.join(dict.fromkeys(r[i] for r in matrix if i<len(r) and r[i])) for i in range(width)]


def column_index(paths,column):
    result=[]
    for i,path in enumerate(paths):
        if i<4:continue
        p=key(path)
        if column.startswith('TX'):
            number=column[2:]
            match=bool(re.search(r'(?:dgtx|diem dgtx|tx|thuong xuyen)\s*'+number+r'\b',p))
        elif column=='Giữa kỳ':match=bool(re.search(r'\b(?:dggk|dgk|dg gk|gk|giua ky|giua ki)\b',p))
        else:match=bool(re.search(r'\b(?:dgck|dck|dg ck|ck|cuoi ky|cuoi ki)\b',p))
        if match:result.append(i)
    if len(result)!=1:raise ValueError(f'Không xác định duy nhất cột {column} từ tiêu đề web: {paths}. Không nhập phỏng đoán.')
    return result[0]


def confirm_is_paste(message):
    # Auto-accept only the expected paste confirmation while a checked range is active.
    m=key(message)
    if any(w in m for w in ('xoa','delete','khoa so','dong so')):return False
    return bool(re.search(r'\b(?:dan|paste)\b',m))


def grade_from_class(clazz):
    label=re.sub(r'^lop\s+', '', key(clazz))
    found=re.match(r'^(10|11|12)(?=\D|$)',label)
    if not found:raise ValueError(f'Không suy ra được khối 10/11/12 từ lớp {clazz!r}.')
    return 'Khối '+found.group(1)


def grade_batch_state(rows,run,index):
    """A transient redraw or clipped column is pending verification, never IndexError."""
    lookup={r['stt']:r for r in rows}
    values_ok=True;saved=True
    if not isinstance(index,int) or index<4:return {'values_ok':False,'saved':False}
    for expected in run:
        actual=lookup.get(expected['stt'])
        if not actual or (actual.get('name'),actual.get('dob'))!=(expected['name'],expected['dob']):
            return {'values_ok':False,'saved':False}
        cells=actual.get('cells') or [];colors=actual.get('saved') or []
        if index>=len(cells):return {'values_ok':False,'saved':False}
        left=str(cells[index]).strip();right=str(expected['value']).strip()
        equal=left==right
        if not equal:
            try:equal=float(left.replace(',','.'))==float(right.replace(',','.'))
            except ValueError:equal=False
        values_ok=values_ok and equal
        saved=saved and index<len(colors) and bool(colors[index])
    return {'values_ok':bool(run) and values_ok,'saved':bool(run) and values_ok and saved}


def inactive_excel(value):
    if value is True:return True
    return key(value) in {'nghi','nghi hoc','da nghi','da nghi hoc','thoi hoc','chuyen truong','chuyen di','inactive','withdrawn'}
