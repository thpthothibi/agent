import queue
import threading
import unittest
from unittest.mock import Mock
from full_auto import AutoWorker


class AutoLoginTests(unittest.TestCase):
    def make(self,captcha=False):
        worker=AutoWorker('',queue.Queue(),threading.Event())
        worker.credentials=('demo-account','demo-secret')
        page=Mock();page.url='https://nhapdiem.truonghocviet.vn/Account/Login'
        password=Mock();form=Mock();form.count.return_value=1
        password.locator.return_value=form
        passwords=Mock();passwords.count.return_value=1;passwords.nth.return_value=password
        page.locator.return_value=passwords
        user=Mock();users=Mock();users.count.return_value=1;users.nth.return_value=user
        challenge=Mock();challenge.count.return_value=int(captcha)
        form.locator.side_effect=lambda selector:challenge if 'captcha' in selector else users
        button=Mock();button.is_visible.return_value=True
        buttons=Mock();buttons.count.return_value=1;buttons.nth.return_value=button
        form.get_by_role.return_value=buttons
        return worker,page,user,password,button

    def test_fills_and_submits_once(self):
        w,p,u,pw,b=self.make()
        self.assertEqual(w.submit_login(p),'submitted')
        u.fill.assert_called_once_with('demo-account',timeout=4000)
        pw.fill.assert_called_once_with('demo-secret',timeout=4000)
        b.click.assert_called_once()
        self.assertIsNone(w.credentials)
        self.assertEqual(w.submit_login(p),'manual')
        b.click.assert_called_once()

    def test_never_submits_to_other_hosts_or_plain_http(self):
        for url in ['https://example.com/login','http://nhapdiem.truonghocviet.vn/login','https://nhapdiem.truonghocviet.vn.example.com/login']:
            w,p,u,pw,b=self.make();p.url=url
            self.assertEqual(w.submit_login(p),'manual')
            u.fill.assert_not_called();pw.fill.assert_not_called();b.click.assert_not_called()

    def test_captcha_waits_for_user(self):
        w,p,u,pw,b=self.make(captcha=True)
        self.assertEqual(w.submit_login(p),'manual')
        b.click.assert_not_called()
        self.assertIsNone(w.credentials)

    def test_failed_fill_does_not_log_credentials(self):
        w,p,u,pw,b=self.make()
        pw.fill.side_effect=RuntimeError('demo-secret')
        self.assertEqual(w.submit_login(p),'manual')
        while not w.events.empty():
            self.assertNotIn('demo-secret',str(w.events.get()))
        b.click.assert_not_called();self.assertIsNone(w.credentials)

    def test_ambiguous_form_does_not_guess_username(self):
        w,p,u,pw,b=self.make();p.locator.return_value.count.return_value=2
        self.assertEqual(w.submit_login(p),'wait')
        u.fill.assert_not_called();pw.fill.assert_not_called();b.click.assert_not_called()


if __name__=='__main__':unittest.main()
