"""Pure, fail-closed mapping; never use STT Excel as a student's identity."""
from collections import Counter
from skip_policy import requested_skip, SKIP_STATUS, SKIP_REASON
from chrome_bridge import normalize_name
from base_agent import grade_string, rating_mode, vietschool_value


def build_plan(excel, site, column, subject, requested='Tự động', index=None, clazz=None):
    if not excel or not site:
        raise ValueError('Chưa đọc được danh sách Excel hoặc VietSchool.')
    if len(excel)>70 or len(site)>70:
        raise ValueError('Danh sách quá 70 học sinh; kiểm tra lại lớp.')
    for label, rows, key in [('Excel', excel, 'student'), ('VietSchool', site, 'name')]:
        counts=Counter(normalize_name(r.get(key)) for r in rows if not requested_skip(clazz,r.get(key)))
        duplicate=[n for n,c in counts.items() if c>1 or not n]
        if duplicate:
            raise ValueError(f'{label}: tên trống/trùng tên ({", ".join(duplicate)}). Cần phân biệt bằng mã học sinh/ngày sinh; không tự ghép.')
    # Match unique normalized full names only. Unmatched rows on either side
    # are audit-only gaps and can never enter the clipboard.
    source={normalize_name(r['student']):r for r in excel if not requested_skip(clazz,r['student'])}
    target={normalize_name(r['name']):r for r in site}
    ordered=sorted(site,key=lambda r:r['stt'])
    if [r['stt'] for r in ordered]!=list(range(1,len(ordered)+1)):
        raise ValueError('Chưa đọc đủ STT liên tục từ 1 đến cuối lớp. Không dán.')
    mode=rating_mode(subject,requested); plan=[]
    for row in ordered:
        if requested_skip(clazz,row['name']):
            cells=row.get('cells',[])
            old=str(cells[index]).strip() if index is not None and 0<=index<len(cells) else ''
            plan.append({'stt':row['stt'],'name':row['name'],'dob':row.get('dob',''),
                         'row':'','value':None,'original':None,'old':old,'status':SKIP_STATUS,'reason':SKIP_REASON})
            continue
        src=source.get(normalize_name(row['name']))
        inactive=row.get('inactive',False) or bool(src and src.get('inactive'))
        original=None if inactive or not src else grade_string(src[column],mode)
        value=vietschool_value(original,mode)
        old=''
        # Withdrawn rows may omit or merge score cells. Skip them before
        # accessing any target column, while keeping their web STT as a gap.
        if index is not None and not inactive and src is not None:
            if index<4 or index>=len(row['cells']):raise ValueError('Cột đã chọn không phải ô điểm hợp lệ.')
            old=str(row['cells'][index]).strip()
        locks=row.get('locks') or []
        locked=not inactive and index is not None and index<len(locks) and bool(locks[index])
        status='Bỏ qua: không có trong Excel' if src is None and not inactive else ('Bỏ qua: học sinh nghỉ' if inactive else ('Bỏ qua: ô bị khóa' if locked else ('Bỏ qua: Excel trống' if value is None else ('Bỏ qua: web đã có điểm' if old else 'Sẽ dán'))))
        plan.append({'stt':row['stt'],'name':row['name'],'dob':row.get('dob',''), 'row':src['row'] if src else '', 'value':value,'original':original,'old':old,'status':status,'reason':('Không có dữ liệu nguồn; giữ nguyên ô web, không dán và không kết luận học sinh nghỉ' if src is None and not inactive else (row.get('inactiveReason','') if row.get('inactive') else ('Đánh dấu nghỉ trong Excel' if inactive else '')))})
    for name,src in source.items():
        if name in target:continue
        plan.append({'stt':'','name':src['student'],'dob':src.get('dob',''),
                     'row':src.get('row',''),'value':None,'original':src.get(column),'old':'',
                     'status':'Bỏ qua: không tìm thấy tên trên web',
                     'reason':'Không ghép gần đúng hoặc dùng STT Excel thay tên; tiếp tục các tên khớp'})
    return plan


def paste_runs(plan):
    runs=[]
    for r in plan:
        if r['status']!='Sẽ dán':continue
        if not runs or runs[-1][-1]['stt']+1!=r['stt']:runs.append([])
        runs[-1].append(r)
    return runs
