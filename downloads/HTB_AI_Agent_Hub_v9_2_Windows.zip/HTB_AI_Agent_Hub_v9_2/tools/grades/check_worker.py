"""Read-only checker using the established v3.6 navigation and DOM reader."""
import datetime
import json
import time
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from full_auto import AutoWorker, Cancelled
from auto_core import read_jobs
from compare_core import compare_rows, summary, UNCHECKED

class CheckWorker(AutoWorker):
    def __init__(self,*args):
        super().__init__(*args)
        self.jobs=[]; self.finished=set()

    def check(self):
        if self.cancel.is_set():raise Cancelled('Đã dừng đối chiếu. Báo cáo giữ kết quả đã đọc; các nhóm còn lại ghi chưa kiểm tra được.')

    def paste(self,*args,**kwargs):
        raise RuntimeError('Chế độ đối chiếu không cho phép dán điểm')

    def dom(self,f,op,**args):
        allowed={'busy','snapshot','snapshot_all','headers','scroll_init','scroll','restore',
                 'reset_grid_view','reset_horizontal','year','select','target','diagnostic'}
        if op not in allowed:raise RuntimeError('Chặn thao tác ngoài chế độ đọc: '+op)
        return super().dom(f,op,**args)

    def configure_subjects(self,jobs):
        self.jobs=jobs
        super().configure_subjects(jobs)

    def login_and_open(self):
        # Fresh page before reading: old UI values from a prior paste are not reused.
        self.emit('Đang tải lại VietSchool để đọc điểm đã lưu...')
        self.page().reload(wait_until='domcontentloaded',timeout=30000)
        super().login_and_open()

    def process_job(self,job,n,total):
        self.check()
        self.emit(f'[{n}/{total}] Đối chiếu {job["class"]} / {job["subject"]} / {job["column"]}')
        try:
            assessment='ĐGTX'
            self.navigate(job,assessment);self.prepare_grid()
            f,_=self.grid()
            try:index=self.headers(f,job)
            except ValueError:
                if job['column'] not in ('Giữa kỳ','Cuối kỳ'):raise
                assessment='Thi';self.navigate(job,assessment);self.prepare_grid()
                f,_=self.grid();index=self.headers(f,job)
            self.scope_is_selected(job,assessment)
            # Without expected names, collect scans all scroll regions instead of early stopping.
            first=self.collect(f)
            self.tick(self.page(),400)
            second=self.collect(f)
            self.scope_is_selected(job,assessment)
            if index!=self.headers(f,job):raise RuntimeError('Tiêu đề cột thay đổi trong khi đọc')
            def signature(rows):
                return [(r['stt'],r['name'],r.get('dob'),r.get('inactive'),tuple(r.get('cells',[]))) for r in rows]
            if signature(first)!=signature(second):
                raise RuntimeError('Bảng chưa ổn định qua hai lần đọc; chưa kết luận điểm')
            stts=[r['stt'] for r in second]
            if not stts or stts!=list(range(1,len(stts)+1)) or len(stts)>70:
                raise RuntimeError('Danh sách web trống/không liên tục hoặc vượt 70 học sinh')
            results=compare_rows(job,second,index)
        except Cancelled:raise
        except Exception as exc:
            try:
                diagnostic={'stage':self.stage,'error':str(exc).split('Call log:')[0],
                            'frames':[self.dom(frame,'diagnostic') for frame in self.frames()]}
                Path(__file__).with_name('chan_doan_giao_dien.json').write_text(json.dumps(diagnostic,ensure_ascii=False,indent=2),encoding='utf-8')
            except Exception:pass
            results=self.unchecked(job,str(exc).split('Call log:')[0])
        self.audit.extend(results);self.finished.add(n-1)
        self.total=sum(r['result']=='Đúng' for r in self.audit)
        self.events.put(('comparison',{'scope':f'{job["class"]} / {job["subject"]} / {job["column"]}','rows':results}))
        self.emit(summary(self.audit))

    def unchecked(self,job,reason):
        return [{**{k:job[k] for k in ('year','class','subject','term','column')},
                 'sheet':r.get('sheet',''),'row':r['row'],'name':r['student'],
                 'expected':r[job['column']],'actual':'','result':UNCHECKED,'reason':reason} for r in job['rows']]

    def completion_message(self,jobs):
        return 'Đã kết thúc đối chiếu. '+summary(self.audit)+' Chỉ đọc qua giao diện sau khi tải lại, không phải truy vấn trực tiếp cơ sở dữ liệu.'

    def report(self,result):
        for i,job in enumerate(self.jobs):
            if i not in self.finished:
                self.audit.extend(self.unchecked(job,'Chương trình dừng trước khi kiểm tra xong nhóm này'))
                self.finished.add(i)
        folder=Path(__file__).resolve().parent/'bao_cao';folder.mkdir(exist_ok=True)
        path=folder/('doi_chieu_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.xlsx')
        wb=Workbook();overview=wb.active;overview.title='Tong_hop'
        overview.append(['Nội dung','Kết quả'])
        overview.append(['Trạng thái chạy',result])
        overview.append(['Kết quả',summary(self.audit)])
        overview.append(['Phạm vi','Chỉ cột có ít nhất một điểm Excel; ô nguồn trống không kết luận.'])
        overview.append(['Nguồn đọc','Giao diện VietSchool sau tải lại; không truy vấn API/cơ sở dữ liệu.'])
        fields=[('year','Năm học'),('class','Lớp'),('subject','Môn'),('term','Học kỳ'),('column','Cột điểm'),
                ('sheet','Sheet Excel'),('row','Dòng Excel'),('stt','STT web'),('name','Họ tên'),
                ('dob','Ngày sinh Excel'),('expected','Điểm Excel'),('actual','Điểm VietSchool'),
                ('result','Kết quả'),('reason','Chi tiết')]
        for title,rows in [('Tat_ca',self.audit),('Can_kiem_tra',[r for r in self.audit if r['result']!='Đúng'])]:
            ws=wb.create_sheet(title);ws.append([label for _,label in fields])
            for r in rows:
                values=[]
                for k,_ in fields:
                    v=r.get(k,'')
                    if isinstance(v,str) and v.startswith(('=','+','-','@')):v="'"+v
                    values.append(v)
                ws.append(values)
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width=min(60,max(15,max(len(str(c.value or '')) for c in col)+2))
            for cell in ws[1]:
                cell.font=Font(color='FFFFFF',bold=True);cell.fill=PatternFill('solid',fgColor='075497')
        overview.column_dimensions['A'].width=25;overview.column_dimensions['B'].width=110
        wb.save(path)
        return str(path)
