# -*- coding: utf-8 -*-
"""VietSchool Excel -> Chrome, phiên bản an toàn bán tự động.
Không truy cập tài khoản, không gọi API riêng, không tự xác nhận hộp thoại lưu.
"""
import csv
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import datetime as dt
import os
import queue
import re
import threading
import unicodedata
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from openpyxl import load_workbook
    import pyperclip
except ImportError as exc:
    raise SystemExit('Thiếu thư viện. Chạy: python -m pip install -r requirements.txt') from exc

COLS = ['TX1', 'TX2', 'TX3', 'TX4', 'TX5', 'TX6', 'Giữa kỳ', 'Cuối kỳ']
ALIASES = {
    'name': ['Họ và tên', 'Họ tên', 'Họ và tên học sinh', 'Tên học sinh'],
    'ho': ['Họ', 'Họ đệm'], 'ten': ['Tên'],
    'class': ['Lớp', 'Lớp học'], 'subject': ['Môn học', 'Môn'],
    'term': ['Học kỳ', 'Kỳ'], 'year': ['Năm học'],
    'stt': ['STT', 'Số thứ tự'],
    'TX1': ['TX1', 'ĐGTX1', 'Thường xuyên 1', 'Điểm TX1'],
    'TX2': ['TX2', 'ĐGTX2', 'Thường xuyên 2', 'Điểm TX2'],
    'TX3': ['TX3', 'ĐGTX3', 'Thường xuyên 3', 'Điểm TX3'],
    'TX4': ['TX4', 'ĐGTX4', 'Thường xuyên 4', 'Điểm TX4'],
    'TX5': ['TX5', 'ĐGTX5'], 'TX6': ['TX6', 'ĐGTX6'],
    'Giữa kỳ': ['Giữa kỳ', 'Giữa kì', 'ĐGGK', 'GK', 'Giữa HK'],
    'Cuối kỳ': ['Cuối kỳ', 'Cuối kì', 'ĐGCK', 'CK', 'Cuối HK'],
}

def norm(x):
    return re.sub(r'\s+', ' ', str(x or '').strip()).casefold()

def txt(x):
    return str(x).strip() if x is not None else ''

# Các môn đánh giá bằng nhận xét. Tên có dấu, không dấu và viết tắt đều được nhận diện.
# Không suy ra chế độ từ dữ liệu điểm để tránh âm thầm sửa quy tắc đánh giá.
COMMENT_SUBJECT_KEYS = {
    'gddp', 'giao duc dia phuong',
    'gdtc', 'giao duc the chat',
    'hdtn hn', 'hdtnhn', 'hoat dong trai nghiem huong nghiep',
    'hd trai nghiem huong nghiep', 'hoat dong trai nghiem, huong nghiep',
}


def normalize_subject(s):
    x = unicodedata.normalize('NFD', str(s or '').casefold().strip())
    x = ''.join(c for c in x if unicodedata.category(c) != 'Mn').replace('đ', 'd')
    x = re.sub(r'[^a-z0-9]+', ' ', x).strip()
    return ' '.join(x.split())


def rating_mode(subject, requested='Tự động'):
    if requested == 'Nhận xét (Đ/CĐ)':
        return 'comment'
    if requested == 'Điểm số (0–10)':
        return 'score'
    return 'comment' if normalize_subject(subject) in COMMENT_SUBJECT_KEYS else 'score'


def grade_string(v, mode='score'):
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    if isinstance(v, bool):
        raise ValueError('Giá trị kiểu đúng/sai (boolean) không hợp lệ')
    if mode == 'comment':
        # Luôn giữ đúng ký hiệu tiếng Việt VietSchool: Đ hoặc CĐ.
        raw = re.sub(r'\s+', ' ', str(v).strip()).upper()
        equivalent = {'Đ': 'Đ', 'CĐ': 'CĐ', 'ĐẠT': 'Đ', 'CHƯA ĐẠT': 'CĐ'}
        if raw not in equivalent:
            raise ValueError(f'Nhận xét {v!r} không hợp lệ; chỉ nhận Đ hoặc CĐ (có thể nhập Đạt/Chưa đạt)')
        return equivalent[raw]
    if mode != 'score':
        raise ValueError(f'Chế độ đánh giá không được hỗ trợ: {mode!r}')
    try:
        n = Decimal(str(v).strip().replace(',', '.'))
        if not n.is_finite() or not Decimal('0') <= n <= Decimal('10'):
            raise ValueError('Ngoài khoảng 0–10')
        # Compare exact decimal values: do not round an Excel grade silently.
        if n != n.quantize(Decimal('0.01')):
            raise ValueError('Quá hai chữ số thập phân')
    except (InvalidOperation, ValueError, OverflowError) as exc:
        raise ValueError(f'Điểm {v!r} không hợp lệ, phải nằm trong 0–10 (tối đa 2 chữ số thập phân; không tự làm tròn)') from exc
    if n == 0:
        return '0'
    return format(n, 'f').rstrip('0').rstrip('.') if '.' in format(n, 'f') else format(n, 'f')

def vietschool_value(value, mode='score'):
    """Normalize a validated source to VietSchool's displayed one-decimal score."""
    original=grade_string(value,mode)
    if original is None or mode=='comment':return original
    rounded=Decimal(original).quantize(Decimal('0.1'),rounding=ROUND_HALF_UP)
    return grade_string(rounded,mode)


class Agent:
    def __init__(self, root):
        self.root=root; root.title('VIETSCHOOL · AGENT NHẬP ĐIỂM v2.2'); root.geometry('900x715'); root.minsize(780,620)
        self.path=''; self.wb=None; self.records=[]; self.header={}; self.preview_payload=''; self.preview_rows=[]
        self.sheet=tk.StringVar(); self.clazz=tk.StringVar(); self.subject=tk.StringVar(); self.term=tk.StringVar(); self.year=tk.StringVar(); self.col=tk.StringVar(value='Giữa kỳ')
        self.rating=tk.StringVar(value='Tự động'); self.mode_info=tk.StringVar(value=''); self.delay=tk.IntVar(value=7); self.armed=False; self.countdown_var=tk.StringVar(value='Chưa chuẩn bị'); self.after_id=None
        root.configure(bg='#f1f5fb')
        style=ttk.Style(root); style.theme_use('clam')
        style.configure('Title.TLabel',font=('Segoe UI',17,'bold'),foreground='#0c4e95',background='#f1f5fb')
        style.configure('Body.TLabel',font=('Segoe UI',10),background='#f1f5fb')
        style.configure('TButton',font=('Segoe UI',10),padding=7)
        wrap=ttk.Frame(root,padding=18); wrap.pack(fill='both',expand=True)
        ttk.Label(wrap,text='AGENT NHẬP ĐIỂM VIETSCHOOL',style='Title.TLabel').pack(anchor='w')
        ttk.Label(wrap,text='Đọc Excel · dò đúng họ tên · bỏ qua học sinh nghỉ · tự dán theo cột đã chọn',style='Body.TLabel').pack(anchor='w',pady=(0,14))
        filebar=ttk.Frame(wrap); filebar.pack(fill='x',pady=2)
        ttk.Button(filebar,text='1  CHỌN FILE EXCEL',command=self.choose_file).pack(side='left')
        self.filelbl=ttk.Label(filebar,text='Chưa chọn file'); self.filelbl.pack(side='left',padx=10)
        opts=ttk.LabelFrame(wrap,text='2  CHỌN PHẠM VI NHẬP',padding=10); opts.pack(fill='x',pady=10)
        vals=[('Sheet',self.sheet),('Lớp',self.clazz),('Môn',self.subject),('Học kỳ',self.term),('Năm học',self.year),('Cột điểm',self.col)]
        self.boxes={}
        for i,(name,var) in enumerate(vals):
            cell=ttk.Frame(opts); cell.grid(row=i//3,column=i%3,sticky='ew',padx=5,pady=5)
            ttk.Label(cell,text=name).pack(anchor='w')
            cb=ttk.Combobox(cell,textvariable=var,state='readonly',width=24,values=COLS if name=='Cột điểm' else [])
            cb.pack(fill='x',pady=4); cb.bind('<<ComboboxSelected>>',self.refresh)
            self.boxes[name]=cb
        for c in range(3): opts.columnconfigure(c,weight=1)
        mode_bar=ttk.Frame(opts);mode_bar.grid(row=2,column=0,columnspan=3,sticky='ew',padx=5,pady=(5,2))
        ttk.Label(mode_bar,text='Chế độ đánh giá:').pack(side='left',padx=(0,8))
        mode_cb=ttk.Combobox(mode_bar,textvariable=self.rating,state='readonly',width=23,
                             values=['Tự động','Điểm số (0–10)','Nhận xét (Đ/CĐ)'])
        mode_cb.pack(side='left'); mode_cb.bind('<<ComboboxSelected>>', lambda _event: self.preview())
        ttk.Label(mode_bar,textvariable=self.mode_info,foreground='#075985').pack(side='left',padx=12)
        self.state=ttk.Label(wrap,text='Chưa có dữ liệu để kiểm tra',foreground='#475569'); self.state.pack(anchor='w',pady=(5,8))
        preview=ttk.LabelFrame(wrap,text='DANH SÁCH EXCEL / KẾT QUẢ DÒ TÊN',padding=7); preview.pack(fill='both',expand=True)
        cols=['row','stt','student','grade']; table=ttk.Treeview(preview,columns=cols,show='headings',height=10)
        for key,name,width in [('row','Dòng Excel',95),('stt','STT',60),('student','Họ và tên',340),('grade','Điểm',100)]:
            table.heading(key,text=name);table.column(key,width=width,anchor='w' if key=='student' else 'center')
        scroll=ttk.Scrollbar(preview,orient='vertical',command=table.yview);table.configure(yscrollcommand=scroll.set)
        table.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y'); self.table=table
        act=ttk.Frame(wrap);act.pack(fill='x',pady=(12,8))
        ttk.Button(act,text='4  KIỂM TRA & SAO CHÉP CỘT',command=self.prepare).pack(side='left',padx=(0,6))
        ttk.Button(act,text='5  DÁN VÀO CHROME (ĐẾM NGƯỢC)',command=self.start_paste).pack(side='left',padx=6)
        ttk.Button(act,text='DỪNG',command=self.cancel).pack(side='left',padx=6)
        ttk.Label(act,textvariable=self.countdown_var,foreground='#2563eb').pack(side='right')
        caution=('QUAN TRỌNG: Sắp xếp học sinh trong Excel PHẢI trùng thứ tự VietSchool. '
                 'Chỉ dán vào các ô trống và đúng cột. Agent KHÔNG tự xác nhận hộp thoại OK, '
                 'KHÔNG xác minh điểm đã lưu. Bạn phải kiểm tra lại trên VietSchool.')
        ttk.Label(wrap,text=caution,wraplength=845,foreground='#a13c00',background='#fff5e7',padding=9).pack(fill='x',pady=6)
        ttk.Label(wrap,text='Bản 1: chọn lớp/môn/cột trên VietSchool bằng tay. Chrome vẫn phải đang mở và đã đăng nhập.',style='Body.TLabel').pack(anchor='w')
        self.root.protocol('WM_DELETE_WINDOW',self.close)

    def choose_file(self):
        p=filedialog.askopenfilename(title='Chọn Excel điểm',filetypes=[('Excel (*.xlsx)','*.xlsx')])
        if not p:return
        try:
            self.wb=load_workbook(p,data_only=True,read_only=True)
            self.path=p;self.filelbl.configure(text=os.path.basename(p))
            sheets=list(self.wb.sheetnames); self.boxes['Sheet']['values']=sheets
            self.sheet.set('NHAP_DIEM' if 'NHAP_DIEM' in sheets else sheets[0]);self.refresh()
        except Exception as e: messagebox.showerror('Không mở được Excel',str(e))

    def headers(self, ws):
        """Locate the header by row number, never from cells in read-only mode.

        In read_only=True, openpyxl may yield EmptyCell (without .row) and
        certain workbooks have no dimension metadata (ws.max_row is None).
        """
        alias_sets = {key: {norm(label) for label in labels}
                      for key, labels in ALIASES.items()}
        for row_number, row in enumerate(
                ws.iter_rows(min_row=1, max_row=20, values_only=True), start=1):
            values = [norm(value) for value in row]
            found = {}
            for key, variants in alias_sets.items():
                for index, value in enumerate(values):
                    if value and value in variants:
                        found[key] = index
                        break
            has_name = 'name' in found or ('ho' in found and 'ten' in found)
            if has_name and ('class' in found or ws.title.upper() == 'NHAP_DIEM'):
                found['_row'] = row_number
                return found
        raise ValueError(
            'Không tìm thấy hàng tiêu đề Excel (Họ và tên, Lớp, Môn...). '
            'Hãy dùng file mẫu, không xóa hàng tiêu đề.')

    def refresh(self,_=None):
        if not self.wb: return
        try:
            ws=self.wb[self.sheet.get()];self.header=self.headers(ws)
            def get(row,key):
                i=self.header.get(key);return row[i] if i is not None and i<len(row) else None
            records=[]
            for i,row in enumerate(ws.iter_rows(min_row=self.header['_row']+1,values_only=True),start=self.header['_row']+1):
                name=txt(get(row,'name')) or ' '.join(filter(None,[txt(get(row,'ho')),txt(get(row,'ten'))]))
                if not name:continue
                rec={'row':i,'stt':get(row,'stt'),'student':name,'class':txt(get(row,'class')),'subject':txt(get(row,'subject')),'term':txt(get(row,'term')),'year':txt(get(row,'year'))}
                for col in COLS:rec[col]=get(row,col)
                records.append(rec)
            self.records=records
            if not records:
                self.state.configure(text='Excel mẫu đang trống: hãy dán danh sách học sinh và điểm vào NHAP_DIEM từ dòng 8, sau đó chọn lại file.',foreground='#b45309')
            for title,field,var in [('Lớp','class',self.clazz),('Môn','subject',self.subject),('Học kỳ','term',self.term),('Năm học','year',self.year)]:
                options=sorted({r[field] for r in records if r[field]})
                self.boxes[title]['values']=options
                if var.get() not in options:var.set(options[0] if options else '')
            self.preview()
        except Exception as exc:
            self.records=[];self.state.configure(text=f'LỖI: {exc}',foreground='#b91c1c')
            messagebox.showerror('Lỗi dữ liệu',str(exc))

    def filtered(self):
        return [r for r in self.records if r['class']==self.clazz.get() and r['subject']==self.subject.get() and r['term']==self.term.get() and r['year']==self.year.get()]

    def preview(self):
        for ch in self.table.get_children(): self.table.delete(ch)
        rows=self.filtered(); column=self.col.get()
        mode=rating_mode(self.subject.get(),self.rating.get())
        self.mode_info.set('Đ/CĐ (nhận xét)' if mode=='comment' else '0–10 (điểm số)')
        for r in rows:
            self.table.insert('', 'end',values=(r['row'], txt(r['stt']),r['student'], txt(r[column])))
        with_grade=sum(1 for r in rows if r[column] is not None and txt(r[column])!='')
        self.preview_payload='';self.preview_rows=[]
        if not self.records:
            self.state.configure(text='Excel chưa có học sinh: điền dữ liệu vào NHAP_DIEM từ dòng 8 rồi chọn lại file.',foreground='#b45309')
        else:
            self.state.configure(text=f'{len(rows)} học sinh · {with_grade} ô có điểm · Phạm vi: {self.clazz.get()} / {self.subject.get()} / {self.term.get()} / {column}',foreground='#075985')

    def validate(self):
        rows=self.filtered();column=self.col.get()
        mode=rating_mode(self.subject.get(),self.rating.get())
        if not rows:raise ValueError('File Excel chưa có học sinh cho lớp/môn/học kỳ đã chọn. Hãy dán họ tên, lớp, môn, học kỳ, năm học và điểm từ hàng 8 trong sheet NHAP_DIEM.')
        if len(rows)>70:raise ValueError(f'Tìm thấy {len(rows)} học sinh. Kiểm tra Excel bị gộp nhiều danh sách hoặc lớp quá đông.')
        names=[norm(r['student']) for r in rows]
        if len(set(names))!=len(names):raise ValueError('Có tên học sinh trùng trong danh sách. Phải đối chiếu ngày sinh hoặc mã học sinh trước khi dán.')
        stt=[txt(r['stt']) for r in rows]
        if any(x for x in stt) and all(x.isdigit() for x in stt):
            ints=[int(x) for x in stt]
            if ints!=list(range(1,len(rows)+1)):
                raise ValueError('STT Excel không liên tục từ 1 đến N. Kiểm tra danh sách có đúng thứ tự VietSchool hay không.')
        elif any(x for x in stt):
            raise ValueError('Cột STT không đồng nhất. Cần xác minh thứ tự học sinh.')
        values=[]
        for r in rows:
            try: values.append(grade_string(r[column], mode))
            except Exception as e: raise ValueError(f'Dòng Excel {r["row"]}, {r["student"]}: {e}')
        if not any(v is not None for v in values):raise ValueError('Chưa có điểm tại cột đã chọn.')
        # Chỉ dán phần đầu liên tiếp, ngăn việc bỏ qua hàng trống dẫn tới lệch điểm.
        first_blank=next((i for i,v in enumerate(values) if v is None),len(values))
        if any(v is not None for v in values[first_blank:]):
            raise ValueError(f'Cột {column} có ô trống xen giữa các điểm. Không dán để tránh lệch học sinh. Hãy xử lý dữ liệu trước.')
        paste=values[:first_blank]
        if len(paste)>60:raise ValueError('Quá 60 điểm trong một đợt; kiểm tra thứ tự lớp.')
        self.preview_rows=rows[:first_blank]
        self.preview_payload='\n'.join(paste)
        return paste

    def prepare(self):
        self.cancel(quiet=True)
        try: values=self.validate()
        except ValueError as e: messagebox.showerror('ĐÃ CHẶN DÁN',str(e));return
        msg=(f'Lớp: {self.clazz.get()} · Môn: {self.subject.get()} · Học kỳ: {self.term.get()}\n'
             f'Cột: {self.col.get()} · {len(values)} giá trị ({self.mode_info.get()}) liên tiếp từ học sinh đầu tiên.\n\n'
             f'Học sinh đầu: {self.preview_rows[0]["student"]} — {values[0]}\n'
             f'Học sinh cuối: {self.preview_rows[-1]["student"]} — {values[-1]}\n\n'
             'Bạn đã đối chiếu tên và thứ tự với VietSchool?\n'
             'CẢNH BÁO: Dán sẽ có thể ghi đè điểm cũ trong vùng chọn.')
        if not messagebox.askyesno('Xác nhận sao chép cột điểm',msg):return
        pyperclip.copy(self.preview_payload)
        self.armed=True;self.countdown_var.set(f'Đã sao chép {len(values)} điểm')
        self.log('CHUAN_BI_SAO_CHEP',len(values))
        messagebox.showinfo('Đã sao chép',f'Đã sao chép {len(values)} điểm.\n\nCÁCH 1: Chọn ô đúng cột, hàng đầu của lớp trên Chrome, nhấn Ctrl+V; xem hộp xác nhận.\n\nCÁCH 2: Nhấn nút "DÁN VÀO CHROME", sau đó nhanh chóng chuyển sang Chrome và bấm ô đầu tiên trước khi đếm ngược kết thúc.')

    def start_paste(self):
        if not self.armed or not self.preview_payload:
            messagebox.showwarning('Chưa chuẩn bị','Phải chọn nút KIỂM TRA & SAO CHÉP CỘT trước.');return
        if not messagebox.askyesno('Chuẩn bị dán vào Chrome',
              '1. Chắc chắn Chrome đang mở VietSchool, đúng LỚP / MÔN / HỌC KỲ / CỘT.\n'
              '2. Sau khi bấm Có, chuyển ngay qua Chrome và CLICK VÀO Ô ĐIỂM HỌC SINH ĐẦU TIÊN.\n'
              '3. Sau 7 giây, công cụ sẽ gõ Ctrl+V ở cửa sổ đang chọn.\n'
              '4. TỰ KIỂM TRA rồi bấm OK trên VietSchool.\n\nKhông muốn dán: quay lại chương trình và bấm DỪNG.'):
            return
        self.armed=False
        self.remaining=7
        self.tick()

    def tick(self):
        if self.remaining>0:
            self.countdown_var.set(f'Dán sau {self.remaining} giây...');self.remaining-=1
            self.after_id=self.root.after(1000,self.tick);return
        self.after_id=None
        try:
            import pyautogui
            title=pyautogui.getActiveWindowTitle() or ''
            if 'Chrome' not in title and 'VIETSCHOOL' not in title.upper() and 'nhapdiem' not in title.casefold():
                self.countdown_var.set('ĐÃ HỦY: chưa đúng cửa sổ Chrome')
                messagebox.showwarning('Đã hủy','Cửa sổ hiện tại không có dấu hiệu là Chrome/VietSchool. Không dán.');return
            pyautogui.hotkey('ctrl','v',interval=0.15)
            self.countdown_var.set('ĐÃ GỬI CTRL+V · CHƯA XÁC NHẬN LƯU')
            self.log('GUI_LENH_DAN_CHUA_XAC_NHAN_LUU',len(self.preview_rows))
            messagebox.showinfo('Đã gửi lệnh dán','Kiểm tra hộp thoại và điểm trên VietSchool, chỉ bấm OK khi đúng học sinh và cột.\nSau đó quan sát trạng thái lưu màu xanh lá. Không có xác nhận lưu tự động trong công cụ này.')
        except Exception as e:
            self.countdown_var.set('Lỗi khi dán')
            messagebox.showerror('Lỗi dán',str(e))

    def cancel(self,quiet=False):
        if self.after_id:self.root.after_cancel(self.after_id);self.after_id=None
        self.remaining=0
        if not quiet:self.countdown_var.set('Đã dừng')

    def log(self,kind,n):
        path=os.path.join(os.path.dirname(os.path.abspath(__file__)),'nhat_ky_agent.csv')
        try:
            exists=os.path.exists(path)
            with open(path,'a',newline='',encoding='utf-8-sig') as f:
                w=csv.writer(f)
                if not exists:w.writerow(['Thời điểm','Trạng thái','Tên file Excel','Lớp','Môn','Học kỳ','Năm học','Cột điểm','Số điểm'])
                w.writerow([dt.datetime.now().isoformat(timespec='seconds'),kind,os.path.basename(self.path),self.clazz.get(),self.subject.get(),self.term.get(),self.year.get(),self.col.get(),n])
        except OSError:pass

    def close(self):
        self.cancel(quiet=True)
        if self.wb:self.wb.close()
        self.root.destroy()

if __name__=='__main__':
    root=tk.Tk();Agent(root);root.mainloop()
