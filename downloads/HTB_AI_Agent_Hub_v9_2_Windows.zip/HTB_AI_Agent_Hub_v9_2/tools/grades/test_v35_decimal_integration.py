import queue
import tempfile
import threading
import unittest
from decimal import Decimal
from pathlib import Path
from openpyxl import Workbook
from base_agent import grade_string
from auto_core import read_jobs, grade_batch_state
from compare_core import compare_rows
from full_auto import AutoWorker


class DecimalIntegrationTests(unittest.TestCase):
    def test_exact_decimal_inputs(self):
        for value,expected in [(8.75,'8.75'),('8,75','8.75'),('8.7500','8.75'),
                               ('7.25','7.25'),('0,05','0.05'),(10,'10'),(0,'0'),
                               (Decimal('9.90'),'9.9'),('10.00','10')]:
            with self.subTest(value=value):self.assertEqual(grade_string(value),expected)

    def test_invalid_values_are_not_rounded(self):
        for value in ['8.751','10.01','-0.01','NaN','Infinity',True,'8,7,5','abc']:
            with self.subTest(value=value),self.assertRaises(ValueError):grade_string(value)
        self.assertIsNone(grade_string(None))
        self.assertEqual(grade_string('Chưa đạt','comment'),'CĐ')

    def test_excel_screenshot_case_and_comparison(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'diem.xlsx';wb=Workbook();ws=wb.active;ws.title='NHAP_DIEM'
            ws.append(['Họ và tên','Lớp','Môn học','Học kỳ','Năm học','Giữa kỳ'])
            ws.append(['Đặng Lê Lam Anh','10A01','Toán','HK1','2026-2027',8.75])
            wb.save(path);wb.close();jobs=read_jobs(path)
        self.assertEqual(len(jobs),1);job=jobs[0]
        self.assertEqual(job['rows'][0]['Giữa kỳ'],'8.75')
        web=dict(stt=1,name='Đặng Lê Lam Anh',dob='',cells=['1','Đặng Lê Lam','Anh','','8,8'])
        self.assertEqual(compare_rows(job,[web],4)[0]['result'],'Đúng')
        web['cells'][4]='8,7'
        self.assertEqual(compare_rows(job,[web],4)[0]['result'],'Sai điểm')

    def test_rounded_web_value_is_never_marked_saved(self):
        run=[dict(stt=1,name='Winnie',dob='',value='8.75')]
        row=dict(stt=1,name='Winnie',dob='',cells=['1','','Winnie','','8.8'],saved=[True]*5)
        self.assertFalse(grade_batch_state([row],run,4)['saved'])
        row['cells'][4]='8,75'
        self.assertTrue(grade_batch_state([row],run,4)['saved'])
        worker=AutoWorker('',queue.Queue(),threading.Event())
        self.assertFalse(worker.same_value('8.8','8.75'))
        self.assertTrue(worker.same_value('8,75','8.75'))


if __name__=='__main__':unittest.main()
