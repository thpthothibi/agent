"""Multi-file Excel transfer workspace inside HTB; completely local."""
from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
from desktop_ui import FONT,WHITE,BLUE,MUTED,label,card,button
from transfer_core import describe_file,prepare_records,export_template,GRADE_COLUMNS

BASE=Path(__file__).resolve().parent
SUBJECTS=['Tin học','Công nghệ nông nghiệp','Công nghệ công nghiệp','Công nghệ','Toán','Ngữ văn','Tiếng Anh','Vật lí','Hóa học','Sinh học','Lịch sử','Địa lí','GDĐP','GDTC','HĐTN-HN']

class TransferWorkspace:
    def __init__(self,root,hub):
        self.root=root;self.hub=hub;self.specs=[];self.active_index=None
        self.busy=False;self.worker=None;self.cancel_event=None;self.exported=None
        self.status=tk.StringVar(value='Chọn nhiều file nguồn, kiểm tra môn/cột điểm của từng file, rồi xem trước và xuất mẫu.')
        self.subject=tk.StringVar();self.score=tk.StringVar()
        self.year=tk.StringVar(value='2026-2027');self.term=tk.StringVar(value='HK1');self.column=tk.StringVar(value='Giữa kỳ');self.clazz=tk.StringVar()
        self.template=tk.StringVar(value=str(BASE/'Mau_Nhap_Diem_VietSchool_Chrome.xlsx'))
        head=card(root);head.pack(fill='x',padx=18,pady=(18,10))
        label(head,'CHUYỂN ĐIỂM VÀO MẪU',size=18,color=BLUE,bold=True).pack(anchor='w')
        label(head,'Nhiều Excel nguồn → dò cột và ghép Họ/Tên → xem trước → xuất mẫu VietSchool',color=MUTED,wraplength=800).pack(anchor='w',pady=(5,10))
        bar=tk.Frame(head,bg=WHITE);bar.pack(fill='x')
        button(bar,'Thêm nhiều file Excel…',self.add_files,True).pack(side='left')
        button(bar,'Xóa file chọn',self.remove_file).pack(side='left',padx=6)
        self.files=ttk.Treeview(head,columns=('file','subject','score'),show='headings',height=5,selectmode='browse')
        for key,title,width in [('file','File nguồn',280),('subject','Môn cho file',220),('score','Cột điểm nguồn',180)]:self.files.heading(key,text=title);self.files.column(key,width=width)
        self.files.pack(fill='x',pady=10);self.files.bind('<<TreeviewSelect>>',self.select_file)
        config=tk.Frame(head,bg=WHITE);config.pack(fill='x')
        label(config,'Môn:',size=10).pack(side='left')
        ttk.Combobox(config,textvariable=self.subject,values=SUBJECTS,width=28).pack(side='left',padx=(4,12))
        label(config,'Cột nguồn:',size=10).pack(side='left')
        self.score_box=ttk.Combobox(config,textvariable=self.score,state='readonly',width=22);self.score_box.pack(side='left',padx=4)
        button(config,'Áp dụng cho file chọn',self.commit_file).pack(side='left',padx=6)
        label(head,'Môn gợi ý theo tên file có thể sửa. “Điểm TN” không tự cộng tự luận: hãy chọn đúng giá trị nguồn cần đưa vào mẫu.',size=9,color=MUTED,wraplength=820).pack(anchor='w',pady=(8,0))
        dest=card(root);dest.pack(fill='x',padx=18,pady=6)
        settings=tk.Frame(dest,bg=WHITE);settings.pack(fill='x')
        for text,var,width,values in [('Năm học',self.year,13,None),('Học kỳ',self.term,7,['HK1','HK2']),('Cột đích',self.column,13,GRADE_COLUMNS),('Lớp nếu nguồn thiếu',self.clazz,10,None)]:
            group=tk.Frame(settings,bg=WHITE);group.pack(side='left',padx=(0,14))
            label(group,text,size=9).pack(anchor='w')
            widget=ttk.Combobox(group,textvariable=var,values=values,state='readonly',width=width) if values else ttk.Entry(group,textvariable=var,width=width)
            widget.pack(anchor='w',pady=(4,0))
        label(dest,'Năm học, học kỳ và cột đích trên áp dụng cho toàn bộ lần chuyển; điểm nguồn được giữ nguyên, không tự làm tròn.',size=9,color=MUTED,wraplength=820).pack(anchor='w',pady=(10,8))
        tpl=tk.Frame(dest,bg=WHITE);tpl.pack(fill='x')
        ttk.Entry(tpl,textvariable=self.template).pack(side='left',fill='x',expand=True)
        button(tpl,'Chọn mẫu trống…',self.choose_template).pack(side='left',padx=(8,0))
        act=tk.Frame(dest,bg=WHITE);act.pack(fill='x',pady=(12,0))
        button(act,'1. Xem trước',self.preview,True).pack(side='left')
        button(act,'2. Xuất file mẫu…',self.export).pack(side='left',padx=8)
        self.use_button=button(act,'Dùng file xuất để nhập điểm →',self.use_output);self.use_button.pack(side='left');self.use_button.configure(state='disabled')
        body=card(root);body.pack(fill='both',expand=True,padx=18,pady=(8,18))
        tk.Label(body,textvariable=self.status,bg=WHITE,fg=BLUE,font=(FONT,10),wraplength=850,justify='left').pack(fill='x',pady=(0,8))
        frame=tk.Frame(body,bg=WHITE);frame.pack(fill='both',expand=True)
        self.table=ttk.Treeview(frame,columns=('name','class','subject','score','status'),show='headings',height=10)
        for key,title,width in [('name','Họ và tên',240),('class','Lớp',75),('subject','Môn',190),('score','Điểm nguồn',100),('status','Kết quả / lý do',330)]:self.table.heading(key,text=title);self.table.column(key,width=width)
        scroll=ttk.Scrollbar(frame,orient='vertical',command=self.table.yview);self.table.configure(yscrollcommand=scroll.set)
        self.table.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')

    def commit_file(self):
        if self.active_index is not None and self.active_index<len(self.specs):
            spec=self.specs[self.active_index];spec['subject']=self.subject.get().strip();spec['score_header']=self.score.get()
            self.files.item(str(self.active_index),values=(Path(spec['path']).name,spec['subject'] or '(chưa chọn)',spec['score_header'] or '(chưa chọn)'))

    def select_file(self,event=None):
        selected=self.files.selection()
        if not selected:return
        self.commit_file();self.active_index=int(selected[0]);spec=self.specs[self.active_index]
        self.subject.set(spec['subject']);self.score.set(spec['score_header']);self.score_box.configure(values=spec['score_options'])

    def redraw_files(self):
        self.active_index=None
        for iid in self.files.get_children():self.files.delete(iid)
        for i,spec in enumerate(self.specs):self.files.insert('','end',iid=str(i),values=(Path(spec['path']).name,spec['subject'] or '(chưa chọn)',spec['score_header'] or '(chưa chọn)'))
        if self.specs:self.files.selection_set('0')
        else:self.subject.set('');self.score.set('')

    def add_files(self):
        self.commit_file()
        paths=filedialog.askopenfilenames(parent=self.hub.root,title='Chọn nhiều Excel điểm nguồn',filetypes=[('Excel','*.xlsx')])
        errors=[];existing={str(Path(s['path']).resolve()) for s in self.specs}
        for path in paths:
            if str(Path(path).resolve()) in existing:continue
            try:self.specs.append(describe_file(path));existing.add(str(Path(path).resolve()))
            except Exception as exc:errors.append(Path(path).name+': '+str(exc))
        self.redraw_files();self.status.set(f'Đã chọn {len(self.specs)} file nguồn. Kiểm tra môn và cột điểm cho từng file.')
        if errors:messagebox.showwarning('File chưa đọc được','\n'.join(errors),parent=self.hub.root)

    def remove_file(self):
        selected=self.files.selection()
        if selected:self.specs.pop(int(selected[0]));self.redraw_files()

    def choose_template(self):
        path=filedialog.askopenfilename(parent=self.hub.root,title='Chọn mẫu Excel trống',filetypes=[('Excel','*.xlsx')])
        if path:self.template.set(path)

    def build_preview(self):
        self.commit_file()
        if not self.specs:raise ValueError('Chọn ít nhất một file nguồn.')
        records,issues=prepare_records(self.specs,self.year.get().strip(),self.term.get(),self.column.get(),self.clazz.get().strip())
        for iid in self.table.get_children():self.table.delete(iid)
        display=[(r,'Sẽ chuyển') for r in records]+[(r,'Không xuất: '+r['reason']) for r in issues]
        for r,status in display[:1000]:self.table.insert('','end',values=(r['name'],r['class'],r['subject'],r['raw'],status))
        self.status.set(f'{len(self.specs)} file · {len(records)} dòng hợp lệ · {len(issues)} dòng không xuất. Xem lý do trong bảng/CAN_KIEM_TRA. Hiển thị tối đa 1.000 dòng; file xuất chứa đầy đủ. Mẫu không ghi đè file nguồn.')
        return records,issues

    def preview(self):
        try:self.build_preview()
        except Exception as exc:messagebox.showerror('Chưa xem trước được',str(exc),parent=self.hub.root)

    def export(self):
        if not self.hub.can_start(self):return
        try:
            records,issues=self.build_preview()
            if not records:raise ValueError('Không có dòng hợp lệ; kiểm tra cột nguồn, môn và các lý do trong bảng.')
            path=filedialog.asksaveasfilename(parent=self.hub.root,title='Lưu bản mẫu đã điền',initialfile='Diem_Chuyen_Vao_Mau.xlsx',defaultextension='.xlsx',filetypes=[('Excel','*.xlsx')])
            if not path:return
            if Path(path).resolve() in {Path(s['path']).resolve() for s in self.specs}:raise ValueError('Không được ghi đè file điểm nguồn; chọn tên xuất khác.')
            self.exported=export_template(records,issues,self.template.get(),path)
            self.use_button.configure(state='normal')
            self.status.set(f'Đã xuất {len(records)} dòng vào {self.exported.name}. {len(issues)} dòng không xuất nằm trong CAN_KIEM_TRA. Nguồn/điểm gốc có trong NGUON_DIEM. Bấm “Dùng file xuất để nhập điểm” khi đã kiểm tra xong.')
        except Exception as exc:messagebox.showerror('Chưa xuất được',str(exc),parent=self.hub.root)

    def use_output(self):
        if self.exported and self.exported.is_file():self.hub.path.set(str(self.exported));self.hub.show(1)
