import tempfile, unittest
from pathlib import Path
from openpyxl import Workbook
from auto_core import read_jobs
from name_matching import build_plan, paste_runs

class SingleNameTests(unittest.TestCase):
    def test_split_excel_name_can_have_empty_surname(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'scores.xlsx';wb=Workbook();ws=wb.active
            ws.append(['Họ','Tên','Lớp','Môn học','Học kỳ','Năm học','Giữa kỳ'])
            ws.append([None,'Winnie','11A06','Toán','HK1','2026-2027',10])
            wb.save(p);jobs=read_jobs(p)
        self.assertEqual(jobs[0]['rows'][0]['student'],'Winnie')
        self.assertEqual(jobs[0]['rows'][0]['Giữa kỳ'],'10')
    def test_42_students_with_winnie_at_40_and_retired_gap(self):
        site=[];source=[]
        for i in range(1,43):
            ho,ten=('','Winnie') if i==40 else ('Học sinh',str(i))
            name=' '.join(part for part in (ho,ten) if part)
            site.append({'stt':i,'name':name,'dob':'14/10/2009','cells':[str(i),ho,ten,'14/10/2009',''], 'inactive':i==5})
            if i!=5:source.append({'student':name,'row':i+1,'Giữa kỳ':10 if i==40 else 6.5})
        plan=build_plan(list(reversed(source)),site,'Giữa kỳ','Toán',index=4)
        self.assertEqual(plan[39]['name'],'Winnie');self.assertEqual(plan[39]['value'],'10')
        self.assertEqual(plan[40]['stt'],41);self.assertEqual(plan[40]['value'],'6.5')
        self.assertEqual([[r['stt'] for r in run] for run in paste_runs(plan)],[list(range(1,5)),list(range(6,43))])

if __name__=='__main__':unittest.main()
