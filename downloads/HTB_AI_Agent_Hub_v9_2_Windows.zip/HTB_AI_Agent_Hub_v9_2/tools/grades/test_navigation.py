import queue, threading, unittest
from unittest.mock import Mock, patch
from auto_core import grade_from_class
from full_auto import AutoWorker

class NavigationTests(unittest.TestCase):
    def make(self):return AutoWorker('',queue.Queue(),threading.Event())
    def test_grade_from_excel_class(self):
        for c,g in [('10A06','Khối 10'),('11A01','Khối 11'),('Lớp 12A13','Khối 12')]:self.assertEqual(grade_from_class(c),g)
        with self.assertRaises(ValueError):grade_from_class('101A01')
    def test_loading_overlay_waits_even_if_aria_hidden(self):
        w=self.make();clock=[0.0]
        w.page=Mock(return_value=object());w.frames=Mock(return_value=['main'])
        w.tick=lambda *args:clock.__setitem__(0,clock[0]+.2)
        w.dom=Mock(side_effect=lambda *args,**kw:[{'id':'loading','ariaHidden':'true'}] if clock[0]<.6 else [])
        with patch('full_auto.time.monotonic',side_effect=lambda:clock[0]):w.wait_idle('môn',timeout=2)
        self.assertGreaterEqual(clock[0],1.0)
    def test_stuck_overlay_times_out_without_any_click(self):
        w=self.make();clock=[0.0];w.page=Mock(return_value=object());w.frames=Mock(return_value=['main'])
        w.tick=lambda *args:clock.__setitem__(0,clock[0]+.2)
        w.dom=Mock(return_value=[{'id':'loading','ariaHidden':'true'}])
        with patch('full_auto.time.monotonic',side_effect=lambda:clock[0]):
            with self.assertRaisesRegex(RuntimeError,'vẫn đang tải'):w.wait_idle('lớp',timeout=1)
    def test_cancel_loading(self):
        w=self.make();w.page=Mock(return_value=object());w.cancel.set()
        from full_auto import Cancelled
        with self.assertRaises(Cancelled):w.wait_idle()
    def test_reresolve_navigation_after_rerender(self):
        w=self.make();w.page=Mock(return_value=Mock());w.wait_idle=Mock()
        f=Mock();old=Mock();old.click.side_effect=RuntimeError('element was detached');new=Mock()
        f.locator.side_effect=lambda selector:old if selector=='old' else new
        w.ui_target=Mock(side_effect=[(f,{'selector':'old','active':False}),(f,{'selector':'new','active':False}),(f,{'selector':'selected','active':True})])
        w.choose(['GDĐP'])
        old.click.assert_called_once_with(timeout=4000);new.click.assert_called_once_with(timeout=4000)
    def test_navigation_expands_grade_before_class_and_waits(self):
        w=self.make();w.page=Mock(return_value=Mock());calls=[]
        w.year=lambda v:calls.append(('year',v))
        w.choose_class=lambda v:calls.append(('class',v))
        w.expand=lambda values,group:calls.append(('expand',values[0]))
        w.choose=lambda values,**kw:calls.append(('choose',values[0],kw.get('branch')))
        w.wait_idle=lambda label:calls.append(('idle',label))
        job={'year':'2026-2027','class':'10A06','subject':'GDĐP','term':'Học kỳ 1'}
        w.navigate(job)
        self.assertEqual(calls[0],('year','2026-2027'))
        self.assertEqual(calls[1],('class','10A06'))
        self.assertEqual(calls[2],('expand','Học kỳ 1'))
        self.assertEqual(calls[3],('choose','ĐGTX','Học kỳ 1'))
        self.assertEqual(calls[4][0:2],('choose','GDĐP'))
    def test_expand_open_wijmo_does_not_collapse(self):
        w=self.make();w.wait_idle=Mock();f=Mock()
        w.ui_target=Mock(return_value=(f,{'selector':'label','expanded':'true','toggle':None}))
        w.expand(['Khối 10'],['LỚP HỌC']);f.locator.assert_not_called()
    def test_wijmo_collapsed_arrow_clicked_once(self):
        w=self.make();w.wait_idle=Mock();f=Mock();f.locator.return_value.bounding_box.return_value={'height':30}
        w.ui_target=Mock(side_effect=[(f,{'selector':'label','expanded':'false','toggle':None,'expandMode':'wijmo','expandSelector':'node'}),(f,{'expanded':'true'})])
        w.expand(['Khối 10'],['LỚP HỌC'])
        f.locator.return_value.click.assert_called_once_with(position={'x':8,'y':15},timeout=4000)

if __name__=='__main__':unittest.main(verbosity=2)
