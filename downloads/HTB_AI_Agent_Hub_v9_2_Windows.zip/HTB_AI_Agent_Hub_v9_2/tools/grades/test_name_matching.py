import unittest
from name_matching import build_plan, paste_runs
from chrome_bridge import SNAPSHOT_JS, CAPTURE_JS
from auto_bridge import FOCUS_JS

def src(name,n,value='Đ'):
    return {'student':name,'row':n,'Giữa kỳ':value}
def dest(name,n,old='',inactive=False,lock=False):
    return {'name':name,'stt':n,'dob':'22/03/2011','cells':[str(n),'Hồ Quỳnh',name.split()[-1],'22/03/2011',old], 'inactive':inactive,'locks':[False]*4+[lock]}

def plan(e,s):return build_plan(e,s,'Giữa kỳ','GDĐP',index=4)

class MatchingTests(unittest.TestCase):
    def test_reorder(self):
        p=plan([src('Bình',9,'CĐ'),src('An',8)],[dest('An',1),dest('Bình',2)])
        self.assertEqual([r['value'] for r in p],['Đ','CĐ'])
        self.assertEqual([r['row'] for r in p],[8,9])
    def test_retired_middle_no_shift(self):
        p=plan([src('An',8),src('Bình',9),src('Chi',10)],[dest('An',1),dest('Bình',2,inactive=True),dest('Chi',3)])
        self.assertEqual([[r['stt'] for r in run] for run in paste_runs(p)],[[1],[3]])
    def test_retired_missing_excel(self):
        p=plan([src('An',8),src('Chi',10)],[dest('An',1),dest('Bình',2,inactive=True),dest('Chi',3)])
        self.assertEqual(p[1]['status'],'Bỏ qua: học sinh nghỉ')
    def test_occupied_blank_locked(self):
        p=plan([src('An',8),src('Bình',9,None),src('Chi',10)],[dest('An',1,'Đ'),dest('Bình',2),dest('Chi',3,lock=True)])
        self.assertEqual(paste_runs(p),[])
    def test_duplicate_missing_invalid(self):
        for e,s in [([src('An',8),src('AN',9)],[dest('An',1)]),([src('An',8,'X')],[dest('An',1)])]:
            with self.assertRaises(ValueError):plan(e,s)
    def test_nonconsecutive_web(self):
        with self.assertRaises(ValueError):plan([src('An',8)],[dest('An',2)])
    def test_numeric_zero(self):
        e=[{'student':'An','row':8,'Giữa kỳ':0}]
        self.assertEqual(build_plan(e,[dest('An',1)],'Giữa kỳ','Toán',index=4)[0]['value'],'0')

class DOMTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from playwright.sync_api import sync_playwright
        cls.pw=sync_playwright().start()
        try:cls.browser=cls.pw.chromium.launch(headless=True)
        except Exception as e:
            cls.pw.stop();raise unittest.SkipTest('Chưa có Chromium kiểm thử: '+str(e).splitlines()[0])
    @classmethod
    def tearDownClass(cls):cls.browser.close();cls.pw.stop()
    def test_red_gray_and_paste_boundary(self):
        p=self.browser.new_page()
        p.set_content('''<table><tr><td>1</td><td>Nguyễn</td><td>An</td><td>22/03/2011</td><td tabindex="0"></td></tr>
        <tr><td>2</td><td style="color:red">Hồ Quỳnh</td><td style="color:red">Anh</td><td style="color:red">22/03/2011</td><td style="background:rgb(241,242,243)"></td></tr>
        <tr><td>3</td><td>Lê</td><td>Chi</td><td>22/03/2011</td><td tabindex="0"></td></tr></table>''')
        s=p.evaluate(SNAPSHOT_JS)
        self.assertEqual(len(s['rows']),3);self.assertTrue(s['rows'][1]['inactive']);self.assertFalse(s['rows'][0]['inactive'])
        result=plan([src('Lê Chi',10),src('Nguyễn An',8)],s['rows'])
        self.assertEqual([[r['stt'] for r in run] for run in paste_runs(result)],[[1],[3]])
        self.assertTrue(p.evaluate(FOCUS_JS,{'run':[result[2]],'index':4}))
        p.locator('tr').nth(2).locator('td').nth(4).evaluate("e=>e.textContent='Đ'")
        with self.assertRaises(Exception):p.evaluate(FOCUS_JS,{'run':[result[2]],'index':4})
        p.close()

if __name__=='__main__':unittest.main(verbosity=2)
