import queue, tempfile, threading, unittest
from pathlib import Path
from unittest.mock import patch
from openpyxl import Workbook
from auto_core import read_jobs, expand_headers, column_index, confirm_is_paste
from full_auto import AutoWorker

class ProgridColumnTests(unittest.TestCase):
    def test_short_vietschool_exam_headers(self):
        paths=['STT','Họ','Tên','Ngày sinh','Điểm ĐGTX 1','Điểm ĐGTX 2','Điểm ĐGTX 3','Điểm ĐGTX 4','ĐGK','ĐCK']
        self.assertEqual(column_index(paths,'TX1'),4)
        self.assertEqual(column_index(paths,'TX4'),7)
        self.assertEqual(column_index(paths,'Giữa kỳ'),8)
        self.assertEqual(column_index(paths,'Cuối kỳ'),9)

    def test_worker_reports_resolved_header(self):
        worker=AutoWorker('',queue.Queue(),threading.Event())
        paths=['STT','Họ','Tên','Ngày sinh','Điểm ĐGTX 1','ĐGK']
        worker.dom=lambda *a,**kw:[[[dict(text=p,rowspan=1,colspan=1) for p in paths]]]
        self.assertEqual(worker.headers(None,{'column':'Giữa kỳ'}),5)
        self.assertIn('cột 6',worker.events.get()[1])

class ExcelTests(unittest.TestCase):
    def make(self, rows, second=None):
        td=tempfile.TemporaryDirectory();self.addCleanup(td.cleanup)
        path=Path(td.name)/'diem.xlsx';w=Workbook();s=w.active
        heads=['Họ và tên','Lớp','Môn học','Học kỳ','Năm học','TX1','Giữa kỳ','Cuối kỳ'];s.append(heads)
        for r in rows:s.append(r)
        if second:
            s=w.create_sheet('Lop khac');s.append(heads)
            for r in second:s.append(r)
        w.save(path);return path
    def test_auto_groups_all_columns_sheets(self):
        path=self.make([['An','10A06','GDĐP','HK1','2026-2027','Đ','CĐ',None],['Bình','10A06','GDĐP','HK1','2026-2027',None,None,None]],
                       [['Chi','11A01','Toán','HK2','2026-2027',0,8.5,9]])
        jobs=read_jobs(path)
        self.assertEqual(len(jobs),5)
        self.assertEqual([j['column'] for j in jobs],['TX1','Giữa kỳ','TX1','Giữa kỳ','Cuối kỳ'])
        self.assertEqual(len(jobs[0]['rows']),2)
        self.assertEqual(jobs[2]['rows'][0]['TX1'],'0')
    def test_missing_scope_before_browser(self):
        with self.assertRaises(ValueError):read_jobs(self.make([['An',None,'Toán','HK1','2026-2027',7,None,None]]))
    def test_bad_grade_before_browser(self):
        with self.assertRaises(ValueError):read_jobs(self.make([['An','10A01','GDTC','HK1','2026-2027',8,None,None]]))
    def test_duplicate_name_before_browser(self):
        with self.assertRaises(ValueError):read_jobs(self.make([['An','10A01','Toán','HK1','2026-2027',8,None,None],['AN','10A01','Toán','HK1','2026-2027',9,None,None]]))
    def test_hdtn_alias_rating(self):
        j=read_jobs(self.make([['An','10A01','HĐTN3','HK1','2026-2027','Đ',None,None]]))
        self.assertEqual(j[0]['rows'][0]['TX1'],'Đ')

class HeaderTests(unittest.TestCase):
    def test_merged_header_screenshot(self):
        cell=lambda t,rs=1,cs=1:{'text':t,'rowspan':rs,'colspan':cs}
        raw=[[cell('STT',2),cell('Họ',2),cell('Tên',2),cell('Ngày sinh',2),cell('Điểm ĐGTX',1,3),cell('ĐGGK',2)],
             [cell('1'),cell('2'),cell('3')]]
        paths=expand_headers(raw)
        self.assertEqual(column_index(paths,'TX1'),4)
        self.assertEqual(column_index(paths,'TX3'),6)
        self.assertEqual(column_index(paths,'Giữa kỳ'),7)
        with self.assertRaises(ValueError):column_index(paths,'Cuối kỳ')
    def test_ambiguous_no_position_guess(self):
        with self.assertRaises(ValueError):column_index(['STT','Họ','Tên','Ngày sinh','TX1','TX1'],'TX1')
    def test_no_guess_unlabelled(self):
        with self.assertRaises(ValueError):column_index(['STT','Họ','Tên','Ngày sinh','1'],'TX1')
    def test_only_expected_dialogs(self):
        self.assertTrue(confirm_is_paste('Bạn có muốn dán dữ liệu từ Excel?'))
        self.assertTrue(confirm_is_paste('Dán có thể ghi đè vùng chọn. Tiếp tục?'))
        for msg in ['Bạn có muốn xóa dữ liệu?', 'Xác nhận lưu', 'Khóa sổ sau khi dán?']:
            self.assertFalse(confirm_is_paste(msg))

class WorkerTests(unittest.TestCase):
    def test_error_reports_terminal_event_no_hanging_status(self):
        events=queue.Queue();w=AutoWorker('bad.xlsx',events,threading.Event())
        with patch('full_auto.read_jobs',side_effect=ValueError('Excel sai')),patch.object(w,'report',return_value='bao_cao.csv'),patch('pathlib.Path.write_text'):
            w.run()
        received=[]
        while not events.empty():received.append(events.get())
        self.assertEqual(received[-1][0],'error');self.assertIn('Excel sai',received[-1][1])
    def test_value_equivalence(self):
        w=AutoWorker('',queue.Queue(),threading.Event())
        self.assertTrue(w.same_value('8,0','8'));self.assertTrue(w.same_value('Đ','Đ'));self.assertFalse(w.same_value('CĐ','Đ'))

if __name__=='__main__':unittest.main(verbosity=2)
