import unittest
from unittest.mock import Mock, patch
from types import SimpleNamespace
import time
from htb_agent import Hub

class HubTests(unittest.TestCase):
    def setUp(self):
        self.hub=object.__new__(Hub)
        self.hub.root=Mock()
        self.app=SimpleNamespace(busy=True,worker=None,cancel_event=None,events=Mock(),status=Mock(),launch_when_ready=Mock())
        self.other=SimpleNamespace(busy=False,worker=Mock(),cancel_event=Mock())
        self.other.worker.is_alive.return_value=True
        self.hub.apps=[self.app,self.other]

    @patch('htb_agent.messagebox.showinfo')
    def test_block_concurrent_vietschool_jobs(self,show):
        self.other.busy=True
        self.assertFalse(self.hub.can_start(self.app))
        show.assert_called_once()

    def test_release_browser_before_switch(self):
        self.assertFalse(self.hub.released(self.app,'input.xlsx',time.monotonic()+10))
        self.other.cancel_event.set.assert_called_once()
        self.hub.root.after.assert_called_once()
        self.other.worker.is_alive.return_value=False
        self.assertTrue(self.hub.released(self.app,'input.xlsx',time.monotonic()+10))

    def test_timeout_does_not_start_new_browser(self):
        self.assertFalse(self.hub.released(self.app,'input.xlsx',time.monotonic()-1))
        self.assertEqual(self.app.events.put.call_args.args[0][0],'error')
        self.hub.root.after.assert_not_called()

if __name__=='__main__':unittest.main()
