# -*- coding: utf-8 -*-
"""Browser automation limited to the user-visible VietSchool UI; no private API requests."""
import os, queue, threading, time, unicodedata, re
from urllib.parse import urlparse

DOMAIN = 'nhapdiem.truonghocviet.vn'


def normalize_name(s):
    s = unicodedata.normalize('NFD', str(s or '').casefold().strip())
    s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    s = s.replace('đ', 'd')
    return re.sub(r'\s+', ' ', s)


def match_students(excel, site):
    """Require exact length and name+order; empty/partial virtualized grids are not approved."""
    if len(site) != len(excel):
        return False, (f'Danh sách Chrome đang hiển thị {len(site)} dòng, Excel có {len(excel)} dòng. '
                       'Có thể bảng cuộn ảo hoặc chưa đúng lớp. Không tự dán.')
    for i, (left, right) in enumerate(zip(excel, site), start=1):
        if normalize_name(left['student']) != normalize_name(right.get('name', '')):
            return False, f'Sai tên ở STT {i}: Excel = {left["student"]}; VietSchool = {right.get("name", "")}.'
        stt = right.get('stt')
        if stt is not None and int(stt) != i:
            return False, f'Thứ tự VietSchool bất thường tại STT {i}: {stt}.'
    return True, f'Đã đối chiếu đúng thứ tự {len(excel)} học sinh theo họ tên.'


# Runs inside signed-in browser, no requests and no data sent anywhere.
SNAPSHOT_JS = r'''() => {
  const visible = e => {let r=e.getBoundingClientRect(), s=getComputedStyle(e); return r.width>0 && r.height>0 && s.display!=='none' && s.visibility!=='hidden'};
  let containers=[...document.querySelectorAll('tr, [role="row"], .ag-row, .wj-row')];
  let groups=[];
  for(let row of containers) {
    if(!visible(row)) continue;
    let cells=[...row.children].filter(c => c.matches('td, th, [role="gridcell"], [role="cell"], .ag-cell, .wj-cell'));
    if(cells.length<5) continue;
    let t=cells.map(c=>(c.innerText||c.textContent||'').replace(/\s+/g,' ').trim());
    let stt=(t[0]||'').match(/^\d{1,3}$/);
    if(!stt || Number(stt[0])>100) continue;
    let dob= (t[3]||'').match(/^\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{4}$/);
    if(!dob) continue;
    const rgb=e=>(getComputedStyle(e).color.match(/\d+/g)||[]).map(Number);
    const red=e=>[e,...e.querySelectorAll('*')].some(n=>{let c=rgb(n);return c[0]>150 && c[1]<100 && c[2]<100});
    const gray=e=>{let c=(getComputedStyle(e).backgroundColor.match(/\d+/g)||[]).map(Number);return c.length>=3 && c[0]>=190 && c[0]<250 && Math.max(...c.slice(0,3))-Math.min(...c.slice(0,3))<15 && (c.length<4 || c[3]>0)};
    const inactive=red(cells[1]) && red(cells[2]) && cells.slice(4).some(gray);
    const locks=cells.map(c=>c.getAttribute('aria-disabled')==='true'||c.getAttribute('aria-readonly')==='true'||c.matches('.locked,.readonly,.readOnly')||!!c.querySelector('[disabled],[readonly]'));
    let r={inactive, locks, stt:Number(stt[0]), name:([t[1],t[2]]).join(' ').trim(), dob:t[3], cells:t, cellCount:cells.length};
    groups.push(r);
  }
  let seen=new Set(); let rows=[];
  for(let r of groups){let key=r.stt+'|'+r.name+'|'+r.dob; if(!seen.has(key)){seen.add(key);rows.push(r)}}
  rows.sort((a,b)=>a.stt-b.stt);
  let selected=[...document.querySelectorAll('.active,.selected,.is-active,[aria-selected="true"]')]
    .filter(visible).map(e=>(e.innerText||'').trim()).filter(s=>s && s.length<45).slice(0,30);
  return {title:document.title, url:location.href, rows, selected, totalDOM:groups.length};
}'''

CAPTURE_JS = r'''() => {
  window.__vsAgentTarget=null;
  if(window.__vsAgentHandler)document.removeEventListener('click',window.__vsAgentHandler,true);
  window.__vsAgentHandler=(ev)=>{
    let c=ev.target.closest('td, [role="gridcell"], [role="cell"], .ag-cell, .wj-cell');
    if(!c) return;
    let row=c.closest('tr, [role="row"], .ag-row, .wj-row');
    if(!row)return;
    let cells=[...row.children].filter(n=>n.matches('td, th, [role="gridcell"], [role="cell"], .ag-cell, .wj-cell'));
    let idx=cells.indexOf(c);
    if(idx<0)return;
    window.__vsAgentTarget={element:c, index:idx, first:(cells[0].innerText||'').trim(),
      name:([cells[1]?.innerText||'', cells[2]?.innerText||'']).join(' ').replace(/\s+/g,' ').trim(),
      text:(c.innerText||'').trim(), capturedAt:Date.now()};
  };
  document.addEventListener('click',window.__vsAgentHandler,true);
  return true;
}'''

TARGET_JS = r'''() => {
  const o=window.__vsAgentTarget;
  return o?{index:o.index, first:o.first, name:o.name, text:o.text, ageMs:Date.now()-o.capturedAt}:null;
}'''

PRECHECK_JS = r'''({count})=>{
  let o=window.__vsAgentTarget;
  if(!o||!o.element||!o.element.isConnected)return {ok:false, reason:'Ô đã chọn không còn tồn tại. Hãy chọn lại.'};
  let row=o.element.closest('tr,[role="row"],.ag-row,.wj-row');
  if(!row)return {ok:false,reason:'Không xác định được hàng của ô đã chọn.'};
  const rows=[...document.querySelectorAll('tr,[role="row"],.ag-row,.wj-row')].filter(r=>{
    let c=[...r.children].filter(x=>x.matches('td,th,[role="gridcell"],[role="cell"],.ag-cell,.wj-cell'));
    return c.length>o.index && /^\d{1,3}$/.test((c[0]?.innerText||'').trim()) && /^\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{4}$/.test((c[3]?.innerText||'').trim());
  });
  let seen=new Set(), clean=[];
  for(let r of rows){let c=[...r.children].filter(x=>x.matches('td,th,[role="gridcell"],[role="cell"],.ag-cell,.wj-cell'));let stt=(c[0]?.innerText||'').trim();if(!seen.has(stt)){clean.push({node:r,cells:c,stt:Number(stt)});seen.add(stt)}}
  clean.sort((a,b)=>a.stt-b.stt);
  if(clean.length<count) return {ok:false, reason:'Chưa đọc đủ hàng điểm cần dán (có thể bảng cuộn ảo).'};
  if(o.first!=='1')return {ok:false,reason:'Phải bấm ô điểm của học sinh STT 1 (đang chọn STT '+o.first+').'};
  for(let i=0;i<count;i++){
    let r=clean[i]; if(r.stt!==i+1)return {ok:false,reason:'STT không liên tục ở vị trí '+(i+1)};
    let cell=r.cells[o.index];let content=(cell?.innerText||'').trim();
    if(content!=='')return {ok:false,reason:'Đã có điểm hoặc nội dung ở STT '+r.stt+' ("'+content+'"). Chặn ghi đè.'};
    let locked=cell?.getAttribute('aria-disabled')==='true'||cell?.classList.contains('locked')||cell?.querySelector('[disabled]');
    if(locked)return {ok:false,reason:'Ô điểm STT '+r.stt+' bị khóa.'};
  }
  o.element.focus(); o.element.click();
  return {ok:true,index:o.index, count:count};
}'''


class ChromeBridge(threading.Thread):
    def __init__(self, requests, responses):
        super().__init__(daemon=True)
        self.requests=requests; self.responses=responses; self.ctx=None; self.pw=None

    def output(self, task, data=None, err=None):
        self.responses.put({'task':task, 'data':data, 'error':err})

    def page(self):
        if not self.ctx:raise RuntimeError('Chưa kết nối Chrome. Bấm MỞ CHROME VIETSCHOOL.')
        for p in reversed(self.ctx.pages):
            if DOMAIN in urlparse(p.url).netloc and not p.is_closed():return p
        raise RuntimeError('Không thấy tab VietSchool trong cửa sổ Chrome do Agent mở.')

    def run(self):
        from playwright.sync_api import sync_playwright
        while True:
            name, args=self.requests.get()
            if name=='stop':
                try:
                    if self.ctx:self.ctx.close()
                    if self.pw:self.pw.stop()
                except Exception: pass
                return
            try:
                if name=='connect':
                    if self.ctx is None:
                        self.pw=sync_playwright().start()
                        profile=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'chrome_agent_profile')
                        self.ctx=self.pw.chromium.launch_persistent_context(profile,channel='chrome',headless=False,
                            viewport={'width':1450,'height':950}, accept_downloads=False)
                        p=self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
                        if DOMAIN not in p.url:p.goto('https://nhapdiem.truonghocviet.vn/',wait_until='domcontentloaded',timeout=45000)
                    self.output(name,'Đã mở Chrome riêng cho Agent. Đăng nhập thủ công, rồi mở màn hình Nhập điểm.')
                elif name=='inspect':
                    self.output(name,self.page().evaluate(SNAPSHOT_JS))
                elif name=='arm':
                    self.page().evaluate(CAPTURE_JS)
                    self.output(name,'Đã bật chọn ô. Trong Chrome hãy nhấp vào ô điểm đầu tiên (STT 1) của cột cần nhập.')
                elif name=='target':
                    self.output(name,self.page().evaluate(TARGET_JS))
                elif name=='paste':
                    p=self.page()
                    chk=p.evaluate(PRECHECK_JS,{'count':args['count']})
                    if not chk.get('ok'):raise RuntimeError(chk.get('reason','Không thể kiểm tra ô điểm.'))
                    import pyperclip
                    pyperclip.copy(args['payload'])
                    # JavaScript confirm() must NEVER auto-accept. Ask user in native GUI.
                    def handle_dialog(dialog):
                        evt=threading.Event(); choice={'yes':False}
                        self.responses.put({'task':'dialog','message':dialog.message,'event':evt,'choice':choice})
                        if not evt.wait(90):
                            dialog.dismiss();return
                        if choice['yes']: dialog.accept()
                        else: dialog.dismiss()
                    p.once('dialog',handle_dialog)
                    p.bring_to_front()
                    p.keyboard.press('Control+V')
                    self.output(name,'Đã gửi lệnh dán. Kiểm tra điểm đã lưu trên VietSchool, không coi thao tác này là xác nhận lưu.')
                elif name=='diagnostic':
                    p=self.page()
                    info=p.evaluate('''() => ({url:location.href,title:document.title, tables:document.querySelectorAll('table').length,
                     tr:document.querySelectorAll('tr').length, roles:document.querySelectorAll('[role="row"]').length,
                     ag:document.querySelectorAll('.ag-row').length, wijmo:document.querySelectorAll('.wj-row').length,
                     editables:document.querySelectorAll('input:not([type=hidden]),[contenteditable]').length})''')
                    self.output(name,info)
                else: self.output(name,err='Lệnh không hợp lệ')
            except Exception as e:self.output(name,err=str(e))
