# HTB AI Agent v1.3 — Bé Bi

Thêm linh vật robot trắng/xanh dương trong cửa sổ tổng hợp.
Có lời chào theo trang, chuyển động nhún nhẹ và hiển thị tiến độ tác vụ.
Có nút tắt chuyển động, thu gọn và hiện lại. Không gọi thêm API.
Các Agent nhập điểm, đối chiếu, SBD/phòng thi, báo cáo/kế hoạch vẫn nằm trong cùng bộ.

Mở CHAY_HTB_AI_AGENT.bat như trước.

Kiểm thử: 96 ca unittest, 95 đạt, 1 bỏ qua do thiếu Chromium.
Đã kiểm tra cú pháp Python và định dạng PNG RGBA có nền trong suốt.
Chưa kiểm thử giao diện v1.3 trên Windows hoặc API/VietSchool thật.

Thiết kế ảnh và prompt: assets/BE_BI_THIET_KE.md.
