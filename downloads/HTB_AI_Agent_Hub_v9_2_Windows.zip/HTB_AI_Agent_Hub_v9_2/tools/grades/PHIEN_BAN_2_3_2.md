# HTB v2.3.2 — Ngoại lệ Trần Ngọc Khánh, 12A06

Theo yêu cầu, bỏ qua tất cả dòng họ tên Trần Ngọc Khánh trong lớp 12A06 ở cả đọc Excel, lập kế hoạch dán và kiểm tra cuối đợt. Không tự chọn một em theo ngày sinh. Với ảnh mẫu: STT 9 (08/07/2009) và 10 (19/04/2009) đều không vào clipboard; hai vùng dán tách tại khoảng 9–10.

Ghi nhật ký và báo cáo “Bỏ qua theo yêu cầu: trùng tên”; giữ nguyên điểm web. Học sinh khác nhập bình thường. Ngoại lệ không áp dụng lớp khác, và không bỏ kiểm tra các tên trùng khác. Vẫn nhập hết lớp mới kiểm tra cuối đợt.

Kiểm tra: 155 unittest, 154 đạt và một bỏ qua do thiếu Chromium. Kiểm tra Excel có hai tên trùng, tách vùng dán, phạm vi ngoại lệ và kết quả kiểm tra cuối đợt đều đạt. Chưa thử nhập điểm trên VietSchool thực tế.

Đóng bản cũ, giải nén, chạy CHAY_HTB_AI_AGENT.bat rồi chọn lại toàn bộ Excel. Không cần xóa hai em khỏi Excel. Ô đã có điểm vẫn được bỏ qua.
