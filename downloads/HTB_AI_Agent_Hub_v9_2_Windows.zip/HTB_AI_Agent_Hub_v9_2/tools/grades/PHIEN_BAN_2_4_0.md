# HTB v2.4.0 — Chuyển điểm từ nhiều Excel vào mẫu

Thêm trang và menu thứ tám Chuyển điểm vào mẫu. Nạp nhiều .xlsx, nhận diện họ tên hoặc ghép Họ/Tên, lớp và các cột điểm; chọn môn/cột nguồn cho từng file; chọn năm/học kỳ/cột đích chung. Xem trước rồi xuất một bản mẫu trống đã điền và hai trang nguồn/kiểm tra. Nút dùng file xuất chỉ chọn file và chuyển tab, không tự ghi điểm lên web.

Không ghi đè nguồn hoặc mẫu; chặn mẫu có danh sách sẵn; loại ví dụ và tránh nhập trùng các tab ghi nguồn. Điểm gốc giữ nguyên; thiếu dữ liệu hoặc trùng tên được ghi riêng. Giữ các tính năng trước, luồng nhập hết lớp rồi kiểm tra và ngoại lệ hai Trần Ngọc Khánh lớp 12A06.

Kiểm tra: 162 unittest, 161 đạt, một bỏ qua do thiếu Chromium; bảy kiểm tra chuyển Excel đạt. Thử ba file người dùng: 620 dòng hợp lệ và hai dòng bỏ qua theo quy tắc 12A06; mẫu thử đọc lại thành 17 nhóm, 620 ô. Chưa chạy giao diện mới trực tiếp trên Windows và chưa ghi điểm VietSchool thực tế.

Xem HUONG_DAN_CHUYEN_DIEM.md. Chạy CHAY_HTB_AI_AGENT.bat như trước.
