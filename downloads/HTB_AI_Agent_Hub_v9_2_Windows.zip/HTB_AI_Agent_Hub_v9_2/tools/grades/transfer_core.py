"""Local Excel sources -> a clean VietSchool input template; no browser actions."""
from collections import Counter
from copy import copy
from pathlib import Path
import re
from openpyxl import load_workbook
from base_agent import grade_string,rating_mode
from chrome_bridge import normalize_name
from skip_policy import requested_skip

ALIASES={
 'name':{'ho va ten','ho ten','ten hoc sinh','hoc sinh','fullname','full name'},
 'ho':{'ho','ho dem','ho va ten dem'},'ten':{'ten','ten goi'},
 'class':{'lop','lop hoc','class'},'subject':{'mon','mon hoc','subject'},
 'year':{'nam hoc','school year'},'term':{'hoc ky','hoc ki','term'},
 'status':{'trang thai','tinh trang','nghi hoc'},
}
GRADE_COLUMNS=['TX1','TX2','TX3','TX4','TX5','TX6','Giữa kỳ','Cuối kỳ']

def norm(value):return normalize_name(value)

def infer_subject(filename):
    name=norm(Path(filename).stem)
    if re.search(r'\bcnnn\b',name):return 'Công nghệ nông nghiệp'
    if re.search(r'\bcncn\b',name):return 'Công nghệ công nghiệp'
    if re.search(r'\btin\b',name):return 'Tin học'
    for token,subject in [('toan','Toán'),('van','Ngữ văn'),('vat li','Vật lí'),('hoa','Hóa học'),('sinh','Sinh học'),('lich su','Lịch sử'),('dia','Địa lí')]:
        if re.search(r'\b'+token+r'\b',name):return subject
    return ''

def header_info(ws):
    for rownum,row in enumerate(ws.iter_rows(max_row=20,values_only=True),1):
        values=[norm(v) for v in row]
        mapping={kind:next((i for i,v in enumerate(values) if v in variants),None) for kind,variants in ALIASES.items()}
        if mapping['name'] is not None or (mapping['ho'] is not None and mapping['ten'] is not None):
            scores=[(i,str(v).strip()) for i,v in enumerate(row) if v is not None and
                    ('diem' in norm(v) or re.fullmatch(r'tx\s*[1-6]',norm(v)) or norm(v) in {'giua ky','giua ki','cuoi ky','cuoi ki','score','nhan xet'})]
            return rownum,mapping,scores
    return None

def describe_file(path):
    wb=load_workbook(path,read_only=True,data_only=True)
    try:
        options=[];sheets=[]
        for ws in wb:
            info=header_info(ws)
            if info:
                sheets.append(ws.title)
                for _,header in info[2]:
                    if header not in options:options.append(header)
        if not sheets:raise ValueError('Không tìm thấy cột Họ và tên hoặc cặp Họ / Tên trong 20 dòng đầu.')
        return {'path':str(path),'subject':infer_subject(path),'score_header':options[0] if len(options)==1 else '',
                'score_options':options,'sheets':sheets}
    finally:wb.close()

def prepare_records(specs,year='2026-2027',term='HK1',column='Giữa kỳ',default_class=''):
    if column not in GRADE_COLUMNS:raise ValueError('Chọn cột điểm đích hợp lệ.')
    if not re.fullmatch(r'\d{4}-\d{4}',year.strip()):raise ValueError('Năm học phải có dạng 2026-2027.')
    if term not in ('HK1','HK2'):raise ValueError('Học kỳ phải là HK1 hoặc HK2.')
    records=[];issues=[]
    for spec in specs:
        path=Path(spec['path']);wb=load_workbook(path,read_only=True,data_only=True)
        try:
            for ws in wb:
                info=header_info(ws)
                if not info:continue
                start,mapping,scores=info
                choices=[i for i,label in scores if norm(label)==norm(spec.get('score_header',''))]
                if len(choices)!=1:
                    raise ValueError(f'{path.name} / {ws.title}: cần chọn duy nhất cột điểm nguồn, đang chọn {spec.get("score_header","")!r}.')
                score_index=choices[0]
                for number,row in enumerate(ws.iter_rows(min_row=start+1,values_only=True),start+1):
                    def get(kind):
                        index=mapping.get(kind)
                        return row[index] if index is not None and index<len(row) else None
                    name=str(get('name') or '').strip() or ' '.join(str(get(k) or '').strip() for k in ('ho','ten')).strip()
                    raw=row[score_index] if score_index<len(row) else None
                    if not name and raw is None:continue
                    clazz=str(get('class') or default_class or '').strip().upper()
                    subject=str(spec.get('subject') or get('subject') or '').strip()
                    record={'name':name,'class':clazz,'subject':subject,'term':term,'year':year.strip(),
                            'column':column,'raw':raw,'source':path.name,'sheet':ws.title,'row':number,'score':None}
                    reason=''
                    if not name:reason='Thiếu họ tên'
                    elif not re.fullmatch(r'(10|11|12)[A-Z][0-9]{1,2}',clazz):reason='Thiếu hoặc sai lớp; hãy nhập lớp mặc định nếu nguồn không có cột Lớp'
                    elif not subject:reason='Chưa xác định môn; chọn môn cho file này'
                    elif requested_skip(clazz,name):reason='Bỏ qua theo yêu cầu: Trần Ngọc Khánh lớp 12A06'
                    elif norm(get('status')) in {'nghi','nghi hoc','da nghi','chuyen truong'}:reason='Học sinh nghỉ/chuyển trường'
                    elif raw is None or (isinstance(raw,str) and not raw.strip()):reason='Điểm nguồn trống'
                    if not reason:
                        try:record['score']=grade_string(raw,rating_mode(subject))
                        except ValueError as exc:reason=str(exc)
                    if reason:issues.append({**record,'reason':reason})
                    else:records.append(record)
        finally:wb.close()
    counts=Counter((norm(r['name']),r['class'],norm(r['subject']),r['term'],r['year'],r['column']) for r in records)
    good=[]
    for record in records:
        key=(norm(record['name']),record['class'],norm(record['subject']),record['term'],record['year'],record['column'])
        if counts[key]>1:issues.append({**record,'reason':'Trùng họ tên + lớp + môn + học kỳ + cột; bỏ tất cả dòng trùng, không tự chọn điểm'})
        else:good.append(record)
    return good,issues

def export_template(records,issues,template_path,output_path):
    if not records:raise ValueError('Chưa có dòng hợp lệ để xuất; xem các dòng cần kiểm tra.')
    output=Path(output_path).resolve();template=Path(template_path).resolve()
    if output==template:raise ValueError('Chọn tên file xuất khác mẫu gốc.')
    wb=load_workbook(template)
    try:
        ws=wb['NHAP_DIEM'] if 'NHAP_DIEM' in wb.sheetnames else wb.active
        info=header_info(ws)
        if not info:raise ValueError('Mẫu không có tiêu đề Họ và tên hoặc Họ/Tên.')
        header,fields,_=info
        if any(fields[k] is None for k in ('name','class','subject','term','year')):
            raise ValueError('Mẫu cần Họ và tên, Lớp, Môn học, Học kỳ, Năm học.')
        labels={norm(c.value):c.column for c in ws[header] if c.value is not None}
        target={c:labels.get(norm(c)) for c in GRADE_COLUMNS}
        for row in records:
            if not target.get(row['column']):raise ValueError('Mẫu thiếu cột '+row['column'])
        if any(ws.cell(i,fields['name']+1).value not in (None,'') for i in range(header+1,ws.max_row+1)):
            raise ValueError('File mẫu đã có danh sách học sinh. Hãy dùng mẫu trống để tránh thay thế dữ liệu sẵn có.')
        styles=[copy(ws.cell(header+1,c)._style) for c in range(1,ws.max_column+1)]
        if ws.max_row>header:ws.delete_rows(header+1,ws.max_row-header)
        # Example data must never become jobs when the user loads this workbook.
        for other in list(wb):
            if other is not ws and (header_info(other) or other.title in {'NGUON_DIEM','CAN_KIEM_TRA'}):wb.remove(other)
        for i,record in enumerate(records,header+1):
            for col,style in enumerate(styles,1):ws.cell(i,col)._style=copy(style)
            def put(col,value):
                cell=ws.cell(i,col,value)
                if isinstance(value,str):cell.data_type='s'
            for key in ('name','class','subject','term','year'):put(fields[key]+1,record[key])
            if 'stt' in labels:put(labels['stt'],i-header)
            value=record['score']
            put(target[record['column']],value if value in ('Đ','CĐ') else float(value))
            if value not in ('Đ','CĐ'):ws.cell(i,target[record['column']]).number_format='0.00'
            if 'ghi chu' in labels:put(labels['ghi chu'],f"{record['source']} / {record['sheet']} / dòng {record['row']}")
        for row in ws.iter_rows(max_row=header-1):
            for cell in row:
                if isinstance(cell.value,str) and 'tối đa 1 chữ số thập phân' in cell.value:
                    cell.value=cell.value.replace('tối đa 1 chữ số thập phân','tối đa 2 chữ số thập phân; khi dán VietSchool, ứng dụng làm tròn 1 chữ số')
        ws.freeze_panes=f'A{header+1}'
        ws.auto_filter.ref=f'A{header}:{ws.cell(header+len(records),ws.max_column).coordinate}'
        for title,rows in [('NGUON_DIEM',records),('CAN_KIEM_TRA',issues)]:
            out=wb.create_sheet(title)
            # No source-reader identity/scope headers: these audit sheets cannot
            # be misread as a second set of VietSchool import jobs.
            heads=['Tệp nguồn','Trang nguồn','Dòng nguồn','Tên nguồn','Lớp nguồn','Môn nguồn','Giá trị gốc','Giá trị xuất / lý do']
            out.append(heads)
            for record in rows:
                values=[record['source'],record['sheet'],record['row'],record['name'],record['class'],record['subject'],record['raw'],record.get('reason',record.get('score'))]
                out.append(values)
                for cell in out[out.max_row]:
                    if isinstance(cell.value,str):cell.data_type='s'
            out.freeze_panes='A2';out.auto_filter.ref=out.dimensions
            for letter,width in [('A',30),('B',20),('C',14),('D',30),('E',14),('F',28),('G',18),('H',65)]:out.column_dimensions[letter].width=width
        wb.save(output)
        return output
    finally:wb.close()
