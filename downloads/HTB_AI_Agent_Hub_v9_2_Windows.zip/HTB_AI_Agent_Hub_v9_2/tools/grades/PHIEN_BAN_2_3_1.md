# HTB v2.3.1 — Nhập hết lớp rồi kiểm tra cuối đợt

Đổi thứ tự theo yêu cầu: nhập và xác nhận lưu toàn bộ các nhóm trước. Không tải lại sau mỗi lớp/vùng. Sau khi nhập thành công hết nhóm, tự chạy bộ đối chiếu chỉ đọc: tải lại một lần, duyệt tất cả nhóm, đọc hai lần ổn định và ghi báo cáo.

Sai lệch trong giai đoạn đối chiếu được ghi cho từng lớp rồi tiếp tục kiểm tra các lớp khác. Khi hết danh sách, báo tổng hợp. Không tự sửa điểm. Lỗi chưa xác nhận lưu trong giai đoạn nhập vẫn dừng trước khi chuyển lớp; lúc đó báo cáo thể hiện các ô đã lưu còn chờ kiểm tra cuối đợt.

Báo cáo CSV có phase phân biệt Nhập điểm/Kiểm tra cuối đợt và expected/actual/result/reason. UI hiển thị kết quả riêng từng nhóm ở lượt kiểm tra. Giữ tự đăng nhập, đúng tên mới dán và bỏ qua học sinh nghỉ/tên không tìm thấy.

Kiểm tra: 151 unittest, 150 đạt, một bỏ qua vì thiếu Chromium. Kiểm tra thứ tự nhập tất cả trước kiểm tra, không reload khi nhập, reload một lần khi kiểm tra, tiếp tục rà lớp khác khi sai và báo chưa kiểm tra khi tải lại thất bại đều đạt. Mô phỏng DOM/Progrid đạt. Chưa xác nhận trên VietSchool thực tế.

Chạy: đóng bản cũ, giải nén bản mới, mở CHAY_HTB_AI_AGENT.bat, chọn Excel. Không cần bấm Đối chiếu riêng.
