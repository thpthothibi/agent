const {JSDOM}=require(process.env.HTB_JSDOM_MODULE || 'jsdom');
const assert=require('node:assert/strict');
const fs=require('fs');
const code=fs.readFileSync(0,'utf8');
function fixture(count=5, scoreCount=count, ids=false, reversed=false){
 const nums=Array.from({length:count},(_,i)=>i+1);
 const scores=Array.from({length:scoreCount},(_,i)=>i+1);
 if(reversed)scores.reverse();
 const cell=(t,x,y,w)=>`<td data-x="${x}" data-y="${y}" data-w="${w}">${t}</td>`;
 const html='<div id="grid"><table data-panel="ids">'+nums.map((n,i)=>'<tr '+(ids?`data-row-index="${n}"`:'')+'>'+[cell(n,0,80+i*61,40),cell('Nguyễn',40,80+i*61,160),cell('Tên '+n,200,80+i*61,90),cell('01/01/2010',290,80+i*61,120)].join('')+'</tr>').join('')+'</table><table data-panel="scores">'+scores.map((n,i)=>'<tr '+(ids?`data-row-index="${n}"`:'')+'>'+[cell(String(n),410,80+i*45,60),cell('',470,80+i*45,60),cell(String(n)+'.5',530,80+i*45,60)].join('')+'</tr>').join('')+'</table></div>';
 const dom=new JSDOM(html,{runScripts:'outside-only'}),w=dom.window;
 w.HTMLElement.prototype.getBoundingClientRect=function(){
  const x=Number(this.dataset.x||0),y=Number(this.dataset.y||0),width=Number(this.dataset.w||600),height=this.tagName==='TD'?(this.closest('table').dataset.panel==='ids'?61:45):600;
  return {x,y,left:x,top:y,width,height,right:x+width,bottom:y+height};
 };
 w.document.elementFromPoint=undefined;
 return {w,read:()=>w.eval('('+code+')')({op:'snapshot_all'})};
}
let f=fixture(),r=f.read();
assert.equal(r.rows.length,5);
assert.deepEqual(Array.from(r.rows,x=>x.cells[4]),['1','2','3','4','5']);
assert.deepEqual(Array.from(r.rows,x=>x.cells[6]),['1.5','2.5','3.5','4.5','5.5']);
f=fixture(5,5,true,true);r=f.read();
assert.deepEqual(Array.from(r.rows,x=>x.cells[4]),['1','2','3','4','5']);
assert.throws(()=>fixture(5,4).read(),/lệch số hàng/);
f=fixture(5,5,true);f.w.document.querySelector('[data-panel="scores"] tr').setAttribute('data-row-index','99');
assert.throws(()=>f.read(),/Không khớp mã hàng/);
f=fixture();f.w.document.querySelector('[data-panel="scores"] tr').removeChild(f.w.document.querySelector('[data-panel="scores"] td'));
assert.throws(()=>f.read(),/chưa đủ các ô cột/);
f=fixture();f.w.document.querySelector('[data-panel="ids"] tr td').textContent='27';
assert.throws(()=>f.read(),/Chưa đọc đủ danh sách/);
f=fixture();f.w.document.querySelectorAll('[data-panel="scores"] tr')[1].children[0].dataset.x='480';
assert.throws(()=>f.read(),/Vị trí cột/);

function progrid(f){for(const t of f.w.document.querySelectorAll('table'))t.className='progrid-btable';return f}
// Replay the supplied diagnostic: both Progrid tables have 47 physical rows;
// one DOB is blank, so the previous reader incorrectly compressed to 46/47.
f=progrid(fixture(47));f.w.document.querySelectorAll('[data-panel="ids"] tr')[23].children[3].textContent='';
r=f.read();assert.equal(r.rows.length,47);assert.equal(r.rows[23].stt,24);assert.equal(r.rows[23].dob,'');
assert.equal(r.rows[24].cells[4],'25');assert.equal(r.rows[46].cells[4],'47');
f=progrid(fixture());f.w.document.querySelectorAll('[data-panel="ids"] tr')[1].children[3].textContent='2010-01-01';
r=f.read();assert.equal(r.rows.length,5);assert.equal(r.rows[2].cells[4],'3');
f=progrid(fixture());let row=f.w.document.querySelectorAll('[data-panel="ids"] tr')[2];row.children[1].textContent='';row.children[2].textContent='';
r=f.read();assert.equal(r.rows.length,5);assert.equal(r.rows[2].name,'');assert.equal(r.rows[3].cells[4],'4');
f=progrid(fixture());f.w.document.querySelectorAll('[data-panel="scores"] tr')[2].children[0].textContent='lỗi lưu';
r=f.read();assert.equal(r.rows.length,5);assert.equal(r.rows[2].cells[4],'lỗi lưu');assert.equal(r.rows[3].cells[4],'4');
f=progrid(fixture());let header=f.w.document.createElement('table');header.className='progrid-htable';header.innerHTML='<tr><td data-x="410">1</td><td data-x="470">2</td></tr><tr><td data-x="410">3</td><td data-x="470">4</td></tr>';f.w.document.querySelector('#grid').appendChild(header);
r=f.read();assert.equal(r.rows.length,5);
f=progrid(fixture(47,46));assert.throws(()=>f.read(),/lệch số hàng/);

for(const position of [0,23,46]){
 f=progrid(fixture(46));
 for(const panel of ['ids','scores']){
   const body=f.w.document.querySelector('[data-panel="'+panel+'"] tbody');
   const blank=f.w.document.createElement('tr');blank.innerHTML=panel==='ids'?'<td colspan="4">&nbsp;</td>':'<td colspan="3">&nbsp;</td>';
   body.insertBefore(blank,body.children[position]||null);
 }
 r=f.read();assert.equal(r.rows.length,46);assert.equal(r.rows[45].cells[4],'46');
}
f=progrid(fixture(46));for(const panel of ['ids','scores'])f.w.document.querySelector('[data-panel="'+panel+'"] tbody').prepend(f.w.document.createElement('tr'));
r=f.read();assert.equal(r.rows.length,46);
// Real Progrid pane hierarchy, merged headers, independently scrolled body:
f=progrid(fixture());
for(const panel of ['ids','scores']){
 const body=f.w.document.querySelector('[data-panel="'+panel+'"]'),pane=f.w.document.createElement('div');
 body.replaceWith(pane);pane.append(body);
 const h=f.w.document.createElement('table');h.className='progrid-htable';
 h.innerHTML=panel==='ids'?'<tr><td rowspan="2">STT</td><td rowspan="2">Họ</td><td rowspan="2">Tên</td><td rowspan="2">Ngày sinh</td></tr><tr></tr>':'<tr><td colspan="2">Điểm ĐGTX</td><td rowspan="2">ĐGK</td></tr><tr><td>1</td><td>2</td></tr>';
 pane.prepend(h);
}
r=f.read();assert.deepEqual(Array.from(r.headerPaths),['STT','Họ','Tên','Ngày sinh','Điểm ĐGTX 1','Điểm ĐGTX 2','ĐGK']);
let headers=f.w.eval('('+code+')')({op:'headers'});assert.equal(headers[0][0][6].text,'ĐGK');
// A non-empty right row opposite an identity placeholder must never be guessed.
f=progrid(fixture());f.w.document.querySelector('[data-panel="ids"] tr').innerHTML='<td colspan="4"></td>';
assert.throws(()=>f.read(),/chưa có STT/);
console.log('19 DOM scenarios passed: blank sizing slots, 47/46 physical/student rows, merged Progrid headers, missing data and row identity checks.');
