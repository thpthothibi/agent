# -*- coding: utf-8 -*-
"""Shared visual components. Worker/navigation logic stays in existing modules."""
import os
import queue
FONT="Segoe UI" if os.name=="nt" else "DejaVu Sans"
import tkinter as tk
from tkinter import ttk

BG='#F3F6FB'
WHITE='#FFFFFF'
INK='#152B4D'
MUTED='#6B7C93'
BLUE='#2563EB'
LINE='#DFE7F2'
NAVY='#102B50'


def label(parent,text='',size=11,color=INK,bg=None,bold=False,**kw):
    return tk.Label(parent,text=text,font=(FONT,size,'bold' if bold else 'normal'),fg=color,bg=bg or parent.cget('bg'),**kw)


def card(parent,padx=20,pady=18,bg=WHITE):
    return tk.Frame(parent,bg=bg,highlightthickness=1,highlightbackground=LINE,padx=padx,pady=pady)


def button(parent,text,command,primary=False):
    return ttk.Button(parent,text=text,command=command,style='Primary.TButton' if primary else 'Secondary.TButton')


def configure(root):
    s=ttk.Style(root);s.theme_use('clam')
    s.configure('.',font=(FONT,10),background=BG,foreground=INK)
    s.configure('TFrame',background=BG)
    s.configure('TLabel',background=WHITE)
    s.configure('TButton',font=(FONT,10,'bold'),padding=(16,10),borderwidth=0)
    s.configure('Primary.TButton',background=BLUE,foreground=WHITE)
    s.map('Primary.TButton',background=[('disabled','#DFE7F2'),('pressed','#1D4ED8'),('active','#3476F5')],foreground=[('disabled','#8A99AF')])
    s.configure('Secondary.TButton',background='#EAF0F8',foreground='#27466F')
    s.map('Secondary.TButton',background=[('disabled','#F1F4F8'),('active','#DCE7F5')],foreground=[('disabled','#A5B1C2')])
    s.configure('Danger.TButton',background='#FFF1F1',foreground='#B84242')
    s.map('Danger.TButton',background=[('disabled','#F4F6F9'),('active','#FFE1E1')],foreground=[('disabled','#A5B1C2')])
    s.configure('Horizontal.TProgressbar',background=BLUE,troughcolor='#E8EFF9',borderwidth=0,lightcolor=BLUE,darkcolor=BLUE)
    s.configure('Treeview',background=WHITE,fieldbackground=WHITE,foreground=INK,rowheight=34,borderwidth=0,font=(FONT,10))
    s.configure('Treeview.Heading',background='#EDF3FB',foreground='#466185',font=(FONT,10,'bold'),padding=(8,10),relief='flat')
    s.map('Treeview',background=[('selected','#DDEAFE')],foreground=[('selected','#164491')])
    s.configure('TScrollbar',background='#D6E1EE',troughcolor='#F1F5FA',borderwidth=0,arrowsize=12)


class ScrollPage(tk.Frame):
    """Page scroll keeps actions reachable on small laptop displays."""
    def __init__(self,parent):
        super().__init__(parent,bg=BG)
        self.canvas=tk.Canvas(self,bg=BG,highlightthickness=0)
        bar=ttk.Scrollbar(self,orient='vertical',command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=bar.set)
        bar.pack(side='right',fill='y');self.canvas.pack(side='left',fill='both',expand=True)
        self.content=tk.Frame(self.canvas,bg=BG,padx=28,pady=22)
        self.window=self.canvas.create_window((0,0),window=self.content,anchor='nw')
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(self.window,width=e.width))
        self.content.bind('<Configure>',lambda e:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        # Only scroll this page when the pointer is over its non-scrollable content.
        self.canvas.bind_all('<MouseWheel>',self.wheel,add='+')

    def wheel(self,event):
        if not self.winfo_ismapped():return
        current=self.winfo_containing(event.x_root,event.y_root)
        if isinstance(current,(tk.Text,ttk.Treeview)):return
        while current is not None:
            if current is self:
                self.canvas.yview_scroll(int(-event.delta/120),'units');return
            current=getattr(current,'master',None)


def build_workspace(app,root,hub,checking=False):
    app.root=root;app.hub=hub;app.events=queue.Queue();app.worker=None;app.cancel_event=None
    app.busy=False;app.stopping=False;app.start=0;app.last_event=0
    app.last_message='Chọn file Excel, sau đó bấm bắt đầu.'
    app.filevar=tk.StringVar(value='Chưa có phiên làm việc')
    app.status=tk.StringVar(value=app.last_message)
    app.clock=tk.StringVar(value='')
    app.roster_label=tk.StringVar(value='Kết quả sẽ xuất hiện khi đọc được bảng điểm VietSchool.')
    app.row_ids={}
    top=card(root);top.pack(fill='x',pady=(0,16))
    label(top,'ĐỐI CHIẾU ĐIỂM' if checking else 'NHẬP ĐIỂM VIETSCHOOL',size=10,color=BLUE,bold=True).pack(anchor='w')
    label(top,'Kiểm tra lại để yên tâm' if checking else 'Từ Excel đến bảng điểm',size=23,bold=True).pack(anchor='w',pady=(6,5))
    label(top,'Tải lại trang • Đọc điểm đã lưu • So sánh và xuất báo cáo' if checking else 'Đọc Excel • Chọn lớp và môn • Dò học sinh • Nhập và kiểm tra',color=MUTED).pack(anchor='w')
    if checking:
        picker=card(top,padx=14,pady=12,bg='#F0F6FF');picker.pack(fill='x',pady=(16,0))
        label(picker,'1. CHỌN EXCEL ĐỐI CHIẾU',size=10,color=BLUE,bold=True).pack(anchor='w')
        pickrow=tk.Frame(picker,bg='#F0F6FF');pickrow.pack(fill='x',pady=(10,6))
        button(pickrow,'Chọn Excel đối chiếu…',hub.browse,True).pack(side='left',padx=(0,12))
        ttk.Entry(pickrow,textvariable=hub.path,state='readonly').pack(side='left',fill='x',expand=True)
        tk.Label(picker,textvariable=hub.file_name,bg='#F0F6FF',fg=INK,font=(FONT,10),anchor='w',wraplength=720,justify='left').pack(fill='x')
        label(picker,'Chọn file .xlsx trên máy, rồi bấm Bắt đầu đối chiếu bên dưới. File này dùng chung với tab Nhập điểm.',size=9,color=MUTED,wraplength=720,justify='left').pack(anchor='w',pady=(6,0))
    controls=tk.Frame(top,bg=WHITE);controls.pack(fill='x',pady=(18,0))
    app.load=button(controls,'Bắt đầu đối chiếu  →' if checking else 'Bắt đầu nhập điểm  →',app.choose,True)
    app.load.pack(side='left')
    app.stop=ttk.Button(controls,text='Dừng tác vụ',command=app.stop_run,style='Danger.TButton',state='disabled');app.stop.pack(side='left',padx=10)
    if not checking:button(controls,'Đổi file Excel',hub.browse).pack(side='left')
    if not checking:
        fileline=tk.Frame(top,bg='#F5F8FD',padx=12,pady=10);fileline.pack(fill='x',pady=(16,0))
        label(fileline,'EXCEL',size=9,color=BLUE,bold=True).pack(side='left',padx=(0,12))
        tk.Label(fileline,textvariable=hub.file_name,font=(FONT,10),fg=INK,bg='#F5F8FD',anchor='w',wraplength=680).pack(side='left',fill='x',expand=True)
    note='Đối chiếu chỉ đọc điểm. Những ô sai hoặc chưa kiểm tra được có trong báo cáo.' if checking else 'Ô đã có điểm, ô khóa và học sinh nghỉ được bỏ qua. Đăng nhập trong Chrome Agent khi được yêu cầu.'
    label(top,note,size=10,color=MUTED,wraplength=790,justify='left').pack(anchor='w',pady=(12,0))
    progressbox=card(root,pady=14);progressbox.pack(fill='x',pady=(0,16))
    label(progressbox,'TRẠNG THÁI TÁC VỤ',size=9,color=MUTED,bold=True).pack(anchor='w')
    tk.Label(progressbox,textvariable=app.status,bg=WHITE,fg=INK,font=(FONT,11),wraplength=790,justify='left',anchor='w').pack(fill='x',pady=8)
    app.progress=ttk.Progressbar(progressbox,mode='indeterminate');app.progress.pack(fill='x')
    tk.Label(progressbox,textvariable=app.clock,bg=WHITE,fg=MUTED,font=(FONT,9)).pack(anchor='w',pady=(5,0))
    results=card(root,padx=0,pady=0);results.pack(fill='both',expand=True,pady=(0,16))
    title=tk.Frame(results,bg=WHITE,padx=18,pady=14);title.pack(fill='x')
    label(title,'Kết quả đối chiếu' if checking else 'Danh sách xử lý',size=13,bold=True).pack(anchor='w')
    tk.Label(title,textvariable=app.roster_label,bg=WHITE,fg=MUTED,font=(FONT,9),wraplength=780,justify='left').pack(anchor='w',pady=(5,0))
    pane=tk.Frame(results,bg=WHITE);pane.pack(fill='both',expand=True)
    columns=[('stt','STT',52),('name','Họ và tên',210),('grade','Excel' if checking else 'Điểm',68)]
    if checking:columns.append(('actual','VietSchool',115))
    columns.append(('status','Trạng thái / Chi tiết',350))
    app.roster=ttk.Treeview(pane,columns=tuple(c[0] for c in columns),show='headings',height=7)
    for key,text,width in columns:
        app.roster.heading(key,text=text);app.roster.column(key,width=width,minwidth=48,anchor='center' if key in ('stt','grade','actual') else 'w',stretch=key in ('name','status'))
    y=ttk.Scrollbar(pane,orient='vertical',command=app.roster.yview)
    x=ttk.Scrollbar(results,orient='horizontal',command=app.roster.xview)
    app.roster.configure(yscrollcommand=y.set,xscrollcommand=x.set)
    y.pack(side='right',fill='y');app.roster.pack(fill='both',expand=True);x.pack(fill='x')
    for tag,color,bg in [('retired','#B14343','#FFF3F2'),('existing','#3868A2','#F0F6FF'),('done','#16734C','#EDFAF3')]:
        app.roster.tag_configure(tag,foreground=color,background=bg)
    logs=card(root,pady=14);logs.pack(fill='both',expand=True)
    toolbar=tk.Frame(logs,bg=WHITE);toolbar.pack(fill='x',pady=(0,10))
    label(toolbar,'Nhật ký hoạt động',size=12,bold=True).pack(side='left')
    button(toolbar,'Mở báo cáo  ↗',hub.reports).pack(side='right')
    logwrap=tk.Frame(logs,bg=WHITE);logwrap.pack(fill='both',expand=True)
    app.log=tk.Text(logwrap,height=7,wrap='word',font=('Consolas',10),state='disabled',bg='#F7FAFE',fg='#44607F',relief='flat',padx=12,pady=12,highlightthickness=0)
    scroll=ttk.Scrollbar(logwrap,command=app.log.yview);app.log.configure(yscrollcommand=scroll.set)
    scroll.pack(side='right',fill='y');app.log.pack(fill='both',expand=True)
    root.after(150,app.poll)
