import queue
import threading
import unittest
from unittest.mock import Mock
from base_agent import vietschool_value
from auto_core import grade_batch_state
from full_auto import AutoWorker
from compare_core import compare_rows


class MultiClassRoundingTests(unittest.TestCase):
    def test_platform_half_up_rules(self):
        for src,dst in [('8.75','8.8'),('6,25','6.3'),('7.25','7.3'),('7.05','7.1'),('0.05','0.1'),('8.74','8.7'),('10','10')]:
            self.assertEqual(vietschool_value(src),dst)
        self.assertEqual(vietschool_value('CĐ','comment'),'CĐ')

    def simulate(self,first_saved=False):
        w=AutoWorker('',queue.Queue(),threading.Event())
        w.page=Mock(return_value=Mock());w.tick=Mock();w.scope_is_selected=Mock()
        w.prepare_grid=Mock();w.headers=Mock(return_value=4);w.dom=Mock(return_value='bound')
        jobs=[{'year':'2026-2027','class':c,'subject':'Vật lí','term':'Học kỳ 1','column':'Giữa kỳ',
               'rows':[dict(student='Winnie',row=9,sheet='NHAP_DIEM',dob='',**{'Giữa kỳ':score})]}
              for c,score in [('10A01','8.75'),('10A02','6.25')]]
        sites={c:[dict(stt=1,name='Winnie',dob='',cells=['1','','Winnie','',''],saved=[True]*5)] for c in ['10A01','10A02']}
        if first_saved:sites['10A01'][0]['cells'][4]='8.8'
        current={};sent=[]
        def navigate(job,assessment):current['class']=job['class']
        w.navigate=navigate;w.grid=lambda:(None,{})
        w.collect=lambda *a,**kw:sites[current['class']]
        def paste(frame,batch,index,job,assessment):
            site=sites[job['class']]
            site[0]['cells'][index]=vietschool_value(batch[0]['value'])
            self.assertTrue(grade_batch_state(site,batch,index)['saved'])
            sent.append(job['class'])
        w.paste=paste;w.verify_all_jobs=Mock();w.process_jobs(jobs)
        self.assertEqual([compare_rows(j,sites[j['class']],4)[0]['result'] for j in jobs],['Đúng','Đúng'])
        return w,sent

    def test_saved_first_batch_continues_to_second_class(self):
        worker,sent=self.simulate()
        self.assertEqual(sent,['10A01','10A02'])
        self.assertEqual(worker.total,2)
        self.assertEqual([(r['original'],r['value']) for r in worker.audit],[('8.75','8.8'),('6.25','6.3')])

    def test_restart_skips_saved_class_and_continues(self):
        worker,sent=self.simulate(first_saved=True)
        self.assertEqual(sent,['10A02'])
        self.assertEqual(worker.total,1)


if __name__=='__main__':unittest.main()
