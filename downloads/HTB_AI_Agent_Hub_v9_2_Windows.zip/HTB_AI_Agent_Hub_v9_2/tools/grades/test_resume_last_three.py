import queue, threading, unittest
from unittest.mock import Mock
from full_auto import AutoWorker

class ResumeLastThreeTests(unittest.TestCase):
    def run_roster(self, existing, retired_cells_missing=False):
        w=AutoWorker('',queue.Queue(),threading.Event());w.page=Mock(return_value=Mock());w.tick=Mock();w.scope_is_selected=Mock()
        site=[];excel=[]
        for i in range(1,48):
            retired=i in (4,44)
            value='Đ' if not retired and i in existing else ''
            site.append({'stt':i,'name':f'Học sinh {i}','dob':'01/01/2011','cells':[str(i),'Học sinh',str(i),'01/01/2011','','','',value], 'locks':[False]*8,'inactive':retired,'inactiveReason':'Họ/tên/ngày sinh đỏ' if retired else ''})
            if retired and retired_cells_missing:
                site[-1]['cells']=site[-1]['cells'][:4]
                site[-1]['locks']=[]
            if not retired:excel.append({'student':f'Học sinh {i}','row':i+7,'Giữa kỳ':'Đ'})
        f=Mock();w.navigate=Mock();w.prepare_grid=Mock();w.grid=Mock(return_value=(f,{'rows':site}));w.collect=Mock(return_value=site);w.headers=Mock(return_value=7);w.dom=Mock(return_value='registered-physical-GK-cells');w.paste=Mock()
        job={'class':'10A06','subject':'GDĐP','column':'Giữa kỳ','rows':excel}
        w.process_job(job,1,9)
        return w, site

    def test_skips_42_existing_and_two_retired_then_sends_only_45_to_47(self):
        w,site=self.run_roster(set(range(1,45)))
        self.assertEqual(w.total,3);self.assertEqual(w.paste.call_count,1)
        self.assertEqual([r['stt'] for r in w.paste.call_args.args[1]],[45,46,47])
        linked=[c for c in w.dom.call_args_list if c.args[1]=='bind_column']
        self.assertEqual([r['stt'] for r in linked[0].kwargs['run']],[45,46,47])
        events=[]
        while not w.events.empty():events.append(w.events.get())
        plan=next(payload['rows'] for kind,payload in events if kind=='roster')
        self.assertEqual(sum(r['status']=='Bỏ qua: web đã có điểm' for r in plan),42)
        self.assertEqual([r['stt'] for r in plan if r['status']=='Bỏ qua: học sinh nghỉ'],[4,44])
        self.assertEqual(sum(bool(r['cells'][7]) for r in site),42)

    def test_full_class_continues_after_both_retired_rows_with_missing_score_cells(self):
        w,site=self.run_roster(set(),retired_cells_missing=True)
        sent=[[r['stt'] for r in call.args[1]] for call in w.paste.call_args_list]
        self.assertEqual(sent,[list(range(1,4)),list(range(5,44)),list(range(45,48))])
        self.assertEqual(w.total,45)
        self.assertEqual(len(w.audit),47)
        self.assertEqual([r['stt'] for r in w.audit if r['result']=='Bỏ qua: học sinh nghỉ'],[4,44])
        for call in w.paste.call_args_list:
            self.assertTrue(all(r['name']==f'Học sinh {r["stt"]}' for r in call.args[1]))

    def test_resume_after_retired_row_even_when_it_has_no_score_cells(self):
        w,_=self.run_roster(set(range(1,45)),retired_cells_missing=True)
        self.assertEqual([[r['stt'] for r in call.args[1]] for call in w.paste.call_args_list],[[45,46,47]])

if __name__=='__main__':unittest.main()

