# HTB v2.2.4 — Dò tên, không thấy tự bỏ qua

Theo yêu cầu mới: chỉ dán cho các họ tên khớp duy nhất giữa Excel và web. Bộ chuẩn hóa tên hiện có xử lý khoảng trắng, hoa/thường, dấu; không dò gần đúng, không lấy STT Excel để gán người khác. Không tìm được tên ở bên kia thì ghi dòng bỏ qua, không dừng toàn bộ lớp. Dòng Excel không có tên web không có STT đích và không bao giờ được đưa vào clipboard.

Các dòng web không có Excel, học sinh nghỉ và ô khóa vẫn là khoảng cách tách vùng dán. Khi không có tên nào khớp, nhóm được bỏ qua hoàn toàn rồi chuyển nhóm kế tiếp. Chưa đọc được bảng, STT web không liên tục, tên trùng, sai cột hoặc danh tính thay đổi vẫn bị chặn.

Kiểm tra: 145 unittest, 144 đạt, một bỏ qua vì chưa có Chromium. Ca có tên không tìm thấy, tên gần giống không được ghép, không có tên nào khớp và quét tới cuối danh sách đều đạt. Chưa thử trên VietSchool thực tế.

Đóng bản cũ, giải nén, chạy CHAY_HTB_AI_AGENT.bat và chọn Excel. Xem báo cáo để biết các tên bỏ qua. Giữ tự đăng nhập và các công cụ HTB.
