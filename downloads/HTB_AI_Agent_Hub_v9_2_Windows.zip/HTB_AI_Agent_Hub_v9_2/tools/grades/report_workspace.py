"""Report agent embedded in the existing Tk desktop hub."""
import json
import os
import queue
import threading
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
from desktop_ui import label, card, button, FONT, BG, WHITE, INK, MUTED, BLUE
from report_engine import generate, extract, research_prompt, draft_prompt, to_docx, unique_sources


def run_pipeline(config, emit, cancelled, generate_fn=generate):
    """No UI calls here: one immutable snapshot per job, queued incremental results."""
    def check():
        if cancelled.is_set():
            raise InterruptedError('Đã dừng trước bước tiếp theo; yêu cầu API đang gửi không bị thu hồi.')

    def call(provider, prompt, search=False):
        check()
        key, model = config['providers'][provider]
        return generate_fn(provider, key, model, prompt, search)

    emit('status', 'Đang đọc tài liệu…')
    check()
    template_path = config['template']
    template = extract(Path(template_path).name, Path(template_path).read_bytes()) if template_path else ''
    evidence = config['notes']
    for path in config['files']:
        check()
        evidence += '\n\nTệp: ' + Path(path).name + '\n' + extract(Path(path).name, Path(path).read_bytes())
    if len(template) + len(evidence) > 180000:
        raise ValueError('Tổng tài liệu tối đa 180.000 ký tự; vui lòng chia nhỏ.')
    research, sources, review = '', [], ''
    if config['search']:
        emit('status', 'Đang tìm nguồn công khai trên web…')
        r = call(config['researcher'], research_prompt(config['topic'], config['kind'], config['unit'], config['period']), True)
        research, sources = r.text, r.sources
        emit('research', {'text': research, 'sources': sources})
        if not r.searched:
            emit('warning', 'Nhà cung cấp chưa trả bằng chứng tìm web. Nguồn cần được xác minh.')
    check()
    emit('status', 'Đang soạn văn bản theo tài liệu…')
    prompt = draft_prompt(config['topic'], config['kind'], config['unit'], config['period'],
                          config['requirements'], template, evidence,
                          research + '\n' + json.dumps(sources, ensure_ascii=False))
    draft = call(config['writer'], prompt).text
    # Deliver draft before review: review failure/cancellation cannot erase successful work.
    emit('draft', draft)
    if config['review']:
        check()
        emit('status', 'Đang rà soát dự thảo…')
        try:
            review = call(config['reviewer'], 'Chỉ nhận xét, không viết lại toàn văn. Đối chiếu số liệu, bố cục, nguồn; '
                          'nêu thông tin thiếu và điều chưa kiểm chứng. Không khẳng định đã tra web độc lập.\n'
                          + prompt + '\nDỰ THẢO:\n' + draft).text
        except RuntimeError as exc:
            review = 'Chưa rà soát được: ' + str(exc) + '. Dự thảo đã được giữ lại.'
        emit('review', review)
    return {'draft': draft, 'research': research, 'sources': sources, 'review': review,
            'topic': config['topic'], 'created': datetime.now().isoformat()}


class ReportWorkspace:
    def __init__(self, root, hub):
        self.root, self.hub = root, hub
        self.events = queue.Queue()
        self.worker = None
        self.cancel_event = None
        self.busy = False
        self.result = {}
        self.files = []
        self.template = tk.StringVar()
        self.file_caption = tk.StringVar(value='Chưa chọn tài liệu số liệu')
        self.status = tk.StringVar(value='Chọn tài liệu mẫu và nhập chủ đề để bắt đầu.')
        self.kind = tk.StringVar(value='Báo cáo')
        self.topic = tk.StringVar()
        self.unit = tk.StringVar(value='Trường THPT Hồ Thị Bi')
        self.period = tk.StringVar(value='Năm học 2026–2027')
        self.researcher = tk.StringVar(value='Gemini')
        self.writer = tk.StringVar(value='OpenAI')
        self.reviewer = tk.StringVar(value='Gemini')
        self.search = tk.BooleanVar(value=True)
        self.review = tk.BooleanVar(value=True)
        self.openai_key = tk.StringVar(value=os.getenv('OPENAI_API_KEY', ''))
        self.gemini_key = tk.StringVar(value=os.getenv('GEMINI_API_KEY', ''))
        self.openai_model = tk.StringVar(value=os.getenv('OPENAI_MODEL', 'gpt-6-astra'))
        self.gemini_model = tk.StringVar(value=os.getenv('GEMINI_MODEL', 'gemini-3.8-flash'))
        label(root, 'AGENT VĂN BẢN', size=9, color=BLUE, bold=True).pack(anchor='w')
        label(root, 'Báo cáo & Kế hoạch', size=24, bold=True).pack(anchor='w', pady=(6,5))
        label(root, 'Đọc mẫu → tìm nguồn → soạn nội dung → rà soát → xuất Word', color=MUTED).pack(anchor='w', pady=(0,16))
        tabs = ttk.Notebook(root); tabs.pack(fill='both', expand=True)
        self.tabs = tabs
        form = tk.Frame(tabs, bg=WHITE, padx=16, pady=16)
        result_page = tk.Frame(tabs, bg=WHITE, padx=12, pady=12)
        source_page = tk.Frame(tabs, bg=WHITE, padx=12, pady=12)
        review_page = tk.Frame(tabs, bg=WHITE, padx=12, pady=12)
        settings = tk.Frame(tabs, bg=WHITE, padx=16, pady=16)
        for page, name in [(form,'Yêu cầu & tài liệu'),(result_page,'Bản thảo'),(source_page,'Nguồn tra cứu'),(review_page,'Rà soát'),(settings,'Kết nối AI')]:
            tabs.add(page, text=name)

        def entry(parent, caption, variable, row, secret=False):
            label(parent, caption, size=10).grid(row=row, column=0, sticky='w', pady=6, padx=(0,12))
            item = ttk.Entry(parent, textvariable=variable, show='•' if secret else '')
            item.grid(row=row, column=1, sticky='ew', pady=6)
            parent.grid_columnconfigure(1,weight=1)
            return item

        label(form,'Loại văn bản',size=10).grid(row=0,column=0,sticky='w')
        ttk.Combobox(form,textvariable=self.kind,values=['Báo cáo','Kế hoạch','Báo cáo sơ kết','Báo cáo tổng kết'],state='readonly').grid(row=0,column=1,sticky='ew')
        for row, (caption, variable) in enumerate([('Chủ đề',self.topic),('Đơn vị',self.unit),('Thời gian / năm học',self.period)],1):
            entry(form,caption,variable,row)
        files = tk.Frame(form,bg=WHITE); files.grid(row=4,column=0,columnspan=2,sticky='ew',pady=8)
        button(files,'Chọn mẫu Word / PDF',self.pick_template).pack(side='left')
        button(files,'Bỏ mẫu',lambda:self.template.set('')).pack(side='left',padx=5)
        label(form,'',size=9,color=MUTED,textvariable=self.template,wraplength=740,justify='left').grid(row=5,column=0,columnspan=2,sticky='w')
        file_buttons=tk.Frame(form,bg=WHITE); file_buttons.grid(row=6,column=0,columnspan=2,sticky='w',pady=8)
        button(file_buttons,'Chọn tài liệu số liệu',self.pick_evidence).pack(side='left')
        button(file_buttons,'Dùng Excel đang chọn',self.use_hub_file).pack(side='left',padx=5)
        button(file_buttons,'Xóa danh sách',self.clear_files).pack(side='left')
        label(form,'',size=9,color=MUTED,textvariable=self.file_caption,wraplength=740,justify='left').grid(row=7,column=0,columnspan=2,sticky='w')
        label(form,'Yêu cầu viết (độ dài, nội dung, người ký…)',size=10).grid(row=8,column=0,columnspan=2,sticky='w',pady=(10,4))
        self.requirements=ScrolledText(form,height=3,font=(FONT,10),wrap='word');self.requirements.grid(row=9,column=0,columnspan=2,sticky='ew')
        label(form,'Số liệu thực tế / ghi chú của đơn vị',size=10).grid(row=10,column=0,columnspan=2,sticky='w',pady=(10,4))
        self.notes=ScrolledText(form,height=4,font=(FONT,10),wrap='word');self.notes.grid(row=11,column=0,columnspan=2,sticky='ew')
        roles=tk.Frame(form,bg=WHITE);roles.grid(row=12,column=0,columnspan=2,sticky='ew',pady=10)
        for i,(caption,var) in enumerate([('Tìm nguồn',self.researcher),('Soạn thảo',self.writer),('Rà soát',self.reviewer)]):
            label(roles,caption,size=10).grid(row=0,column=i,sticky='w')
            ttk.Combobox(roles,textvariable=var,values=['Gemini','OpenAI'],state='readonly',width=18).grid(row=1,column=i,padx=(0,14),pady=5)
        ttk.Checkbutton(form,text='Tìm thông tin công khai trên web',variable=self.search).grid(row=13,column=0,columnspan=2,sticky='w')
        ttk.Checkbutton(form,text='Rà soát sau khi soạn (thêm lượt API)',variable=self.review).grid(row=14,column=0,columnspan=2,sticky='w')
        label(form,'Khi bấm soạn, phần chữ trong tài liệu được gửi tới AI viết/rà soát đã chọn. '
              'Tìm web chỉ gửi chủ đề và kỳ báo cáo. API có thể phát sinh phí. Loại bỏ dữ liệu cá nhân không cần thiết.',
              size=9,color=MUTED,wraplength=740,justify='left').grid(row=15,column=0,columnspan=2,sticky='w',pady=10)

        label(result_page,'Chỉnh sửa trực tiếp trước khi lưu. Nguồn được bổ sung trong tệp xuất.',size=10,color=MUTED).pack(anchor='w',pady=(0,8))
        self.editor=ScrolledText(result_page,height=23,font=(FONT,11),wrap='word',undo=True);self.editor.pack(fill='both',expand=True)
        export=tk.Frame(result_page,bg=WHITE);export.pack(fill='x',pady=(10,0))
        button(export,'Lưu Word',lambda:self.save('docx'),True).pack(side='left')
        button(export,'Lưu Markdown',lambda:self.save('md')).pack(side='left',padx=8)
        button(export,'Lưu hồ sơ JSON',lambda:self.save('json')).pack(side='left')
        button(export,'Mở thư mục báo cáo',hub.reports).pack(side='right')
        self.source_box=ScrolledText(source_page,height=25,font=(FONT,10),wrap='word');self.source_box.pack(fill='both',expand=True)
        self.review_box=ScrolledText(review_page,height=25,font=(FONT,10),wrap='word');self.review_box.pack(fill='both',expand=True)
        for row,(caption,var,secret) in enumerate([('OpenAI API key',self.openai_key,True),('Model OpenAI',self.openai_model,False),('Gemini API key',self.gemini_key,True),('Model Gemini',self.gemini_model,False)]):
            entry(settings,caption,var,row,secret)
        label(settings,'Khóa chỉ giữ trong bộ nhớ phiên, không ghi vào hồ sơ hoặc báo cáo. '
              'Nhập đúng model được tài khoản cấp quyền. Công cụ gọi API qua Internet; chưa chạy AI ngoại tuyến.',
              color=MUTED,size=10,wraplength=700,justify='left').grid(row=4,column=0,columnspan=2,sticky='w',pady=15)
        import webbrowser
        button(settings,'Lấy khóa OpenAI',lambda:webbrowser.open('https://platform.openai.com/api-keys')).grid(row=5,column=0,sticky='w')
        button(settings,'Lấy khóa Gemini',lambda:webbrowser.open('https://aistudio.google.com/apikey')).grid(row=5,column=1,sticky='w')
        label(settings,'Đọc nội dung và thứ tự mục của mẫu. Chưa giữ nguyên logo, chữ ký và định dạng mẫu. '
              'PDF scan cần OCR trước. Tài liệu hỗ trợ: DOCX, PDF có chữ, XLSX, TXT/CSV UTF-8, MD.',
              color=MUTED,size=10,wraplength=700,justify='left').grid(row=6,column=0,columnspan=2,sticky='w',pady=18)
        controls=card(root,padx=14,pady=12);controls.pack(fill='x',pady=14)
        self.start_button=button(controls,'Bắt đầu soạn văn bản',self.start_job,True);self.start_button.pack(side='left')
        self.stop_button=button(controls,'Dừng sau bước hiện tại',self.stop_job);self.stop_button.pack(side='left',padx=10);self.stop_button.configure(state='disabled')
        self.progress=ttk.Progressbar(root,mode='indeterminate');self.progress.pack(fill='x')
        label(root,'',textvariable=self.status,size=10,color=BLUE,wraplength=780,justify='left').pack(anchor='w',pady=8)
        hub.root.after(150,self.poll)

    def pick_template(self):
        path=filedialog.askopenfilename(parent=self.hub.root,title='Chọn tài liệu mẫu',filetypes=[('Tài liệu mẫu','*.docx *.pdf *.txt *.md')])
        if path:self.template.set(path)

    def pick_evidence(self):
        paths=filedialog.askopenfilenames(parent=self.hub.root,title='Chọn tài liệu số liệu',filetypes=[('Tài liệu','*.docx *.pdf *.xlsx *.txt *.csv *.md')])
        if paths:self.files=list(dict.fromkeys(self.files+list(paths)));self.update_files()

    def use_hub_file(self):
        path=self.hub.path.get()
        if path and Path(path).is_file():
            self.files=list(dict.fromkeys(self.files+[path]));self.update_files()
        else:messagebox.showinfo('Chưa chọn Excel','Chọn Excel tại Tổng quan trước.',parent=self.hub.root)

    def clear_files(self):
        self.files=[];self.update_files()

    def update_files(self):
        self.file_caption.set('\n'.join(Path(p).name for p in self.files) or 'Chưa chọn tài liệu số liệu')

    def snapshot(self):
        c={name:getattr(self,name).get().strip() for name in ['kind','topic','unit','period','template','researcher','writer','reviewer']}
        c.update(search=self.search.get(),review=self.review.get(),files=list(self.files),
                 notes=self.notes.get('1.0','end-1c'),requirements=self.requirements.get('1.0','end-1c'),
                 providers={'OpenAI':(self.openai_key.get().strip(),self.openai_model.get().strip()),
                            'Gemini':(self.gemini_key.get().strip(),self.gemini_model.get().strip())})
        if not c['topic']:raise ValueError('Vui lòng nhập chủ đề.')
        if len(c['files'])>12:raise ValueError('Tối đa 12 tài liệu số liệu mỗi lần.')
        needed={c['writer']} | ({c['researcher']} if c['search'] else set()) | ({c['reviewer']} if c['review'] else set())
        for provider in needed:
            if not all(c['providers'][provider]):raise ValueError('Điền khóa API và tên model '+provider+' tại thẻ Kết nối AI.')
        return c

    def start_job(self):
        if self.busy or not self.hub.can_start(self):return
        try:c=self.snapshot()
        except ValueError as exc:
            messagebox.showinfo('Chưa đủ thông tin',str(exc),parent=self.hub.root);return
        if self.editor.get('1.0','end-1c').strip() and not messagebox.askyesno('Bản thảo hiện tại','Tác vụ mới sẽ thay nội dung đang sửa khi có dự thảo mới. Thầy đã lưu nội dung cần giữ và muốn tiếp tục?',parent=self.hub.root):return
        self.cancel_event=threading.Event();self.busy=True
        self.start_button.configure(state='disabled');self.stop_button.configure(state='normal');self.progress.start()
        self.worker=threading.Thread(target=self.work,args=(c,),daemon=True);self.worker.start()

    def work(self,config):
        try:
            self.events.put(('begin',None))
            result=run_pipeline(config,lambda kind,value:self.events.put((kind,value)),self.cancel_event)
            self.events.put(('complete',result))
        except InterruptedError as exc:self.events.put(('warning',str(exc)))
        except Exception as exc:
            message=str(exc) if isinstance(exc,(ValueError,RuntimeError)) else 'Không xử lý được tài liệu hoặc kết nối. Kiểm tra định dạng tệp và mạng.'
            self.events.put(('error',message))
        finally:self.events.put(('finished',None))

    def stop_job(self):
        if self.cancel_event:self.cancel_event.set()
        self.status.set('Đang đợi bước hiện tại kết thúc; không gửi thêm bước AI mới.')

    @staticmethod
    def put_text(widget,value):
        widget.delete('1.0','end');widget.insert('1.0',value)

    def poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='begin':
                    # Keep the editable draft until a replacement draft arrives.
                    self.pending={'research':'','sources':[],'review':''}
                elif kind in ('status','warning','error'):self.status.set(value)
                elif kind=='research':
                    self.pending.update(research=value['text'],sources=value['sources'])
                elif kind=='draft':
                    self.result=dict(self.pending,draft=value)
                    self.put_text(self.editor,value)
                    self.put_text(self.source_box,self.result['research']+'\n\n'+'\n'.join(s['title']+': '+s['url'] for s in unique_sources(self.result['sources'])))
                    self.put_text(self.review_box,'Chưa hoàn tất rà soát.')
                    self.tabs.select(1)
                elif kind=='review':
                    self.result['review']=value;self.put_text(self.review_box,value)
                elif kind=='complete':
                    self.result=value;self.status.set('Đã tạo dự thảo. Kiểm tra, chỉnh sửa và lưu trước khi sử dụng.')
                elif kind=='finished':
                    self.busy=False;self.start_button.configure(state='normal');self.stop_button.configure(state='disabled');self.progress.stop()
        except queue.Empty:pass
        self.hub.root.after(150,self.poll)

    def save(self,extension):
        text=self.editor.get('1.0','end-1c')
        if not text.strip():
            messagebox.showinfo('Chưa có nội dung','Soạn hoặc nhập nội dung trước khi lưu.',parent=self.hub.root);return
        folder=Path(__file__).resolve().parent/'bao_cao';folder.mkdir(exist_ok=True)
        path=filedialog.asksaveasfilename(parent=self.hub.root,initialdir=str(folder),initialfile='Van_ban_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.'+extension,
                                        defaultextension='.'+extension,filetypes=[('Văn bản','*.'+extension)])
        if not path:return
        try:
            sources=unique_sources(self.result.get('sources',[]))
            export=text+ ('\n\n## Nguồn tham khảo đã tra cứu\n'+'\n'.join('- '+s['title']+': '+s['url'] for s in sources) if sources else '')
            if extension=='docx':Path(path).write_bytes(to_docx(export))
            elif extension=='md':Path(path).write_text(export,encoding='utf-8')
            else:Path(path).write_text(json.dumps(dict(self.result,draft=text),ensure_ascii=False,indent=2),encoding='utf-8')
            self.status.set('Đã lưu: '+str(Path(path).name))
        except Exception:
            messagebox.showerror('Không lưu được','Kiểm tra quyền ghi hoặc đóng tệp đang mở trong Word rồi thử lại.',parent=self.hub.root)
