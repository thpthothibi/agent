import threading
import unittest
from report_engine import Result
from report_workspace import run_pipeline


class ReportPipelineTests(unittest.TestCase):
    def config(self):
        return dict(template='',files=[],notes='Số liệu nội bộ: 125 GV',topic='Chuyển đổi số',kind='Báo cáo',
                    unit='THPT Hồ Thị Bi',period='2026–2027',requirements='Ngắn gọn',search=True,review=True,
                    researcher='Gemini',writer='OpenAI',reviewer='Gemini',
                    providers={'OpenAI':('secret-openai','model-a'),'Gemini':('secret-gemini','model-b')})

    def test_roles_sequential_sources_passed_and_no_secrets_in_result(self):
        calls,events=[],[]
        def fake(provider,key,model,prompt,search):
            calls.append((provider,prompt,search))
            return Result('Nội dung '+str(len(calls)),[{'title':'Nguồn','url':'https://example.org'}],searched=search)
        result=run_pipeline(self.config(),lambda k,v:events.append((k,v)),threading.Event(),fake)
        self.assertEqual([x[0] for x in calls],['Gemini','OpenAI','Gemini'])
        self.assertNotIn('125 GV', calls[0][1])
        self.assertIn('125 GV', calls[1][1])
        self.assertIn('https://example.org', calls[1][1])
        self.assertNotIn('secret',str(result))
        self.assertLess([k for k,v in events].index('draft'),[k for k,v in events].index('review'))

    def test_review_failure_keeps_draft(self):
        calls=[]
        def fake(*args):
            calls.append(args)
            if len(calls)==3:raise RuntimeError('Hết hạn mức')
            return Result('Dự thảo',searched=True)
        r=run_pipeline(self.config(),lambda *a:None,threading.Event(),fake)
        self.assertEqual(r['draft'],'Dự thảo')
        self.assertIn('Hết hạn mức',r['review'])

    def test_cancel_after_draft_prevents_review(self):
        stop=threading.Event();calls=[];events=[]
        def fake(*args):calls.append(args);return Result('Dự thảo',searched=True)
        def emit(k,v):
            events.append((k,v))
            if k=='draft':stop.set()
        with self.assertRaises(InterruptedError):run_pipeline(self.config(),emit,stop,fake)
        self.assertEqual(len(calls),2)
        self.assertTrue(any(k=='draft' for k,v in events))

    def test_single_provider_without_search_or_review(self):
        c=self.config();c.update(search=False,review=False,writer='OpenAI')
        calls=[]
        def fake(*args):calls.append(args);return Result('Báo cáo')
        r=run_pipeline(c,lambda *a:None,threading.Event(),fake)
        self.assertEqual(len(calls),1)
        self.assertEqual(r['sources'],[])

if __name__=='__main__':unittest.main()
