import queue, threading, unittest
from unittest.mock import Mock, patch
from full_auto import AutoWorker

class TreeLoadingTests(unittest.TestCase):
    def worker(self):
        w=AutoWorker('',queue.Queue(),threading.Event());w.page=Mock(return_value=Mock());w.wait_idle=Mock();w.choose=Mock();return w
    def test_visible_class_does_not_require_grade_label(self):
        w=self.worker();w.expand=Mock(side_effect=AssertionError('Parent label must not block visible class'))
        w.ui_target=Mock(side_effect=lambda values,**kw:('main',{'selector':'class','active':False}) if values==['10A06'] else None)
        w.choose_class('10A06')
        w.choose.assert_called_once_with(['10A06'],group=['LỚP HỌC','LỚP']);w.expand.assert_not_called()
    def test_waits_for_class_and_grade_tree_to_arrive(self):
        w=self.worker();clock=[0.0];w.tick=lambda *args:clock.__setitem__(0,clock[0]+.2);w.expand=Mock()
        w.ui_target=Mock(side_effect=lambda values,**kw:('main',{'selector':'class','active':False}) if clock[0]>=1 and values==['10A06'] else None)
        with patch('full_auto.time.monotonic',side_effect=lambda:clock[0]):w.choose_class('10A06')
        self.assertGreaterEqual(clock[0],1);w.choose.assert_called_once();w.expand.assert_not_called()
    def test_collapsed_grade_opens_then_waits_for_child_class(self):
        w=self.worker();state={'open':False};clock=[0.0];w.tick=lambda *args:clock.__setitem__(0,clock[0]+.2)
        def target(values,*args,**kw):
            if values==['Khối 10']:return 'main',{'selector':'grade','expanded':'false'}
            if state['open'] and clock[0]>=.4:return 'main',{'selector':'class','active':False}
            return None
        w.ui_target=Mock(side_effect=target);w.expand=Mock(side_effect=lambda *args,**kw:state.update(open=True))
        with patch('full_auto.time.monotonic',side_effect=lambda:clock[0]):w.choose_class('10A06')
        w.expand.assert_called_once_with(['Khối 10'],group=['LỚP HỌC','LỚP']);w.choose.assert_called_once()
    def test_tree_timeout_does_not_click_or_paste(self):
        w=self.worker();clock=[0.0];w.tick=lambda *args:clock.__setitem__(0,clock[0]+1);w.ui_target=Mock(return_value=None);w.expand=Mock()
        with patch('full_auto.time.monotonic',side_effect=lambda:clock[0]):
            with self.assertRaisesRegex(RuntimeError,'15 giây'):w.choose_class('10A06')
        w.choose.assert_not_called();w.expand.assert_not_called();w.page().keyboard.press.assert_not_called()
    def test_expansion_waits_for_delayed_parent(self):
        w=self.worker();clock=[0.0];w.tick=lambda *args:clock.__setitem__(0,clock[0]+.2);f=Mock()
        w.ui_target=Mock(side_effect=lambda *args,**kw:None if clock[0]<.6 else (f,{'selector':'term','expanded':'true','toggle':None}))
        with patch('full_auto.time.monotonic',side_effect=lambda:clock[0]):w.expand(['Học kỳ 1'],['ĐỢT ĐIỂM'])
        self.assertGreaterEqual(clock[0],.6);f.locator.assert_not_called()
    def test_scope_checks_exact_unique_selected_class_without_parent(self):
        w=self.worker();page=Mock(main_frame='main');w.page=Mock(return_value=page);w.dom=Mock(return_value={'matched':True});calls=[]
        def target(values,group=None,branch=None):
            calls.append((values,branch))
            if values==['10A06'] and branch is not None:return None
            return 'frame',{'active':True}
        w.ui_target=Mock(side_effect=target)
        w.scope_is_selected({'year':'2026-2027','class':'10A06','subject':'GDĐP','term':'Học kỳ 1'},'ĐGTX')
        self.assertIn((['10A06'],None),calls)

if __name__=='__main__':unittest.main()
