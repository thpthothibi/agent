# HTB v2.2.2

Sửa dừng ở lớp đầu khi Excel có 8,75 nhưng VietSchool lưu 8,8. Giữ điểm gốc trong Excel và báo cáo; chuẩn hóa HALF_UP một chữ số thập phân trước dán và khi đối chiếu. Vẫn kiểm tra đúng học sinh, cột, giá trị và chữ xanh, không bỏ qua lỗi lưu để chuyển lớp.

Thêm ô tài khoản và mật khẩu trong Nhập điểm. Khi chọn Excel, tự điền và bấm Đăng nhập một lần trên tên miền HTTPS VietSchool. Mật khẩu chỉ trong bộ nhớ, không ghi ra tệp hoặc nhật ký; CAPTCHA/OTP hoặc biểu mẫu không rõ chờ người dùng.

Kiểm tra: 138 unittest chạy, 137 đạt và một bỏ qua vì chưa có Chromium. Mô phỏng hai lớp liên tiếp và chọn lại Excel khi lớp đầu đã lưu đều đạt. Kiểm thử đăng nhập dùng biểu mẫu mô phỏng, chưa xác nhận trên trang đăng nhập VietSchool thực tế. Không đăng nhập/ghi điểm thực từ môi trường phát triển.

Dùng: đóng bản cũ, giải nén, chạy CHAY_HTB_AI_AGENT.bat. Vào Nhập điểm, nhập tài khoản/mật khẩu nếu muốn tự đăng nhập, rồi chọn lại toàn bộ Excel. Các ô đã có điểm được bỏ qua; kiểm tra lại bằng Đối chiếu khi xong.
