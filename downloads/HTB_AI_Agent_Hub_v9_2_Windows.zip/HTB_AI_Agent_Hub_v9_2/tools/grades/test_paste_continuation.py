import queue, threading, unittest
from unittest.mock import Mock, patch
from auto_core import column_index, grade_batch_state
from full_auto import AutoWorker

IDENTITY=['STT','Họ','Tên','Ngày sinh']
BEFORE=IDENTITY+['Điểm ĐGTX 1','Điểm ĐGTX 2','Điểm ĐGTX 3','ĐGGK']
AFTER=IDENTITY+['Điểm ĐGTX 2','Điểm ĐGTX 3','ĐGGK']

def expected(i):return {'stt':i,'name':f'Học sinh {i}','dob':'01/01/2011','value':'Đ'}
def actual(i,index=6,saved=True):
    cells=[str(i),'Học sinh',str(i),'01/01/2011']+['']*(index-3);cells[index]='Đ'
    colors=[False]*len(cells);colors[index]=saved
    return {**expected(i),'cells':cells,'saved':colors}

class PasteContinuationTests(unittest.TestCase):
    def worker(self):
        w=AutoWorker('',queue.Queue(),threading.Event());w.page=Mock(return_value=Mock())
        w.tick=Mock();w.wait_idle=Mock();w.scope_is_selected=Mock();w.html_dialog=Mock();return w
    def test_offset_changes_without_changing_column_identity(self):
        self.assertEqual(column_index(BEFORE,'Giữa kỳ'),7)
        self.assertEqual(column_index(AFTER,'Giữa kỳ'),6)
        self.assertTrue(grade_batch_state([actual(1)],[expected(1)],6)['saved'])
    def test_stale_offset_or_partial_redraw_never_index_error(self):
        self.assertFalse(grade_batch_state([actual(1)],[expected(1)],7)['values_ok'])
        row=actual(1);row['saved']=[]
        self.assertTrue(grade_batch_state([row],[expected(1)],6)['values_ok'])
        self.assertFalse(grade_batch_state([row],[expected(1)],6)['saved'])
    def test_paste_verifies_after_horizontal_scroll_without_repeating_ctrl_v(self):
        w=self.worker();f=Mock();w.headers=Mock(side_effect=[7,6]);checks=[]
        run=[expected(1),expected(2),expected(3)]
        def dom(frame,op,**kw):
            if op=='focus':self.assertEqual(kw['index'],7);return 'actual-gk-cell'
            if op=='verify_focus':checks.append(kw['index']);return True
            if op=='snapshot':return {'rows':[actual(i) for i in (1,2,3)],'headerPaths':AFTER}
            raise AssertionError(op)
        w.dom=Mock(side_effect=dom)
        with patch('pyperclip.copy'):w.paste(f,run,7,{'class':'10A06','column':'Giữa kỳ'},'ĐGTX')
        self.assertEqual(checks,[6]);w.page().keyboard.press.assert_called_once_with('Control+V')
        self.assertIsNone(w.last_submitted)
    def test_temporary_short_cell_array_waits_then_verifies_same_paste(self):
        w=self.worker();f=Mock();w.headers=Mock(return_value=6);snapshots=[{'rows':[actual(1,index=5)],'headerPaths':AFTER},{'rows':[actual(1)],'headerPaths':AFTER}]
        def dom(frame,op,**kw):
            if op=='focus':return 'gk-cell'
            if op=='verify_focus':return True
            if op=='snapshot':return snapshots.pop(0)
            raise AssertionError(op)
        w.dom=Mock(side_effect=dom)
        with patch('pyperclip.copy'):w.paste(f,[expected(1)],7,{'class':'10A06','column':'Giữa kỳ'},'ĐGTX')
        w.page().keyboard.press.assert_called_once_with('Control+V')
    def process(self,already_saved=False):
        w=self.worker();site=[];excel=[]
        for i in range(1,48):
            row={'stt':i,'name':f'Học sinh {i}','dob':'01/01/2011','cells':[str(i),'Học sinh',str(i),'01/01/2011','','','','Đ' if already_saved and i<=3 else ''], 'locks':[False]*8,'inactive':i in (4,44)}
            site.append(row)
            if i not in (4,44):excel.append({'student':row['name'],'row':i+7,'Giữa kỳ':'Đ'})
        job={'class':'10A06','column':'Giữa kỳ','subject':'GDĐP','rows':excel}
        f=Mock();w.navigate=Mock();w.prepare_grid=Mock();w.grid=Mock(return_value=(f,{'rows':site}));w.collect=Mock(return_value=site);w.headers=Mock(return_value=7)
        w.visible_run=Mock(return_value=True);w.seek=Mock();w.paste=Mock();w.dom=Mock(return_value='binding')
        w.process_job(job,1,1)
        return w,[[r['stt'] for r in c.args[1]] for c in w.paste.call_args_list]
    def test_paste_ranges_continue_after_both_retired_students(self):
        w,ranges=self.process()
        self.assertEqual(ranges,[list(range(1,4)),list(range(5,44)),list(range(45,48))]);self.assertEqual(w.total,45)
    def test_restart_keeps_first_three_and_continues_at_five(self):
        w,ranges=self.process(already_saved=True)
        self.assertEqual(ranges,[list(range(5,44)),list(range(45,48))]);self.assertEqual(w.total,42)

if __name__=='__main__':unittest.main()
