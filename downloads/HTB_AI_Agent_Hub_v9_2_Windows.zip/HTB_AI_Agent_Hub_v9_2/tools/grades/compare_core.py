"""Read-only grade comparison. No browser mutation."""
from collections import Counter
from skip_policy import requested_skip, SKIP_STATUS, SKIP_REASON
from datetime import datetime
from base_agent import grade_string, rating_mode, vietschool_value
from chrome_bridge import normalize_name
from auto_core import subject_aliases

OK='Đúng'
UNCHECKED='Chưa kiểm tra được'

def dob_key(value):
    text=str(value or '').strip()
    for fmt in ('%Y-%m-%d %H:%M:%S','%Y-%m-%d','%d/%m/%Y','%d-%m-%Y'):
        try:return datetime.strptime(text,fmt).date().isoformat()
        except ValueError:pass
    return text

def compare_rows(job, site, index):
    sources=job['rows']; column=job['column']; mode=rating_mode(subject_aliases(job['subject'])[-1])
    counts=Counter(normalize_name(r['name']) for r in site)
    lookup={normalize_name(r['name']):r for r in site}
    sourcecounts=Counter(normalize_name(r['student']) for r in sources)
    out=[]
    for src in sources:
        name=normalize_name(src['student']); web=lookup.get(name)
        row={'year':job['year'],'class':job['class'],'subject':job['subject'],
             'term':job['term'],'column':column,'sheet':src.get('sheet',''),
             'row':src['row'],'name':src['student'],'dob':src.get('dob',''),
             'stt':web.get('stt','') if web else '', 'expected':src[column],
             'actual':'','result':UNCHECKED,'reason':''}
        cells=web.get('cells',[]) if web else []
        if web and index>=4 and index<len(cells):row['actual']=str(cells[index]).strip()
        if requested_skip(job['class'],src['student']):
            row.update(stt='',actual='',result=SKIP_STATUS,reason=SKIP_REASON)
        elif src.get('inactive') or (web and web.get('inactive')):
            row.update(result='Bỏ qua: học sinh nghỉ',reason='Không kết luận điểm cho học sinh nghỉ')
        elif sourcecounts[name]!=1 or counts[name]>1:
            row['reason']='Họ tên trùng; cần đối chiếu mã học sinh/ngày sinh riêng'
        elif not web:
            row.update(result='Không tìm thấy học sinh',reason='Không tìm thấy họ tên trong các dòng web đã đọc')
        elif src.get('dob') and dob_key(src['dob'])!=dob_key(web.get('dob')):
            row['reason']='Ngày sinh khác nhau hoặc không đọc được; không ghép theo tên'
        elif index<4 or index>=len(cells):
            row['reason']='Không đọc được ô của cột điểm'
        elif src[column] is None:
            row.update(result='Excel trống — web có điểm' if row['actual'] else 'Excel trống — không kết luận',
                       reason='Ô Excel trống không phải yêu cầu xóa điểm')
        else:
            try:
                actual=grade_string(row['actual'],mode)
                expected=vietschool_value(src[column],mode)
                if expected!=grade_string(src[column],mode):
                    row['reason']=f"Theo VietSchool: {src[column]} → {expected} (làm tròn một chữ số thập phân)"
                row['result']='Thiếu điểm trên web' if actual is None else (OK if actual==expected else 'Sai điểm')
            except ValueError as exc:
                row.update(result='Giá trị web không hợp lệ',reason=str(exc))
        out.append(row)
    names={normalize_name(r['student']) for r in sources}
    for web in site:
        if normalize_name(web['name']) not in names:
            out.append({'year':job['year'],'class':job['class'],'subject':job['subject'],
                        'term':job['term'],'column':column,'name':web['name'],
                        'stt':web['stt'],'actual':web['cells'][index] if index<len(web.get('cells',[])) else '',
                        'result':SKIP_STATUS if requested_skip(job['class'],web['name']) else 'Web có học sinh ngoài Excel','reason':SKIP_REASON if requested_skip(job['class'],web['name']) else 'Không có dữ liệu nguồn để kết luận'})
    return out

def summary(rows):
    c=Counter(r['result'] for r in rows)
    correct=c[OK]; issues=sum(c[s] for s in ('Sai điểm','Thiếu điểm trên web','Giá trị web không hợp lệ','Không tìm thấy học sinh'))
    pending=c[UNCHECKED]
    return f'Đúng: {correct} ô · Sai/thiếu/không tìm thấy: {issues} · Chưa kiểm tra được: {pending} · Các dòng khác: {len(rows)-correct-issues-pending}. Xem đầy đủ báo cáo.'
