import queue, threading, unittest
from unittest.mock import Mock
from full_auto import AutoWorker
from name_matching import build_plan

class FullRosterTests(unittest.TestCase):
    def roster(self):
        site=[];excel=[]
        for i in range(1,48):
            name=f'Học sinh {i:02d}';inactive=i in (4,44)
            site.append({'stt':i,'name':name,'dob':'01/01/2011','cells':[str(i),'Học sinh',f'{i:02d}','01/01/2011',''], 'locks':[False]*5,'inactive':inactive})
            if not inactive:excel.append({'student':name,'row':i+7,'TX1':'Đ'})
        return site,excel
    def make(self):
        w=AutoWorker('',queue.Queue(),threading.Event());w.page=Mock(return_value=Mock());w.tick=Mock();return w
    def test_reads_all_47_dom_rows_without_scroll_with_45_active(self):
        site,excel=self.roster();w=self.make()
        def dom(f,op,**kw):
            if op=='snapshot_all':return {'rows':site}
            raise AssertionError('Full DOM roster should avoid unnecessary scrolling: '+op)
        w.dom=Mock(side_effect=dom)
        result=w.collect('frame',expected=excel)
        self.assertEqual(len(result),47)
        plan=build_plan(excel,result,'TX1','GDĐP',index=4)
        self.assertEqual(sum(r['status']=='Sẽ dán' for r in plan),45)
        self.assertEqual([r['stt'] for r in plan if 'học sinh nghỉ' in r['status']],[4,44])
    def test_virtual_scroll_merges_all_windows_and_restores(self):
        site,excel=self.roster();w=self.make();state={'window':0,'restored':False}
        def dom(f,op,**kw):
            if op=='snapshot_all':return {'rows':[site[:14],site[12:29],site[27:]][state['window']]}
            if op=='scroll_init':return 1
            if op=='scroll':
                state['window']=0 if kw.get('top') else min(2,state['window']+1)
                return {'end':state['window']==2}
            if op=='restore':state['restored']=True;return True
            raise AssertionError(op)
        w.dom=Mock(side_effect=dom)
        result=w.collect('frame',expected=excel)
        self.assertEqual([r['stt'] for r in result],list(range(1,48)))
        self.assertTrue(state['restored'])
    def test_non_scrollable_candidate_does_not_block_next_candidate(self):
        site,excel=self.roster();w=self.make();state={'candidate':0}
        def dom(f,op,**kw):
            if op=='snapshot_all':return {'rows':site if state['candidate']==1 else site[:14]}
            if op=='scroll_init':return 2
            if op=='scroll':
                state['candidate']=kw['i'];return {'end':True,'blocked':kw['i']==0}
            if op=='restore':return True
            raise AssertionError(op)
        w.dom=Mock(side_effect=dom)
        self.assertEqual(len(w.collect('frame',expected=excel)),47)
        self.assertEqual(state['candidate'],1)
    def test_seek_reveals_dom_row_before_scroll_search(self):
        w=self.make();w.visible_run=Mock(side_effect=[False,True]);w.dom=Mock(return_value=True)
        student={'stt':47,'name':'Học sinh 47','dob':'01/01/2011'}
        w.seek('frame',student)
        w.dom.assert_called_once_with('frame','reveal',student=student)

if __name__=='__main__':unittest.main()
