import os
import sys
import tkinter as tk
from pathlib import Path
from tkinter import ttk, filedialog, messagebox
from .core import load, guess_header, norm, Mapping, records, combine, export


class Source(ttk.LabelFrame):
    def __init__(self, parent, title):
        super().__init__(parent, text=title, padding=12)
        self.data = {}
        self.path = ''
        self.file = tk.StringVar(value='Chưa chọn file')
        ttk.Button(self, text='Chọn file Excel / CSV', command=self.choose).grid(row=0, column=0, sticky='w')
        ttk.Label(self, textvariable=self.file, wraplength=420).grid(row=1, column=0, columnspan=2, sticky='w', pady=7)
        self.sheet = ttk.Combobox(self, state='readonly', width=24)
        self.sheet.grid(row=2, column=1, sticky='ew')
        ttk.Label(self, text='Sheet').grid(row=2, column=0, sticky='w')
        self.sheet.bind('<<ComboboxSelected>>', lambda e: self.new_sheet())
        self.header = tk.StringVar(value='1')
        ttk.Label(self, text='Dòng tiêu đề').grid(row=3, column=0, sticky='w', pady=5)
        f = ttk.Frame(self)
        f.grid(row=3, column=1, sticky='ew')
        ttk.Entry(f, textvariable=self.header, width=6).pack(side='left')
        ttk.Button(f, text='Đọc cột', command=self.columns).pack(side='left', padx=8)
        self.boxes = {}
        labels = [('name', 'Cột họ tên / tên'), ('surname', 'Cột họ đệm (nếu tách)'), ('classroom', 'Cột lớp'), ('grade', 'Cột điểm cần cộng'), ('subject', 'Cột môn (nếu nhiều môn)')]
        for i, (key, label) in enumerate(labels, 4):
            ttk.Label(self, text=label).grid(row=i, column=0, sticky='w', pady=4)
            box = ttk.Combobox(self, state='readonly', width=24)
            box.grid(row=i, column=1, sticky='ew')
            self.boxes[key] = box
        self.fixed = tk.StringVar()
        ttk.Label(self, text='Lớp chung nếu không có cột lớp').grid(row=9, column=0, sticky='w')
        ttk.Entry(self, textvariable=self.fixed).grid(row=9, column=1, sticky='ew')
        self.note = tk.StringVar(value='Chọn file để bắt đầu.')
        ttk.Label(self, textvariable=self.note, wraplength=450, foreground='#375a7f').grid(row=10, column=0, columnspan=2, sticky='w', pady=8)
        self.columnconfigure(1, weight=1)

    def choose(self):
        p = filedialog.askopenfilename(filetypes=[('Excel hoặc CSV', '*.xlsx *.xlsm *.csv'), ('Tất cả', '*.*')])
        if not p:
            return
        try:
            data = load(p)
            if not data:
                raise ValueError('File không có sheet.')
            self.data, self.path = data, p
            self.file.set(Path(p).name)
            self.sheet['values'] = list(data)
            self.sheet.current(0)
            self.new_sheet()
        except Exception as e:
            messagebox.showerror('Không đọc được file', str(e))

    def new_sheet(self):
        self.header.set(str(guess_header(self.data[self.sheet.get()])))
        self.columns()

    def columns(self):
        try:
            rows = self.data[self.sheet.get()]
            n = int(self.header.get())
            if n < 1 or n > len(rows):
                raise ValueError('Dòng tiêu đề nằm ngoài dữ liệu.')
            self.column_header = n
            from openpyxl.utils import get_column_letter
            headers = [str(v or '').strip() for v in rows[n-1]]
            choices = ['— Không chọn —'] + [f'{get_column_letter(i+1)}: {v or "(không tiêu đề)"}' for i, v in enumerate(headers)]
            aliases = {'name': ['ho va ten', 'ho ten', 'ho va ten hoc sinh', 'ten hoc sinh', 'ten'],
                       'surname': ['ho va ten lot', 'ho dem', 'ho lot'],
                       'classroom': ['lop', 'ten lop', 'lop hoc'],
                       'grade': ['diem tu luan', 'diem trac nghiem', 'diem thi', 'diem', 'tong diem'],
                       'subject': ['mon', 'mon hoc', 'ten mon']}
            for key, box in self.boxes.items():
                box['values'] = choices
                idx = next((i+1 for alias in aliases[key] for i, h in enumerate(headers) if norm(h, True) == alias), 0)
                box.current(idx)
            self.note.set(f'{max(0, len(rows)-n)} dòng sau tiêu đề. Kiểm tra các cột đã chọn trước khi cộng.')
        except Exception as e:
            messagebox.showerror('Chọn dòng tiêu đề', str(e))

    def read_records(self, fold):
        if not self.path:
            raise ValueError('Hãy chọn đủ hai file.')
        if int(self.header.get()) != self.column_header:
            raise ValueError('Đã đổi dòng tiêu đề: hãy bấm Đọc cột trước.')
        indices = {k: b.current()-1 for k, b in self.boxes.items()}
        if indices['name'] < 0 or indices['grade'] < 0:
            raise ValueError('Cần chọn cột họ tên và cột điểm cho cả hai file.')
        selected = [i for i in indices.values() if i >= 0]
        if len(set(selected)) != len(selected):
            raise ValueError('Mỗi loại dữ liệu cần một cột riêng. Không chọn cùng một cột hai lần.')
        if indices['classroom'] < 0 and not self.fixed.get().strip():
            raise ValueError('Chọn cột lớp hoặc nhập lớp chung cho file.')
        mapping = Mapping(header=self.column_header, fixed_class=self.fixed.get(), **indices)
        return records(self.data[self.sheet.get()], mapping, fold), mapping


class App(ttk.Frame):
    def __init__(self, parent, hub):
        super().__init__(parent)
        self.hub = hub
        self.pack(fill='both', expand=True)
        body = ttk.Frame(self, padding=18)
        body.pack(fill='both', expand=True)
        ttk.Label(body, text='CỘNG ĐIỂM TỰ LUẬN + TRẮC NGHIỆM', font=('Segoe UI', 18, 'bold'), foreground='#174c83').pack(anchor='w')
        ttk.Label(body, text='Chọn 2 file → Kiểm tra cột → Bấm đối chiếu → Xuất Excel. Dữ liệu được xử lý tại máy.').pack(anchor='w', pady=(5, 12))
        sources = ttk.Frame(body)
        sources.pack(fill='x')
        sources.columnconfigure(0, weight=1)
        sources.columnconfigure(1, weight=1)
        self.left = Source(sources, '1. Danh sách điểm TỰ LUẬN')
        self.right = Source(sources, '2. Danh sách điểm TRẮC NGHIỆM')
        self.left.grid(row=0, column=0, sticky='nsew', padx=(0, 6))
        self.right.grid(row=0, column=1, sticky='nsew', padx=(6, 0))
        self._stacked = None
        def arrange(event):
            stacked = event.width < 980
            if stacked == self._stacked:
                return
            self._stacked = stacked
            self.left.grid_configure(row=0, column=0, columnspan=2 if stacked else 1, padx=(0, 0) if stacked else (0, 6))
            self.right.grid_configure(row=1 if stacked else 0, column=0 if stacked else 1, columnspan=2 if stacked else 1, padx=(0, 0) if stacked else (6, 0), pady=(10, 0) if stacked else (0, 0))
        sources.bind('<Configure>', arrange)

        opts = ttk.Frame(body)
        opts.pack(fill='x', pady=10)
        self.fold = tk.BooleanVar(value=False)
        ttk.Checkbutton(opts, text='Bỏ dấu khi so khớp tên (chỉ bật khi cần)', variable=self.fold).pack(anchor='w')
        rounding = ttk.Frame(opts); rounding.pack(fill='x', pady=8)
        ttk.Label(rounding, text='Làm tròn tổng:').pack(side='left', padx=(0, 6))
        self.places = ttk.Combobox(rounding, values=['0', '1', '2', '3'], width=3, state='readonly')
        self.places.set('2')
        self.places.pack(side='left')
        ttk.Button(opts, text='ĐỐI CHIẾU & CỘNG ĐIỂM', command=self.run, style='Primary.TButton').pack(anchor='w', pady=(3, 0))
        self.summary = tk.StringVar(value='Tổng = tự luận + trắc nghiệm. Không nhân hệ số; không tự đoán tên gần giống.')
        ttk.Label(body, textvariable=self.summary, foreground='#174c83', wraplength=1000).pack(anchor='w', pady=5)
        frame = ttk.Frame(body)
        frame.pack(fill='both', expand=True)
        cols = ['name', 'cls', 'tl', 'tn', 'total', 'status']
        self.table = ttk.Treeview(frame, columns=cols, show='headings', height=8)
        for c, label, width in zip(cols, ['Họ và tên', 'Lớp', 'Tự luận', 'Trắc nghiệm', 'Tổng', 'Trạng thái'], [220, 80, 80, 100, 80, 410]):
            self.table.heading(c, text=label)
            self.table.column(c, width=width, minwidth=60)
        scroll = ttk.Scrollbar(frame, orient='vertical', command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        horizontal = ttk.Scrollbar(frame, orient='horizontal', command=self.table.xview)
        self.table.configure(xscrollcommand=horizontal.set)
        horizontal.pack(side='bottom', fill='x')
        self.table.pack(side='left', fill='both', expand=True)
        self.table.tag_configure('issue', background='#fff1d4')
        ttk.Label(body, text='Dòng vàng cần kiểm tra. Tổng chỉ có khi khớp duy nhất và đủ hai điểm. Bản Excel xuất đầy đủ các dòng.').pack(anchor='w', pady=7)
        bottom = ttk.Frame(body); bottom.pack(fill='x')
        ttk.Button(bottom, text='Mở hướng dẫn', command=self.help).pack(side='left')
        ttk.Button(bottom, text='Mở thư mục báo cáo', command=hub.reports).pack(side='left', padx=8)

    def help(self):
        messagebox.showinfo('Cách dùng', '1. Chọn từng file, sheet và đúng dòng tiêu đề.\n2. Kiểm tra cột họ tên, lớp, điểm; chọn họ đệm nếu tên tách cột.\n3. Nếu file chỉ có một lớp, có thể nhập Lớp chung.\n4. Nếu nhiều môn, chọn cột môn ở cả hai file. Tên môn cần thống nhất.\n5. Bấm Đối chiếu & cộng điểm và chọn nơi lưu Excel.\n\nKhớp theo tên + lớp (+ môn nếu chọn). Không phân biệt chữ hoa/thường, khoảng trắng thừa. Mặc định giữ dấu tiếng Việt. Tên nước ngoài như Winnie được xử lý bình thường.\n\nTrùng tên cùng lớp/môn cần kiểm tra thủ công; tool không tự ghép. Thiếu điểm/không hợp lệ sẽ để trống tổng.\n\nExcel có công thức phải được mở, tính và lưu lại trước. File .xls cũ cần Save As .xlsx. Dòng tổng kết/chú thích sau bảng cần được bỏ khỏi nguồn hoặc kiểm tra ở sheet Can_kiem_tra.')

    def run(self):
        if not self.hub.can_start(self):
            return
        try:
            a, ma = self.left.read_records(self.fold.get())
            b, mb = self.right.read_records(self.fold.get())
            if (ma.subject >= 0) != (mb.subject >= 0):
                raise ValueError('Nếu đối chiếu theo môn, hãy chọn cột môn ở cả hai file; hoặc bỏ chọn cả hai khi chỉ có một môn.')
            if not a or not b:
                raise ValueError('Có danh sách không có dòng dữ liệu. Kiểm tra sheet và dòng tiêu đề.')
            places = int(self.places.get())
            result = combine(a, b, places)
            self.table.delete(*self.table.get_children())
            def fmt(v):
                return '' if v is None else str(v).replace('.', ',')
            for r in result[:3000]:
                self.table.insert('', 'end', values=[r['name'], r['cls'], fmt(r['tl']), fmt(r['tn']), fmt(r['total']), r['status']], tags=('issue',) if r['total'] is None else ())
            good = sum(r['total'] is not None for r in result)
            self.summary.set(f'Tự luận: {len(a)} dòng • Trắc nghiệm: {len(b)} dòng • Đã cộng: {good} • Cần kiểm tra: {len(result)-good} • Kết quả: {len(result)} dòng' + (' • Xem trước tối đa 3.000 dòng.' if len(result)>3000 else ''))
            folder = Path(__file__).resolve().parent.parent / 'bao_cao'
            folder.mkdir(exist_ok=True)
            path = filedialog.asksaveasfilename(parent=self.winfo_toplevel(), initialdir=str(folder), defaultextension='.xlsx', initialfile='Tong_hop_diem.xlsx', filetypes=[('Excel', '*.xlsx')])
            if not path:
                return
            if Path(path).resolve() in (Path(self.left.path).resolve(), Path(self.right.path).resolve()):
                raise ValueError('Hãy chọn tên file mới; không ghi đè hai file nguồn.')
            export(path, result, [('Nguon_TL', self.left.path + ' | ' + self.left.sheet.get(), a), ('Nguon_TN', self.right.path + ' | ' + self.right.sheet.get(), b)], places)
            self.last_export = path
            messagebox.showinfo('Đã xuất Excel', f'Đã cộng {good} dòng.\nCần kiểm tra {len(result)-good} dòng.\n\nFile: {path}\n\nXem sheet Can_kiem_tra trước khi dùng điểm.')
        except PermissionError:
            messagebox.showerror('Không lưu được', 'Đóng file Excel kết quả đang mở hoặc chọn thư mục khác rồi thử lại.')
        except Exception as e:
            messagebox.showerror('Cần kiểm tra', str(e))


# Opened by HTB Hub; do not create a second Tk root/mainloop.
