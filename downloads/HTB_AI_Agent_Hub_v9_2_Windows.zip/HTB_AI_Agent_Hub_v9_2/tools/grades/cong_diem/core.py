"""Đối chiếu điểm: khóa họ tên + lớp, tùy chọn thêm môn. Python 3.10+."""
import csv
import io
import re
import unicodedata
from collections import defaultdict
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path


def text(value):
    return '' if value is None else str(value).strip()


def norm(value, fold=False):
    s = unicodedata.normalize('NFC', text(value)).casefold()
    s = ' '.join(s.split())
    if fold:
        s = ''.join(c for c in unicodedata.normalize('NFD', s) if not unicodedata.combining(c)).replace('đ', 'd')
    return s


def score(value):
    s = text(value).replace('\u00a0', '').strip()
    if not s:
        return None, 'Thiếu điểm'
    if isinstance(value, bool) or not re.fullmatch(r'[+-]?\d+(?:[.,]\d+)?', s):
        return None, 'Điểm không hợp lệ: ' + text(value)
    try:
        d = Decimal(s.replace(',', '.'))
        if not d.is_finite() or d < 0:
            raise InvalidOperation
        return d, ''
    except InvalidOperation:
        return None, 'Điểm không hợp lệ: ' + text(value)


def load(path):
    p = Path(path)
    if p.suffix.lower() == '.csv':
        raw = p.read_bytes()
        for encoding in ('utf-8-sig', 'utf-16', 'cp1258'):
            try:
                content = raw.decode(encoding)
                break
            except UnicodeError:
                continue
        else:
            raise ValueError('Không đọc được mã hóa CSV. Hãy lưu lại CSV UTF-8.')
        try:
            dialect = csv.Sniffer().sniff(content[:16000], delimiters=';,\t')
        except csv.Error:
            dialect = csv.excel
        return {'CSV': list(csv.reader(io.StringIO(content), dialect))}
    if p.suffix.lower() not in ('.xlsx', '.xlsm'):
        raise ValueError('Hỗ trợ .xlsx, .xlsm, .csv. Với .xls cũ, mở Excel và Save As .xlsx.')
    from openpyxl import load_workbook
    wb = load_workbook(p, read_only=True, data_only=True)
    try:
        return {ws.title: list(ws.iter_rows(values_only=True)) for ws in wb.worksheets}
    finally:
        wb.close()


def guess_header(rows):
    best = (0, 0)
    for i, row in enumerate(rows[:50]):
        cells = [norm(v, True) for v in row]
        n = sum(v in ('ho ten', 'ho va ten', 'ten hoc sinh', 'lop', 'diem', 'diem tu luan', 'diem trac nghiem', 'tong diem', 'ho va ten hoc sinh', 'ten', 'ho va ten lot', 'ho dem') for v in cells)
        if n > best[0]:
            best = n, i
    return best[1] + 1


@dataclass
class Mapping:
    header: int
    name: int
    classroom: int
    grade: int
    surname: int = -1
    subject: int = -1
    fixed_class: str = ''


def records(rows, m, fold=False):
    result = []
    for line, row in enumerate(rows[m.header:], m.header + 1):
        if not any(text(v) for v in row):
            continue
        def get(i):
            return text(row[i]) if 0 <= i < len(row) else ''
        name = ' '.join((get(m.surname) + ' ' + get(m.name)).split())
        cls = get(m.classroom) if m.classroom >= 0 else m.fixed_class.strip()
        subj = get(m.subject)
        raw = get(m.grade)
        # Giữ mọi dòng không rỗng để không làm mất học sinh có dữ liệu thiếu.
        value, err = score(raw)
        issues = []
        if not name:
            issues.append('Thiếu họ tên')
        if not cls:
            issues.append('Thiếu lớp')
        if m.subject >= 0 and not subj:
            issues.append('Thiếu môn')
        if err:
            issues.append(err)
        key = (norm(name, fold), re.sub(r'\s+', '', norm(cls)), norm(subj, fold))
        valid_key = bool(name and cls and (m.subject < 0 or subj))
        result.append(dict(name=name, cls=cls, subject=subj, raw=raw, value=value,
                           issues=issues, key=key if valid_key else None, line=line))
    return result


def combine(left, right, places=2):
    groups = [defaultdict(list), defaultdict(list)]
    keys = []
    for side, rows in enumerate((left, right)):
        for r in rows:
            k = r['key'] if r['key'] is not None else ('INVALID', side, r['line'])
            if k not in groups[0] and k not in groups[1]:
                keys.append(k)
            groups[side][k].append(r)
    result = []
    for k in keys:
        a, b = groups[0][k], groups[1][k]
        duplicate = len(a) > 1 or len(b) > 1
        # Trùng khóa: xuất từng dòng độc lập, không tạo tích Descartes hay tự chọn điểm.
        pairs = [(r, None) for r in a] + [(None, r) for r in b] if duplicate else [(a[0] if a else None, b[0] if b else None)]
        for l, r in pairs:
            base = l or r
            errors = []
            if duplicate:
                errors.append(f'Trùng họ tên + lớp/môn (TL: {len(a)} dòng; TN: {len(b)} dòng); cần kiểm tra')
            else:
                if l is None:
                    errors.append('Không có trong danh sách tự luận')
                if r is None:
                    errors.append('Không có trong danh sách trắc nghiệm')
            for label, rec in (('TL', l), ('TN', r)):
                if rec:
                    errors.extend(label + ': ' + msg for msg in rec['issues'])
            total = None
            if not errors:
                total = (l['value'] + r['value']).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP)
            result.append(dict(name=base['name'], cls=base['cls'], subject=base['subject'],
                               tl=l['value'] if l else None, tn=r['value'] if r else None,
                               total=total, status='; '.join(errors) if errors else 'Đã cộng',
                               line_tl=l['line'] if l else '', line_tn=r['line'] if r else '',
                               name_tn=r['name'] if r else ''))
    return result


HEADERS = ['STT', 'Họ và tên', 'Lớp', 'Môn', 'Điểm tự luận', 'Điểm trắc nghiệm', 'Tổng điểm', 'Trạng thái', 'Dòng TL', 'Dòng TN', 'Họ tên gốc TN']


def export(path, result, sources, places=2):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    wb.remove(wb.active)
    def append(ws, row):
        ws.append([float(v) if isinstance(v, Decimal) else v for v in row])
        # Chuỗi nhập từ file luôn là văn bản, không thực thi công thức.
        for c in ws[ws.max_row]:
            if isinstance(c.value, str):
                c.data_type = 's'
    def add(title, data, widths):
        ws = wb.create_sheet(title)
        for row in data:
            append(ws, row)
        ws.freeze_panes = 'A2'
        ws.auto_filter.ref = ws.dimensions
        ws.row_dimensions[1].height = 30
        for c in ws[1]:
            c.fill = PatternFill('solid', fgColor='174C83')
            c.font = Font(color='FFFFFF', bold=True)
        for i, width in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = width
        return ws
    def output_rows(items):
        return [HEADERS] + [[i, r['name'], r['cls'], r['subject'], r['tl'], r['tn'], r['total'], r['status'], r['line_tl'], r['line_tn'], r['name_tn']] for i, r in enumerate(items, 1)]
    widths = [7, 30, 14, 18, 17, 20, 17, 65, 12, 12, 30]
    for title, items in [('Tong_hop', result), ('Can_kiem_tra', [r for r in result if r['total'] is None])]:
        ws = add(title, output_rows(items), widths)
        for row in ws.iter_rows(min_row=2):
            for c in row:
                c.alignment = Alignment(vertical='top', wrap_text=True)
            for c in row[4:7]:
                c.number_format = '0' + ('.' + '0' * places if places else '')
            if row[6].value is None:
                for c in row:
                    c.fill = PatternFill('solid', fgColor='FFF1D4')
    for title, name, rows in sources:
        add(title, [['Dòng Excel', 'Họ tên', 'Lớp', 'Môn', 'Điểm gốc', 'Ghi chú', 'Nguồn']] +
            [[r['line'], r['name'], r['cls'], r['subject'], r['raw'], '; '.join(r['issues']), name] for r in rows], [16, 35, 15, 20, 18, 65, 60])
    # Ghi file tạm trước để không để lại file kết quả dở dang.
    import os
    import tempfile
    fd, tmp = tempfile.mkstemp(suffix='.xlsx', dir=str(Path(path).parent))
    os.close(fd)
    try:
        wb.save(tmp)
        os.replace(tmp, path)
    finally:
        wb.close()
        if os.path.exists(tmp):
            os.unlink(tmp)
