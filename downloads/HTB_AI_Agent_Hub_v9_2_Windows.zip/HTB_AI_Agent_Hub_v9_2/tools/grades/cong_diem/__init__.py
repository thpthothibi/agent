"""Tool cộng điểm được tích hợp trong HTB AI Agent."""
