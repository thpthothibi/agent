"""Native Tk chat UI. Provider credentials are shared with ReportWorkspace."""
import html
import json
import os
import queue
import threading
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
from tkinter.scrolledtext import ScrolledText
from pathlib import Path
from datetime import datetime
import webbrowser
from desktop_ui import label,button,card,FONT,WHITE,BLUE,MUTED
from report_engine import generate,extract,to_docx,unique_sources
from robot_brain import local_route,chat_prompt,redact,load_history,save_history,add_turn,export_chat
from robot_voice import start_speech

BASE=Path(__file__).resolve().parent

class RobotChat:
    def __init__(self,root,hub):
        self.hub,self.root=hub,root
        self.events=queue.Queue();self.worker=None;self.cancel_event=None;self.busy=False
        self.messages=[];self.files=[];self.last_answer='';self.last_sources=[];self.suggestions=''
        self.voice_process=None;self.voice_directory=None
        self.status=tk.StringVar(value='Chép chào thầy! Thầy muốn Chép giúp việc gì ạ?')
        self.provider=tk.StringVar(value='Gemini');self.search=tk.BooleanVar(value=False)
        self.remember=tk.BooleanVar(value=False);self.share_context=tk.BooleanVar(value=False)
        self.persona=tk.StringVar(value='Dễ thương, ngắn gọn')
        self.history_path=BASE/'du_lieu_be_bi'/'lich_su.json'
        label(root,'CÁ CHÉP AI • TRỢ LÝ AI',size=9,color=BLUE,bold=True).pack(anchor='w')
        label(root,'Mình cùng làm việc nhé thầy!',size=23,bold=True).pack(anchor='w',pady=(6,12))
        toolbar=card(root,padx=12,pady=10);toolbar.pack(fill='x',pady=(0,10))
        ttk.Combobox(toolbar,textvariable=self.provider,values=['Gemini','OpenAI'],state='readonly',width=10).pack(side='left')
        ttk.Combobox(toolbar,textvariable=self.persona,values=['Dễ thương, ngắn gọn','Chuyên nghiệp, chi tiết','Gia sư kiên nhẫn'],state='readonly',width=25).pack(side='left',padx=8)
        button(toolbar,'Kết nối AI',self.open_settings).pack(side='right')
        options=tk.Frame(root,bg=root.cget('bg'));options.pack(fill='x',pady=(0,8))
        ttk.Checkbutton(options,text='Tìm web (có thể tính phí)',variable=self.search).pack(anchor='w')
        ttk.Checkbutton(options,text='Gửi tên trang và trạng thái tác vụ hiện tại cho AI',variable=self.share_context).pack(anchor='w')
        ttk.Checkbutton(options,text='Lưu lịch sử chat trên máy (không lưu khóa/tệp đính kèm)',variable=self.remember,command=self.toggle_memory).pack(anchor='w')
        self.transcript=ScrolledText(root,height=16,font=(FONT,11),wrap='word',state='disabled',bg=WHITE)
        self.transcript.pack(fill='both',expand=True)
        self.transcript.tag_config('user',foreground='#174DA0',font=(FONT,11,'bold'))
        self.transcript.tag_config('assistant',foreground='#146C58',font=(FONT,11,'bold'))
        attachments=tk.Frame(root,bg=root.cget('bg'));attachments.pack(fill='x',pady=8)
        button(attachments,'Đính kèm tài liệu',self.attach).pack(side='left')
        button(attachments,'Bỏ tài liệu',self.clear_files).pack(side='left',padx=6)
        self.file_label=label(attachments,'Chưa đính kèm',size=9,color=MUTED,wraplength=400,justify='left');self.file_label.pack(side='left',padx=8)
        self.input=ScrolledText(root,height=3,font=(FONT,11),wrap='word');self.input.pack(fill='x')
        self.input.bind('<Control-Return>',lambda e:self.send())
        actions=tk.Frame(root,bg=root.cget('bg'));actions.pack(fill='x',pady=8)
        self.send_button=button(actions,'Gửi cho Chép  →',self.send,True);self.send_button.pack(side='left')
        self.stop_button=button(actions,'Dừng nhận phản hồi',self.stop);self.stop_button.pack(side='left',padx=6);self.stop_button.configure(state='disabled')
        button(actions,'Lưu cuộc trò chuyện',self.export).pack(side='left')
        button(actions,'Xóa lịch sử',self.clear_history).pack(side='right')
        quick=card(root,padx=10,pady=10);quick.pack(fill='x',pady=5)
        for caption,page in [('Nhập điểm',1),('Đối chiếu',2),('Phòng thi',3),('Báo cáo',4)]:
            button(quick,caption,lambda p=page:hub.show(p)).pack(side='left',padx=3)
        handoff=tk.Frame(root,bg=root.cget('bg'));handoff.pack(fill='x',pady=7)
        button(handoff,'Chuyển câu trả lời sang bản thảo',self.to_report).pack(side='left')
        button(handoff,'Xem nguồn web',self.open_sources).pack(side='left',padx=6)
        voice=tk.Frame(root,bg=root.cget('bg'));voice.pack(fill='x',pady=5)
        button(voice,'Đọc câu trả lời',self.speak).pack(side='left')
        button(voice,'Dừng đọc',self.stop_speech).pack(side='left',padx=6)
        button(voice,'Giúp lập kế hoạch',lambda:self.preset('Hãy giúp tôi lập kế hoạch công việc cho trường. Hỏi tôi mục tiêu, thời hạn và số liệu còn thiếu; sau đó đề xuất các bước thực hiện.')).pack(side='left')
        label(root,'Ctrl+Enter để gửi. Tài liệu đính kèm và 16 lượt chat gần nhất được gửi tới AI đã chọn. '
              'Tắt Tìm web nếu không muốn dùng nội dung này trong truy vấn tìm kiếm. API có thể phát sinh phí.',
              size=9,color=MUTED,wraplength=800,justify='left').pack(anchor='w',pady=6)
        label(root,'',textvariable=self.status,size=10,color=BLUE,wraplength=800,justify='left').pack(anchor='w',pady=8)
        self.render()
        hub.root.after(150,self.poll)

    def open_settings(self):
        self.hub.show(4);self.hub.report.tabs.select(4)

    def secrets(self):
        r=self.hub.report
        return (r.openai_key.get(),r.gemini_key.get())

    def render(self):
        self.transcript.configure(state='normal');self.transcript.delete('1.0','end')
        if not self.messages:self.transcript.insert('end','Cá Chép AI: Dạ, Chép có thể trả lời câu hỏi, tìm nguồn và đọc tài liệu thầy đính kèm.\n\n')
        for m in self.messages:
            self.transcript.insert('end',('Thầy' if m['role']=='user' else 'Cá Chép AI')+':\n',m['role'])
            self.transcript.insert('end',m['text']+'\n\n')
        self.transcript.configure(state='disabled');self.transcript.see('end')

    def persist(self):
        if self.remember.get():
            try:save_history(self.history_path,self.messages,self.secrets())
            except OSError:self.status.set('Chat vẫn còn trong phiên; không ghi được lịch sử vào máy.')

    def toggle_memory(self):
        if self.remember.get():
            try:
                if not self.messages:self.messages=load_history(self.history_path)
                self.persist();self.render()
            except (OSError,ValueError):
                self.remember.set(False);messagebox.showerror('Không đọc được lịch sử','Tệp lịch sử bị lỗi hoặc quá lớn. Thầy có thể xóa lịch sử rồi bật lại.',parent=self.hub.root)
        else:self.status.set('Đã tắt lưu thêm. Dùng Xóa lịch sử nếu muốn xóa cả bản đã lưu trên máy.')

    def clear_history(self):
        if self.busy:
            messagebox.showinfo('Đang trả lời','Đợi phản hồi kết thúc hoặc bấm dừng trước khi xóa.',parent=self.hub.root);return
        if not messagebox.askyesno('Xóa lịch sử','Xóa nội dung trò chuyện trong phiên và tệp lịch sử đã lưu trên máy?',parent=self.hub.root):return
        try:self.history_path.unlink(missing_ok=True)
        except OSError:
            messagebox.showerror('Chưa xóa được','Không xóa được tệp lịch sử trên máy.',parent=self.hub.root);return
        self.messages=[];self.last_answer='';self.last_sources=[];self.suggestions='';self.render()
        self.status.set('Đã xóa lịch sử chat.')

    def attach(self):
        paths=filedialog.askopenfilenames(parent=self.hub.root,title='Chọn tài liệu cho Cá Chép AI',filetypes=[('Tài liệu','*.docx *.pdf *.xlsx *.txt *.md *.csv')])
        selected=list(dict.fromkeys(self.files+list(paths)))
        if len(selected)>5:
            messagebox.showinfo('Giới hạn tài liệu','Mỗi lượt chat tối đa 5 tệp.',parent=self.hub.root);return
        self.files=selected;self.file_label.configure(text=', '.join(Path(p).name for p in self.files) or 'Chưa đính kèm')

    def clear_files(self):
        self.files=[];self.file_label.configure(text='Chưa đính kèm')

    def send(self):
        if self.busy:return
        question=self.input.get('1.0','end-1c').strip()
        if not question:return
        route=local_route(question)
        if route is not None:
            self.hub.show(route);self.input.delete('1.0','end');return
        if len(question)>16000:
            messagebox.showinfo('Nội dung quá dài','Câu hỏi tối đa 16.000 ký tự.',parent=self.hub.root);return
        report=self.hub.report;provider=self.provider.get()
        key,model=(report.gemini_key.get(),report.gemini_model.get()) if provider=='Gemini' else (report.openai_key.get(),report.openai_model.get())
        if not key.strip() or not model.strip():
            messagebox.showinfo('Kết nối AI','Điền khóa API và tên model tại Báo cáo & Kế hoạch → Kết nối AI.',parent=self.hub.root);self.open_settings();return
        if not self.hub.can_start(self):return
        context='Không gửi ngữ cảnh giao diện.'
        if self.share_context.get():
            active=next((a for a in self.hub.apps if a.busy),None)
            context='Trang: '+self.hub.titles[self.hub.current]+'; trạng thái: '+(active.status.get() if active else 'Sẵn sàng')
        config=dict(question=redact(question,self.secrets()),history=list(self.messages),context=context,
                    files=list(self.files),persona=self.persona.get(),provider=provider,key=key,model=model,search=self.search.get())
        self.cancel_event=threading.Event();self.busy=True
        self.send_button.configure(state='disabled');self.stop_button.configure(state='normal')
        self.status.set('Chép đang đọc và suy nghĩ…')
        self.worker=threading.Thread(target=self.work,args=(config,),daemon=True);self.worker.start()

    def work(self,c):
        try:
            documents=''
            for path in c['files']:
                if self.cancel_event.is_set():return
                documents+='\n\nTài liệu: '+Path(path).name+'\n'+extract(Path(path).name,Path(path).read_bytes())
            if len(documents)>100000:raise ValueError('Tổng tài liệu chat tối đa 100.000 ký tự; hãy chia nhỏ.')
            if self.cancel_event.is_set():return
            prompt=chat_prompt(c['question'],c['history'],c['context'],documents,c['persona'])
            if not c['search']:prompt+='\nTìm web đang tắt. Không khẳng định đã tra cứu nguồn trực tuyến hoặc xác minh thông tin mới.'
            result=generate(c['provider'],c['key'],c['model'],prompt,c['search'])
            if not self.cancel_event.is_set():self.events.put(('answer',(c['question'],result)))
        except Exception as exc:
            self.events.put(('error',str(exc) if isinstance(exc,(ValueError,RuntimeError)) else 'Không đọc được tài liệu hoặc kết nối AI.'))
        finally:self.events.put(('finished',None))

    def stop(self):
        if self.cancel_event:self.cancel_event.set()
        self.status.set('Đang dừng nhận phản hồi. Yêu cầu API đã gửi có thể vẫn được tính phí.')

    def poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='answer':
                    question,r=value
                    text=redact(r.text,self.secrets())
                    self.last_sources=unique_sources(r.sources);self.suggestions=r.suggestions
                    self.last_answer=text
                    add_turn(self.messages,'user',question);add_turn(self.messages,'assistant',text)
                    self.render();self.persist()
                    if redact(self.input.get('1.0','end-1c').strip(),self.secrets())==question:self.input.delete('1.0','end')
                    self.status.set('Chép đã trả lời. Thầy kiểm tra nguồn trước khi dùng nhé!')
                elif kind=='error':self.status.set(value)
                elif kind=='finished':
                    self.busy=False;self.send_button.configure(state='normal');self.stop_button.configure(state='disabled')
                    if self.cancel_event.is_set():self.status.set('Đã dừng nhận phản hồi. Nội dung chat trước vẫn còn.')
        except queue.Empty:pass
        if self.voice_process and self.voice_process.poll() is not None:
            failed=self.voice_process.returncode!=0
            self.stop_speech()
            if failed:self.status.set('Giọng Windows chưa đọc được. Kiểm tra giọng đã cài trong Windows.')
        self.hub.root.after(150,self.poll)

    def preset(self,text):
        self.input.delete('1.0','end');self.input.insert('1.0',text);self.input.focus_set()

    def speak(self):
        if not self.last_answer:return
        self.stop_speech()
        try:
            self.voice_process,self.voice_directory=start_speech(self.last_answer)
            self.status.set('Đang đọc bằng giọng trên Windows; tiếng Việt tùy giọng đã cài.')
        except RuntimeError as exc:self.status.set(str(exc))

    def stop_speech(self):
        if self.voice_process:
            if self.voice_process.poll() is None:
                self.voice_process.terminate()
                try:self.voice_process.wait(timeout=2)
                except Exception:pass
            self.voice_process=None
        if self.voice_directory:
            try:self.voice_directory.cleanup()
            except OSError:pass
            self.voice_directory=None

    def to_report(self):
        if not self.last_answer:return
        report=self.hub.report
        if report.busy:
            messagebox.showinfo('Đang soạn văn bản','Đợi Agent báo cáo kết thúc trước khi chuyển nội dung.',parent=self.hub.root);return
        if report.editor.get('1.0','end-1c').strip() and not messagebox.askyesno('Thay bản thảo','Thay nội dung bản thảo báo cáo bằng câu trả lời của Chép?',parent=self.hub.root):return
        report.put_text(report.editor,self.last_answer)
        report.result={'draft':self.last_answer,'sources':self.last_sources,'research':'Nội dung chuyển từ trò chuyện Cá Chép AI.','review':''}
        report.put_text(report.source_box,'\n'.join(s['title']+': '+s['url'] for s in self.last_sources))
        report.put_text(report.review_box,'Chưa chạy rà soát cho nội dung chuyển từ chat.')
        self.hub.show(4);report.tabs.select(1)

    def open_sources(self):
        if not self.last_sources and not self.suggestions:
            messagebox.showinfo('Nguồn web','Chưa có nguồn từ lần trả lời gần nhất. Bật Tìm web khi cần tra cứu.',parent=self.hub.root);return
        # Provider suggestion HTML is displayed in a local browser document, not executed as desktop code.
        import tempfile
        f=tempfile.NamedTemporaryFile(suffix='.html',prefix='be_bi_nguon_',delete=False)
        sources=''.join('<li><a href="'+html.escape(s['url'],quote=True)+'">'+html.escape(s['title'] or s['url'])+'</a></li>' for s in self.last_sources)
        content='<meta charset="utf-8"><title>Nguồn Cá Chép AI</title><h2>Nguồn tham khảo</h2><ul>'+sources+'</ul>'+self.suggestions
        f.write(content.encode('utf-8'));f.close();webbrowser.open(Path(f.name).as_uri())

    def export(self):
        if not self.messages:return
        path=filedialog.asksaveasfilename(parent=self.hub.root,initialfile='Tro_chuyen_Be_Bi.md',defaultextension='.md',filetypes=[('Markdown','*.md'),('Word','*.docx')])
        if not path:return
        text=redact(export_chat(self.messages),self.secrets())
        try:
            if Path(path).suffix.lower()=='.docx':Path(path).write_bytes(to_docx(text))
            else:Path(path).write_text(text,encoding='utf-8')
            self.status.set('Đã lưu cuộc trò chuyện.')
        except OSError:messagebox.showerror('Không lưu được','Kiểm tra quyền ghi hoặc đóng tệp đang mở.',parent=self.hub.root)
