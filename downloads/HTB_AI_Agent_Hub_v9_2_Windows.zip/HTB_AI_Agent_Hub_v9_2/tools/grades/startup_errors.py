"""Report Tk callback failures locally; never retry an external write."""
import traceback
from pathlib import Path
from tkinter import messagebox

def startup_hint(detail):
    text=detail.lower()
    if ('executable' in text and ('exist' in text or 'not found' in text)) or ('chrome' in text and ('distribution' in text or 'not found' in text)):
        return 'Không tìm thấy trình duyệt yêu cầu. Tool đang dùng Google Chrome (channel chrome). Hãy cài Google Chrome; cài Chromium của Playwright chưa thay thế được Chrome trong cấu hình này.'
    if any(word in text for word in ('singletonlock','processsingleton','user data directory is already in use','profile in use')):
        return 'Hồ sơ Chrome Agent đang được một phiên khác sử dụng. Đóng cửa sổ Chrome Agent cũ và thử lại. Không cần xóa hồ sơ hoặc đóng tất cả Chrome cá nhân.'
    if 'no module named' in text and ('playwright' in text or 'pyperclip' in text or 'openpyxl' in text):
        return 'Thiếu thư viện trong môi trường đang chạy. Mở bằng 2_MO_HE_THONG.bat sau khi chạy thành công 1_CAI_DAT_WINDOWS.bat.'
    return ''

def install_callback_reporting(root,folder,apps=lambda:()):
    def report(kind,value,tb):
        path=Path(folder)/'loi_giao_dien.txt'
        try:
            path.write_text(''.join(traceback.format_exception(kind,value,tb)),encoding='utf-8')
            location='Chi tiết được lưu tại: '+str(path)
        except OSError:
            location='Không ghi được nhật ký; kiểm tra quyền ghi thư mục đã giải nén.'
        for app in apps():
            worker=getattr(app,'worker',None)
            if getattr(app,'busy',False) and (worker is None or not worker.is_alive()):
                app.events.put(('error','Lỗi thao tác giao diện: '+kind.__name__+'. '+location))
        try:
            messagebox.showerror('HTB — Không thực hiện được thao tác',
                'Nút bấm gặp lỗi '+kind.__name__+'. Chương trình chưa xác nhận tác vụ đã bắt đầu.\n'+location+'\nKhông tự chạy lại thao tác ghi; kiểm tra trạng thái trước khi thử lại.',parent=root)
        except Exception:
            pass
    root.report_callback_exception=report
    return report
