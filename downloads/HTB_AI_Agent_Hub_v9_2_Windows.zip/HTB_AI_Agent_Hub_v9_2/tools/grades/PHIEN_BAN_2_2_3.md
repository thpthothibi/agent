# HTB v2.2.3 — Sửa xác nhận lớp có học sinh nghỉ và Excel không đủ mọi tên web

Căn cứ loi_khoi_dong(1).txt và chan_doan_giao_dien(3).json: 10A06 có 47 dòng web, Excel 44 tên. Hai dòng nghỉ đã được nhận diện; Nguyễn Ngọc Trinh còn trên web nhưng không có trong Excel khiến bộ kiểm tra cũ từ chối cả lớp.

Nay giữ kiểm tra đủ các tên Excel, nhưng tạo dòng bỏ qua riêng cho học sinh web không có nguồn. Không gán nhầm trạng thái nghỉ, không dán vào các ô đó. Vùng dán luôn tách theo STT thật trên web. Nhật ký/báo cáo ghi tên, STT, lý do bỏ qua. Chế độ Đối chiếu vẫn hiển thị học sinh ngoài Excel để người dùng kiểm tra.

Kiểm tra: 142 unittest, 141 đạt và một bỏ qua do không có Chromium. Mô phỏng 47/44, học sinh nghỉ tại 4 và 44, thiếu tên Excel tại 41, tiếp tục 45–47 đều đạt. Thiếu tên Excel trên web, trùng tên hoặc sai danh tính vẫn bị chặn. Chưa ghi điểm trên VietSchool thực tế.

Chạy: đóng ứng dụng cũ, giải nén bản mới, chạy CHAY_HTB_AI_AGENT.bat, chọn lại toàn bộ Excel. Ô có điểm không bị nhập lại. Muốn nhập điểm cho Nguyễn Ngọc Trinh thì bổ sung dữ liệu em đó vào Excel.
