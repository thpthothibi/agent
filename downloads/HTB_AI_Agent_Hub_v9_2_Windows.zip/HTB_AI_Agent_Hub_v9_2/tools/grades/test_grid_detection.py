import queue, threading, unittest
from unittest.mock import Mock
from full_auto import AutoWorker

class GridDetectionTests(unittest.TestCase):
    def make(self):return AutoWorker('',queue.Queue(),threading.Event())
    def test_javascript_error_not_silently_swallowed(self):
        w=self.make();w.frames=Mock(return_value=['main']);w.dom=Mock(side_effect=RuntimeError('bad cell shape'))
        with self.assertRaisesRegex(RuntimeError,'bad cell shape'):w.grid()
    def test_zero_frames_reports_detection_not_paste_failure(self):
        w=self.make();w.frames=Mock(return_value=[])
        with self.assertRaisesRegex(RuntimeError,'0 khung'):w.grid()
    def test_one_valid_snapshot(self):
        w=self.make();w.frames=Mock(return_value=['main']);snap={'rows':[{'stt':1}]};w.dom=Mock(return_value=snap)
        self.assertEqual(w.grid(),('main',snap))
    def test_hidden_iframe_excluded(self):
        w=self.make();main=Mock(url='https://nhapdiem.truonghocviet.vn/');hidden=Mock(url=main.url);hidden.frame_element.return_value.is_visible.return_value=False
        visible=Mock(url=main.url);visible.frame_element.return_value.is_visible.return_value=True
        page=Mock(main_frame=main,frames=[main,hidden,visible]);w.page=Mock(return_value=page)
        self.assertEqual(w.frames(),[main,visible])

if __name__=='__main__':unittest.main()
