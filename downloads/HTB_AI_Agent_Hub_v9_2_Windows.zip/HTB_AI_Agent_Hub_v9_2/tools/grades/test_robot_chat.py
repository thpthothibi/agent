import queue
import threading
import unittest
from unittest.mock import patch,Mock
from robot_chat import RobotChat
from report_engine import Result


class RobotChatWorkerTests(unittest.TestCase):
    def app(self):
        app=object.__new__(RobotChat);app.cancel_event=threading.Event();app.events=queue.Queue()
        return app

    def config(self):
        return dict(files=[],question='Xin chào',history=[],context='Không chia sẻ',persona='Dễ thương',provider='Gemini',key='fake',model='test',search=False)

    @patch('robot_chat.generate',return_value=Result('Dạ, Chép đây!'))
    def test_success_queues_result_and_finishes(self,generate):
        app=self.app();app.work(self.config())
        self.assertEqual(app.events.get()[0],'answer')
        self.assertEqual(app.events.get()[0],'finished')
        self.assertIn('Tìm web đang tắt',generate.call_args.args[3])

    @patch('robot_chat.generate')
    def test_cancel_prevents_api_call(self,generate):
        app=self.app();app.cancel_event.set();app.work(self.config())
        generate.assert_not_called()
        self.assertEqual(app.events.get()[0],'finished')

    @patch('robot_chat.generate',side_effect=RuntimeError('Hết hạn mức'))
    def test_api_error_finishes_without_fake_answer(self,generate):
        app=self.app();app.work(self.config())
        self.assertEqual(app.events.get(),('error','Hết hạn mức'))
        self.assertEqual(app.events.get()[0],'finished')

    @patch('robot_chat.generate')
    def test_cancel_in_flight_discards_late_reply(self,generate):
        app=self.app()
        def fake(*a):app.cancel_event.set();return Result('Trả lời muộn')
        generate.side_effect=fake;app.work(self.config())
        self.assertEqual(app.events.get()[0],'finished')
        self.assertTrue(app.events.empty())

if __name__=='__main__':unittest.main()
