import tkinter as tk
import unittest
from unittest.mock import Mock,patch
from types import SimpleNamespace
import test_carp_swim as existing
from mascot import FloatingMascot


class MotionRecoveryTests(unittest.TestCase):
    def fish(self):
        fish=existing.CarpSwimTests().robot()
        fish.timer='old-timer';fish.tooltip_until=0;fish.pause_until=0
        fish.frame.winfo_exists.return_value=True
        return fish

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_native_popdown_does_not_kill_loop_and_motion_returns(self,clock):
        fish=self.fish()
        fish.root.grab_current.side_effect=[KeyError('popdown'),None]
        fish.tick()
        self.assertEqual(fish.position,(100,200))
        fish.frame.after.assert_called_once()
        fish.swim_last=10;fish.tick()
        self.assertLess(fish.position[0],100)
        self.assertEqual(fish.frame.after.call_count,2)

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_expired_tooltip_unpauses_even_if_mouse_leave_was_lost(self,clock):
        fish=self.fish();tip=Mock();fish.tooltip=tip;fish.tooltip_until=9
        fish.tick()
        tip.destroy.assert_called_once()
        self.assertIsNone(fish.tooltip)
        self.assertLess(fish.position[0],100)

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_short_hover_pause_is_respected(self,clock):
        fish=self.fish();fish.tooltip=Mock();fish.tooltip_until=11
        fish.tick()
        self.assertEqual(fish.position,(100,200))
        fish.tooltip.destroy.assert_not_called()
        fish.frame.after.assert_called_once()

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_transient_canvas_error_still_schedules_next_frame(self,clock):
        fish=self.fish();fish.canvas.itemconfigure.side_effect=tk.TclError('redraw')
        fish.tick()
        fish.frame.after.assert_called_once()
        self.assertIn('TclError',fish.last_motion_error)
        fish.canvas.itemconfigure.side_effect=None;fish.swim_last=10;fish.tick()
        fish.sync_position.assert_called_once()
        self.assertEqual(fish.frame.after.call_count,2)

    @patch('mascot.time.monotonic',return_value=10.1)
    @patch('mascot.physical_left_button_down',return_value=False)
    def test_lost_release_clears_drag_without_opening_chat(self,button,clock):
        fish=self.fish();fish.press=(1,2,100,200);fish.dragged=True;fish.say_hello=Mock()
        fish.tick()
        self.assertIsNone(fish.press);self.assertFalse(fish.dragged)
        self.assertLess(fish.position[0],100);fish.say_hello.assert_not_called()

    @patch('mascot.time.monotonic',return_value=10.1)
    @patch('mascot.physical_left_button_down',return_value=True)
    def test_real_drag_still_pauses_swimming(self,button,clock):
        fish=self.fish();fish.press=(1,2,100,200)
        fish.tick()
        self.assertEqual(fish.position,(100,200))
        self.assertIsNotNone(fish.press)

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_resume_enables_motion_and_replaces_old_timer(self,clock):
        fish=self.fish();fish.visible=False;fish.animate.get.return_value=False
        fish.press=(1,2,3,4);fish.pause_until=100;fish.tooltip=Mock()
        fish.resume_swimming()
        fish.animate.set.assert_called_once_with(True)
        self.assertTrue(fish.visible);self.assertIsNone(fish.press)
        self.assertIsNone(fish.tooltip);self.assertEqual(fish.pause_until,0)
        fish.frame.after_cancel.assert_called_once_with('old-timer')
        fish.frame.after.assert_called_once_with(16,fish.tick)

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_click_pause_is_short_and_chat_opens_once(self,clock):
        fish=self.fish();fish.press=(1,2,3,4);fish.dragged=False;fish.say_hello=Mock()
        fish.drag_end(None)
        self.assertAlmostEqual(fish.pause_until,11.3)
        fish.say_hello.assert_called_once()

    @patch('mascot.time.monotonic',return_value=10.1)
    def test_destroyed_canvas_does_not_spawn_a_timer(self,clock):
        fish=self.fish();fish.frame.winfo_exists.return_value=False
        fish.tick();fish.frame.after.assert_not_called()

    def test_minimize_clears_a_pending_drag(self):
        fish=self.fish();fish.press=(1,2,3,4)
        fish.owner_unmapped(SimpleNamespace(widget=fish.root))
        self.assertIsNone(fish.press);fish.frame.withdraw.assert_called_once()


if __name__=='__main__':unittest.main()
