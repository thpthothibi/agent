# HTB v2.4.1 — Sửa Cá Chép đứng yên

Chuột phải lên cá → Cho cá bơi lại. Bản này tự phục hồi chuyển động sau tooltip/hộp chọn và rút ngắn dừng khi trò chuyện; xem PHIEN_BAN_2_4_1.md.

# HTB v2.4.0 — Thêm menu Chuyển điểm vào mẫu

Xem HUONG_DAN_CHUYEN_DIEM.md để nạp nhiều file Excel, chọn cột, xem trước và xuất mẫu. Giữ luồng nhập hết các lớp rồi kiểm tra cuối đợt.

# HTB v2.3.2 — Bỏ qua hai em Trần Ngọc Khánh lớp 12A06

Đã thêm quy tắc riêng theo đúng lớp và họ tên: mọi dòng Trần Ngọc Khánh ở 12A06 được ghi “Bỏ qua theo yêu cầu: trùng tên”, không có trong clipboard, không thay đổi ô điểm và không bị kết luận đúng/sai ở lượt kiểm tra cuối đợt. Với bảng trong ảnh, giữ STT 9–10 thành khoảng trống giữa hai vùng dán; STT 11 trở đi không bị dồn lên.

Excel có cả hai tên trùng này vẫn đọc được và nhập các học sinh khác. Quy tắc áp dụng các môn/cột của 12A06; không áp dụng ở lớp khác. Các trường hợp trùng tên khác vẫn bị chặn như cũ.

Giữ luồng nhập hết tất cả lớp rồi tải lại một lần và kiểm tra tổng thể. Đóng bản cũ, giải nén bản mới, chạy CHAY_HTB_AI_AGENT.bat và chọn lại toàn bộ Excel. Các ô có điểm không bị nhập lại. Hai em được bỏ qua cần thầy nhập riêng sau nếu muốn.

# HTB v2.3.1 — Nhập hết tất cả các lớp rồi tự kiểm tra một lượt

Xem HUONG_DAN_KIEM_TRA_TU_DONG.md. Không tải lại sau từng lớp/vùng. Các hướng dẫn cũ bên dưới không còn mô tả luồng hiện tại.

# HTB v2.3.0 — Tự nhập và kiểm tra kỹ ngay sau lưu

Xem HUONG_DAN_KIEM_TRA_TU_DONG.md. Tính năng kiểm tra sau tải lại luôn bật; không cần bấm riêng. Các hướng dẫn cũ bên dưới mô tả các bản trước.

# HTB v2.2.4 — Chỉ dán đúng tên, không tìm thấy thì tự bỏ qua

- Ghép theo họ tên đầy đủ đã chuẩn hóa khoảng trắng, hoa/thường và dấu theo bộ dò hiện có; không dò gần đúng, không lấy STT Excel để gán cho học sinh khác.
- Tên trên web không có trong Excel: giữ nguyên ô điểm và bỏ qua.
- Tên trong Excel không tìm thấy trên web sau khi quét danh sách: ghi rõ “Bỏ qua: không tìm thấy tên trên web” rồi tiếp tục các tên khớp và lớp kế tiếp.
- Chỉ các tên khớp duy nhất, đúng cột, chưa có điểm và không nghỉ/khóa mới được đưa vào vùng dán. Tên trùng, cột không xác định, chưa đọc được bảng hoặc danh tính thay đổi vẫn dừng.
- Các dòng bỏ qua được ghi trong nhật ký, bảng xử lý và CSV. Chế độ Đối chiếu vẫn báo các tên chưa tìm được để thầy rà soát.

Đóng bản cũ, giải nén toàn bộ bản mới, chạy CHAY_HTB_AI_AGENT.bat và chọn lại toàn bộ Excel. Tài khoản/mật khẩu tùy chọn để tự đăng nhập như bản trước; ô đã có điểm không nhập lại.

# HTB v2.2.3 — Lớp có học sinh nghỉ và danh sách Excel thiếu người

Sửa trường hợp lớp 10A06 trong nhật ký: web 47 dòng, Excel 44 tên; STT 4 và 44 nghỉ, thêm Nguyễn Ngọc Trinh không có trong Excel.

- Học sinh nghỉ: bỏ qua theo trạng thái nhận diện trên web hoặc Excel.
- Học sinh trên web không có trong Excel: bỏ qua riêng với nhãn “Bỏ qua: không có trong Excel”; không coi là nghỉ và không thay đổi ô điểm.
- Tất cả học sinh đang học có trong Excel vẫn phải tìm thấy trên web; thiếu tên, tên trùng, sai lớp/cột, hoặc danh tính thay đổi vẫn dừng trước khi dán.
- Giữ STT trên web và tách vùng dán ở từng dòng nghỉ/không có nguồn, nên các học sinh sau đó không bị dồn điểm.
- Nhật ký và báo cáo CSV ghi rõ từng trường hợp bỏ qua. Đối chiếu vẫn báo “Web có học sinh ngoài Excel” để thầy kiểm tra dữ liệu thiếu.
- Giữ tự đăng nhập, làm tròn đúng một chữ số thập phân như VietSchool, tự chuyển lớp và các công cụ HTB.

Đóng bản cũ, giải nén bản mới, chạy CHAY_HTB_AI_AGENT.bat và chọn lại toàn bộ Excel. Những ô đã có điểm không bị dán lại. Nếu muốn nhập cho học sinh ngoài Excel, bổ sung học sinh đó vào file nguồn.

# HTB v2.2.2 — Tự chuyển lớp và tự đăng nhập

- Điểm số chuẩn hóa một chữ số thập phân HALF_UP trước khi dán: 8,75 → 8,8; 6,25 → 6,3, khớp cách VietSchool hiển thị trong ảnh lỗi. Giữ điểm Excel gốc trong cột original của báo cáo CSV. Đối chiếu áp dụng cùng quy tắc và ghi chú chuyển đổi.
- Giữ xác minh đúng tên/cột/giá trị/chữ xanh. Chỉ chuyển nhóm kế tiếp sau khi xác minh hoặc bỏ qua các ô đã có điểm. Không tự dán lại một vùng vừa gửi khi chưa xác định lưu thành công.
- Mở Nhập điểm, nhập Tài khoản và Mật khẩu VietSchool rồi chọn Excel. Chương trình chỉ tự gửi một lần trên đúng tên miền HTTPS nhapdiem.truonghocviet.vn. Mật khẩu được che, không lưu ra tệp. Không tự thử lại nhiều lần khi tài khoản sai.
- Nếu phiên Chrome còn đăng nhập thì dùng luôn. Nếu CAPTCHA, OTP hoặc không nhận diện duy nhất biểu mẫu thì chờ thao tác trong Chrome.
- Đóng ứng dụng cũ, giải nén toàn bộ bản mới, chạy CHAY_HTB_AI_AGENT.bat. Chọn lại toàn bộ Excel để tiếp tục: lớp đã có điểm được bỏ qua; các lớp còn lại tự chạy. Sau đó dùng Đối chiếu để kiểm tra toàn bộ các lớp.
- Chưa thử trực tiếp trên tài khoản VietSchool của thầy. Các hướng dẫn cũ bên dưới có thể mô tả phiên bản trước.

# HTB v2.2.1 — Sửa dừng sau lớp đầu

VietSchool hiển thị điểm một chữ số thập phân: nay chuẩn hóa HALF_UP (8,75 → 8,8; 6,25 → 6,3) trước dán và khi đối chiếu. Điểm gốc và điểm nhập đều có trong báo cáo CSV. Không nới lỏng xác minh chữ xanh hoặc đúng học sinh/cột.

Đóng bản cũ, giải nén bản mới và chọn lại toàn bộ Excel. Ô đã có điểm vẫn được bỏ qua; ứng dụng tiếp tục các nhóm lớp còn lại. Dùng Đối chiếu để kiểm tra lại cả lớp đã lưu.

# HTB v2.2.0 — Nhập điểm VietSchool v3.5 tích hợp

Xem PHIEN_BAN_2_2_0.md để biết sửa lỗi điểm 8,75 và cách chạy.

# Bản cập nhật Cá Chép AI v2.1.6

Xem HUONG_DAN_CA_CHEP_AI.md để dùng nhân vật mới. Các hướng dẫn Bé Bi bên dưới là tài liệu của phiên bản cũ.

# HTB AI Agent v2.1.2 — Bé Bi nổi tự do, kéo thả

Gộp từ VietSchool Agent v3.6, VietSchool Đối chiếu v1 và Tool Sắp xếp phòng thi HTB v2.

## Cài và mở trên Windows

1. Giải nén **toàn bộ** ZIP vào thư mục riêng, ví dụ `D:\HTB_AI_Agent_v1`. Không chạy trực tiếp bên trong ZIP.
2. Máy cần Python 3.10 trở lên (bản có Tcl/Tk, chọn Add Python to PATH khi cài) và Google Chrome.
3. Nhấp đúp **CHAY_HTB_AI_AGENT.bat**. Lần đầu cần Internet để tải thư viện; chương trình tạo môi trường Python riêng trong `.venv`.
4. Những lần sau mở lại cùng file BAT. Đây là bản mã nguồn chạy bằng Python, chưa phải bộ cài EXE.

Nhập điểm, đối chiếu, SBD/phòng thi không cần khóa AI. Riêng Agent Báo cáo & Kế hoạch dùng API Gemini/OpenAI, cần Internet và khóa API của nhà cung cấp được chọn. Chưa dùng mô hình AI ngoại tuyến.

## Một giao diện điều khiển

**Mới trong v2.0: Trò chuyện Bé Bi** nằm trong cùng cửa sổ. Bé có thể hỏi đáp qua Gemini/OpenAI, đọc tài liệu đính kèm, tìm web, lưu lịch sử tùy chọn, chuyển nội dung sang bản thảo và đọc bằng giọng Windows. Xem **HUONG_DAN_BE_BI.md** để thiết lập. Các mô tả v1.2/v1.3 bên dưới là lịch sử tính năng, v2.0 bổ sung khả năng chat thực tế.

- **Tổng quan:** chọn/đổi Excel điểm dùng chung cho nhập điểm và đối chiếu, mở các chức năng và thư mục báo cáo.
- **Nhập điểm VietSchool:** mở mục Nhập điểm, bấm “Bắt đầu nhập điểm”. Nếu đã chọn file ở Tổng quan sẽ dùng file đó. Nếu chưa có, hộp chọn file xuất hiện. Chrome Agent mở lên để bạn tự đăng nhập; phần còn lại xử lý theo Excel. Giữ khả năng nhận xét Đ/CĐ, dò tên, chỉ xử lý môn/cột có điểm và bỏ qua học sinh nghỉ theo v3.6.
- **Đối chiếu điểm:** sau khi nhập xong, mở mục Đối chiếu, bấm “Bắt đầu đối chiếu”. Chương trình đóng phiên Chrome trước, mở lại cùng hồ sơ, tải lại VietSchool và đọc so sánh. Không tự ghi sửa điểm. Báo cáo gồm đúng, sai và chưa kiểm tra được.
- **Báo cáo & Kế hoạch:** làm việc ngay trong cửa sổ chính. Chọn mẫu, tài liệu số liệu hoặc dùng Excel đang chọn ở Tổng quan. Cấu hình AI tìm nguồn, viết và rà soát; sửa bản thảo, xuất Word/Markdown/JSON vào thư mục báo cáo. Xem `HUONG_DAN_BAO_CAO.md`.
- **SBD & Phòng thi:** bấm nút mở công cụ. Giao diện xử lý Excel mở ở trình duyệt trên máy, dùng được ngoại tuyến. Chọn danh sách riêng trong công cụ này. Có tạo/giữ SBD, sĩ số riêng, nhóm môn, mẫu trường và xuất Excel/in PDF. Xem `phong_thi/HUONG_DAN.txt`.

Nhập điểm và đối chiếu nằm trong cùng cửa sổ, chọn từ menu bên trái. SBD/phòng thi giữ giao diện trình duyệt của bản v2 và mở từ menu chung; bản này chưa nhúng giao diện đó vào cửa sổ desktop. Dữ liệu giữa danh sách phòng thi và file nhập điểm chưa tự chuyển đổi cấu trúc.

## Quy trình sử dụng

1. Sắp phòng, tạo SBD và xuất danh sách khi chuẩn bị kỳ thi.
2. Chuẩn bị Excel điểm theo `Mau_Nhap_Diem_VietSchool_Chrome.xlsx`.
3. Chọn file điểm ở Tổng quan, chạy Nhập điểm.
4. Chờ kết thúc; chuyển Đối chiếu để kiểm tra lại cùng file.
5. Mở thư mục `bao_cao` để xem kết quả. Không xem “kết thúc” là mọi điểm đều đúng; đọc các dòng sai/chưa kiểm tra/bỏ qua trong báo cáo.

Không chạy hai tác vụ VietSchool cùng lúc. Khi dừng, chờ tác vụ kết thúc rồi chuyển chức năng. Khi chuyển chức năng sau hoàn tất, chương trình yêu cầu phiên trước nhả Chrome trước khi chạy phiên mới. Đóng các bản Agent cũ trước khi mở bộ tổng hợp vì chúng dùng chung hồ sơ Chrome.

Các báo cáo điểm lưu tại `bao_cao` cạnh chương trình; Excel phòng thi tải về theo thiết lập trình duyệt. Phần phòng thi xử lý file ngay trong trình duyệt, không tự lưu dữ liệu học sinh khi đóng trang. Giữ thư mục chương trình ở nơi bạn có quyền ghi.

## Kiểm thử phiên bản gốc v1.1

Đã chạy 82 ca unittest: 81 đạt, 1 bỏ qua do môi trường thiếu thư viện tùy chọn. Bao gồm kiểm tra dò tên, phạm vi môn, xử lý bảng điểm, đối chiếu và phối hợp chuyển phiên Chrome. Đã kiểm tra cú pháp Python.

Chưa kiểm thử giao diện desktop trên Windows hoặc phiên đăng nhập VietSchool thật trong lần đóng gói này. Giao diện VietSchool thay đổi có thể cần cập nhật bộ đọc. Đối chiếu đọc từ giao diện sau tải lại, không truy vấn trực tiếp cơ sở dữ liệu VietSchool. Các hướng dẫn chi tiết gốc nằm trong `HUONG_DAN_NHAP_DIEM.md` và `HUONG_DAN_DOI_CHIEU.md`.

## Chẩn đoán

- Không mở được: chạy BAT và xem lỗi ở cửa sổ lệnh; kiểm tra Python/Tcl-Tk và Chrome.
- Chrome báo hồ sơ đang dùng: đóng bản Agent/Chrome Agent cũ, chờ vài giây rồi thử lại.
- Sai cấu trúc Excel: dùng file mẫu đi kèm, xem hướng dẫn nhập điểm gốc.
- Không đọc được bảng: dừng, kiểm tra lớp/môn/học kỳ; giữ `chan_doan_giao_dien.json` và `loi_khoi_dong.txt` nếu được tạo để sửa lỗi.
- Xếp phòng/SBD: có thể mở trực tiếp `phong_thi/index.html` ngay cả khi máy chưa cài Python.

## Giao diện kế thừa v1.1

- Menu xanh đậm bên trái, có nút thu gọn ☰.
- Tổng quan gồm bốn thẻ chức năng, vùng chọn Excel chung và số báo cáo thật đang có trên máy.
- Màn hình nhập/đối chiếu có bảng kết quả rộng, cuộn ngang/dọc và màu trạng thái.
- Trang có cuộn dọc để thao tác trên màn hình nhỏ; chữ rõ, font Segoe UI.
- Phòng thi/SBD có tông màu đồng bộ; giữ nguyên bố cục in và mẫu Excel.
- Nhãn “Sẵn sàng” chỉ trạng thái tác vụ trên máy; không xác nhận kết nối VietSchool.

Giao diện đã được mở và kiểm tra bằng màn hình ảo Linux; vẫn cần chạy thử trên Windows và tài khoản VietSchool thực tế.

Ảnh trong thư mục `xem_truoc` thuộc phiên bản v1.1 trước khi thêm Agent văn bản; chưa có ảnh màn hình v1.2.

## Bổ sung ở v1.2

- Thêm Agent Báo cáo & Kế hoạch trực tiếp trong cửa sổ chính, không chạy ứng dụng web riêng.
- Dùng cùng nút CHAY_HTB_AI_AGENT.bat; tự cài thêm thư viện đọc PDF và xuất Word khi cần.
- Chọn Gemini hoặc OpenAI cho từng vai trò: tìm nguồn, viết, rà soát. Khóa giữ trong phiên, không xuất ra hồ sơ.
- Dùng được Excel đang chọn của bộ tổng hợp khi bạn chủ động bấm “Dùng Excel đang chọn”.
- Mỗi lần chỉ chạy một tác vụ trong bộ tổng hợp; trạng thái hoạt động chung bao gồm Agent văn bản.
- Nút dừng ngăn bước tiếp theo; yêu cầu API đã gửi có thể tiếp tục đến khi trả lời hoặc hết thời gian.
- Bản thảo được giữ lại nếu rà soát lỗi. Đóng chương trình sẽ mất phần chưa lưu.
- Đã chạy kiểm thử Python và kiểm tra logic điều phối bằng phản hồi mô phỏng. Chưa kiểm thử API thật, giao diện mới trên Windows hoặc VietSchool thực tế.

## Bổ sung ở v1.3 — linh vật Bé Bi

Robot nhỏ tông trắng/xanh dương xuất hiện ở thanh dưới cửa sổ. Bé Bi chào thầy, gợi ý theo trang đang mở, hiển thị tiến độ thật khi Agent đang làm việc và nhắc kiểm tra kết quả khi tác vụ kết thúc. Bé không tự xác nhận kết quả đúng hoặc hoàn thành thành công.

- Chuyển động nhún nhẹ và ngôi sao khi đang xử lý. Đây là một ảnh linh vật có chuyển động vị trí, chưa phải hoạt hình tay/chân hoặc nhiều biểu cảm khuôn mặt.
- Bấm ảnh để chào Bé Bi.
- Bỏ chọn **Chuyển động** để dừng nhún.
- Bấm **Thu gọn** để ẩn thanh; bấm **Bé Bi ♡** phía trên để hiện lại.
- Linh vật chạy tại máy, không cần API và không đọc tệp hoặc gửi thêm dữ liệu. Đây là bạn đồng hành hiển thị trạng thái, chưa có chức năng trò chuyện bằng giọng nói hoặc chat tự do.
- Không thêm thư viện cài đặt; sử dụng Tkinter có sẵn và ảnh PNG đi kèm. Nếu ảnh bị thiếu, chương trình vẫn mở với nhãn Bé Bi.

Kiểm thử v1.3: kiểm tra trạng thái linh vật và chạy lại bộ unittest Python; chưa kiểm thử giao diện mới trên Windows hoặc kết nối API/VietSchool thật.

## Kiểm thử v2.0

106 ca unittest: 105 đạt, 1 bỏ qua do thiếu Chromium kiểm thử. Đã kiểm tra cú pháp Python. Lượt API trong kiểm thử dùng phản hồi mô phỏng. Chưa kiểm thử API/VietSchool thật, giao diện mới và giọng hệ thống trên Windows.

## Sửa giao diện v2.0.1

Trong tab Đối chiếu điểm có vùng **1. CHỌN EXCEL ĐỐI CHIẾU** riêng ngay phía trên các nút chạy. Bấm **Chọn Excel đối chiếu…**, chọn file .xlsx trên máy, kiểm tra tên/đường dẫn rồi bấm **Bắt đầu đối chiếu**. File vẫn dùng chung với Nhập điểm và Tổng quan; không cần quay về Tổng quan để chọn. Bản trước có nút Đổi file Excel cùng hàng nút chạy, dễ bị khuất khi cửa sổ hẹp.

## Sửa ghép bảng v2.0.2

VietSchool có thể hiển thị danh sách họ tên và điểm ở hai bảng HTML có chiều cao hàng khác nhau. Bản này ưu tiên ghép mã hàng công khai. Nếu không có mã hàng, chỉ ghép theo thứ tự DOM khi có đầy đủ STT từ 1, hai bảng có cùng số hàng và các cột ổn định. Không ghép hai bảng này theo vị trí dọc màn hình. Nếu thiếu hàng/ô hoặc không khớp mã hàng thì dừng kết luận và báo Chưa kiểm tra được. Thay đổi nằm ở bộ đọc bảng dùng chung nhập điểm và đối chiếu; không thay quy tắc điểm hoặc thứ tự học sinh trong Excel.

Khi thử lại: đóng Agent/Chrome Agent cũ, giải nén bản mới sang thư mục riêng, chạy CHAY_HTB_AI_AGENT.bat, chọn Excel tại Đối chiếu và chạy lại. Không tự nhập lại hàng loạt điểm đã lưu khi chưa đối chiếu. Nếu vẫn không đọc được, gửi tệp chan_doan_giao_dien.json được tạo cạnh chương trình; ảnh màn hình không đủ để nhận diện hết cấu trúc bảng cụ thể.

Đã kiểm tra 7 tình huống DOM mô phỏng, gồm hàng hai bên cao 61/45 px, thứ tự mã hàng khác nhau, thiếu hàng/cột, mã hàng không khớp và cột lệch vị trí. Mã cũ không vượt qua ca mô phỏng chiều cao khác nhau, mã mới vượt qua. Đây là mô phỏng DOM bằng jsdom, chưa phải chạy trên phiên VietSchool thật. Bộ unittest Python: 105 đạt, 1 bỏ qua vì thiếu Chromium. Kiểm tra cú pháp đạt.

Tệp test_split_tables.js là kiểm thử phát triển, cần Node.js và jsdom, không cần cài để sử dụng ứng dụng.

## Sửa lỗi 46/47 trong v2.0.3

Chẩn đoán thực tế cho thấy hai bảng progrid-btable đều có 47 hàng, nhưng bộ đọc v2.0.2 lọc chỉ còn 46 hàng danh tính. Một dòng không đạt bộ lọc ngày sinh/họ tên đã làm cả lớp bị từ chối. Bản này nhận diện bảng Progrid theo mẫu các dòng hợp lệ rồi giữ từng vị trí hàng theo STT, kể cả dòng trống hoặc khác định dạng thông tin. Không lọc mất hàng theo nội dung ngày sinh/tên hoặc nội dung điểm. Tách bảng tiêu đề progrid-htable khỏi dữ liệu điểm để không nhận nhầm hàng tiêu đề là điểm.

Vẫn kiểm tra đủ số hàng, STT liên tục, mã hàng (nếu có) và vị trí cột. Thông tin thiếu được xử lý theo từng học sinh: ví dụ Excel có ngày sinh nhưng web thiếu thì học sinh đó chưa kiểm tra được, không làm các dòng sau lệch điểm. Bộ chẩn đoán bổ sung số ô, STT, loại dữ liệu ngày sinh của từng vị trí hàng; không bổ sung họ tên/giá trị điểm vào phần này.

Đã tái hiện đúng lỗi 46/47 trên mã v2.0.2. Bản sửa qua 13 tình huống DOM mô phỏng và 107 ca unittest Python (106 đạt, 1 bỏ qua do thiếu Chromium). Chưa chạy trực tiếp trên phiên đăng nhập VietSchool của người dùng.

Đóng Agent/Chrome Agent cũ, giải nén bản v2.0.3 sang thư mục riêng, chạy CHAY_HTB_AI_AGENT.bat và chỉ chạy Đối chiếu trước. Nếu vẫn còn lỗi, gửi lại chan_doan_giao_dien.json mới tạo trong thư mục bản v2.0.3.

## Định vị bảng/cột v2.0.4

- Giữ toàn bộ hàng/ô DOM của bảng Progrid, bao gồm hàng căn kích thước, hàng trống hoặc bị cắt khỏi vùng nhìn. Ghép hai phần theo vị trí DOM hoặc mã hàng trước khi xác định học sinh. Chỉ bỏ một vị trí trống khi cả hai phần đều trống và không có mã hàng; không tự bỏ dòng chứa dữ liệu ở một bên.
- Đọc tiêu đề từ progrid-htable đúng bảng, mở rộng rowspan/colspan để nhận diện cột ĐGTX/Giữa kỳ/Cuối kỳ. Không dựa vào việc ô tiêu đề đang nằm dưới con trỏ/được vẽ trên màn hình trong trường hợp Progrid đã nhận diện.
- Nhận diện ĐGK cho Giữa kỳ và ĐCK cho Cuối kỳ, bên cạnh các tên trước đây. Nhật ký hiện “Định vị Giữa kỳ → cột N của bảng (ĐGK)” khi xác định được. N là vị trí trong bảng đầy đủ, tính cả STT/Họ/Tên/Ngày sinh; không phải thứ tự riêng trong nhóm điểm.
- Không bỏ kiểm tra danh tính, số hàng hoặc cột không rõ. Nếu hai phần thực sự không thể ghép, kết quả vẫn là Chưa kiểm tra được thay vì đoán điểm.

Đã qua 19 tình huống DOM mô phỏng, gồm hàng căn ở đầu/giữa/cuối, hàng rỗng không có ô, bảng 47 hàng DOM với 46 học sinh, tiêu đề gộp và mã hàng. Bộ Python: 109 ca, 108 đạt, 1 bỏ qua do thiếu Chromium. Chưa kiểm chứng trên tài khoản VietSchool thật.

Đóng bản cũ và Chrome Agent cũ, giải nén sang thư mục riêng, chạy CHAY_HTB_AI_AGENT.bat rồi chọn Đối chiếu. Nếu còn lỗi, gửi file chan_doan_giao_dien.json do chính bản v2.0.4 tạo ra để xem cấu trúc hàng cụ thể.

## Tích hợp tool Cộng điểm trong v2.1

Chọn **Cộng điểm TL + TN** ở menu trái hoặc thẻ chức năng tại Tổng quan. Chọn hai file tự luận/trắc nghiệm, sheet, dòng tiêu đề và cột họ tên/lớp/điểm. Chọn thêm cột môn ở cả hai nguồn nếu cần phân biệt môn. Bấm ĐỐI CHIẾU & CỘNG ĐIỂM, xem trước và lưu Excel; hộp lưu mặc định mở tại thư mục bao_cao chung. Xem **cong_diem/HUONG_DAN.txt**.

Tool cộng điểm dùng nguyên bộ tính toán từ ZIP người dùng cung cấp: dò họ tên + lớp (+ môn), không ghép theo vị trí dòng, không tự chọn khi trùng tên, không biến điểm thiếu thành 0. Giao diện nằm trực tiếp trong cửa sổ chung, tự xếp hai nguồn trên/dưới khi cửa sổ hẹp, bảng kết quả có cuộn ngang. Chức năng chạy tại máy, không dùng khóa API.

Bé Bi có thể mở trang bằng lệnh /congdiem hoặc “mở cộng điểm”. Kết quả cộng chưa tự chuyển thành mẫu Excel nhập VietSchool; cần kiểm tra/chuyển đúng định dạng trước khi dùng nhập điểm.

Bộ đọc và xử lý VietSchool giữ nguyên từng byte từ v2.0.4 mà người dùng đã xác nhận chạy đúng. Đã kiểm tra dữ liệu mẫu, trùng/thiếu, xuất Excel và bộ unittest: 112 ca, 111 đạt, 1 bỏ qua do thiếu Chromium. Chưa kiểm tra giao diện tích hợp trên Windows thực tế.

## Vị trí Bé Bi v2.1.1

Bé Bi được chuyển vào phần trống ở cuối menu xanh bên trái, phía trên Thư mục báo cáo. Không còn thanh linh vật ngang phía dưới nội dung. Bấm robot để mở trò chuyện; rê chuột để xem lời nhắn/trạng thái; chuột phải để bật/tắt chuyển động hoặc ẩn. Nút Bé Bi ♡ phía trên có thể hiện lại robot. Khi thu gọn menu, ảnh thu nhỏ theo bề rộng; nếu vùng trống quá thấp, ảnh tạm ẩn để tránh che các nút menu.

Giữ nguyên chức năng nhập/đối chiếu, SBD/phòng thi, báo cáo, chat và cộng điểm của v2.1. Đã kiểm tra cú pháp và 4 ca trạng thái linh vật. Chưa kiểm tra trực tiếp bố cục mới trên Windows.

## Bé Bi nổi tự do v2.1.2 — thay thế bố trí v2.1.1

Bé Bi hiện là một cửa sổ robot nền trong suốt trên Windows, không có thanh tiêu đề/khung, không gắn hoặc chiếm chỗ trong menu. Vị trí ban đầu là vùng thầy đã chỉ phía trên Thư mục báo cáo; thanh menu giữ nguyên. Có thể kéo Bé sang bất cứ vị trí nào trong cửa sổ ứng dụng.

- Kéo giữ chuột trái để di chuyển; thả sau khi kéo sẽ không mở chat.
- Bấm nhẹ vào robot để mở Trò chuyện Bé Bi.
- Chuột phải: Trò chuyện, bật/tắt chuyển động, Về vị trí ban đầu hoặc Ẩn Bé Bi.
- Nút Bé Bi ♡ phía trên giúp ẩn/hiện lại.
- Robot đi theo ứng dụng khi di chuyển cửa sổ, ẩn khi thu nhỏ và xuất hiện lại khi mở ứng dụng. Không ghim nổi trên mọi ứng dụng khác.
- Vị trí kéo chỉ giữ trong phiên hiện tại. Chạy lại sẽ về vị trí ban đầu.
- Nền trong suốt sử dụng khả năng của Tk trên Windows. Nền trên hệ điều hành khác có thể không trong suốt hoàn toàn.

Đã kiểm tra cú pháp và 11 ca liên quan tới trạng thái, kéo/thả, bấm mở chat, ẩn theo cửa sổ và điều phối. Chưa kiểm tra trực tiếp nền trong suốt và kéo thả trên Windows thực tế. Giữ nguyên bộ xử lý VietSchool và cộng điểm.
