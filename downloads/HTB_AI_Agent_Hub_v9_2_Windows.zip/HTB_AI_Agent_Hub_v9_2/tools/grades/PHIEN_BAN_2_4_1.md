# HTB v2.4.1 — Sửa Cá Chép đứng yên

Trong bản cũ, tooltip giữ cá tạm dừng đến khi nhận được sự kiện rời chuột, bấm chat dừng 12 giây, và callback chuyển động không được hẹn lại nếu widget của hộp chọn gây lỗi KeyError/TclError. Các đường lỗi này có thể làm cá ngừng bơi khi dùng menu/hộp chọn.

Bản sửa:
- Giới hạn dừng khi rê chuột 1,5 giây, tự đóng tooltip và bơi lại dù mất sự kiện rời chuột.
- Bấm trò chuyện chỉ dừng 1,2 giây.
- Bọc kiểm tra grab của cửa sổ bật lên, luôn hẹn lại khung hình khi có lỗi widget tạm thời.
- Windows: tự thoát trạng thái kéo nếu chuột đã thả mà không nhận được sự kiện; khi thu nhỏ cũng xóa trạng thái kéo.
- Chuột phải lên cá → Cho cá bơi lại để bật bơi, xóa trạng thái tạm dừng và khởi động lại bộ hẹn giờ. Có thể bật/tắt Tự bơi qua lại như trước.

Kiểm tra: 28 kiểm tra chuyển động/trạng thái/kéo thả đạt. Gồm callback tiếp tục sau lỗi native popdown, tooltip hết hạn, lỗi canvas tạm thời, thả chuột bị mất, timer hồi phục và không tạo timer cho cửa sổ đã hủy. Đã kiểm tra đủ 256 ảnh hoạt họa trong gói. Chưa tái hiện trực tiếp lỗi trên máy Windows của thầy; các nguyên nhân nêu trên được xác định qua mã và mô phỏng. Khi hộp thoại đang mở hoặc luồng giao diện đang bận đọc Excel, chuyển động vẫn có thể tạm dừng rồi tiếp tục khi giao diện rảnh.

Đóng bản cũ, giải nén toàn bộ bản này, chạy CHAY_HTB_AI_AGENT.bat. Giữ thư mục assets cùng mã nguồn. Các công cụ nhập/kiểm tra/chuyển Excel của v2.4.0 giữ nguyên.
