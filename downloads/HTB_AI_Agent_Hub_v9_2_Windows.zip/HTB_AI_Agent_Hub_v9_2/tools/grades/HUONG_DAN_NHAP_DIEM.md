# VietSchool Agent v3.6 — Hỗ trợ tên một từ, cột Họ để trống

Chạy CAI_DAT_VA_CHAY.bat rồi chọn Excel như trước.

Sửa bộ đọc bảng chia hai phần: không còn bắt buộc cả cột Họ và Tên đều có chữ. Tên như Winnie với cột Họ trống được ghép thành đúng “Winnie”, không thêm dấu cách đầu/cuối. Tên Excel phải khớp tên đầy đủ trên web sau chuẩn hóa dấu và khoảng trắng như trước.

Áp dụng cùng cách ghép tên cho đọc danh sách, gắn ô điểm, tìm lại dòng sau cuộn và xác minh trước/sau khi dán. Không bỏ qua học sinh chỉ vì tên một từ; nếu ô còn trống và Excel có điểm thì vẫn nhập đúng người. Tên trống hoàn toàn hoặc trùng tên vẫn bị chặn.

Giữ chức năng chỉ chọn các môn có điểm trong Excel, bỏ học sinh nghỉ/ô khóa/ô đã có điểm và tiếp tục dán sau dòng nghỉ.

Đã kiểm thử bằng mô phỏng DOM và kiểm thử Python; chưa xác nhận trực tiếp trên VietSchool thực tế của người dùng.

## Sửa theo nhật ký lỗi v3.3

Nhật ký gửi kèm cho thấy chương trình đã đi đến STT 45–47, nhưng dừng ở bound_check trước Control+V. Các liên kết học sinh 45, 46, 47 đều hợp lệ. Bảng thật dùng Progrid, progrid-body overflow:hidden và mCSB_container_wrapper.

Bản này dùng con lăn chuột trong khung bảng và chọn điểm nằm trong phần ô đang thực sự hiển thị. Không dùng scrollIntoView hay locator.click cho ô điểm đã liên kết vì chúng có thể tự cuộn khung ẩn, xung đột với thanh cuộn riêng. Khi bấm, chương trình ghi nhận sự kiện chuột thật vào chính ô đã đối chiếu rồi mới gửi Control+V. Nếu giao diện cuộn lại sau bấm, chương trình vẫn xác minh danh tính bằng các ô HTML gốc, không dò lại bằng tâm ô trên màn hình.

Chỉ nhận thao tác chuột thật vào đúng ô; bấm nhầm ô hoặc sự kiện giả không được phép dẫn tới dán. Họ tên, ngày sinh và hàng/cột vẫn phải giữ nguyên. Không tắt kiểm tra danh tính.

Nhận diện thêm dấu gachCell trên cả ba ô họ/tên/ngày sinh và khóa lockCell theo cấu trúc thực trong chẩn đoán. Tiếp tục nhận diện học sinh nghỉ bằng trạng thái nghỉ/chuyển trường hoặc các ô thông tin màu đỏ.

Với 47 dòng, nghỉ tại 4 và 44: vùng dán là 1–3, 5–43, 45–47. Nếu 42 học sinh phía trước đã có điểm, chỉ nhập các ô trống 45–47.

## Kiểm tra và giới hạn

Đã chạy 66 kiểm thử Python và mô phỏng DOM cho bảng chia hai phần, dòng nghỉ, cuộn ngang/dọc, ô bị cắt bởi khung overflow:hidden, thao tác bấm nhầm, sự kiện giả và tiếp tục 45–47. Kiểm thử mô phỏng không thay thế xác nhận trên VietSchool thực tế. Không có phiên đăng nhập của người dùng trong môi trường phát triển để kiểm chứng trực tiếp.

Nếu dừng, gửi loi_khoi_dong.txt và chan_doan_giao_dien.json trong thư mục bản này. Chẩn đoán mới bổ sung kết quả ghi nhận thao tác bấm và vị trí hiển thị của ô để phân biệt lỗi cuộn, lỗi bấm và lỗi thay thế bảng.
