@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (set "HTB_PY=python") else (set "HTB_PY=py -3")
%HTB_PY% -c "import sys; assert sys.version_info >= (3,10); import tkinter" >nul 2>&1
if errorlevel 1 goto python_error
if not exist ".venv\Scripts\python.exe" %HTB_PY% -m venv .venv
if not exist ".venv\Scripts\python.exe" goto error
.venv\Scripts\python.exe -c "import openpyxl, pyperclip, docx, pypdf; from playwright.sync_api import sync_playwright" >nul 2>&1
if errorlevel 1 (
  echo Dang cai thu vien lan dau. Can Internet...
  .venv\Scripts\python.exe -m pip install --timeout 30 --retries 1 -r requirements.txt
  if errorlevel 1 goto error
)
.venv\Scripts\python.exe htb_agent.py
if errorlevel 1 goto error
exit /b 0
:python_error
echo Can cai Python 3.10 tro len, chon Add Python to PATH va thanh phan Tcl/Tk.
pause
exit /b 1
:error
echo Khong khoi dong duoc. Xem loi phia tren va HUONG_DAN.md.
pause
exit /b 1
