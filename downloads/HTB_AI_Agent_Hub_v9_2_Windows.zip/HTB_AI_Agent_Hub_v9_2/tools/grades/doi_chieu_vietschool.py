# -*- coding: utf-8 -*-
"""VietSchool v3.6: load one Excel and run without per-step confirmations."""
import os, queue, time, tkinter as tk
from tkinter import ttk, filedialog
from check_worker import CheckWorker as AutoWorker
import threading

class AutoApp:
    def __init__(self,root):
        self.root=root;self.events=queue.Queue();self.worker=None;self.cancel_event=None
        self.busy=False;self.stopping=False;self.start=0;self.last_event=0;self.last_message='Chọn Excel để bắt đầu tự động.'
        style=ttk.Style(root);style.theme_use('clam')
        style.configure('TButton',font=('Segoe UI',12),padding=12)
        wrap=ttk.Frame(root,padding=18);wrap.pack(fill='both',expand=True)
        ttk.Label(wrap,text='VIETSCHOOL — ĐỐI CHIẾU ĐIỂM VỚI EXCEL',font=('Segoe UI',19,'bold'),foreground='#075497').pack(anchor='w')
        ttk.Label(wrap,text='Đọc Excel → tải lại VietSchool → dò lớp/môn/học kỳ/cột → so sánh điểm → xuất báo cáo Excel',wraplength=870,font=('Segoe UI',10)).pack(anchor='w',pady=(6,12))
        bar=ttk.Frame(wrap);bar.pack(fill='x')
        self.load=ttk.Button(bar,text='CHỌN EXCEL VÀ ĐỐI CHIẾU',command=self.choose);self.load.pack(side='left')
        self.stop=ttk.Button(bar,text='DỪNG',command=self.stop_run,state='disabled');self.stop.pack(side='left',padx=10)
        self.filevar=tk.StringVar(value='Chưa chọn file')
        ttk.Label(wrap,textvariable=self.filevar,wraplength=870).pack(anchor='w',pady=10)
        self.progress=ttk.Progressbar(wrap,mode='indeterminate');self.progress.pack(fill='x')
        self.status=tk.StringVar(value=self.last_message)
        ttk.Label(wrap,textvariable=self.status,foreground='#075985',font=('Segoe UI',11),wraplength=870).pack(fill='x',pady=12)
        self.clock=tk.StringVar(value='')
        ttk.Label(wrap,textvariable=self.clock,foreground='#666666').pack(anchor='w')
        ttk.Label(wrap,text='Lần đầu: tự đăng nhập trong cửa sổ Chrome Agent. Sau đó chương trình tự tiếp tục.\nChỉ đọc điểm, không tự sửa. Kiểm tra cả ô đã có điểm và ô khóa. Excel trống/nghỉ học được ghi riêng, không tính là đúng.',wraplength=870,foreground='#a13c00').pack(fill='x',pady=8)
        self.roster_label=tk.StringVar(value='Đối chiếu học sinh: chờ đọc Excel và trang web')
        ttk.Label(wrap,textvariable=self.roster_label,foreground='#075985').pack(anchor='w',pady=(3,5))
        pane=ttk.Frame(wrap);pane.pack(fill='x',pady=(0,8))
        self.roster=ttk.Treeview(pane,columns=('stt','name','grade','actual','status'),show='headings',height=5)
        for col,label,width in [('stt','STT web',65),('name','Họ và tên',290),('grade','Excel',65),('actual','Web',65),('status','Trạng thái / lý do',440)]:
            self.roster.heading(col,text=label);self.roster.column(col,width=width,anchor='center' if col in ('stt','grade') else 'w')
        vs=ttk.Scrollbar(pane,command=self.roster.yview);self.roster.configure(yscrollcommand=vs.set)
        self.roster.pack(side='left',fill='x',expand=True);vs.pack(side='right',fill='y')
        self.roster.tag_configure('retired',foreground='#b91c1c');self.roster.tag_configure('existing',foreground='#075985');self.roster.tag_configure('done',foreground='#15803d')
        self.row_ids={}
        logwrap=ttk.Frame(wrap);logwrap.pack(fill='both',expand=True)
        self.log=tk.Text(logwrap,height=12,wrap='word',font=('Segoe UI',10),state='disabled',bg='#f4f8fd',relief='flat')
        scroll=ttk.Scrollbar(logwrap,command=self.log.yview);self.log.configure(yscrollcommand=scroll.set)
        self.log.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        root.after(150,self.poll)

    def write(self,msg):
        self.log.configure(state='normal');self.log.insert('end',time.strftime('%H:%M:%S')+'  '+msg+'\n');self.log.see('end');self.log.configure(state='disabled')

    def choose(self):
        if self.busy:return
        if hasattr(self, "hub") and not self.hub.can_start(self):return
        path=self.hub.pick_file() if hasattr(self, 'hub') else filedialog.askopenfilename(filetypes=[('Excel','*.xlsx')])
        if not path:return
        self.filevar.set(os.path.basename(path));self.start=time.monotonic();self.last_event=self.start
        self.last_message='Đang chuẩn bị đọc file...';self.status.set(self.last_message)
        self.stopping=False;self.busy=True;self.load.configure(state='disabled');self.stop.configure(state='normal');self.progress.start(15)
        if self.cancel_event:self.cancel_event.set()
        self.launch_when_ready(path,time.monotonic()+12)

    def launch_when_ready(self,path,deadline):
        if self.stopping:
            self.events.put(('stopped','Đã hủy trước khi bắt đầu nhập.'));return
        # Previous worker owns Playwright and must close its profile before another starts.
        if self.worker and self.worker.is_alive():
            if time.monotonic()>deadline:
                self.events.put(('error','Chrome cũ chưa đóng sau 12 giây. Hãy đóng Chrome Agent rồi chọn lại file.'));return
            self.status.set('Đang đóng phiên Chrome Agent trước...');self.root.after(150,lambda:self.launch_when_ready(path,deadline));return
        if hasattr(self,'hub') and not self.hub.released(self, path, deadline):return
        self.cancel_event=threading.Event();self.worker=AutoWorker(path,self.events,self.cancel_event);self.worker.start()

    def stop_run(self):
        self.stopping=True
        if self.cancel_event:self.cancel_event.set()
        self.status.set('Đã yêu cầu dừng. Đang kết thúc thao tác hiện tại...')
        self.stop.configure(state='disabled')

    def poll(self):
        try:
            while True:
                kind,msg=self.events.get_nowait();self.last_event=time.monotonic()
                if kind=='comparison':
                    for iid in self.roster.get_children():self.roster.delete(iid)
                    self.roster_label.set(msg['scope']+' · Kết quả chi tiết có trong báo cáo Excel')
                    for r in msg['rows']:
                        tag='done' if r['result']=='Đúng' else 'retired'
                        self.roster.insert('','end',values=(r.get('stt',''),r['name'],r.get('expected',''),r.get('actual',''),r['result']+' — '+r.get('reason','')),tags=(tag,))
                    continue
                if kind=='roster':
                    for iid in self.roster.get_children():self.roster.delete(iid)
                    self.row_ids={}
                    retired=sum(r['status']=='Bỏ qua: học sinh nghỉ' for r in msg['rows'])
                    existing=sum(r['status']=='Bỏ qua: web đã có điểm' for r in msg['rows'])
                    self.roster_label.set(f'{msg["scope"]} · {len(msg["rows"])} dòng · Nghỉ: {retired} · Đã có điểm: {existing}')
                    for r in msg['rows']:
                        tag='retired' if 'học sinh nghỉ' in r['status'] else ('existing' if 'web đã có điểm' in r['status'] else '')
                        detail=r['status']+(' — '+r.get('reason','') if r.get('reason') else '')
                        self.row_ids[r['stt']]=self.roster.insert('','end',values=(r['stt'],r['name'],r['value'] if r['value'] is not None else r['old'],detail),tags=(tag,))
                    continue
                if kind=='verified':
                    for stt in msg['stts']:
                        iid=self.row_ids.get(stt)
                        if iid:
                            values=list(self.roster.item(iid,'values'));values[3]='Đã dán · Đúng giá trị / chữ xanh lá'
                            self.roster.item(iid,values=values,tags=('done',));self.roster.see(iid)
                    continue
                self.last_message=msg;self.status.set(msg);self.write(msg)
                if kind in ('done','error','stopped'):
                    self.busy=False;self.progress.stop();self.load.configure(state='normal');self.stop.configure(state='disabled')
        except queue.Empty:pass
        if self.busy:
            elapsed=int(time.monotonic()-self.start);waiting=int(time.monotonic()-self.last_event)
            self.clock.set(f'Tổng thời gian {elapsed//60:02}:{elapsed%60:02} · Bước hiện tại: {waiting} giây')
            if waiting>25 and 'đăng nhập' not in self.last_message.lower():
                self.status.set(self.last_message+'\nBước này đang mất lâu hơn dự kiến. Có thể bấm DỪNG; lỗi kết nối/đọc bảng sẽ được báo khi hết thời hạn.')
        self.root.after(150,self.poll)

    def close(self):
        if self.cancel_event:self.cancel_event.set()
        self.root.destroy()

if __name__=='__main__':
    app=tk.Tk();AutoApp(app);app.mainloop()
