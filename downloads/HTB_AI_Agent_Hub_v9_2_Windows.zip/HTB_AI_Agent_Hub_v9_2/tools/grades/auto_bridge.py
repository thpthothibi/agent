import os, threading, time
from urllib.parse import urlparse
from chrome_bridge import ChromeBridge, DOMAIN, SNAPSHOT_JS, CAPTURE_JS, TARGET_JS

# Rows are read only from rendered UI, including overflow rows that exist in DOM.
# No internal API, hidden model or database access.
FOCUS_JS = r'''({run,index}) => {
 const cs=r=>[...r.children].filter(c=>c.matches('td,th,[role="gridcell"],[role="cell"],.ag-cell,.wj-cell'));
 const tx=c=>(c?.innerText||c?.textContent||'').replace(/\s+/g,' ').trim();
 const all=[...document.querySelectorAll('tr,[role="row"],.ag-row,.wj-row')].filter(r=>r.getBoundingClientRect().height>0);
 let first=null;
 for (const expected of run) {
   const found=all.filter(r=>{const c=cs(r);return tx(c[0])===String(expected.stt) && (tx(c[1])+' '+tx(c[2])).trim()===expected.name && tx(c[3])===expected.dob;});
   if(found.length!==1)throw Error('Không xác định duy nhất học sinh STT '+expected.stt+'. Hãy đọc lại lớp.');
   const c=cs(found[0])[index];
   if(!c || tx(c) || c.getAttribute('aria-disabled')==='true' || c.getAttribute('aria-readonly')==='true' || c.matches('.locked,.readonly,.readOnly') || c.querySelector('[disabled],[readonly]'))throw Error('Ô đã có điểm/bị khóa tại STT '+expected.stt);
   if(!first)first=c;
 }
 first.scrollIntoView({block:'center',inline:'center'});first.focus();first.click();return true;
}'''

class NameBridge(ChromeBridge):
    def __init__(self,requests,responses):
        super().__init__(requests,responses);self.cancel_event=threading.Event();self.frame=None

    def grid(self):
        p=self.page(); candidates=[]
        for f in p.frames:
            try:
                s=f.evaluate(SNAPSHOT_JS)
                if s['rows']:candidates.append((f,s))
            except Exception:pass
        if len(candidates)!=1:
            raise RuntimeError('Không tìm được một bảng học sinh duy nhất. Mở đúng màn hình Nhập điểm rồi thử lại; nếu vẫn lỗi dùng CHẨN ĐOÁN.')
        return candidates[0]

    def run(self):
        from playwright.sync_api import sync_playwright
        while True:
            name,args=self.requests.get()
            try:
                if name=='stop':
                    if self.ctx:self.ctx.close()
                    if self.pw:self.pw.stop()
                    return
                if name=='connect':
                    if self.ctx is None:
                        self.pw=sync_playwright().start()
                        self.ctx=self.pw.chromium.launch_persistent_context(os.path.join(os.path.dirname(__file__),'chrome_agent_profile'),channel='chrome',headless=False,no_viewport=True,args=['--start-maximized'])
                        p=self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
                        p.goto('https://'+DOMAIN,wait_until='domcontentloaded',timeout=45000)
                    self.output(name,'Đã mở Chrome Agent. Đăng nhập và chọn lớp, môn, học kỳ trên web.')
                elif name=='inspect':
                    self.frame,s=self.grid();self.output(name,s)
                elif name=='arm':
                    self.frame,s=self.grid();self.frame.evaluate(CAPTURE_JS)
                    self.output(name,'Trong Chrome Agent, bấm một ô thuộc CỘT ĐIỂM cần nhập (bất kỳ học sinh). Sau đó bấm 4. DÒ TÊN & XEM TRƯỚC.')
                elif name=='plan':
                    f,s=self.grid()
                    t=f.evaluate(TARGET_JS)
                    if not t or t['index']<4:raise RuntimeError('Bấm 3. CHỌN CỘT, sau đó click ô điểm trên Chrome Agent trước.')
                    self.frame=f;self.output(name,{'site':s,'target':t})
                elif name=='diagnostic':
                    p=self.page()
                    self.output(name,{'frames':len(p.frames),'tables':[f.evaluate('() => ({url:location.href, tables:document.querySelectorAll("table").length, rows:document.querySelectorAll("tr,[role=row],.ag-row,.wj-row").length})') for f in p.frames]})
                elif name=='paste_names':
                    p=self.page();f=self.frame;done=0
                    import pyperclip
                    from name_matching import build_plan, paste_runs
                    if not f or f.is_detached():raise RuntimeError('Trang đã thay đổi; đọc và dò tên lại.')
                    current=f.evaluate(SNAPSHOT_JS)
                    if current['url']!=args['url']:raise RuntimeError('Trang đã thay đổi; đọc và dò tên lại.')
                    plan=build_plan(args['excel'],current['rows'],args['column'],args['subject'],args['rating'],args['index'])
                    # Detect any changed roster, destination content, or source before mutation.
                    if plan!=args['plan']:raise RuntimeError('Dữ liệu web đã thay đổi sau bước xem trước. Hãy dò tên lại.')
                    for run in paste_runs(plan):
                        if self.cancel_event.is_set():break
                        fresh=build_plan(args['excel'],f.evaluate(SNAPSHOT_JS)['rows'],args['column'],args['subject'],args['rating'],args['index'])
                        fresh_map={r['stt']:r for r in fresh}
                        if any(fresh_map.get(r['stt'])!=r for r in run):raise RuntimeError('Ô hoặc trạng thái học sinh đã thay đổi; dò tên lại trước khi tiếp tục.')
                        f.evaluate(FOCUS_JS,{'run':run,'index':args['index']})
                        pyperclip.copy('\n'.join(r['value'] for r in run))
                        state={'declined':False}
                        def dialog_handler(d):
                            evt=threading.Event();choice={'yes':False}
                            self.responses.put({'task':'dialog','message':d.message,'event':evt,'choice':choice})
                            if evt.wait(90) and choice['yes'] and not self.cancel_event.is_set():d.accept()
                            else:state['declined']=True;d.dismiss()
                        p.on('dialog',dialog_handler)
                        try:
                            p.bring_to_front();p.keyboard.press('Control+V');p.wait_for_timeout(500)
                        finally:p.remove_listener('dialog',dialog_handler)
                        if state['declined']:raise RuntimeError(f'Đã hủy hộp thoại. {done} ô trước đó đã được dán; kiểm tra trên web.')
                        # Confirm visible values before moving to another region. This is not server save verification.
                        deadline=time.monotonic()+12
                        while True:
                            snap=f.evaluate(SNAPSHOT_JS);lookup={r['stt']:r for r in snap['rows']}
                            if all(r['stt'] in lookup and lookup[r['stt']]['name']==r['name'] and lookup[r['stt']]['cells'][args['index']].strip().replace(',','.')==r['value'] for r in run):break
                            if time.monotonic()>deadline:raise RuntimeError(f'Chưa xác minh được giá trị hiển thị sau dán tại STT {run[0]["stt"]}. Dừng để tránh nhập lặp; kiểm tra web rồi dò lại.')
                            p.wait_for_timeout(200)
                        done+=len(run);self.output('progress',f'Đã đối chiếu hiển thị {done} ô. Đang tiếp tục...')
                    self.output(name,f'Đã dán và đối chiếu hiển thị {done} ô'+(' · Đã dừng theo yêu cầu.' if self.cancel_event.is_set() else '.')+' Kiểm tra màu xanh lá / thời gian lưu trên VietSchool để xác nhận máy chủ đã lưu.')
                else:raise RuntimeError('Lệnh không hợp lệ')
            except Exception as e:self.output(name,err=str(e))
