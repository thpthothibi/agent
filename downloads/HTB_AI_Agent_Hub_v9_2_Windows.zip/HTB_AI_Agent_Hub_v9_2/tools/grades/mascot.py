"""Cá Chép AI: a local visual companion for the HTB desktop workspace."""
import math
import time
import sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk
from desktop_ui import FONT, WHITE, BLUE, INK, MUTED, NAVY

PAGE_HINTS = {
    7: 'Thầy chọn nhiều Excel nguồn, kiểm tra môn và cột điểm, rồi xuất file mẫu nhé!',
    6: 'Thầy chọn hai danh sách tự luận và trắc nghiệm, rồi kiểm tra cột họ tên, lớp và điểm nhé!',
    0: 'Chép chào thầy! Hôm nay mình cùng làm việc gì ạ?',
    1: 'Thầy chọn Excel điểm trước nhé. Chép ở đây cùng thầy!',
    2: 'Đối chiếu xong, thầy nhớ xem các dòng sai hoặc chưa kiểm tra nhé.',
    3: 'Mình đặt sĩ số phòng và quy tắc SBD rồi xem trước nhé thầy!',
    5: 'Chép ở đây! Thầy có thể hỏi Chép hoặc đính kèm tài liệu để mình cùng đọc nhé.',
    4: 'Thầy gửi mẫu và số liệu nhé. Mình cùng soạn báo cáo thật rõ ràng!',
}


class MascotState:
    def __init__(self):
        self.was_busy = False
        self.previous_page = None
        self.completion_until = 0

    def update(self, busy, page, task_status='', now=0):
        changed_page = page != self.previous_page
        self.previous_page = page
        if self.was_busy and not busy:
            self.completion_until = now + 9
        self.was_busy = busy
        if busy:
            return 'working', (task_status.strip() or 'Mình đang xử lý, thầy đợi một chút nhé!')[:220]
        if changed_page:
            self.completion_until = 0
        if now < self.completion_until:
            return 'finished', 'Tác vụ vừa kết thúc. Thầy kiểm tra kết quả trước khi dùng nhé!'
        return 'idle', PAGE_HINTS.get(page, PAGE_HINTS[0])


class MascotDock:
    def __init__(self, parent, sidebar=False):
        self.sidebar=sidebar
        self.origin=(58,55)
        if sidebar:
            self.build_sidebar(parent)
            return
        self.frame = tk.Frame(parent, bg=WHITE, padx=15, pady=4, highlightthickness=1, highlightbackground='#DCE8F8')
        self.frame.pack(side='bottom', fill='x')
        self.state = MascotState()
        self.open_chat = None
        self.speaking = False
        self.visible = True
        self.phase = 0
        self.mode = 'idle'
        self.greeting_until = 0
        self.animate = tk.BooleanVar(value=True)
        self.canvas = tk.Canvas(self.frame, width=120, height=112, bg=WHITE, highlightthickness=0, cursor='hand2')
        self.canvas.pack(side='left')
        self.image = None
        try:
            original = tk.PhotoImage(file=str(Path(__file__).resolve().parent/'assets'/'ca_chep_ai.png'))
            scale = max(1, math.ceil(max(original.width(), original.height()) / 106))
            self.image = original.subsample(scale, scale)
            self.character = self.canvas.create_image(58, 55, image=self.image)
        except (tk.TclError, OSError):
            # A missing asset must not prevent the school tools from opening.
            self.character = self.canvas.create_text(58, 55, text='Cá Chép AI', font=(FONT,18,'bold'), fill=BLUE)
        self.spark = self.canvas.create_text(105, 22, text='✦', font=(FONT,12,'bold'), fill='#55BBEB')
        self.canvas.bind('<Button-1>', self.say_hello)
        body = tk.Frame(self.frame,bg=WHITE);body.pack(side='left',fill='both',expand=True,padx=(7,10))
        self.name = tk.Label(body,text='CÁ CHÉP AI  •  Bạn đồng hành HTB',bg=WHITE,fg=BLUE,font=(FONT,10,'bold'),anchor='w')
        self.name.pack(anchor='w',pady=(12,4))
        self.bubble = tk.Label(body,text=PAGE_HINTS[0],bg=WHITE,fg=INK,font=(FONT,11),justify='left',anchor='w',wraplength=600)
        self.bubble.pack(fill='x')
        body.bind('<Configure>',lambda e:self.bubble.configure(wraplength=max(180,e.width-10)))
        controls=tk.Frame(self.frame,bg=WHITE);controls.pack(side='right',padx=(6,0))
        ttk.Checkbutton(controls,text='Chuyển động',variable=self.animate,command=self.set_motion).pack(anchor='e',pady=(12,6))
        ttk.Button(controls,text='Trò chuyện ♡',command=self.chat,style='Primary.TButton').pack(anchor='e',pady=(0,5))
        ttk.Button(controls,text='Thu gọn',command=self.toggle,style='Secondary.TButton').pack(anchor='e')
        self.timer = self.frame.after(70,self.tick)
        self.frame.bind('<Destroy>',self.on_destroy,add='+')

    def build_sidebar(self,parent):
        self.parent=parent
        self.frame=tk.Frame(parent,bg=NAVY)
        self.state=MascotState();self.open_chat=None;self.speaking=False
        self.visible=True;self.phase=0;self.mode='idle';self.greeting_until=0
        self.animate=tk.BooleanVar(value=True)
        self.canvas=tk.Canvas(self.frame,bg=NAVY,highlightthickness=0,cursor='hand2')
        self.canvas.pack(fill='both',expand=True)
        self.original=None;self.image=None;self.scale=None;self.tooltip=None
        try:
            self.original=tk.PhotoImage(file=str(Path(__file__).resolve().parent/'assets'/'ca_chep_ai.png'))
            self.image=self.original.subsample(max(1,math.ceil(max(self.original.width(),self.original.height())/106)))
            self.character=self.canvas.create_image(58,55,image=self.image)
        except (tk.TclError,OSError):
            self.character=self.canvas.create_text(58,55,text='Cá Chép AI',font=(FONT,12,'bold'),fill=WHITE)
        self.spark=self.canvas.create_text(105,18,text='✦',font=(FONT,11,'bold'),fill='#55BBEB')
        # Keep state labels for the shared update API; display their text on hover.
        self.name=tk.Label(self.frame,text='CÁ CHÉP AI • Bạn đồng hành HTB')
        self.bubble=tk.Label(self.frame,text=PAGE_HINTS[0])
        self.canvas.bind('<Button-1>',self.say_hello)
        self.canvas.bind('<Enter>',self.show_hint)
        self.canvas.bind('<Leave>',self.hide_hint)
        self.menu=tk.Menu(self.frame,tearoff=False)
        self.menu.add_command(label='Trò chuyện với Cá Chép AI',command=self.chat)
        self.menu.add_checkbutton(label='Chuyển động',variable=self.animate,command=self.set_motion)
        self.menu.add_command(label='Ẩn Cá Chép AI',command=self.toggle)
        self.canvas.bind('<Button-3>',self.popup_menu)
        parent.bind('<Configure>',self.resize_sidebar,add='+')
        self.timer=self.frame.after(70,self.tick)
        self.frame.bind('<Destroy>',self.on_destroy,add='+')
        self.frame.after_idle(self.resize_sidebar)

    def resize_sidebar(self,event=None):
        width=min(160,self.parent.winfo_width()-8)
        height=min(122,self.parent.winfo_height()-6)
        if not self.visible or width<44 or height<48:
            self.frame.place_forget()
            return
        self.frame.place(relx=.5,rely=.5,anchor='center',width=width,height=height)
        self.origin=(width/2,height/2)
        if self.original:
            target=max(32,min(106,width-20,height-10))
            scale=max(1,math.ceil(max(self.original.width(),self.original.height())/target))
            if scale!=self.scale:
                self.image=self.original.subsample(scale,scale);self.scale=scale
                self.canvas.itemconfigure(self.character,image=self.image)
        self.canvas.coords(self.character,*self.origin)
        self.canvas.coords(self.spark,width-12,15)

    def show_hint(self,event=None):
        self.hide_hint()
        tip=tk.Toplevel(self.frame);self.tooltip=tip
        tip.overrideredirect(True)
        tip.configure(bg='#DCE8F8',padx=1,pady=1)
        tk.Label(tip,text=self.name.cget('text'),bg=WHITE,fg=BLUE,font=(FONT,10,'bold'),padx=12,pady=7).pack(fill='x')
        tk.Label(tip,text=self.bubble.cget('text')+'\n\nBấm để trò chuyện • Chuột phải để tùy chỉnh',bg=WHITE,fg=INK,font=(FONT,10),wraplength=270,justify='left',padx=12,pady=8).pack(fill='x')
        tip.update_idletasks()
        x=min(self.parent.winfo_rootx()+self.parent.winfo_width()+6,self.frame.winfo_screenwidth()-tip.winfo_reqwidth()-8)
        y=min(self.frame.winfo_rooty(),self.frame.winfo_screenheight()-tip.winfo_reqheight()-12)
        tip.geometry(f'+{max(0,x)}+{max(0,y)}')

    def hide_hint(self,event=None):
        tip=getattr(self,'tooltip',None)
        self.tooltip=None;self.tooltip_until=0
        if tip is not None:
            try:tip.destroy()
            except tk.TclError:pass

    def popup_menu(self,event):
        self.hide_hint()
        try:self.menu.tk_popup(event.x_root,event.y_root)
        finally:self.menu.grab_release()

    def update(self,busy,page,task_status='',now=0):
        mode,message=self.state.update(busy,page,task_status,now)
        if self.speaking and not busy:
            self.mode='speaking'
            self.bubble.configure(text='Chép đang đọc câu trả lời cho thầy nghe. Có thể bấm Dừng đọc tại trang Trò chuyện nhé!')
            self.name.configure(text='CÁ CHÉP AI  •  Đang đọc bằng giọng Windows')
            return
        if mode == 'idle' and now < self.greeting_until:
            return
        self.mode=mode
        self.bubble.configure(text=message)
        self.name.configure(text={'working':'CÁ CHÉP AI  •  Đang đồng hành cùng thầy',
                                  'finished':'CÁ CHÉP AI  •  Mình cùng xem kết quả nhé!',
                                  'idle':'CÁ CHÉP AI  •  Bạn đồng hành HTB'}[mode])

    def chat(self):
        if self.open_chat:self.open_chat()

    def say_hello(self,event=None):
        self.chat()
        if self.mode=='working':
            self.bubble.configure(text='Agent đang làm việc. Thầy theo dõi tiến độ ở trang tác vụ nhé!')
        else:
            self.bubble.configure(text='Dạ, Chép đây! Thầy chọn công việc ở menu bên trái nhé ♡')
            self.greeting_until=time.monotonic()+6

    def set_motion(self):
        if not self.animate.get():self.canvas.coords(self.character,*self.origin)

    def tick(self):
        if self.visible and self.animate.get():
            self.phase += 0.12
            offset = 3 * math.sin(self.phase)
            self.canvas.coords(self.character,self.origin[0],self.origin[1]+offset)
            self.canvas.itemconfigure(self.spark,text='✦' if self.mode!='working' or int(self.phase*3)%2==0 else '·')
        self.timer=self.frame.after(70,self.tick)

    def toggle(self):
        if self.sidebar:
            self.hide_hint()
            self.visible=not self.visible
            self.resize_sidebar()
            return
        self.visible=not self.visible
        if self.visible:
            # Must stay before the expanding content in Tk's packing order.
            self.frame.pack(side='bottom',fill='x',before=self.content)
        else:self.frame.pack_forget()

    def on_destroy(self,event):
        if event.widget is self.frame and self.timer:
            if self.sidebar:self.hide_hint()
            try:self.frame.after_cancel(self.timer)
            except tk.TclError:pass
            self.timer=None


def clamp_position(x,y,area_width,area_height,width=140,height=150):
    return (max(0,min(round(x),max(0,area_width-width))),
            max(0,min(round(y),max(0,area_height-height))))


def swim_step(x, direction, elapsed, area_width, width=140, speed=34):
    """Advance within the owner window and face away from a reached edge."""
    limit = max(0, area_width - width)
    if not limit:
        return 0.0, direction
    x = max(0.0, min(float(x), limit))
    next_x = x + direction * speed * max(0.0, min(elapsed, .15))
    if next_x <= 0:
        return 0.0, 1
    if next_x >= limit:
        return float(limit), -1
    return next_x, direction


def physical_left_button_down():
    """Recover a lost Windows mouse-release event without guessing during a drag."""
    if sys.platform!='win32':return None
    try:
        import ctypes
        return bool(ctypes.windll.user32.GetAsyncKeyState(0x01)&0x8000)
    except (AttributeError,OSError):return None


class FloatingMascot(MascotDock):
    """Owned borderless robot; no layout space and no dependency on the menu."""
    def __init__(self,root,initial_position=None):
        self.parent=root;self.root=root;self.sidebar=False
        self.initial_position=initial_position
        self.position=None;self.press=None;self.dragged=False
        self.width=140;self.height=150;self.origin=(70,75)
        self.swim_direction=-1;self.swim_last=time.monotonic();self.pause_until=0
        self.facing_images={}
        self.swim_frames={};self.turn_frames={}
        self.turn_elapsed=None;self.turn_from=-1
        self.state=MascotState();self.open_chat=None;self.speaking=False
        self.visible=True;self.phase=0;self.mode='idle';self.greeting_until=0
        self.animate=tk.BooleanVar(value=True);self.tooltip=None;self.tooltip_until=0
        self.key='#ff00fe'
        self.frame=tk.Toplevel(root)
        self.frame.withdraw();self.frame.overrideredirect(True)
        self.frame.transient(root)
        self.frame.configure(bg=self.key,highlightthickness=0,bd=0)
        try:self.frame.attributes('-transparentcolor',self.key)
        except tk.TclError:
            # Windows is the supported platform for a transparent floating robot.
            self.key=root.cget('bg');self.frame.configure(bg=self.key)
        self.canvas=tk.Canvas(self.frame,width=self.width,height=self.height,
                              bg=self.key,highlightthickness=0,bd=0,cursor='hand2')
        self.canvas.pack(fill='both',expand=True)
        self.image=None
        try:
            original=tk.PhotoImage(file=str(Path(__file__).resolve().parent/'assets'/'ca_chep_ai.png'))
            scale=max(1,math.ceil(max(original.width(),original.height())/132))
            self.image=original.subsample(scale,scale)
            self.facing_images[-1]=self.image
            right=tk.PhotoImage(file=str(Path(__file__).resolve().parent/'assets'/'ca_chep_ai_right.png'))
            self.facing_images[1]=right.subsample(scale,scale)
            self.character=self.canvas.create_image(*self.origin,image=self.image)
        except (tk.TclError,OSError):
            self.character=self.canvas.create_text(*self.origin,text='Cá Chép AI',fill=BLUE,font=(FONT,16,'bold'))
        # Pre-rendered sprites require no extra imaging dependency on Windows.
        sprite_dir=Path(__file__).resolve().parent/'assets'/'carp_swim'
        try:
            for direction,prefix in [(-1,'left'),(1,'right')]:
                self.swim_frames[direction]=[tk.PhotoImage(file=str(sprite_dir/f'{prefix}_{i:02}.png')) for i in range(96)]
                self.turn_frames[direction]=[tk.PhotoImage(file=str(sprite_dir/f'turn_{prefix}_{i:02}.png')) for i in range(32)]
        except (tk.TclError,OSError):
            self.swim_frames={};self.turn_frames={}
        self.spark=self.canvas.create_text(125,20,text='✦',fill='#55BBEB',font=(FONT,11,'bold'))
        self.name=tk.Label(self.frame,text='CÁ CHÉP AI • Bạn đồng hành HTB')
        self.bubble=tk.Label(self.frame,text=PAGE_HINTS[0])
        self.menu=tk.Menu(self.frame,tearoff=False)
        self.menu.add_command(label='Trò chuyện với Cá Chép AI',command=self.chat)
        self.menu.add_checkbutton(label='Tự bơi qua lại',variable=self.animate,command=self.set_motion)
        self.menu.add_command(label='Cho cá bơi lại',command=self.resume_swimming)
        self.menu.add_command(label='Về vị trí ban đầu',command=self.reset_position)
        self.menu.add_command(label='Ẩn Cá Chép AI',command=self.toggle)
        self.canvas.bind('<ButtonPress-1>',self.drag_start)
        self.canvas.bind('<B1-Motion>',self.drag_move)
        self.canvas.bind('<ButtonRelease-1>',self.drag_end)
        self.canvas.bind('<Button-3>',self.popup_menu)
        self.canvas.bind('<Enter>',self.show_hint)
        self.canvas.bind('<Leave>',self.hide_hint)
        root.bind('<Configure>',self.owner_changed,add='+')
        root.bind('<Map>',self.owner_changed,add='+')
        root.bind('<Unmap>',self.owner_unmapped,add='+')
        root.bind('<FocusIn>',self.owner_focused,add='+')
        self.frame.bind('<Destroy>',self.destroy_float,add='+')
        self.timer=self.frame.after(70,self.tick)
        root.after_idle(self.sync_position)

    def sync_position(self):
        if not self.visible or not self.root.winfo_ismapped():
            self.frame.withdraw();return
        if self.position is None:
            self.position=self.initial_position() if self.initial_position else (45,max(90,self.root.winfo_height()-300))
        self.position=(max(0,min(self.position[0],max(0,self.root.winfo_width()-self.width))),
                       max(0,min(self.position[1],max(0,self.root.winfo_height()-self.height))))
        x=round(self.root.winfo_rootx()+self.position[0]);y=round(self.root.winfo_rooty()+self.position[1])
        geometry=f'{self.width}x{self.height}+{x}+{y}'
        if geometry!=getattr(self,'last_geometry',None):
            self.frame.geometry(geometry);self.last_geometry=geometry
        if not self.frame.winfo_ismapped():self.frame.deiconify();self.frame.lift(self.root)

    def owner_changed(self,event):
        if event.widget is self.root:
            self.hide_hint();self.sync_position()

    def owner_unmapped(self,event):
        if event.widget is self.root:
            self.hide_hint();self.press=None;self.frame.withdraw()

    def owner_focused(self,event):
        if event.widget is self.root and self.visible and not self.grab_active():
            self.sync_position();self.frame.lift(self.root)

    def reset_position(self):
        self.position=None;self.sync_position()

    def toggle(self):
        self.hide_hint();self.visible=not self.visible;self.sync_position()

    def drag_start(self,event):
        self.hide_hint()
        if self.position is None:self.sync_position()
        self.press=(event.x_root,event.y_root,self.position[0],self.position[1]);self.dragged=False

    def drag_move(self,event):
        if not self.press:return
        sx,sy,x,y=self.press;dx,dy=event.x_root-sx,event.y_root-sy
        if abs(dx)+abs(dy)>5:self.dragged=True
        if self.dragged:
            self.position=(x+dx,y+dy);self.sync_position()

    def drag_end(self,event):
        clicked=self.press is not None and not self.dragged
        self.press=None
        if clicked:
            self.pause_until=time.monotonic()+1.2
            self.say_hello()

    def show_hint(self,event=None):
        if self.press:return
        self.hide_hint()
        self.tooltip_until=time.monotonic()+1.5
        tip=tk.Toplevel(self.root);self.tooltip=tip
        tip.withdraw();tip.overrideredirect(True);tip.transient(self.root)
        tk.Label(tip,text=self.bubble.cget('text')+'\n\nKéo để di chuyển • Bấm để trò chuyện • Chuột phải để tùy chỉnh',
                 bg=WHITE,fg=INK,font=(FONT,10),padx=12,pady=10,wraplength=270,justify='left').pack()
        tip.update_idletasks()
        x=self.frame.winfo_rootx()+self.width+5;y=self.frame.winfo_rooty()
        x=max(0,min(x,self.root.winfo_screenwidth()-tip.winfo_reqwidth()-8))
        y=max(0,min(y,self.root.winfo_screenheight()-tip.winfo_reqheight()-8))
        tip.geometry(f'+{x}+{y}');tip.deiconify()

    def grab_active(self):
        try:return self.root.grab_current() is not None
        except KeyError:
            # Native ttk popdowns have Tcl widgets with no Python widget entry.
            # They are modal while open, but must not kill the animation timer.
            return True
        except tk.TclError:return False

    def restart_motion_timer(self):
        if getattr(self,'timer',None):
            try:self.frame.after_cancel(self.timer)
            except tk.TclError:pass
        self.timer=None
        self.swim_last=time.monotonic();self.next_frame_at=self.swim_last
        try:
            if self.frame.winfo_exists():self.timer=self.frame.after(16,self.tick)
        except tk.TclError:pass

    def set_motion(self):
        if self.animate.get():
            self.hide_hint();self.pause_until=0;self.press=None
            self.restart_motion_timer()
        else:self.canvas.coords(self.character,*self.origin)

    def resume_swimming(self):
        self.animate.set(True);self.visible=True;self.press=None
        self.pause_until=0;self.turn_elapsed=None
        self.hide_hint();self.sync_position();self.restart_motion_timer()

    def tick(self):
        now=time.monotonic()
        elapsed=max(0,min(now-self.swim_last,.15));self.swim_last=now
        self.timer=None
        try:
            if self.tooltip is not None and now>=getattr(self,'tooltip_until',now+1):self.hide_hint()
            if self.press is not None and physical_left_button_down() is False:
                self.press=None;self.dragged=False
            hover_paused=self.tooltip is not None
            if (self.visible and self.animate.get() and self.root.winfo_ismapped()
                    and self.press is None and not hover_paused
                    and now >= self.pause_until and not self.grab_active()):
                if self.position is None:self.sync_position()
                turn=getattr(self,'turn_elapsed',None)
                frames=getattr(self,'swim_frames',{})
                turns=getattr(self,'turn_frames',{})
                if turn is None:
                    old_direction=self.swim_direction
                    limit=max(0,self.root.winfo_width()-self.width)
                    distance=self.position[0] if old_direction<0 else limit-self.position[0]
                    approach=max(.18,min(1,distance/50)) if turns else 1
                    speed=34*(1+.06*math.sin(self.phase))*approach
                    x,self.swim_direction=swim_step(self.position[0],old_direction,
                                                   elapsed,self.root.winfo_width(),self.width,speed)
                    y=self.position[1]+elapsed*5*math.sin(self.phase*.28)
                    self.position=(x,y)
                    if self.swim_direction!=old_direction and turns:
                        self.turn_from=old_direction;self.turn_elapsed=0.0
                else:
                    self.turn_elapsed+=elapsed
                    if self.turn_elapsed>=1.0:self.turn_elapsed=None
                self.phase+=elapsed*3.8
                if getattr(self,'turn_elapsed',None) is not None and turns:
                    progress=min(1,self.turn_elapsed/1.0)
                    direction=self.turn_from if progress<.5 else self.swim_direction
                    index=round(math.sin(math.pi*progress)**2*(len(turns[direction])-1))
                    image=turns[direction][index]
                elif frames:
                    index=int(self.phase/(2*math.pi)*len(frames[self.swim_direction]))%len(frames[self.swim_direction])
                    image=frames[self.swim_direction][index]
                else:
                    image=self.facing_images.get(self.swim_direction)
                if image:self.canvas.itemconfigure(self.character,image=image)
                # Body deformation lives in the sprites; only slight buoyancy remains.
                self.canvas.coords(self.character,self.origin[0],self.origin[1]+1.2*math.sin(self.phase*.48))
                self.sync_position()
        except (tk.TclError,KeyError) as exc:
            self.last_motion_error=f'{type(exc).__name__}: {exc}'
        finally:
            # A popup or transient widget error must not terminate the loop.
            finished=time.monotonic()
            deadline=getattr(self,'next_frame_at',now)+1/60
            if deadline<=finished:deadline=finished+1/60
            self.next_frame_at=deadline
            delay=max(1,math.ceil((deadline-finished)*1000))
            try:
                if self.frame.winfo_exists():self.timer=self.frame.after(delay,self.tick)
            except tk.TclError:self.timer=None

    def destroy_float(self,event):
        if event.widget is self.frame:
            self.hide_hint()
            if self.timer:
                try:self.frame.after_cancel(self.timer)
                except tk.TclError:pass
                self.timer=None
