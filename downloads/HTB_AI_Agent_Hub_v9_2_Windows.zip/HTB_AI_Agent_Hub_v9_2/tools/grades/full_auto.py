"""One-file workflow; all browser work stays on a single Playwright thread."""
import csv, datetime, json, os, queue, threading, time, traceback, re
from pathlib import Path
from urllib.parse import urlparse
from auto_core import read_jobs, subject_aliases, expand_headers, column_index, confirm_is_paste, key, grade_from_class, grade_batch_state
from browser_dom import DOM
from name_matching import build_plan, paste_runs
from chrome_bridge import normalize_name
from startup_errors import startup_hint

DOMAIN='nhapdiem.truonghocviet.vn'

class Cancelled(Exception):pass

class AutoWorker(threading.Thread):
    def __init__(self,path,events,cancel):
        super().__init__(daemon=True);self.path=path;self.events=events;self.cancel=cancel
        self.ctx=None;self.pw=None;self.audit=[];self.total=0;self.started=time.monotonic();self.stage=''
        self.allowed_subjects=None
        self.credentials=None
        self.authorized_paste=False;self.dialog_error=None;self.last_submitted=None;self.bound_token=None

    def emit(self,message,kind='progress'):
        self.stage=message;self.events.put((kind,message))

    def check(self):
        if self.cancel.is_set():raise Cancelled('Đã dừng theo yêu cầu. Điểm đã lưu trước đó được giữ nguyên.')

    def tick(self,p,ms=150):
        self.check();p.wait_for_timeout(ms)

    def page(self):
        pages=[p for p in self.ctx.pages if not p.is_closed() and urlparse(p.url).hostname==DOMAIN]
        if not pages:raise RuntimeError('Cửa sổ VietSchool đã đóng. Chọn lại Excel để mở lại.')
        return pages[-1]

    def dom(self,f,op,**args):return f.evaluate(DOM,{'op':op,**args})

    def frames(self):
        p=self.page();frames=[]
        for f in p.frames:
            if urlparse(f.url).hostname!=DOMAIN:continue
            try:
                if f!=p.main_frame and not f.frame_element().is_visible():continue
            except Exception:continue
            frames.append(f)
        return frames

    def ui_target(self,values,group=None,branch=None):
        found=[];searched=[]
        for f in self.frames():
            try:
                target=self.dom(f,'target',values=values,group=group,branch=branch)
                searched.append({'frame':urlparse(f.url).path,'result':target})
                if target and target.get('selector'):found.append((f,target))
            except Exception as e:searched.append({'error':str(e).split('Call log:')[0]})
        if len(found)!=1:
            self.last_target_search={'values':values,'group':group,'branch':branch,'frames':searched}
            return None
        return found[0]

    def wait_target(self,values,group=None,branch=None,timeout=15):
        started=time.monotonic();deadline=started+timeout;notice=started
        while time.monotonic()<deadline:
            self.check();target=self.ui_target(values,group,branch)
            if target:return target
            now=time.monotonic()
            if now-notice>=3:
                self.emit(f'Chờ cây danh sách: {", ".join(values)} ({int(now-started)}/{timeout} giây).');notice=now
            self.tick(self.page(),200)
        raise RuntimeError('Chưa tìm được mục duy nhất '+', '.join(values)+f' sau {timeout} giây. Đã dừng trước khi nhập điểm.')

    def choose_class(self,clazz):
        """A visible exact class is sufficient; an absent parent label must not block it."""
        grade=grade_from_class(clazz);group=['LỚP HỌC','LỚP']
        self.wait_idle('danh sách lớp');started=time.monotonic();deadline=started+15;notice=started
        while time.monotonic()<deadline:
            self.check()
            if self.ui_target([clazz],group=group):
                self.choose([clazz],group=group)
                return
            if self.ui_target([grade],group=group):
                self.expand([grade],group=group)
                self.wait_target([clazz],group=group)
                self.choose([clazz],group=group)
                return
            now=time.monotonic()
            if now-notice>=3:
                self.emit(f'Chờ tải cây lớp {clazz}: {int(now-started)}/15 giây.');notice=now
            self.tick(self.page(),200)
        raise RuntimeError(f'Chưa chọn được lớp {clazz}: cây lớp chưa sẵn sàng sau 15 giây. Chưa nhập điểm.')

    def wait_idle(self,label='trang',timeout=60):
        """Wait for real hit-blocking overlays, even when aria-hidden says true."""
        p=self.page();deadline=time.monotonic()+timeout;stable=None;notice=0;started=time.monotonic()
        while time.monotonic()<deadline:
            self.check();busy=[]
            for f in self.frames():
                try:busy.extend(self.dom(f,'busy'))
                except Exception:
                    busy.append({'id':'đang chuyển trang'})
            now=time.monotonic()
            if not busy:
                if stable is None:stable=now
                if now-stable>=.4:return
            else:
                stable=None
                if now-notice>=2:
                    self.emit(f'Chờ tải {label}: {int(now-started)}/{timeout} giây (lớp phủ tải đang chặn thao tác).');notice=now
            self.tick(p,150)
        raise RuntimeError(f'Trang vẫn đang tải {label} sau {timeout} giây. Đã dừng; chưa bấm xuyên lớp phủ và chưa nhập ở bước này.')

    def choose(self,values,group=None,branch=None,verify=True):
        p=self.page();last_error=None
        # Navigation clicks are reversible; re-resolve after a loading/rerender race.
        # Grade pastes never use this retry loop.
        for attempt in range(3):
            self.wait_idle(', '.join(values));deadline=time.monotonic()+8
            got=None
            while time.monotonic()<deadline:
                self.check();got=self.ui_target(values,group,branch)
                if got:break
                self.tick(p,200)
            if not got:raise RuntimeError('Không tìm thấy mục giao diện duy nhất: '+', '.join(values)+'. Chưa nhập điểm vào phạm vi này.')
            f,t=got
            if verify and t['active']:return
            try:f.locator(t['selector']).click(timeout=4000)
            except Exception as e:
                last_error=e
                if attempt<2:continue
                break
            self.wait_idle(', '.join(values))
            if not verify:return
            deadline=time.monotonic()+5
            while time.monotonic()<deadline:
                got=self.ui_target(values,group,branch)
                if got and got[1]['active']:return
                self.tick(p,150)
            last_error=RuntimeError('Chưa xác minh được mục đã chọn.')
        raise RuntimeError('Không chọn được '+', '.join(values)+'. '+str(last_error).split('Call log:')[0])

    def expand(self,values,group):
        self.wait_idle(', '.join(values));got=self.wait_target(values,group=group)
        f,t=got
        if t.get('expanded')!='false' and not t.get('toggle'):return
        if t.get('toggle'):f.locator(t['toggle']).click(timeout=4000)
        elif t.get('expandMode')=='wijmo':
            node=f.locator(t['expandSelector']);box=node.bounding_box(timeout=4000)
            if not box:raise RuntimeError('Nhánh cây không còn hiển thị.')
            # Wijmo renders the expansion arrow as the node's :before pseudo-element.
            node.click(position={'x':8,'y':box['height']/2},timeout=4000)
        else:f.locator(t['selector']).click(timeout=4000)
        self.wait_idle(', '.join(values));deadline=time.monotonic()+5
        while time.monotonic()<deadline:
            current=self.ui_target(values,group)
            if current and current[1].get('expanded')!='false':return
            self.tick(self.page(),150)
        raise RuntimeError('Chưa mở được nhánh '+', '.join(values))

    def year(self,year):
        self.wait_idle('năm học')
        # Prefer actual select controls, otherwise operate the year dropdown visible in the toolbar.
        for f in self.frames():
            sel=self.dom(f,'select',values=[year])
            if sel:
                if not sel['selected']:f.locator(sel['selector']).select_option(sel['value'],timeout=4000)
                self.wait_idle('năm học')
                if self.dom(f,'select',values=[year])['selected']:return
        f=self.page().main_frame;info=self.dom(f,'year',year=year)
        if info['matched']:return
        if len(info['current'])!=1:raise RuntimeError('Không đọc được mục năm học trên thanh công cụ.')
        f.locator(info['current'][0]['selector']).click(timeout=4000)
        self.choose([year],verify=False)
        self.wait_idle('năm học')
        if not self.dom(self.page().main_frame,'year',year=year)['matched']:raise RuntimeError('Chưa xác minh được năm học '+year)

    def submit_login(self,p):
        """Submit supplied credentials once, only to the exact HTTPS VietSchool host."""
        parsed=urlparse(p.url)
        if parsed.scheme!='https' or parsed.hostname!=DOMAIN:return 'manual'
        if not self.credentials or not all(self.credentials):return 'manual'
        passwords=p.locator('input[type="password"]:visible')
        if passwords.count()!=1:return 'wait'
        password=passwords.nth(0)
        form=password.locator('xpath=ancestor::form[1]')
        scope=form if form.count()==1 else p
        if scope.locator('input[name*="captcha" i]:visible,iframe[src*="recaptcha"]:visible,iframe[src*="hcaptcha"]:visible').count():
            self.emit('VietSchool yêu cầu CAPTCHA; thầy hoàn tất đăng nhập trong Chrome để tiếp tục.')
            self.credentials=None
            return 'manual'
        users=scope.locator('input[autocomplete="username"]:visible,input[name="UserName"]:visible,input[name="username"]:visible,input[id="UserName"]:visible,input[type="tel"]:visible,input[type="email"]:visible,input[type="text"]:visible')
        if users.count()!=1:return 'wait'
        candidates=scope.get_by_role('button',name=re.compile(r'^\s*(?:Đăng nhập|Login|Sign in)\s*$',re.I))
        buttons=[candidates.nth(i) for i in range(candidates.count()) if candidates.nth(i).is_visible()]
        if len(buttons)!=1:
            submit=scope.locator('button[type="submit"]:visible,input[type="submit"]:visible')
            if submit.count()!=1:return 'wait'
            buttons=[submit.nth(0)]
        username,secret=self.credentials
        try:
            users.nth(0).fill(username,timeout=4000)
            password.fill(secret,timeout=4000)
            buttons[0].click(timeout=4000)
            self.emit('Đã điền tài khoản và bấm Đăng nhập. Đang chờ VietSchool xác nhận; nếu có OTP/CAPTCHA thầy xử lý trong Chrome.')
            return 'submitted'
        except Exception:
            self.emit('Chưa hoàn tất đăng nhập tự động. Thầy kiểm tra tài khoản hoặc đăng nhập trong Chrome; chương trình sẽ chờ.')
            return 'manual'
        finally:
            self.credentials=None

    def login_and_open(self):
        p=self.page();deadline=time.monotonic()+600;last_emit=0;login_attempted=False;detect_until=time.monotonic()+15
        while time.monotonic()<deadline:
            self.check()
            locked='/account/login' in p.url.lower() or p.locator('input[type="password"]:visible').count()>0
            if not locked:
                self.credentials=None
                break
            if not login_attempted and self.credentials:
                outcome=self.submit_login(p)
                login_attempted=outcome!='wait' or time.monotonic()>detect_until
                if login_attempted:self.credentials=None
            if time.monotonic()-last_emit>5:
                self.emit('Đang chờ bạn đăng nhập trong Chrome Agent. Đăng nhập xong chương trình tự tiếp tục.');last_emit=time.monotonic()
            self.tick(p,300)
        else:raise RuntimeError('Đã chờ đăng nhập 10 phút. Chọn lại Excel khi sẵn sàng.')
        self.wait_idle('sau đăng nhập')
        # Existing open input screen is reusable. Otherwise open Điểm -> Nhập điểm.
        if not self.ui_target(['LỚP HỌC']):
            self.emit('Đang mở màn hình Điểm → Nhập điểm...')
            direct=self.ui_target(['Nhập điểm'])
            if direct:self.choose(['Nhập điểm'],verify=False)
            else:
                self.choose(['Điểm'],verify=False)
                self.choose(['Nhập điểm'],verify=False)
        deadline=time.monotonic()+12
        while time.monotonic()<deadline:
            if self.ui_target(['LỚP HỌC']):return
            self.tick(p,200)
        raise RuntimeError('Chưa mở được màn hình Nhập điểm. Không có thao tác nhập nào được thực hiện.')

    def configure_subjects(self,jobs):
        # This is built only from Excel jobs containing grades. Never derive the
        # workload by enumerating the school's subject menu.
        self.allowed_subjects={key(subject_aliases(j['subject'])[0]):j['subject'] for j in jobs}
        self.emit('Chỉ xử lý môn có điểm trong Excel: '+', '.join(self.allowed_subjects.values()))

    def subject_values(self,subject):
        values=subject_aliases(subject)
        if self.allowed_subjects is not None and key(values[0]) not in self.allowed_subjects:
            raise RuntimeError('Môn '+subject+' không nằm trong phạm vi Excel đã nạp. Không chọn môn này.')
        return values

    def navigate(self,job,assessment='ĐGTX'):
        subject_values=self.subject_values(job['subject'])
        p=self.page();grade=grade_from_class(job['class'])
        self.emit(f'Chọn {job["year"]} / {grade} / {job["class"]} / {job["term"]} / {assessment} / {job["subject"]}')
        self.year(job['year'])
        self.choose_class(job['class'])
        self.expand([job['term']],group=['ĐỢT ĐIỂM'])
        vals=['ĐGTX','DGTX','Điểm ĐGTX'] if assessment=='ĐGTX' else ['Thi','Điểm thi']
        self.choose(vals,group=['ĐỢT ĐIỂM'],branch=job['term'])
        self.choose(subject_values,group=['MÔN HỌC','MÔN'])
        self.wait_idle('bảng điểm')

    def scope_is_selected(self,job,assessment):
        if not self.dom(self.page().main_frame,'year',year=job['year'])['matched']:
            # Native select may not expose year text outside its options.
            year_ok=any((self.dom(f,'select',values=[job['year']]) or {}).get('selected') for f in self.frames())
            if not year_ok:raise RuntimeError('Năm học thay đổi trong lúc nhập. Đã dừng.')
        vals=['ĐGTX','DGTX','Điểm ĐGTX'] if assessment=='ĐGTX' else ['Thi','Điểm thi']
        for values,group,branch in [([job['class']],['LỚP HỌC','LỚP'],None),(self.subject_values(job['subject']),['MÔN HỌC','MÔN'],None),(vals,['ĐỢT ĐIỂM'],job['term'])]:
            got=self.ui_target(values,group,branch)
            if not got or not got[1]['active']:raise RuntimeError('Phạm vi lớp/môn/học kỳ bị thay đổi hoặc không xác minh được. Đã dừng.')

    def grid(self):
        found=[];errors=[]
        for f in self.frames():
            try:
                s=self.dom(f,'snapshot')
                if s['rows']:found.append((f,s))
            except Exception as e:
                errors.append(str(e).split('Call log:')[0])
        if errors:raise RuntimeError('Bộ đọc bảng báo lỗi: '+errors[0])
        if len(found)!=1:raise RuntimeError(f'Đọc được {len(found)} khung có danh sách. Chưa nhận diện được một bảng học sinh duy nhất; sẽ tự ghi chan_doan_giao_dien.json khi dừng.')
        return found[0]

    def collect(self,f,expected=None):
        p=self.page();allrows={};deadline=time.monotonic()+55
        wanted={normalize_name(r['student']) for r in (expected or []) if not r.get('inactive')}
        def merge():
            # All rendered HTML rows can be read even below a clipped scroll viewport.
            # Focus/paste still uses the separately validated visible snapshot.
            s=self.dom(f,'snapshot_all')
            for r in s['rows']:
                old=allrows.get(r['stt'])
                if old and (old['name'],old['dob'])!=(r['name'],r['dob']):raise RuntimeError('Danh sách thay đổi khi cuộn. Đã dừng.')
                allrows[r['stt']]=r
        def complete():
            if not wanted:return False
            actual={normalize_name(r['name']) for r in allrows.values()}
            keys=sorted(allrows)
            return wanted<=actual and keys==list(range(1,len(keys)+1))
        merge()
        if complete():
            self.emit(f'Đã đọc đủ {len(allrows)} dòng trên web, khớp đủ {len(wanted)} họ tên Excel (gồm các dòng nghỉ nếu có).')
            return sorted(allrows.values(),key=lambda r:r['stt'])
        count=self.dom(f,'scroll_init')
        self.emit(f'Đang quét toàn lớp: đã đọc {len(allrows)} dòng; tìm thấy {count} vùng cuộn.')
        try:
            for i in range(count):
                self.dom(f,'scroll',i=i,top=True);self.tick(p,180);merge()
                if complete():break
                for step in range(120):
                    self.check()
                    if time.monotonic()>deadline:raise RuntimeError(f'Đã quét 55 giây, đọc được {len(allrows)} dòng; chưa đủ tên Excel. Không dán khi chưa đủ danh sách.')
                    state=self.dom(f,'scroll',i=i);self.tick(p,180);merge()
                    if step%3==0:self.emit(f'Đang quét toàn lớp: {len(allrows)} dòng; vùng cuộn {i+1}/{count}.')
                    if complete() or state['end']:break
                if complete():break
        finally:
            self.dom(f,'restore');self.tick(p,200)
        self.emit(f'Kết thúc quét: {len(allrows)} dòng trên web; đang đối chiếu họ tên Excel.')
        return sorted(allrows.values(),key=lambda r:r['stt'])

    def headers(self,f,job):
        raw=self.dom(f,'headers');found=[];matched_paths=[]
        for table in raw:
            paths=expand_headers(table)
            # Alignment is proven using the four identity headers before grade columns.
            if len(paths)<5 or key(paths[0])!='stt' or key(paths[1]) not in ('ho','ho dem') or key(paths[2])!='ten' or key(paths[3])!='ngay sinh':continue
            try:idx=column_index(paths,job['column'])
            except ValueError:continue
            found.append(idx);matched_paths.append(paths)
        if not found or len(set(found))!=1:raise ValueError('Không xác định duy nhất cột '+job['column']+' bằng tiêu đề hiển thị. Chưa nhập cột này.')
        index=found[0]
        self.emit('Định vị '+job['column']+' → cột '+str(index+1)+' của bảng ('+matched_paths[0][index]+').')
        return index

    def dialog(self,d):
        if d.type=='confirm' and self.authorized_paste and confirm_is_paste(d.message):d.accept()
        elif d.type=='alert' and self.authorized_paste:
            self.dialog_error='VietSchool báo: '+d.message;d.accept()
        else:
            self.dialog_error='Hộp thoại ngoài thao tác dán đã được hủy: '+d.message;d.dismiss()

    def html_dialog(self,p):
        # Some sites use an HTML confirmation rather than window.confirm.
        for f in self.frames():
            ds=f.locator('[role="dialog"]:visible,.modal.show:visible,.modal.in:visible,.ui-dialog:visible,.messager-window:visible')
            for d in ds.all():
                if confirm_is_paste(d.inner_text(timeout=2000)):
                    import re
                    buttons=d.get_by_role('button',name=re.compile(r'^(OK|Có|Đồng ý|Xác nhận|Dán)$',re.I))
                    if buttons.count()!=1:raise RuntimeError('Hộp xác nhận dán không có một nút đồng ý duy nhất.')
                    buttons.click(timeout=3000)

    def visible_run(self,f,run):
        rows=self.dom(f,'snapshot')['rows'];known={r['stt'] for r in rows}
        return all(r['stt'] in known for r in run)

    def seek(self,f,student):
        if self.visible_run(f,[student]):return
        p=self.page()
        # Bring a known DOM row into view before searching scrollbar tracks.
        if self.dom(f,'reveal',student=student):
            for _ in range(8):
                self.tick(p,150)
                if self.visible_run(f,[student]):return
        count=self.dom(f,'scroll_init')
        for i in range(count):
            self.dom(f,'scroll',i=i,top=True);self.tick(p,100)
            for _ in range(120):
                if self.visible_run(f,[student]):return
                end=self.dom(f,'scroll',i=i)['end'];self.tick(p,80)
                if end:break
        raise RuntimeError('Không tìm lại được dòng '+student['name']+' khi cuộn. Đã dừng.')

    def same_value(self,actual,expected):
        if actual.strip()==expected:return True
        try:return float(actual.replace(',','.'))==float(expected.replace(',','.'))
        except ValueError:return False

    def select_bound_cell(self,f,run):
        p=self.page();deadline=time.monotonic()+15
        while time.monotonic()<deadline:
            self.check()
            view=self.dom(f,'bound_view',token=self.bound_token,run=run)
            if view['ready']:
                locator=self.dom(f,'bound_focus',token=self.bound_token,run=run)
                # Use a point inside the actual clipped score pane. The normal
                # cell center can sit under a scrollbar or outside the pane.
                rect=f.locator(locator).bounding_box(timeout=4000)
                if not rect:raise RuntimeError('Ô điểm không còn hiển thị để bấm.')
                p.mouse.click(rect['x']+view['position']['x'],rect['y']+view['position']['y'])
                self.dom(f,'bound_check',token=self.bound_token,run=run,selector=locator)
                return
            if not view['dx'] and not view['dy']:
                raise RuntimeError('Ô điểm bị lớp khác che. Chưa dán STT '+str(run[0]['stt']))
            self.emit('Đang cuộn bảng điểm tới STT '+str(run[0]['stt'])+'...')
            rect=f.locator(view['selector']).bounding_box(timeout=4000)
            if not rect:raise RuntimeError('Khung cuộn điểm không còn hiển thị.')
            p.mouse.move(rect['x']+view['position']['x'],rect['y']+view['position']['y'])
            p.mouse.wheel(view['dx'],view['dy'])
            self.tick(p,300)
        raise RuntimeError('Chưa cuộn tới ô điểm STT '+str(run[0]['stt'])+' sau 15 giây. Chưa gửi lệnh dán.')

    def paste(self,f,run,index,job,assessment):
        import pyperclip
        p=self.page();self.check();self.wait_idle('trước khi nhập điểm');self.scope_is_selected(job,assessment)
        p.bring_to_front()
        if self.bound_token:
            self.select_bound_cell(f,run)
        else:
            index=self.headers(f,job)
            self.wait_idle('ô điểm')
            locator=self.dom(f,'focus',run=run,index=index)
            f.locator(locator).click(timeout=4000)
            index=self.headers(f,job)
            self.dom(f,'verify_focus',run=run,index=index,selector=locator)
        pyperclip.copy('\n'.join(r['value'] for r in run))
        self.dialog_error=None;self.authorized_paste=True
        deadline=time.monotonic()+20;save_clicked=False
        try:
            self.last_submitted=(job['class'],job['column'],run[0]['stt'],run[-1]['stt'])
            p.keyboard.press('Control+V')
            while time.monotonic()<deadline:
                self.tick(p,120)
                if self.dialog_error:raise RuntimeError(self.dialog_error)
                self.html_dialog(p)
                # A class/subject switch while waiting must stop processing as well.
                self.scope_is_selected(job,assessment)
                if self.bound_token:
                    snap=self.dom(f,'bound_snapshot',token=self.bound_token,run=run)
                    state=grade_batch_state(snap['rows'],run,4)
                else:
                    snap=self.dom(f,'snapshot')
                    try:
                        paths=snap.get('headerPaths')
                        current_index=column_index(paths,job['column']) if paths else self.headers(f,job)
                    except ValueError:
                        continue
                    state=grade_batch_state(snap['rows'],run,current_index)
                good=state['values_ok']
                if state['saved']:
                    self.last_submitted=None
                    return
                if good and not save_clicked:
                    save=self.dom(f,'save')
                    if save:
                        self.emit('Đã đối chiếu giá trị. Đang bấm Lưu và chờ chữ xanh lá...');f.locator(save).click(timeout=4000);save_clicked=True
            raise RuntimeError('Chưa thấy đúng giá trị và chữ xanh lá sau 20 giây tại STT '+str(run[0]['stt'])+'. Không tự dán lại. Kiểm tra VietSchool rồi chọn lại Excel để tiếp tục các ô trống.')
        finally:self.authorized_paste=False

    def prepare_grid(self):
        # Restore both panels before a new roster/column discovery. This never runs
        # between binding and pasting, so it cannot move a pending destination.
        for frame in self.frames():self.dom(frame,'reset_grid_view')
        self.tick(self.page(),200)

    def process_job(self,job,n,total):
        self.bound_token=None
        self.check();assessment='ĐGTX';self.navigate(job,assessment);self.prepare_grid()
        self.emit(f'[{n}/{total}] Đang đọc và dò tên lớp {job["class"]}...')
        deadline=time.monotonic()+10;last=None
        while time.monotonic()<deadline:
            try:
                f,s=self.grid();self.dom(f,'reset_horizontal');self.tick(self.page(),200);site=self.collect(f,expected=job['rows'])
                # Force roster comparison to wait for the newly selected class to finish loading.
                build_plan(job['rows'],site,job['column'],subject_aliases(job['subject'])[-1],clazz=job['class']);break
            except (ValueError,RuntimeError) as e:last=e;self.tick(self.page(),250)
        else:raise RuntimeError('Không đối chiếu được danh sách: '+str(last))
        try:index=self.headers(f,job)
        except ValueError:
            if job['column'] not in ('Giữa kỳ','Cuối kỳ'):raise
            assessment='Thi';self.navigate(job,assessment);self.prepare_grid();self.tick(self.page(),250)
            f,_=self.grid();self.dom(f,'reset_horizontal');self.tick(self.page(),200);site=self.collect(f,expected=job['rows']);index=self.headers(f,job)
        self.scope_is_selected(job,assessment)
        plan=build_plan(job['rows'],site,job['column'],subject_aliases(job['subject'])[-1],index=index,clazz=job['class'])
        rounded=[r for r in plan if r.get('original') is not None and r['value'] is not None and r.get('original')!=r['value']]
        if rounded:
            self.emit('Chuẩn hóa một chữ số thập phân theo VietSchool: '+ '; '.join(f"STT {r['stt']} {r['name']}: {r['original']} → {r['value']}" for r in rounded))
        for r in plan:
            if r['status']!='Sẽ dán':self.audit.append({**job,'rows':None,**r,'phase':'Nhập điểm','result':r['status']})
        self.events.put(('roster',{'scope':f'{job["class"]} / {job["subject"]} / {job["column"]}','rows':plan}))
        explicit=[r for r in plan if r['status']=='Bỏ qua theo yêu cầu: trùng tên']
        if explicit:self.emit('Bỏ qua theo yêu cầu, giữ nguyên các ô: '+ '; '.join(f"STT {r['stt']} — {r['name']} ({r['dob']})" for r in explicit))
        retired=[r for r in plan if r['status']=='Bỏ qua: học sinh nghỉ']
        if retired:self.emit('Bỏ học sinh nghỉ: '+ '; '.join(f'STT {r["stt"]} — {r["name"]}' for r in retired))
        not_found=[r for r in plan if r['status']=='Bỏ qua: không tìm thấy tên trên web']
        if not_found:self.emit('Bỏ qua tên Excel không tìm thấy trên web: '+ '; '.join(r['name'] for r in not_found)+'. Chỉ dán các tên khớp duy nhất.')
        web_only=[r for r in plan if r['status']=='Bỏ qua: không có trong Excel']
        if web_only:self.emit('Bỏ qua học sinh web không có dữ liệu Excel (không coi là nghỉ): '+ '; '.join(f"STT {r['stt']} — {r['name']}" for r in web_only)+'. Giữ nguyên điểm web, tiếp tục các tên khớp.')
        runs=paste_runs(plan);pending=sum(map(len,runs));done=0
        if pending:
            targets=[r for r in plan if r['status']=='Sẽ dán']
            self.bound_token=self.dom(f,'bind_column',run=targets,index=index,column=job['column'])
            if not isinstance(self.bound_token,str):raise RuntimeError('Không cố định được các ô điểm đã đối chiếu.')
            self.emit(f'Đã gắn đúng {pending} ô cột {job["column"]}; tiếp tục dán theo từng vùng, tách tại học sinh nghỉ.')
        self.emit(f'[{n}/{total}] {job["class"]} / {job["subject"]} / {job["column"]}: {pending} ô cần nhập, {len(plan)-pending} dòng bỏ qua.')
        for run in runs:
            batches=[run]
            for batch in batches:
                self.check()
                if not self.bound_token:
                    self.scope_is_selected(job,assessment)
                    index=self.headers(f,job)
                    self.bound_token=self.dom(f,'bind_column',run=batch,index=index,column=job['column'])
                    if not isinstance(self.bound_token,str):raise RuntimeError('Không gắn lại được các ô đích sau tải trang')
                self.emit(f'[{n}/{total}] {job["class"]} / {job["column"]}: đang nhập STT {batch[0]["stt"]}–{batch[-1]["stt"]} ({done}/{pending} ô).')
                self.paste(f,batch,index,job,assessment)
                for row in batch:self.audit.append({**job,'rows':None,**row,'phase':'Nhập điểm','actual':'','verification':'Chờ kiểm tra cuối đợt','result':'Đã lưu qua giao diện; chờ kiểm tra cuối đợt'})
                done+=len(batch);self.total+=len(batch)
                self.events.put(('verified',{'stts':[r['stt'] for r in batch]}))
                self.emit(f'[{n}/{total}] Đã nhập và xác nhận lưu {done}/{pending} ô của {job["class"]} / {job["column"]}.')

    def report(self,result):
        folder=Path(__file__).resolve().parent/'bao_cao';folder.mkdir(exist_ok=True)
        path=folder/('nhap_diem_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.csv')
        fields=['year','class','subject','term','column','stt','name','row','phase','original','value','expected','actual','verification','reason','old','result']
        with path.open('w',newline='',encoding='utf-8-sig') as fp:
            w=csv.DictWriter(fp,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(self.audit)
            w.writerow({'result':result})
        return str(path)

    def verify_all_jobs(self,jobs):
        # Reuse the existing read-only checker; it reloads exactly once before
        # navigating through every class/column. Never call its run()/cleanup.
        from check_worker import CheckWorker
        parent=self
        class Relay:
            def put(self,event):
                kind,payload=event
                if kind=='comparison':parent.events.put(('final_check',payload))
                elif kind=='progress':parent.emit(payload)
                else:parent.events.put(event)
        checker=CheckWorker(self.path,Relay(),self.cancel)
        checker.ctx=self.ctx;checker.pw=self.pw
        checker.configure_subjects(jobs)
        self.emit('Đã nhập hết các nhóm. Bắt đầu kiểm tra cuối đợt: tải lại VietSchool một lần, sau đó đối chiếu lần lượt các lớp.')
        try:
            checker.login_and_open()
            for n,job in enumerate(jobs,1):
                self.check()
                before=len(checker.audit)
                checker.process_job(job,n,len(jobs))
                for row in checker.audit[before:]:
                    self.audit.append({**row,'phase':'Kiểm tra cuối đợt','value':row.get('expected',''),
                                       'verification':row['result']})
        except Cancelled:raise
        except Exception:
            # Preserve an explicit pending record for groups not reached.
            for i,job in enumerate(jobs):
                if i not in checker.finished:
                    for row in checker.unchecked(job,'Chưa hoàn tất kiểm tra cuối đợt'):
                        self.audit.append({**row,'phase':'Kiểm tra cuối đợt','verification':row['result']})
            raise
        self.final_checked=checker.total
        from compare_core import summary
        self.final_summary=summary(checker.audit)
        bad=[r for r in checker.audit if r['result'] in ('Sai điểm','Thiếu điểm trên web','Giá trị web không hợp lệ','Chưa kiểm tra được')]
        if bad:raise RuntimeError('Đã kiểm tra xong các lớp; có sai lệch hoặc ô chưa kiểm tra được. '+self.final_summary+' Không tự sửa/ghi đè; xem báo cáo.')
        self.emit('Kiểm tra cuối đợt hoàn tất. '+self.final_summary)

    def process_jobs(self,jobs):
        for n,job in enumerate(jobs,1):
            self.process_job(job,n,len(jobs))
            self.emit(f"[{n}/{len(jobs)}] Đã nhập {job['class']} / {job['column']}." + (' Chuyển nhóm tiếp theo, chưa tải lại kiểm tra.' if n<len(jobs) else ' Đã nhập hết danh sách.'))
        self.verify_all_jobs(jobs)

    def completion_message(self,jobs):
        return f"Hoàn tất nhập {len(jobs)} nhóm, {self.total} ô mới. Đã kiểm tra cuối đợt sau khi nhập tất cả lớp. "+getattr(self,'final_summary','')

    def run(self):
        result='';kind='done'
        try:
            self.check()
            self.emit('Đang đọc Excel và kiểm tra toàn bộ điểm trước khi mở Chrome...')
            jobs=read_jobs(self.path);self.configure_subjects(jobs);self.emit(f'Đã đọc {len(jobs)} nhóm lớp/môn/học kỳ/cột. Đang mở Chrome...')
            self.check()
            from playwright.sync_api import sync_playwright
            self.pw=sync_playwright().start()
            profile=Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'VietSchoolAgent'/'ChromeProfile'
            profile.mkdir(parents=True,exist_ok=True)
            self.ctx=self.pw.chromium.launch_persistent_context(str(profile),channel='chrome',headless=False,no_viewport=True,chromium_sandbox=True,timeout=20000,args=['--start-maximized'],accept_downloads=False)
            self.ctx.set_default_timeout(4000);self.ctx.set_default_navigation_timeout(15000)
            for p in self.ctx.pages:p.on('dialog',self.dialog)
            self.ctx.on('page',lambda p:p.on('dialog',self.dialog))
            p=self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
            if urlparse(p.url).hostname!=DOMAIN:
                try:p.goto('https://'+DOMAIN,wait_until='domcontentloaded',timeout=15000)
                except Exception:
                    if urlparse(p.url).hostname!=DOMAIN:raise RuntimeError('Không mở được VietSchool sau 15 giây. Kiểm tra mạng và Chrome.')
            self.login_and_open()
            self.process_jobs(jobs)
            result=self.completion_message(jobs)
        except Cancelled as e:kind='stopped';result=str(e)
        except Exception as e:
            if self.ctx:
                try:
                    diag={'stage':self.stage,'last_target_search':getattr(self,'last_target_search',None),'frames':[self.dom(f,'diagnostic') for f in self.frames()]}
                    Path(__file__).with_name('chan_doan_giao_dien.json').write_text(json.dumps(diag,ensure_ascii=False,indent=2),encoding='utf-8')
                except Exception:pass
            kind='error';detail=str(e).split('Call log:')[0].strip()
            hint=startup_hint(detail) if self.ctx is None else ''
            if hint:detail+='\n'+hint
            pending=''
            if self.last_submitted:
                clazz,col,first,last=self.last_submitted
                pending=f'\nVùng vừa gửi: {clazz} / {col} / STT {first}–{last}. Có thể đã được lưu; cần kiểm tra, không tự dán lặp.'
            result=f'Đã dừng: {detail}\nĐã nhập và xác nhận lưu qua giao diện {self.total} ô. Xem cột phase/verification trong báo cáo để biết kết quả kiểm tra cuối đợt.'+pending
            try:
                Path(__file__).with_name('loi_khoi_dong.txt').write_text(traceback.format_exc(),encoding='utf-8')
            except OSError:pass
        finally:
            try:result+='\nBáo cáo: '+self.report(result)
            except Exception as e:result+='\nKhông ghi được báo cáo: '+str(e)
            self.emit(result,kind)
            # Leave Chrome open for review until the user closes the app or loads another file.
            if self.ctx:
                try:
                    while not self.cancel.wait(.2):
                        if not self.ctx.pages:break
                        self.ctx.pages[0].wait_for_timeout(100)
                except Exception:pass
                try:self.ctx.close()
                except Exception:pass
            if self.pw:
                try:self.pw.stop()
                except Exception:pass
