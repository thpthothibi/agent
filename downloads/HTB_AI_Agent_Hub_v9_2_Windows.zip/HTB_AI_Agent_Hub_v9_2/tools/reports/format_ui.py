"""Streamlit bridge to the recovered HTB Format Pro 1.1 source."""
import hashlib, io, json, os, re, zipfile
from copy import deepcopy
from pathlib import Path
import streamlit as st
from docx import Document
from format_pro.app.engine import (load, audit, normalize, template_docx, component_docx,
                                  pdf_convert, TEMPLATE_TYPES, COMPONENTS, REFERENCE)

BASE = Path(__file__).parent


def reference_label(key):
    # Display these as the presets inherited from the 15/10 source, not a current legal certification.
    return {'auto':'Tự nhận diện', 'admin':'Hành chính', 'party':'Văn bản Đảng'}[key]


def settings(prefix):
    standard = st.selectbox('Bộ quy tắc định dạng', ['auto','admin','party'], format_func=reference_label, key=prefix+'standard')
    st.caption('Các bộ quy tắc kế thừa từ HTB Format Pro ngày 15/10/2026. Rà soát kết quả trước khi sử dụng chính thức.')
    with st.expander('Tùy chọn chuẩn hóa'):
        opts = {}
        for key, label, default in [
            ('safe_layout','Bảo vệ bố cục bảng, chữ ký, Tab và danh sách',True),
            ('page','Khổ A4 và lề trang (giữ phụ lục ngang)',True),
            ('fonts','Chuẩn hóa phông chữ',True),
            ('paragraphs','Chuẩn hóa đoạn nội dung',True),
            ('whitespace','Xóa khoảng trắng thừa trong từng đoạn chữ',False),
            ('legacy','Chuyển TCVN3 / VNI theo phông gốc',False),
            ('table','Căn giữa theo chiều dọc trong ô bảng',False),
            ('page_numbers','Chèn số trang từ trang 2 khi phù hợp',False)]:
            opts[key]=st.checkbox(label,value=default,key=prefix+key)
    return standard, opts


def profile():
    path=BASE/'pages_data'/'co_quan.json'
    try: saved=json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError): saved={}
    defaults={'parent':'SỞ GIÁO DỤC VÀ ĐÀO TẠO','organization':'TRƯỜNG THPT HỒ THỊ BI','city':'TP. Hồ Chí Minh','role':'HIỆU TRƯỞNG','signer':''}
    labels={'parent':'Cơ quan chủ quản','organization':'Tên đơn vị','city':'Địa danh','role':'Chức danh người ký','signer':'Họ tên người ký (để trống nếu chưa có)'}
    with st.expander('Thông tin cơ quan dùng cho mẫu và thành phần'):
        meta={k:st.text_input(labels[k],str(saved.get(k,defaults[k]))[:200],key='meta_'+k,max_chars=200) for k in defaults}
        a,b=st.columns(2)
        if a.button('Lưu thông tin trên máy'):
            path.parent.mkdir(parents=True,exist_ok=True)
            temp=path.with_suffix('.tmp');temp.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,path)
            st.success('Đã lưu thông tin cơ quan.')
        b.download_button('Tải thông tin JSON',json.dumps(meta,ensure_ascii=False,indent=2).encode(),'Thong_tin_co_quan.json','application/json')
        uploaded=st.file_uploader('Nhập thông tin cơ quan đã lưu',type=['json'],key='meta_import')
        if uploaded and st.button('Áp dụng thông tin đã nhập'):
            try:
                obj=json.loads(uploaded.getvalue())
                if not isinstance(obj,dict): raise ValueError('Cần một đối tượng JSON.')
                # Apply before these widgets are instantiated on the next run.
                st.session_state['pending_meta']={k:str(obj[k])[:200] for k in defaults if k in obj}
                st.rerun()
            except (ValueError,TypeError) as exc: st.error(str(exc))
    return meta


def append_component(original, piece, at_start=False):
    doc, fragment=load(original),load(piece)
    body=doc._element.body
    blocks=[deepcopy(x) for x in fragment._element.body if x.tag.rsplit('}',1)[-1]!='sectPr']
    if at_start:
        for i,block in enumerate(blocks): body.insert(i,block)
    else:
        for block in blocks:
            if body.sectPr is not None: body.sectPr.addprevious(block)
            else: body.append(block)
    out=io.BytesIO();doc.save(out);return out.getvalue()


def render():
    pending=st.session_state.pop('pending_meta',{})
    for k,v in pending.items(): st.session_state['meta_'+k]=v
    st.title('📝 HTB Format Pro trong AI Agent')
    st.caption('Khôi phục từ bản HTB Format Pro v1.1 sửa lỗi bố cục đã gửi ngày 15/10/2026.')
    meta=profile()
    section=st.radio('Chức năng', ['Rà soát và chuẩn hóa','12 mẫu văn bản','14 thành phần','Nguồn đã khôi phục'],horizontal=True)
    if section=='Rà soát và chuẩn hóa':
        standard,options=settings('format_')
        files=st.file_uploader('Chọn 1–12 tệp DOCX, tối đa 15 MB mỗi tệp',type=['docx'],accept_multiple_files=True,key='format_files')
        if len(files)>12: st.error('Chỉ xử lý tối đa 12 tệp/lượt.'); return
        inputs=[(f.name,f.getvalue()) for f in files]
        digest=hashlib.sha256(json.dumps({'sources':[(n,hashlib.sha256(b).hexdigest()) for n,b in inputs],'standard':standard,'options':options},sort_keys=True).encode()).hexdigest()
        a,b=st.columns(2)
        audit_click=a.button('🔎 Rà soát văn bản',disabled=not inputs)
        norm_click=b.button('🛠 Chuẩn hóa bản sao',disabled=not inputs,type='primary')
        if audit_click or norm_click:
            try:
                results=[]
                with st.spinner('Đang xử lý văn bản…'):
                    for name,data in inputs:
                        before=audit(load(data),standard)
                        formatted=normalize(data,standard,options) if norm_click else None
                        after=audit(load(formatted),standard) if formatted else None
                        results.append({'name':name,'before':before,'after':after,'docx':formatted})
                st.session_state['format_result']={'digest':digest,'items':results}
            except Exception as exc:
                st.session_state.pop('format_result',None);st.error(f'Đã dừng xử lý: {exc}')
        result=st.session_state.get('format_result')
        if not result: return
        if result['digest']!=digest: st.info('Nguồn hoặc tùy chọn đã đổi; bấm rà soát / chuẩn hóa lại.'); return
        report=[]; zipout=io.BytesIO()
        with zipfile.ZipFile(zipout,'w',zipfile.ZIP_DEFLATED) as archive:
            for i,item in enumerate(result['items'],1):
                name=item['name']; before=item['before']; after=item['after']
                st.subheader(name)
                a,b,c=st.columns(3)
                a.metric('Đoạn',before['stats']['paragraphs']);b.metric('Bảng',before['stats']['tables']);c.metric('Ghi chú kiểm tra',len(before['issues']))
                if before['issues']: st.dataframe(before['issues'],hide_index=True,width='stretch')
                else: st.success('Không phát hiện lỗi theo bộ kiểm tra hiện có.')
                with st.expander('Xem trước nội dung chữ (không phải trang in)'):
                    st.write('\n\n'.join(p['text'] for p in before['stats']['preview']))
                report.append({'file':name,'before':before,'after':after})
                if item['docx']:
                    filename=f'{i:02d}_'+re.sub(r'[^\w-]','_',Path(name).stem)[:70]+'_CHUAN_HOA.docx'
                    archive.writestr(filename,item['docx'])
                    st.download_button('Tải DOCX đã chuẩn hóa',item['docx'],filename,key='format_dl_'+str(i))
                    if after: st.caption(f'Ghi chú sau chuẩn hóa: {len(after["issues"])}. Không tự sửa toàn bộ lỗi được nêu.')
                    if st.button('Tạo PDF từ bản chuẩn hóa',key='format_pdf_'+str(i)):
                        try: st.session_state['format_pdf']={'digest':digest,'index':i,'data':pdf_convert(item['docx']),'name':filename[:-5]+'.pdf'}
                        except RuntimeError as exc: st.error(str(exc))
            audit_json=json.dumps(report,ensure_ascii=False,indent=2).encode()
            archive.writestr('BAO_CAO_KIEM_TRA.json',audit_json)
        st.download_button('Tải kết quả rà soát JSON',audit_json,'BAO_CAO_KIEM_TRA.json','application/json')
        if any(x['docx'] for x in result['items']): st.download_button('Tải trọn bộ chuẩn hóa ZIP',zipout.getvalue(),'HTB_Format_Batch.zip','application/zip')
        pdf=st.session_state.get('format_pdf')
        if pdf and pdf['digest']==digest: st.download_button('⬇ Tải PDF vừa tạo',pdf['data'],pdf['name'],'application/pdf')
        st.caption('Gợi ý chính tả chỉ bao gồm một số từ trong bộ quy tắc cũ; chưa có bộ từ điển đầy đủ. Không tự đổi các từ này.')
    elif section=='12 mẫu văn bản':
        policy=st.selectbox('Loại thể thức',['admin','party'],format_func=reference_label,key='template_policy')
        kind=st.selectbox('Mẫu văn bản',list(TEMPLATE_TYPES),format_func=lambda x:TEMPLATE_TYPES[x][0],key='template_kind')
        st.caption('Mẫu khung để điền nội dung, không tự cấp số văn bản hoặc tạo chữ ký.')
        if st.button('Tạo mẫu văn bản',type='primary'):
            try:
                data=template_docx(kind,policy,meta)
                st.session_state['made_template']={'data':data,'kind':kind,'policy':policy,'meta':meta}
            except Exception as exc:st.error(str(exc))
        result=st.session_state.get('made_template')
        if result and result['kind']==kind and result['policy']==policy and result['meta']==meta:
            st.download_button('Tải mẫu DOCX',result['data'],f'MAU_{kind}_{policy}.docx')
    elif section=='14 thành phần':
        policy=st.selectbox('Loại thể thức',['admin','party'],format_func=reference_label,key='component_policy')
        key=st.selectbox('Thành phần',dict(COMPONENTS),format_func=lambda x:dict(COMPONENTS)[x],key='component_key')
        target=st.file_uploader('DOCX cần chèn thành phần (tùy chọn)',type=['docx'],key='component_target')
        position=st.radio('Vị trí chèn',['Cuối văn bản','Đầu văn bản'],horizontal=True)
        target_bytes=target.getvalue() if target else None
        digest=hashlib.sha256(json.dumps([key,policy,meta,position],ensure_ascii=False).encode()+(target_bytes or b'')).hexdigest()
        if st.button('Tạo / chèn thành phần',type='primary'):
            try:
                data=component_docx(key,policy,meta)
                if target_bytes:data=append_component(target_bytes,data,position=='Đầu văn bản')
                st.session_state['component_result']={'digest':digest,'data':data}
            except Exception as exc:st.error(str(exc))
        result=st.session_state.get('component_result')
        if result and result['digest']==digest:st.download_button('Tải DOCX kết quả',result['data'],'VAN_BAN_CHEN_THANH_PHAN.docx' if target else f'THANH_PHAN_{key}.docx')
    else:
        st.write('Bản nguồn: HTB_Format_Pro_v1_1_Ban_Sua_Loi.zip — ngày 15/10/2026.')
        st.write('Tích hợp đầy đủ các chức năng đã có trong bộ HTB Format Pro: rà soát, chuẩn hóa, chuyển mã theo phông, xử lý hàng loạt, 12 mẫu, 14 thành phần, thông tin cơ quan và PDF qua LibreOffice.')
        st.write('Thư mục format_pro giữ mã nguồn và giao diện cũ. Chạy MO_FORMAT_GOC.bat để mở riêng giao diện cũ tại cổng 8765.')
        st.info('Đây là phần mềm HTB đã xây dựng độc lập trước đó. Không phải mã nguồn V-FORMAT thương mại, chưa có add-in Word và không được coi là bản tương đương toàn bộ V-FORMAT.')
