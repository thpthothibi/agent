@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run CAI_DAT.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" chan_doan_pdf.py
pause
