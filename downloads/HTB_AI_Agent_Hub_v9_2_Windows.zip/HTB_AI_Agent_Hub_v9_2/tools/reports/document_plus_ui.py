import io,json,hashlib
import streamlit as st
from document_plus import repair_unicode,merge_documents,make_variable_template,render_variable_template
from format_pro.app.engine import normalize,pdf_convert


def render():
    st.title('🔧 Chuẩn hóa văn bản mở rộng')
    st.caption('Bổ sung ftfy, docxtpl và docxcompose vào bộ HTB Format Pro. Chạy cục bộ, không cần API.')
    mode=st.radio('Công cụ mở rộng',['Sửa Unicode có đối chiếu','Ghép nhiều tài liệu Word','Mẫu Word có biến'],horizontal=True)
    if mode=='Sửa Unicode có đối chiếu':
        f=st.file_uploader('Tài liệu DOCX cần kiểm tra chữ',type=['docx'],key='plus_unicode')
        if not f:return
        try:
            result,changes=repair_unicode(f.getvalue())
            st.info('Chỉ sửa lỗi mã hóa / tổ hợp Unicode. Không phải công cụ sửa mọi lỗi chính tả hoặc ngữ pháp tiếng Việt.')
            if changes:st.dataframe(changes,hide_index=True,width='stretch')
            else:st.success('Không có thay đổi Unicode được đề xuất.')
            if st.checkbox('Áp dụng các thay đổi đã đối chiếu',value=False):
                st.download_button('Tải bản đã sửa Unicode',result,'Van_ban_sua_Unicode.docx')
            st.download_button('Tải danh sách thay đổi JSON',json.dumps(changes,ensure_ascii=False,indent=2).encode(),'Thay_doi_Unicode.json','application/json')
        except Exception as exc:st.error(str(exc))
    elif mode=='Ghép nhiều tài liệu Word':
        files=st.file_uploader('Chọn 2–12 DOCX',type=['docx'],accept_multiple_files=True,key='plus_merge')
        if not 2<=len(files)<=12:st.info('Chọn từ 2 đến 12 tài liệu.');return
        entries=[f'{i+1:02d} · {f.name}' for i,f in enumerate(files)]
        order=st.multiselect('Thứ tự ghép (bỏ chọn rồi chọn lại để đổi thứ tự)',entries,default=entries)
        if len(order)<2:return
        pagebreaks=st.checkbox('Mỗi tài liệu bắt đầu ở trang mới',value=True)
        normalize_out=st.checkbox('Chuẩn hóa bản ghép bằng HTB Format Pro',value=False)
        accepted=st.checkbox('Dùng đầu trang/chân trang của tệp đầu cho bản ghép (đặc tính của docxcompose)',value=False)
        signature=hashlib.sha256(json.dumps([order,pagebreaks,normalize_out]).encode()+b''.join(f.getvalue() for f in files)).hexdigest()
        if st.button('Ghép các tài liệu',type='primary',disabled=not accepted):
            try:
                data=merge_documents([files[entries.index(n)].getvalue() for n in order],pagebreaks)
                if normalize_out:data=normalize(data,'auto',{'safe_layout':True})
                st.session_state['plus_merged']={'signature':signature,'data':data}
            except Exception as exc:st.error(str(exc))
        result=st.session_state.get('plus_merged')
        if accepted and result and result['signature']==signature:st.download_button('Tải Word đã ghép',result['data'],'Tai_lieu_ghep.docx')
    else:
        st.write('Đặt các biến trong mẫu Word để agent điền nội dung tại đúng vị trí:')
        st.code('{{ tieu_de }}\n{{ don_vi }}\n{{ ky_bao_cao }}\n{{ noi_dung }}\n{{ so_nguon }}\n{{ kiem_tra }}\n{{ nguon }}\n{{ bang }}\n{{p bang_word }}')
        st.caption('Biến dong là danh sách tối đa 500 dòng tổng hợp; dùng cú pháp vòng lặp docxtpl nếu cần bảng tùy biến. Mẫu thiếu biến được báo lỗi, không âm thầm bỏ trống.')
        if st.button('Chuẩn bị mẫu Word có biến'):
            st.session_state['plus_template']=make_variable_template()
        if 'plus_template' in st.session_state:st.download_button('Tải mẫu Word có biến',st.session_state['plus_template'],'Mau_bao_cao_co_bien.docx')
        st.info('Dùng mẫu này ở mục Tổng hợp nhiều nguồn → Mẫu Word có biến. Các mẫu cũ không có dấu {{ ... }} chưa tự điền vào ô bất kỳ.')
