# HTB AI Agent báo cáo v4 tích hợp bộ công cụ PDF

Bản v4 giữ các chức năng báo cáo, tổng hợp nhiều nguồn và chuẩn hóa văn bản của v3; thêm mục Công cụ PDF. Các tính năng PDF chạy tại máy, không cần khóa API và không tải tài liệu lên dịch vụ chuyển đổi bên ngoài.

## Cài và chạy

1. Cài Python 3.12 hoặc 3.11 cho Windows, bật Add Python to PATH.
2. Giải nén toàn bộ vào thư mục mới có quyền ghi, ví dụ D:\HTB_Agent_v4.
3. Bấm CAI_DAT.bat một lần để tạo môi trường và cài thư viện; cần Internet lần đầu. Bộ cài ưu tiên Python 3.12 rồi 3.11.
4. Bấm CHAY_AGENT.bat. Mở http://127.0.0.1:8501 nếu trình duyệt chưa tự mở.
5. Chọn Công cụ PDF ở thanh bên trái.

Chạy KIEM_TRA_MAY.bat nếu cần kiểm tra thư viện, LibreOffice và ngôn ngữ OCR. Kết quả lưu trong CHAN_DOAN_PDF.txt, không chứa mật khẩu tài liệu.

Phần lớn công cụ PDF dùng ngay sau khi cài thư viện. Riêng Office → PDF cần LibreOffice; OCR cần chương trình Tesseract và gói ngôn ngữ. Xem HUONG_DAN_PDF.md để cài thêm và hiểu rõ từng công cụ.

## Những tính năng thêm

| Nhóm | Chức năng |
|---|---|
| Chuyển đổi | PDF → Word sửa được chữ/bảng, Word chữ đơn giản hoặc Word dạng ảnh; PDF → Excel, PNG/JPG ZIP, TXT |
| Chuyển ngược | Ảnh JPG/PNG → PDF; DOCX/XLSX/PPTX → PDF bằng LibreOffice |
| Cắt ráp trang | Ghép nhiều PDF, tách nhiều nhóm, trích trang, xóa trang, đổi thứ tự, đảo trang, xoay, cắt lề hiển thị |
| Nén | Nén nội dung giữ lớp chữ, giảm chất lượng ảnh, nén mạnh bằng ảnh toàn trang |
| Hoàn thiện | Đánh số trang, watermark tiếng Việt, đặt mật khẩu AES, gỡ mật khẩu đã biết |
| OCR | PDF quét → Word chữ, TXT hoặc PDF có lớp chữ tìm kiếm, cần Tesseract |
| Liên kết báo cáo | Đưa Word/Excel/TXT vừa chuyển vào mục Tổng hợp nhiều nguồn, giữ thông tin PDF gốc |

Bật Dùng PDF minh họa 3 trang để chạy thử: trang 1 có chữ/bảng; trang 2 ngang có ảnh; trang 3 là ảnh quét tiếng Anh. Dữ liệu hoàn toàn giả, không dùng làm hồ sơ thực.

## Dùng cùng báo cáo nhiều nguồn

Sau chuyển PDF sang Word/Excel/TXT, bấm Đưa kết quả vào báo cáo nhiều nguồn. Agent chuyển sang mục tổng hợp và giữ tệp chuyển đổi trong phiên. Có thể thêm các nguồn khác để nối hoặc ghép dữ liệu.

Excel trích PDF có các sheet bảng, văn bản theo trang và danh mục. Agent mặc định chỉ chọn sheet Trang_x_Bang_y khi nhận từ nút liên kết để tránh đếm trùng. Nếu không tìm thấy bảng, cần rà soát hoặc đổi cách nhận diện, không coi phần văn bản là bảng số liệu. Danh mục nguồn Excel ghi tên/SHA256 PDF gốc, công cụ chuyển và trang đã chọn; liên kết dòng vẫn chỉ đến bảng chuyển đổi để đối chiếu với PDF.

Các kết quả được giữ trong phiên, không tự lưu xuống ổ đĩa. Bấm tải trước khi đóng. Các công cụ luôn tạo bản sao, không ghi đè file gốc.

## Lưu ý khi dùng

Bố cục PDF phức tạp, font nhúng, bảng gộp ô hoặc ảnh mờ cần kiểm tra sau chuyển đổi. Nén mạnh bằng ảnh làm mất lớp chữ và thành phần tương tác; giao diện yêu cầu chọn rõ chế độ. Cắt lề chỉ thay vùng hiển thị, không xóa hẳn dữ liệu ngoài vùng cắt. Tài liệu đã ký số cần giữ bản gốc để đối chiếu vì thay đổi có thể làm mất hiệu lực chữ ký.

Tổng hợp dữ liệu và phần AI giữ cơ chế v3. Xem HUONG_DAN_V3.md và HUONG_DAN_V2.md. OCR tiếng Việt chỉ hoạt động phù hợp khi máy có gói vie; kiểm tra tên và số sau OCR. Bản đã thử trên Linux/Python 3.12; chưa chạy BAT trực tiếp trên Windows. Xem KIEM_TRA.txt.
