import io,json,zipfile,unittest
from pathlib import Path
from pypdf import PdfReader
from docx import Document
from PIL import Image
from pdf_tools import *

SAMPLE=Path(__file__).parent/'mau'/'PDF_minh_hoa_3_trang.pdf'

class PDFToolsTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.data=SAMPLE.read_bytes()
 def test_page_parser_limits_and_reverse(self):
  self.assertEqual(page_numbers('3,1-2',3),[2,0,1]);self.assertEqual(page_numbers('3-1',3),[2,1,0])
  self.assertEqual(page_numbers('',3),[0,1,2])
  for bad in ('0','4','1-1000000000','1,','-1'):
   with self.assertRaises(ValueError):page_numbers(bad,3)
 def test_inspection_scan_and_preview(self):
  info=inspect_pdf(self.data)
  self.assertEqual(len(info['pages']),3);self.assertEqual(info['pages'][2]['Ký tự đọc được'],0)
  self.assertTrue(preview(self.data,0).startswith(b'\x89PNG'))
 def test_merge_split_selection_delete(self):
  first=select_pages(self.data,'2,1');r=open_pdf(first)
  self.assertGreater(float(r.pages[0].mediabox.width),float(r.pages[0].mediabox.height))
  blob,manifest=merge_pdfs([('A',self.data,'','1'),('B',self.data,'','2-3')])
  self.assertEqual(len(open_pdf(blob).pages),3);self.assertEqual(manifest[1]['start'],2)
  z=zipfile.ZipFile(io.BytesIO(split_pdf(self.data,'1;2-3')))
  self.assertEqual(len(open_pdf(z.read('Phan_002.pdf')).pages),2)
  self.assertEqual(len(open_pdf(delete_pages(self.data,'2')).pages),2)
  with self.assertRaises(ValueError):delete_pages(self.data,'1-3')
 def test_rotation_crop_and_text(self):
  self.assertEqual(open_pdf(rotate_pdf(self.data,'1',90)).pages[0].rotation,90)
  result=open_pdf(crop_pdf(self.data,'1',left_mm=10))
  self.assertGreater(float(result.pages[0].cropbox.left),28)
  self.assertAlmostEqual(float(result.pages[1].cropbox.left),0)
  with self.assertRaises(ValueError):crop_pdf(self.data,'1',left_mm=1000)
  texts,blank=extract_text(self.data);self.assertEqual(blank,[3]);self.assertIn('MINH HỌA',texts[0]['text'])
 def test_lossless_and_image_compression(self):
  blob,report=compress_pdf(self.data)
  self.assertLessEqual(len(blob),len(self.data));self.assertEqual(len(open_pdf(blob).pages),3)
  self.assertIn('MINH HỌA',extract_text(blob,'1')[0][0]['text'])
  blob,report=compress_pdf(self.data,'images',quality=45)
  self.assertLessEqual(len(blob),len(self.data));self.assertEqual(len(open_pdf(blob).pages),3)
 def test_raster_compression(self):
  blob,report=compress_pdf(self.data,'raster',quality=40,dpi=72)
  self.assertLessEqual(len(blob),len(self.data));self.assertEqual(len(open_pdf(blob).pages),3)
  if report['saved_percent']>0:self.assertEqual(extract_text(blob,'1')[1],[1])
 def test_password_roundtrip(self):
  encrypted=set_password(self.data,'TestPassword123')
  with self.assertRaises(ValueError):open_pdf(encrypted,'wrong')
  self.assertEqual(len(open_pdf(encrypted,'TestPassword123').pages),3)
  clear=set_password(encrypted,password='TestPassword123',remove=True)
  self.assertFalse(PdfReader(io.BytesIO(clear)).is_encrypted)
 def test_excel_tables(self):
  from openpyxl import load_workbook
  data,report=pdf_to_excel(self.data,'1')
  self.assertGreaterEqual(report['tables'],1)
  workbook=load_workbook(io.BytesIO(data));self.assertIn('Danh_muc_bang',workbook.sheetnames)
  self.assertEqual(workbook['Trang_1_Bang_1']['D2'].value,'7,5')
  _,report=pdf_to_excel(self.data,'3');self.assertEqual(report['tables'],0)
 def test_word_text_image_and_scan_block(self):
  blob,_=pdf_to_word(self.data,'1',mode='text')
  self.assertIn('MINH HỌA','\n'.join(p.text for p in Document(io.BytesIO(blob)).paragraphs))
  blob,_=pdf_to_word(self.data,'2',mode='image',dpi=72)
  doc=Document(io.BytesIO(blob));self.assertEqual(len(doc.inline_shapes),1)
  with self.assertRaises(ValueError):pdf_to_word(self.data,'3',mode='text')
 def test_word_layout_converter(self):
  blob,_=pdf_to_word(self.data,'1',mode='layout')
  doc=Document(io.BytesIO(blob));self.assertTrue(doc.tables)
  self.assertIn('7,5',' '.join(c.text for t in doc.tables for row in t.rows for c in row.cells))
 def test_images_exports_and_watermark(self):
  imagezip=pdf_to_images(self.data,'2',fmt='JPEG',dpi=72)
  z=zipfile.ZipFile(io.BytesIO(imagezip));self.assertEqual(len(z.namelist()),1)
  img=z.read(z.namelist()[0]);blob=images_to_pdf([('image.jpg',img)])
  self.assertEqual(len(open_pdf(blob).pages),1)
  stamped=stamp_pdf(self.data,'1',text='DỰ THẢO',numbers=True)
  self.assertIn('DỰ THẢO',extract_text(stamped,'1')[0][0]['text'])
 def test_form_names_and_office_conversion(self):
  from reportlab.pdfgen import canvas
  items=[]
  for value in ('Alpha','Beta'):
   out=io.BytesIO();c=canvas.Canvas(out)
   c.acroForm.textfield(name='student',value=value,x=50,y=700,width=180,height=25)
   c.showPage();c.save();items.append((value,out.getvalue(),'',''))
  merged,_=merge_pdfs(items);reader=open_pdf(merged);fields=reader.get_fields()
  self.assertEqual(fields['Nguon_1.student']['/V'],'Alpha')
  self.assertEqual(fields['Nguon_2.student']['/V'],'Beta')
  for page,expected in zip(reader.pages,('Alpha','Beta')):
   annotation=page['/Annots'][0].get_object()
   self.assertEqual(annotation.get('/V',annotation.get('/Parent',{}).get('/V')),expected)
  from openpyxl import Workbook
  workbook=Workbook();ws=workbook.active;ws.append(['Class','Count']);ws.append(['10A01',4])
  out=io.BytesIO();workbook.save(out)
  pdf=office_to_pdf('test.xlsx',out.getvalue())
  self.assertTrue(pdf.startswith(b'%PDF-'));self.assertIn('10A01',extract_text(pdf)[0][0]['text'])
 def test_ocr_english_and_searchable_pdf(self):
  status=ocr_status()
  if not status['available'] or 'eng' not in status['languages']:self.skipTest('Tesseract English unavailable')
  blob=ocr_pdf(self.data,'3',language='eng',output='txt',dpi=130)
  self.assertIn('Total records',blob.decode('utf-8-sig'))
  blob=ocr_pdf(self.data,'3',language='eng',output='pdf',dpi=130)
  text=extract_text(blob)[0][0]['text'];self.assertIn('Total',text)

if __name__=='__main__':unittest.main()
