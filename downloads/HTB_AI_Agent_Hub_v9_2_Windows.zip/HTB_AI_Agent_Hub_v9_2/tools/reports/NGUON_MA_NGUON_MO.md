# Các thành phần được tìm thêm và đã tích hợp

| Thành phần | Chức năng tích hợp | Bản đã thử | Giấy phép | Nguồn chính thức |
|---|---|---|---|---|
| docxtpl | Điền biến trong mẫu Word, chèn bảng Word dưới dạng subdocument | 0.20.2 | LGPL-2.1-only | https://github.com/elapouya/python-docx-template ; https://docxtpl.readthedocs.io/ |
| docxcompose | Ghép Word có quản lý tài nguyên và hình ảnh | 2.2.0 | MIT | https://github.com/4teamwork/docxcompose |
| pdfplumber | Trích bảng có đường kẻ và chữ từ PDF tạo bằng máy | 0.11.9 | MIT | https://github.com/jsvine/pdfplumber |
| ftfy | Sửa một số lỗi Unicode/mã hóa, giữ dạng NFC | 6.3.1 | Apache-2.0 | https://ftfy.readthedocs.io/ ; https://github.com/rspeer/python-ftfy |
| RapidFuzz | Gợi ý tên cột gần giống để người dùng duyệt | 3.14.6 | MIT | https://github.com/rapidfuzz/RapidFuzz |
| Jinja2 | Môi trường biến mẫu giới hạn, báo biến thiếu và escape XML | 3.1.6 | BSD-3-Clause | https://jinja.palletsprojects.com/ |

Thư viện được liên kết/cài thành phụ thuộc riêng; không chép mã của chúng vào mã nguồn HTB. Các bản giấy phép lấy từ gói đã cài được giữ trong third_party_notices. requirements.txt quy định khoảng phiên bản tương thích, vì vậy khi cài lần sau có thể nhận bản vá mới hơn bản đã thử. Có thể cố định các phiên bản ở bảng này khi muốn tái lập chính xác môi trường thử.

Underthesea đã được khảo sát cho chuẩn hóa tiếng Việt nhưng chưa tích hợp trong v3; không cần tải bộ NLP lớn để sử dụng bản này. Không quảng bá ftfy như công cụ sửa chính tả/ngữ pháp hoàn chỉnh.

Bộ HTB Format Pro khôi phục từ ngày 15/10 được giữ lại. Toàn bộ phần tích hợp mới là lớp kết nối các thư viện trên với luồng báo cáo nhiều nguồn, không phải phần mềm V-FORMAT thương mại.

## Bổ sung ở v4

| Thành phần | Tích hợp | Nguồn |
|---|---|---|
| pypdf | Chọn/ghép/tách/xoay/cắt, nén nội dung, mật khẩu AES | https://pypdf.readthedocs.io/ |
| pdf2docx | Chuyển PDF có chữ/bảng sang DOCX | https://github.com/ArtifexSoftware/pdf2docx |
| PyMuPDF | Phụ thuộc của pdf2docx | https://pymupdf.readthedocs.io/ |
| pypdfium2 | Xem trước và dựng ảnh trang PDF, khóa dùng chung cho PDFium | https://pypdfium2.readthedocs.io/ |
| pytesseract / Tesseract | Kết nối OCR cục bộ, Tesseract và model ngôn ngữ cài riêng | https://github.com/madmaze/pytesseract ; https://tesseract-ocr.github.io/tessdoc/ |
| ReportLab / Pillow | Ảnh thành PDF, watermark/số trang, xử lý ảnh | https://docs.reportlab.com/ ; https://pillow.readthedocs.io/ |

Giấy phép và phiên bản đã kiểm tra ghi trong third_party_notices/VERSIONS.json và các tệp license đi kèm. pdf2docx được cấp MIT; PyMuPDF là phụ thuộc có giấy phép AGPL/commercial riêng. Bộ mã HTB không sao chép mã thư viện hoặc đóng gói binary của chúng; requirements cài các thư viện riêng từ pip. Tesseract/LibreOffice không nằm trong ZIP và cần cài riêng cho những tính năng tương ứng.
