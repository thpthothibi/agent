"""Document adapters: Unicode repair, safe variable templates and composition."""
import io,json,unicodedata
from copy import deepcopy
from pathlib import Path
from docx import Document
from format_pro.app.engine import load,validate_docx,iter_paragraphs,template_docx


def repair_unicode(blob, apply=True):
    from ftfy import fix_text
    doc=load(blob);changes=[];seen=set()
    containers=[('Thân văn bản',doc)]
    for i,s in enumerate(doc.sections,1):
        containers.extend([(f'Đầu trang phần {i}',s.header),(f'Chân trang phần {i}',s.footer)])
    for location,container in containers:
        for pi,p in enumerate(iter_paragraphs(container),1):
            if p._p in seen:continue
            seen.add(p._p)
            for ri,run in enumerate(p.runs,1):
                if run._element.xpath('.//w:drawing|.//w:pict|.//w:object|.//w:instrText|.//w:fldChar'):continue
                before=run.text
                after=fix_text(before,normalization='NFC',unescape_html=False,uncurl_quotes=False,fix_latin_ligatures=False,fix_character_width=False)
                if before!=after:
                    changes.append({'Vị trí':location,'Đoạn':pi,'Đoạn chữ':ri,'Trước':before,'Sau':after})
                    if apply:run.text=after
    out=io.BytesIO();doc.save(out);return out.getvalue(),changes


def merge_documents(blobs, page_breaks=True):
    from docxcompose.composer import Composer
    if not 2<=len(blobs)<=12:raise ValueError('Chọn 2–12 DOCX để ghép.')
    master=load(blobs[0]);composer=Composer(master)
    for blob in blobs[1:]:
        other=load(blob)
        if page_breaks:master.add_page_break()
        composer.append(other)
    out=io.BytesIO();composer.save(out);return out.getvalue()


def render_variable_template(blob,context):
    from docxtpl import DocxTemplate
    from jinja2.sandbox import SandboxedEnvironment
    from jinja2 import StrictUndefined
    validate_docx(blob)
    doc=DocxTemplate(io.BytesIO(blob))
    env=SandboxedEnvironment(undefined=StrictUndefined,autoescape=True)
    env.globals.clear()
    context=dict(context)
    for name in ('noi_dung','nguon','kiem_tra'):
        if isinstance(context.get(name),str):context[name]=context[name].replace('\n','\a')
    if 'dong' in context:
        from core import style_result_table,format_value
        sub=doc.new_subdoc()
        records=context['dong']
        if records:
            columns=list(records[0])[:8]
            table=sub.add_table(rows=1,cols=len(columns))
            table.style='Table Grid'
            for cell,name in zip(table.rows[0].cells,columns):cell.text=str(name)
            for record in records:
                for cell,name in zip(table.add_row().cells,columns):cell.text=format_value(record.get(name))
            style_result_table(table)
            if len(records[0])>8:sub.add_paragraph('Xem đầy đủ các cột trong Excel.')
        else:sub.add_paragraph('Không có bảng số liệu.')
        context['bang_word']=sub
    required=doc.get_undeclared_template_variables(jinja_env=env)
    missing=required-set(context)
    if missing:raise ValueError('Mẫu dùng biến chưa có dữ liệu: '+', '.join(sorted(missing)))
    doc.render(context,jinja_env=env,autoescape=True)
    out=io.BytesIO();doc.save(out);return out.getvalue()


def template_context(title,unit,period,text,summary,issues,sources):
    records=json.loads(summary.head(500).to_json(orient='records',force_ascii=False))
    return {'tieu_de':title,'don_vi':unit,'ky_bao_cao':period,'noi_dung':text,
            'so_nguon':len(sources),'kiem_tra':'\n'.join(issues),'nguon':'\n'.join(f'{s.get("id","")} {s["name"]}' for s in sources),
            'bang':summary.head(500).to_string(index=False), 'dong':records}


def make_variable_template():
    doc=Document(io.BytesIO(template_docx('bao-cao','admin',{'organization':'{{ don_vi }}'})))
    for p in iter_paragraphs(doc):
        for r in p.runs:
            if '{{ DON_VI }}' in r.text:r.text=r.text.replace('{{ DON_VI }}','{{ don_vi }}')
    for p in list(doc.paragraphs):
        if p.text=='[Nội dung báo cáo]':p.runs[0].text='{{ tieu_de }}'
        elif p.text=='[Nhập nội dung chi tiết của văn bản tại đây.]':
            p.runs[0].text='{{ noi_dung }}'
            label=doc.add_paragraph('Kỳ báo cáo: {{ ky_bao_cao }}')
            p._p.addprevious(label._p)
        elif p.text=='[Nội dung mục 1.]':p.runs[0].text='{{p bang_word }}'
        elif p.text=='[Nội dung mục 2.]':p.runs[0].text='Nguồn: {{ nguon }}'
    out=io.BytesIO();doc.save(out);return out.getvalue()
