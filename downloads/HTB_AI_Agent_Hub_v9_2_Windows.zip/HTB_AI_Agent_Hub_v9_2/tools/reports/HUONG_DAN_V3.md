# HTB AI Agent báo cáo v3

Bản này giữ nguyên các công cụ đã tích hợp ở v2 và thêm Tổng hợp nhiều nguồn cùng Chuẩn hóa mở rộng. Xem HUONG_DAN_V2.md cho tính năng cũ; tài liệu này mô tả luồng mới.

## Cài và chạy

1. Cài Python 3.11 hoặc 3.12 từ https://www.python.org/downloads/ và bật Add Python to PATH.
2. Giải nén vào thư mục có quyền ghi, ví dụ D:\HTB_Agent_v3. Không chạy trong ZIP.
3. Chạy CAI_DAT.bat để cài các thư viện, cần Internet lần đầu. Khi nâng từ v2, dùng thư mục v3 riêng và chạy cài đặt lại vì có thư viện mới.
4. Chạy CHAY_AGENT.bat, mở http://127.0.0.1:8501 nếu cần.
5. Giữ cửa sổ lệnh trong lúc dùng. Đóng để dừng ứng dụng.

PDF cần LibreOffice. Bản Windows tự tìm trong PATH hoặc Program Files. Có thể xuất PDF từ Word khi chưa cài LibreOffice. Toàn bộ tính toán và công cụ định dạng chạy cục bộ không cần API; phần AI chỉ hoạt động khi có model Ollama hoặc khóa API và cho phép gửi dữ liệu.

## Bốn mục làm việc

- Agent báo cáo: giữ luồng đơn giản của v2.
- Tổng hợp nhiều nguồn: nối/ghép, truy nguồn, so khác biệt, viết báo cáo chung và điền mẫu.
- HTB Format Pro: 12 mẫu, 14 thành phần, rà soát, chuẩn hóa, chuyển mã theo phông, xử lý hàng loạt như v2.
- Chuẩn hóa mở rộng: sửa Unicode có đối chiếu, ghép Word và tạo mẫu Word có biến.

## Tổng hợp nhiều nguồn

Chọn XLSX/CSV/JSON/DOCX/PDF/TXT, tối đa 30 tệp, tổng 50 MB, 200.000 dòng. Không dùng hai tệp có cùng tên. Các tệp đang được chọn trên máy là nguồn; chưa tự đăng nhập website hoặc đọc Drive/database.

Có bộ dữ liệu minh họa trong mau_da_nguon gồm 2 CSV khác cách đặt tên cột và 1 văn bản biên bản giả định. Bật thử dữ liệu, chọn Nhóm báo cáo = Tổ, Số tiết và Số hồ sơ, Tổng, rồi tạo báo cáo. Kết quả Toán 35 tiết/7 hồ sơ và Ngữ văn 37/9; không sử dụng làm số liệu thật.

### 1 Kiểm tra bảng và ánh xạ

Xem từng bảng, đổi Tên chuẩn để các nguồn dùng chung tên cột; để trống để bỏ cột. Ví dụ Họ và tên → Họ tên; Class → Lớp. Các tên phổ biến có gợi ý sẵn và hiển thị để duyệt; gợi ý gần giống từ RapidFuzz không tự áp dụng. Hai cột cùng ánh xạ về một tên sẽ bị chặn.

Excel đọc các sheet có dữ liệu. JSON phải là mảng đối tượng; trường lồng được làm phẳng, mảng con giữ dạng chuỗi JSON. Nếu bật Word/PDF thì agent đọc thêm bảng: Word dùng các bảng trong thân văn bản; PDF dùng bộ nhận diện bảng có đường kẻ của pdfplumber. Dòng tiêu đề dùng chung cho các bảng trong lượt; bảng có tiêu đề ở các dòng khác nhau nên tách lượt hoặc sửa tệp trước.

Bảng PDF phức tạp, ô gộp hoặc nhiều dòng tiêu đề cần đối chiếu và chỉnh nguồn trước khi dùng. Không có OCR. Trang PDF không đọc được chữ sẽ được báo, có thể là trang trắng hoặc ảnh. Có xác nhận rõ nếu tiếp tục với phần chữ bị thiếu. Nội dung tệp bị lỗi sẽ chặn tạo báo cáo.

### 2 Nối hoặc ghép

Nối dòng: dùng cho dữ liệu cùng nghiệp vụ từ nhiều tổ, lớp, đợt; cột chưa có ở một nguồn để trống. Không tự hiểu hai loại chỉ tiêu là một.

Ghép khóa: mỗi lượt chọn đúng 2 bảng, chọn khóa đầy đủ như Họ tên + Lớp hoặc mã hồ sơ. Dùng ghép một–một; khóa trống hoặc trùng bị chặn để tránh nhân đôi kết quả. Giữ cả dòng chưa khớp. So khóa bằng Unicode NFC, bỏ khoảng trắng thừa và không phân biệt hoa/thường; giữ dấu tiếng Việt, không tự ghép tên gần giống. Thay đổi khóa hoặc sửa nguồn khi có nhiều lần ghi cho cùng một người.

Các cột trùng tên ở nguồn 2 có hậu tố [Nguồn 2], gồm cả khóa gốc để đối chiếu. Nếu hai giá trị cùng có nhưng khác nhau, bảng Xung_dot ghi lại. Không tự chọn nguồn nào đúng. Số 7 và chuỗi 7,0 có thể được nêu là khác vì kiểm tra bảo thủ; cần rà soát theo đơn vị/kiểu số. Trạng thái both/left_only/right_only cho biết mức khớp.

Bộ tổng hợp không tự cộng hai cột điểm để ra điểm cuối; muốn tổng hợp một cột phải chọn đúng cột. Không tự quy đổi tiết, phút, giờ hoặc định mức nhân lực.

### 3 Tính và truy nguồn

Chọn phạm vi ngày nếu cần; nhãn kỳ không tự lọc dữ liệu. Chọn nhóm, cột số, phép tổng/trung bình/min/max. Quy tắc số VN và Quốc tế áp dụng cho ô văn bản, số Excel giữ gốc. Không cộng mã/SBD/SĐT. Số dòng là số bản ghi, không mặc định là số người. Giá trị thiếu không thay bằng 0. Bỏ trùng chỉ khi bạn chọn khóa và bật bỏ trùng.

Kết quả có Mã nguồn. Excel gồm Tong_hop, Du_lieu, Kiem_tra, Nguon, Lien_ket_nguon, Xung_dot, Cau_hinh. Sheet Lien_ket_nguon chỉ tệp/vị trí/dòng nguồn theo nhóm. Danh mục nguồn có SHA256. Các dòng thiếu số vẫn được liệt kê trong nhóm và cảnh báo; hãy xem Du_lieu để biết số nào được dùng trong phép tính. Cau_hinh chia JSON thành nhiều phần khi dài; tải riêng cấu hình JSON là cách thuận tiện để dùng lại.

Lưu cấu hình rồi nạp lại để giữ ánh xạ, nhóm/cột số, phép tính, kiểu số, cách ghép và khóa. Chỉ nạp khi tên nguồn và cấu trúc cột khớp; khác cấu trúc bị chặn. Dữ liệu trong các tệp có thể thay đổi nếu cấu trúc vẫn giống. Bộ lọc ngày được chọn lại cho từng kỳ, không tự lưu trong cấu hình.

### 4 Nội dung báo cáo

Không AI: tạo báo cáo theo quy tắc, kèm trích đoạn tài liệu tham khảo. Không tự viết kết luận nghiệp vụ mà dữ liệu không chứng minh.

Ollama/OpenAI API/Gemini API: nhập model, khóa tương ứng nếu cần. API chỉ được gọi sau khi cho phép. Gửi bảng tổng hợp, danh mục nguồn và văn bản đã hiển thị ở phần bằng chứng; không gửi bảng dòng gốc. Tên nhóm vẫn có thể là dữ liệu cá nhân.

Phần văn bản đưa vào AI giới hạn 60.000 ký tự, chia ngân sách theo nguồn và đọc từ đầu nguồn. Nếu vượt, hiển thị mã nguồn chỉ đọc một phần. Đây không phải công cụ bảo đảm đọc hiểu toàn văn tài liệu dài. Tổng yêu cầu vượt 120.000 ký tự bị chặn. Các mã nguồn trong nhận xét AI được kiểm tra có tồn tại, nhưng chưa xác minh từng câu thực sự được nguồn chứng minh; luôn cần người lập báo cáo rà soát. Không tự bịa hoặc hợp thức hóa số liệu thiếu.

## Điền mẫu Word có biến

Có thể dùng mau/Mau_bao_cao_co_bien.docx hoặc tạo lại tại Chuẩn hóa mở rộng → Mẫu Word có biến. Trong mục Tổng hợp nhiều nguồn, chọn mẫu Word để điền đúng vị trí bằng docxtpl. Không chọn mẫu thì dùng khung báo cáo HTB. Chọn thể thức Hành chính hoặc Văn bản Đảng; có thể tắt chuẩn hóa đầu ra để giữ nguyên cách đặt lề của mẫu riêng.

Biến thường dùng:
- {{ tieu_de }}: tên báo cáo.
- {{ don_vi }}: tên đơn vị.
- {{ ky_bao_cao }}: kỳ.
- {{ noi_dung }}: nội dung xem trước đã chỉnh.
- {{ so_nguon }}: số tệp.
- {{ kiem_tra }}: ghi chú chất lượng dữ liệu.
- {{ nguon }}: mã nguồn và tên tệp.
- {{ bang }}: bảng dạng chữ, phù hợp đối chiếu hơn trình bày.
- {{p bang_word }}: bảng Word thật, phải nằm riêng một đoạn. Giới hạn 8 cột và 500 dòng; Excel chứa đầy đủ.
- dong: danh sách tối đa 500 dòng dữ liệu tổng hợp để viết vòng lặp docxtpl tùy biến.

Dùng đúng chữ hoa/thường và khoảng trắng trong biến. Mẫu thiếu biến sẽ báo lỗi. Mẫu có biến hoàn toàn khác cần chỉnh theo danh sách hỗ trợ; agent chưa tự hiểu mọi ô của mọi biểu mẫu. Dữ liệu chứa < > & được escape khi xuất. Không tự tạo số văn bản hoặc chữ ký của người thật.

## Chuẩn hóa mở rộng

Sửa Unicode: ftfy + NFC sửa một số lỗi mã hóa/tổ hợp dấu trong các đoạn chữ, gồm bảng và đầu/chân trang thường. Hiển thị Trước/Sau, chỉ cung cấp bản sửa khi bật áp dụng. Giữ chữ đậm/nghiêng và bỏ qua đoạn chứa hình/field. Tên người vẫn cần đối chiếu. Không có bộ kiểm tra chính tả/ngữ pháp tiếng Việt đầy đủ; không tự đổi cách đặt dấu cũ/mới theo từ điển.

Ghép Word: docxcompose ghép 2–12 tài liệu theo thứ tự đã chọn, có thể thêm ngắt trang. Thư viện dùng đầu/chân trang từ tệp đầu cho bản ghép; các tệp sau không giữ đầu/chân trang riêng. Có xác nhận đặc tính này trước khi ghép. Mặc định không chuẩn hóa lại bố cục ghép; kiểm tra trang in với tài liệu phức tạp.

Các tính năng v3 bổ sung dựa trên thư viện mã nguồn mở, được cài như phụ thuộc qua pip. Không sao chép mã nguồn/bộ cài V-FORMAT thương mại. Bản này chưa có xác nhận tuân thủ toàn bộ quy định văn bản hiện hành.

## Kiểm tra và giới hạn triển khai

Xem KIEM_TRA.txt. Đã kiểm tra chức năng và giao diện trên Linux, chưa chạy trực tiếp tệp BAT trên Windows. AI được kiểm tra bằng phản hồi giả lập, chưa gọi tài khoản thực. Bộ khởi chạy chỉ mở 127.0.0.1; không tự triển khai công khai. Chưa tự chạy lịch, theo dõi thư mục, đăng nhập các nguồn web hay kết nối Drive/database. Kết quả cần bấm tải trước khi đóng phiên.

Danh sách thư viện, phiên bản kiểm tra và giấy phép tại NGUON_MA_NGUON_MO.md và third_party_notices.
