# Sử dụng công cụ PDF trong agent v4

## Chọn trang

Trang đánh số từ 1. Để trống nghĩa là tất cả. Cú pháp ví dụ:

- 1-3,5: trang 1,2,3,5.
- 3,1-2: lấy trang 3 trước rồi đến 1,2.
- 5-1: đảo thứ tự trang 5 về 1.
- Tách file dùng dấu chấm phẩy: 1-2;3;4-6, mỗi nhóm ra một PDF.

Có thể chọn trùng trang để sao chép trang trong bản kết quả. Nguồn tối đa 50 MB và 300 trang. Bản ghép tối đa 300 trang, chọn 2–20 PDF và tổng nguồn không quá 100 MB. Tách tối đa 100 nhóm, tổng trang ở các nhóm không quá 300; tổng dữ liệu các phần không quá 150 MB. Không thể xóa toàn bộ trang.

## PDF sang Word

Word sửa được chữ và bảng sử dụng pdf2docx trong tiến trình riêng, tối đa 180 giây/lượt. Chọn ít trang nếu tệp lớn. Chuyển lại các trang đã chọn thành PDF trung gian để giữ đúng thứ tự lựa chọn. Trang không đọc được chữ được chặn ở chế độ sửa chữ; dùng OCR hoặc Word dạng ảnh.

Chữ đơn giản giữ nội dung có thể sửa nhưng không dựng lại nguyên bảng/bố cục. Word dạng ảnh giữ hình thức mỗi trang và không sửa riêng từng chữ; giới hạn 50 trang/lượt. Công cụ chuyển không thể bảo đảm khôi phục hoàn toàn tài liệu gốc từ mọi PDF. Nên kiểm tra bảng, dấu tiếng Việt, font và xuống trang.

## PDF sang Excel

Chọn nhận diện bảng có đường kẻ hoặc theo vị trí chữ. Mỗi bảng một sheet; có Danh_muc_bang và Van_ban_theo_trang. Có tùy chọn coi dòng đầu mỗi bảng là tiêu đề. Các ô giữ dạng văn bản khi cần để không tự đổi dấu thập phân hoặc mã.

Nếu không tìm thấy bảng, giao diện báo rõ; workbook chỉ chứa văn bản đọc được theo trang và danh mục trống. Đó chưa phải bảng số liệu có thể cộng trực tiếp. PDF quét không tự chuyển thành bảng Excel bằng OCR trong bản này; nhận dạng chữ trước rồi đối chiếu/lập bảng phù hợp. Bảng không đường kẻ, ô gộp và nhiều tầng tiêu đề có thể cần chỉnh thủ công. Tối đa 100 bảng/lượt.

## Ghép tách xoay cắt

Chọn thứ tự tệp khi ghép; mỗi tệp có mật khẩu mở và nhóm trang riêng. Kèm nhật ký JSON nguồn/trang. Tách ra ZIP có các phần PDF và DANH_MUC_TRANG.json. Xoay theo chiều kim đồng hồ 90/180/270 độ. Cắt lề nhập mm và chỉ áp dụng trang đã chọn.

Cắt lề thay cropbox/vùng nhìn, dữ liệu bị che vẫn có thể nằm trong tệp. Không dùng tính năng này như công cụ xóa thông tin nhạy cảm. Bản này chưa có công cụ redaction xóa nội dung vĩnh viễn.

Khi ghép tài liệu có biểu mẫu, các nhóm trường được thêm tiền tố theo nguồn để tránh trùng tên. Không có chức năng điền form/XFA hoặc ký số. Không bảo đảm giữ tất cả hành vi của mọi biểu mẫu đặc biệt.

## Nén PDF

- Giữ lớp chữ và chất lượng nội dung: nén luồng nội dung, loại tài nguyên trùng/không dùng bằng pypdf.
- Giảm chất lượng ảnh: thử nén lại ảnh, giữ chữ PDF. Một số ảnh không hỗ trợ thay đổi sẽ được giữ và báo số lượng.
- Nén mạnh: dựng từng trang thành ảnh JPEG ở DPI/chất lượng chọn. Có thể giảm nhiều hơn nhưng mất lớp chữ gốc, liên kết, biểu mẫu và chữ ký tương tác. Giới hạn 100 trang/lượt.

Giao diện hiện dung lượng trước/sau và tỷ lệ giảm thực tế. Nếu kết quả không nhỏ hơn, trả lại bản gốc và báo không giảm, không giả báo nén thành công. Khi PDF gốc có mật khẩu và bản nén không giảm, bản giữ nguyên vẫn dùng mật khẩu cũ.

## Ảnh Office và xuất ảnh

JPG/PNG → PDF giữ tỷ lệ, sửa hướng EXIF và đặt nền trắng cho ảnh trong suốt. Chọn khổ A4 hoặc khổ theo kích thước ảnh ở quy ước 150 DPI. Giới hạn 50 ảnh/lượt, tổng 100 MB và tối đa 25 triệu điểm ảnh mỗi ảnh.

PDF → PNG/JPG xuất ZIP có số thứ tự và số trang gốc; tối đa 50 trang/lượt. DPI 72–240, có giới hạn 25 triệu điểm ảnh/trang khi render để tránh vượt bộ nhớ máy.

DOCX/XLSX/PPTX → PDF cần LibreOffice: https://www.libreoffice.org/download/download-libreoffice/ . Cài LibreOffice, khởi động lại agent rồi thử. Bộ tìm đường dẫn hỗ trợ PATH hoặc Program Files trên Windows. Mỗi lượt chạy có hồ sơ tạm riêng và thời hạn 90 giây. Với Excel, đặt vùng in/ngắt trang/khổ giấy trước khi chuyển. Chưa cấu hình vùng in trực tiếp trong agent.

## Mật khẩu watermark và số trang

Đặt mật khẩu mở AES-256-R5, ít nhất 6 ký tự. Gỡ mật khẩu yêu cầu biết mật khẩu mở đúng; không dò/bẻ khóa. Các phép xử lý khác tạo PDF không đặt lại mật khẩu, trừ khi kết quả nén giữ nguyên nguồn. Cần đặt mật khẩu lại bằng công cụ riêng nếu muốn bảo vệ bản đầu ra.

Watermark tiếng Việt dùng font Unicode trên máy (Arial, DejaVu Sans hoặc Liberation Sans). Số trang nằm giữa đáy trang, có thể chọn số bắt đầu. Chỉ các trang được chọn được thêm số; thứ tự đánh số tăng theo thứ tự trang đang có trong tệp. Nếu thiếu font Unicode, phần watermark có dấu sẽ báo cần bổ sung font.

Tài liệu có chữ ký số sẽ được nhắc khi nhận diện trường chữ ký. Không dùng các bản đã chỉnh như bằng chứng rằng chữ ký gốc vẫn hợp lệ. Không có công cụ xác minh hay ký số trong bản này.

## OCR cục bộ

OCR yêu cầu hai phần: chương trình Tesseract và dữ liệu ngôn ngữ. Gói Python pytesseract trong requirements chỉ là lớp kết nối, chưa bao gồm chương trình OCR.

Hướng dẫn cài chính thức: https://tesseract-ocr.github.io/tessdoc/Installation.html . Trang này có liên kết cho Windows. Cài Tesseract vào thư mục tiêu chuẩn Program Files/Tesseract-OCR hoặc đưa tesseract.exe vào PATH.

Để OCR tiếng Việt, cài gói ngôn ngữ vie trong trình cài; nếu bổ sung thủ công, lấy vie.traineddata từ kho chính thức https://github.com/tesseract-ocr/tessdata_fast và đặt trong thư mục tessdata của Tesseract. Khởi động lại agent, chạy KIEM_TRA_MAY.bat và kiểm tra danh sách có vie. Gói eng dùng cho tiếng Anh; có thể chọn vie + eng cho văn bản hỗn hợp. Không tự tải bất kỳ model OCR nào khi mở agent.

OCR tối đa 30 trang/lượt, DPI 100–240, thời gian chờ tối đa 90 giây/trang. Đầu ra Word/TXT là chữ nhận dạng theo dòng, chưa khôi phục bảng và bố cục. Đầu ra PDF có lớp chữ tìm kiếm dựng lại từ ảnh; không giữ lớp chữ cũ hoặc thành phần tương tác. Nếu không nhận ra chữ nào thì báo lỗi thay vì xuất kết quả trống. Tên, dấu, số và bảng luôn cần đối chiếu.

Bản này đã kiểm tra OCR tiếng Anh thực tế. Gói vie chưa có trong môi trường kiểm tra, nên chưa xác nhận chất lượng OCR tiếng Việt trên hồ sơ thực của trường.

## Chạy thử

Bật Dùng PDF minh họa 3 trang. Thử Word/Excel với trang 1; ảnh và xoay với trang 2; OCR tiếng Anh với trang 3. Có thể chọn 3,1-2 để thử sắp xếp hoặc 1;2-3 để tách. Đây là dữ liệu giả, không có hồ sơ học sinh thực.

## Kỹ thuật và phạm vi

Dùng pypdf, pdfplumber, pdf2docx, PyMuPDF (phụ thuộc của pdf2docx), pypdfium2, Pillow, reportlab và pytesseract. pdf2docx hiện không còn được Artifex chủ động bảo trì; bản đã thử được ghi trong third_party_notices/VERSIONS.json. Có chế độ chữ đơn giản/ảnh làm lựa chọn khi dựng bố cục không phù hợp. Không cam kết hỗ trợ mọi PDF hỏng hoặc phương thức bảo vệ đặc biệt.

Các PDF có chữ ký, biểu mẫu, tag trợ năng, bookmark hoặc liên kết cần kiểm tra riêng sau chuyển đổi. Không có PDF/A, e-sign, redaction, PDF portfolio, bộ nhớ đệm lâu dài hay tài khoản nhiều người. File luôn xử lý dưới dạng bản sao. Kết quả cần bấm tải, không tự gửi mail hay công bố.
