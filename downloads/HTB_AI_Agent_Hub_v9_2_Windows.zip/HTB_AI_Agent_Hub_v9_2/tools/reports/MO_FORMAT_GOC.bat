@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run CAI_DAT.bat first.
  pause
  exit /b 1
)
start "" "http://127.0.0.1:8765"
cd format_pro
"..\.venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8765
if errorlevel 1 pause
