import io,json,unittest
from pathlib import Path
import pandas as pd
from docx import Document
from multisource import *
from core import analyse
from document_plus import *

class MultiSourceTests(unittest.TestCase):
    def rows(self,sid,data):
        table=pd.DataFrame(data)
        table['__tep_nguon']=sid+'.csv';table['__sheet_nguon']='CSV';table['__dong_nguon']=range(2,2+len(table))
        table[TRACE]=[json.dumps([{'source':sid,'file':sid+'.csv','location':'CSV','row':i+2}]) for i in range(len(table))]
        return table
    def test_append_mapping_and_group_provenance(self):
        a=self.rows('S001',{'Họ và tên':['An'],'Lớp':['10A01'],'Điểm':[7]})
        b=self.rows('S002',{'Họ tên':['Bình'],'Lớp':['10A01'],'Điểm':[8]})
        a=apply_mapping(a,{'Họ và tên':'Họ tên'})
        frame,_=combine([a,b])
        clean,s,issues,_=analyse(frame,['Lớp'],['Điểm'])
        self.assertEqual(s.iloc[0]['Điểm'],15)
        trace=trace_summary(clean,['Lớp'])
        self.assertEqual(set(trace['Mã nguồn']),{'S001','S002'})
    def test_join_exact_keys_conflicts_and_unmatched(self):
        a=self.rows('S001',{'Họ tên':[' An  Bình ','Chi'],'Lớp':['10A01','10A01'],'Điểm':[7,8]})
        b=self.rows('S002',{'Họ tên':['an bình','Dũng'],'Lớp':['10a01','10A01'],'Điểm':[9,10],'Nhận xét':['A','B']})
        frame,conflicts=combine([a,b],'join',['Họ tên','Lớp'])
        self.assertEqual(len(frame),3);self.assertEqual(len(conflicts),1)
        both=frame[frame['__trang_thai_ghep']=='both'].iloc[0]
        self.assertEqual(len(json.loads(both[TRACE])),2)
        self.assertEqual(both['Điểm'],7);self.assertEqual(both['Điểm [Nguồn 2]'],9)
    def test_duplicate_blank_and_mapping_collisions_block(self):
        a=self.rows('S001',{'id':['1','1'],'Điểm':[1,2]})
        b=self.rows('S002',{'id':['1'],'Điểm':[3]})
        with self.assertRaises(ValueError):combine([a,b],'join',['id'])
        a=self.rows('S001',{'id':[''],'Điểm':[1]})
        with self.assertRaises(ValueError):combine([a,b],'join',['id'])
        with self.assertRaises(ValueError):apply_mapping(b,{'id':'Điểm'})
    def test_docx_table_and_json_inputs(self):
        d=Document();table=d.add_table(rows=2,cols=2)
        table.cell(0,0).text='Lớp';table.cell(0,1).text='Số hồ sơ'
        table.cell(1,0).text='10A01';table.cell(1,1).text='7'
        out=io.BytesIO();d.save(out)
        tables,docs,sources,warnings=extract_inputs([('table.docx',out.getvalue()),('data.json',b'[{"Lop":"10A02","Count":8}]')],word_tables=True)
        self.assertEqual(len(tables),2);self.assertEqual(tables[0]['frame'].iloc[0]['Số hồ sơ'],'7')
        self.assertEqual(json.loads(tables[0]['frame'].iloc[0][TRACE])[0]['location'],'Bảng Word 1')
    def test_pdf_table_extraction(self):
        from reportlab.pdfgen import canvas
        from reportlab.lib.pagesizes import A4
        out=io.BytesIO();c=canvas.Canvas(out,pagesize=A4)
        for y in (740,710,680):c.line(40,y,340,y)
        for x in (40,190,340):c.line(x,680,x,740)
        c.drawString(50,720,'Class');c.drawString(200,720,'Count');c.drawString(50,690,'10A01');c.drawString(200,690,'7');c.save()
        tables,docs,_,_=extract_inputs([('table.pdf',out.getvalue())],pdf_tables=True)
        self.assertEqual(tables[0]['frame'].iloc[0]['Count'],'7')
        self.assertTrue(docs)
    def test_evidence_budget_and_xlsx_trace(self):
        evidence,truncated=evidence_pack([{'source_id':'S001','location':'p1','text':'x'*30},{'source_id':'S002','location':'p2','text':'y'*30}],20)
        self.assertEqual(sum(len(x['text']) for x in evidence),20);self.assertEqual(len(truncated),2)
        frame=self.rows('S001',{'Lớp':['10A01'],'Giá trị':[1]})
        clean,summary,issues,_=analyse(frame,['Lớp'],['Giá trị'])
        result=export_multi_xlsx(clean,summary,issues,[{'id':'S001','name':'=bad'}],trace_summary(clean,['Lớp']),pd.DataFrame(),{})
        from openpyxl import load_workbook
        w=load_workbook(io.BytesIO(result))
        self.assertIn('Lien_ket_nguon',w.sheetnames);self.assertIn('Xung_dot',w.sheetnames)
        self.assertEqual(w['Nguon']['B2'].data_type,'s')
    def test_source_codes_and_long_configuration(self):
        frame=self.rows('S001',{'Tổ':['Toán'],'Số tiết':[18]})
        clean,summary,issues,_=analyse(frame,['Tổ'],['Số tiết'])
        trace=trace_summary(clean,['Tổ'])
        tagged=attach_source_codes(summary,trace,['Tổ'])
        self.assertEqual(tagged.iloc[0]['Mã nguồn'],'S001')
        cfg={'long':'x'*65000}
        data=export_multi_xlsx(clean,tagged,[],[],trace,pd.DataFrame(),cfg)
        from openpyxl import load_workbook
        ws=load_workbook(io.BytesIO(data))['Cau_hinh']
        pieces=[ws.cell(row,2).value for row in range(2,ws.max_row+1)]
        self.assertTrue(all(len(p)<=30000 for p in pieces))
        self.assertEqual(json.loads(''.join(pieces)),cfg)
    def test_unicode_bold_and_field_preserved(self):
        d=Document();r=d.add_paragraph().add_run('Cafe\u0301');r.bold=True
        out=io.BytesIO();d.save(out)
        result,changes=repair_unicode(out.getvalue())
        doc=load(result)
        self.assertEqual(doc.paragraphs[0].text,'Café');self.assertTrue(doc.paragraphs[0].runs[0].bold);self.assertEqual(len(changes),1)
    def test_docxtpl_escape_and_missing(self):
        template=make_variable_template()
        context={'don_vi':'Trường A & B','tieu_de':'Kiểm thử','noi_dung':'Nội dung <kiểm thử> & đối chiếu','ky_bao_cao':'2026','nguon':'S001','dong':[{'Lớp':'10A01','Số hồ sơ':7}]}
        result=render_variable_template(template,context)
        doc=load(result)
        self.assertIn('Trường A & B'.upper(),doc.tables[0].cell(0,0).text.upper())
        self.assertIn('<kiểm thử>','\n'.join(p.text for p in doc.paragraphs))
        with self.assertRaises(ValueError):render_variable_template(template,{})
    def test_compose_preserves_images(self):
        from PIL import Image
        blobs=[]
        for label,color in [('A','red'),('B','blue')]:
            d=Document();d.add_paragraph(label)
            img=io.BytesIO();Image.new('RGB',(20,20),color).save(img,'PNG');img.seek(0);d.add_picture(img)
            out=io.BytesIO();d.save(out);blobs.append(out.getvalue())
        result=load(merge_documents(blobs))
        self.assertEqual(len(result.inline_shapes),2)
        self.assertIn('B','\n'.join(p.text for p in result.paragraphs))

if __name__=='__main__':unittest.main()
