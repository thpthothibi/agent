"""HTB Document Format Pro: independent OOXML auditing / normalization engine.
Rules are assistance, not legal certification. Works on copies of DOCX files only.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from io import BytesIO
import re, unicodedata, zipfile
from collections import Counter
from typing import Any
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

SIZE_LIMIT=15*1024*1024
ZIP_UNCOMPRESSED_LIMIT=120*1024*1024
MAX_PARAGRAPHS=30000
REFERENCE={
    'admin': {'label':'Hành chính - Nghị định 30/2020/NĐ-CP', 'margins':(2.0,2.0,3.0,1.5),'body_size':13,'line_pt':None,'first_cm':1.0,'after_pt':6},
    'party': {'label':'Đảng - Hướng dẫn 05-HD/VPTW (2026)', 'margins':(2.0,2.0,3.0,1.5),'body_size':14,'line_pt':20,'first_cm':1.0,'after_pt':6},
}
# Representative TCVN3 (ABC) mapping, only apply when font is explicitly .VnTime or related.
_TCVN3='µ¸¶·¹¨»¾¼½Æ©ÇÊÈÉË®ÌÐÎÏÑªÒÕÓÔÖ×ÝØÜÞßãáâä«åèæçé¬êíëìîïóñòô\u00adõøö÷ùúýûüþ¡¢§£¤¥¦'
_UNICODE='àáảãạăằắẳẵặâầấẩẫậđèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵĂÂĐÊÔƠƯ'
TCVN_MAP=dict(zip(_TCVN3,_UNICODE))
# Narrow correction suggestions. An offline dictionary is not bundled; these are hints, not authoritative spellchecking.
TYPOS={r'\bqui định\b':'quy định', r'\bgiáo duc\b':'giáo dục', r'\btrách nhiêm\b':'trách nhiệm', r'\bthông bao\b':'thông báo', r'\bquản lí\b':'quản lý', r'\bđơn vi\b':'đơn vị', r'\bthực hiên\b':'thực hiện'}
DOC_TYPES=['QUYẾT ĐỊNH','KẾ HOẠCH','BÁO CÁO','THÔNG BÁO','TỜ TRÌNH','CÔNG VĂN','BIÊN BẢN','GIẤY MỜI','HƯỚNG DẪN','QUY CHẾ','QUY ĐỊNH','CHƯƠNG TRÌNH','NGHỊ QUYẾT','KẾT LUẬN']
TEMPLATE_TYPES={
 'quyet-dinh':('QUYẾT ĐỊNH','Về việc [nội dung quyết định]'),
 'ke-hoach':('KẾ HOẠCH','[Tên kế hoạch]'),
 'bao-cao':('BÁO CÁO','[Nội dung báo cáo]'),
 'thong-bao':('THÔNG BÁO','[Nội dung thông báo]'),
 'to-trinh':('TỜ TRÌNH','Về việc [nội dung trình]'),
 'cong-van':('CÔNG VĂN','V/v [nội dung công văn]'),
 'bien-ban':('BIÊN BẢN','[Nội dung cuộc họp]'),
 'giay-moi':('GIẤY MỜI','[Nội dung giấy mời]'),
 'nghi-quyet':('NGHỊ QUYẾT','[Nội dung nghị quyết]'),
 'huong-dan':('HƯỚNG DẪN','[Nội dung hướng dẫn]'),
 'quy-che':('QUY CHẾ','[Nội dung quy chế]'),
 'chuong-trinh':('CHƯƠNG TRÌNH','[Nội dung chương trình]'),
}
COMPONENTS=[
 ('quoc-hieu','Quốc hiệu – Tiêu ngữ'),('co-quan','Tên cơ quan ban hành'),('so-ky-hieu','Số, ký hiệu văn bản'),
 ('dia-danh','Địa danh – ngày tháng'),('ten-loai','Tên loại văn bản'),('trich-yeu','Trích yếu nội dung'),
 ('kinh-gui','Kính gửi'),('can-cu','Căn cứ'),('noi-dung','Đoạn nội dung'),('chu-ky','Khối chữ ký'),
 ('noi-nhan','Nơi nhận'),('do-khan','Dấu chỉ độ khẩn'),('du-thao','Chỉ dẫn dự thảo'),('sao-y','Chứng thực sao y')]

def validate_docx(blob: bytes):
    if not blob or len(blob)>SIZE_LIMIT: raise ValueError('Tệp DOCX trống hoặc vượt giới hạn 15 MB.')
    try:
        with zipfile.ZipFile(BytesIO(blob)) as z:
            infos=z.infolist()
            if len(infos)>3000 or sum(i.file_size for i in infos)>ZIP_UNCOMPRESSED_LIMIT:
                raise ValueError('Tệp DOCX có kích thước giải nén không an toàn.')
            if any(i.flag_bits & 1 for i in infos): raise ValueError('DOCX được mã hóa chưa được hỗ trợ.')
            if '[Content_Types].xml' not in z.namelist() or 'word/document.xml' not in z.namelist():
                raise ValueError('Đây không phải là tệp DOCX hợp lệ.')
            # Macro-bearing packages should not enter this transformation workflow.
            if any('vbaProject.bin' in n or n.endswith('.exe') for n in z.namelist()):
                raise ValueError('Tài liệu chứa macro hoặc nội dung thực thi; hãy sử dụng DOCX không có macro.')
    except zipfile.BadZipFile:
        raise ValueError('Tệp lỗi hoặc không phải định dạng DOCX.')

def load(blob:bytes):
    validate_docx(blob)
    try: return Document(BytesIO(blob))
    except Exception as exc: raise ValueError('Không đọc được nội dung DOCX. Hãy lưu lại bằng Word ở định dạng .docx.') from exc

def iter_paragraphs(doc):
    seen=set()
    def walk(container):
        for p in container.paragraphs:
            if p._p not in seen:
                seen.add(p._p); yield p
        for table in container.tables:
            for row in table.rows:
                for cell in row.cells:
                    yield from walk(cell)
    yield from walk(doc)

def identify(doc):
    sample='\n'.join(p.text for p in list(iter_paragraphs(doc))[:80]).upper()
    if 'ĐẢNG CỘNG SẢN VIỆT NAM' in sample or 'ĐẢNG UỶ' in sample or 'ĐẢNG ỦY' in sample: return 'party'
    return 'admin'

def which_kind(text):
    t=re.sub(r'\s+',' ',text.strip()).upper()
    if t=='CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM': return 'quoc-hieu'
    if t=='ĐỘC LẬP - TỰ DO - HẠNH PHÚC' or t=='ĐỘC LẬP – TỰ DO – HẠNH PHÚC': return 'tieu-ngu'
    if t=='ĐẢNG CỘNG SẢN VIỆT NAM': return 'party-title'
    if t in DOC_TYPES: return 'title'
    if t.startswith('SỐ:') or bool(re.match(r'^SỐ\s+\d+',t)): return 'number'
    if t.startswith('NƠI NHẬN'): return 'recipient'
    if t.startswith('KÍNH GỬI'): return 'kinhgui'
    if re.search(r'NGÀY\s+\d+\s+THÁNG\s+\d+\s+NĂM\s+\d{4}',t): return 'date'
    if t.startswith(('HIỆU TRƯỞNG','KT. ','TL. ','TUQ. ','BÍ THƯ','CHỦ TỊCH','GIÁM ĐỐC')) and len(t)<100: return 'sign'
    if t in {'HỎA TỐC','THƯỢNG KHẨN','KHẨN','MẬT','TỐI MẬT','TUYỆT MẬT'}: return 'urgency'
    if t.startswith(('CĂN CỨ ','- CĂN CỨ ')): return 'basis'
    if t.startswith(('CHƯƠNG ','PHẦN ','MỤC ','ĐIỀU ')) and len(t)<140: return 'heading'
    return 'body'

def summary(doc, sample_limit=110):
    ps=list(iter_paragraphs(doc))
    if len(ps)>MAX_PARAGRAPHS: raise ValueError('Tài liệu vượt quá số đoạn hỗ trợ.')
    texts=[p.text for p in ps]
    return {'paragraphs':len(ps), 'tables':len(doc.tables), 'sections':len(doc.sections),
            'characters':sum(len(t) for t in texts), 'words':sum(len(t.split()) for t in texts),
            'preview':[{'text':p.text[:800],'type':which_kind(p.text)} for p in ps if p.text.strip()][:sample_limit]}

def _font_info(run):
    return run.font.name or (run.style.font.name if run.style else None)

def audit(doc, selected='auto'):
    policy=identify(doc) if selected=='auto' else selected
    if policy not in REFERENCE: raise ValueError('Quy chuẩn không được hỗ trợ.')
    issues=[]
    def add(code,level,place,detail,action):
        if len(issues)<220: issues.append(dict(code=code,level=level,place=place,detail=detail,action=action))
    body_sz=REFERENCE[policy]['body_size']
    for i,s in enumerate(doc.sections,1):
        if abs(s.page_width.cm-21)>.15 or abs(s.page_height.cm-29.7)>.15:
            add('A4','error',f'Phần {i}',f'Kích thước trang {s.page_width.cm:.1f} × {s.page_height.cm:.1f} cm', 'Chuyển trang sang A4 nếu không phải trang phụ lục ngang')
        margins=(s.top_margin.cm,s.bottom_margin.cm,s.left_margin.cm,s.right_margin.cm)
        targets=REFERENCE[policy]['margins']
        for name,m,tar in zip(['trên','dưới','trái','phải'],margins,targets):
            if policy=='admin':
                low,high=({'trên':(2,2.5),'dưới':(2,2.5),'trái':(3,3.5),'phải':(1.5,2)}[name])
                wrong=not low-.04<=m<=high+.04
            else: wrong=abs(m-tar)>.07
            if wrong: add('MARGIN','error',f'Phần {i}',f'Lề {name} đang {m:.2f} cm','Điều chỉnh theo quy chuẩn đã chọn')
    paragraphs=list(iter_paragraphs(doc))
    for index,p in enumerate(paragraphs,1):
        text=p.text.strip()
        if not text: continue
        kind=which_kind(text)
        place=f'Đoạn {index}'
        for r in p.runs:
            if not r.text.strip():continue
            f=_font_info(r)
            if f and f.lower().replace(' ','') not in {'timesnewroman','+body','+minor-latin'}:
                add('FONT','warning',place,f'Phông {f} khác Times New Roman','Chuẩn hóa phông nếu không phải ký hiệu/toán học')
                break
        if kind=='body':
            explicit=[r.font.size.pt for r in p.runs if r.text.strip() and r.font.size]
            if explicit and max(set(explicit),key=explicit.count) not in ({13,14} if policy=='admin' else {14,15}):
                add('BODY_SIZE','warning',place,f'Cỡ chữ nội dung phát hiện: {explicit[0]:g}pt',f'Cỡ chữ nội dung khuyến nghị {body_sz}pt')
            if p.alignment not in (None,WD_ALIGN_PARAGRAPH.JUSTIFY):
                add('ALIGN','info',place,'Đoạn nội dung chưa căn đều hai lề','Cân nhắc căn đều 2 lề')
        if re.search(r'(?<=\S) {2,}(?=\S)',text): add('SPACES','warning',place,'Có từ 2 dấu cách liên tiếp giữa các từ','Xóa dấu cách thừa')
        if re.search(r'\s+[,.;:!?]',text): add('PUNCT','info',place,'Có khoảng trắng ngay trước dấu câu','Xem lại khoảng trắng')
        for old,new in TYPOS.items():
            if re.search(old,text,re.IGNORECASE): add('SPELL_HINT','info',place,f'Từ cần rà soát: {re.search(old,text,re.IGNORECASE).group(0)}',f'Gợi ý: {new} (cần kiểm tra ngữ cảnh)')
        if re.search(r'\b(?:[Vv]ieät|[Tt]ieáng|[Tt]höïc|[Tt]röôøng)\b',text):
            add('VNI','warning',place,'Có dấu hiệu văn bản VNI chưa chuyển Unicode','Chuyển mã theo font VNI rồi kiểm tra thủ công')
    first='\n'.join(p.text for p in paragraphs[:50]).upper()
    if policy=='admin':
        if 'CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM' not in first:
            add('HEADER','warning','Đầu văn bản','Chưa tìm thấy Quốc hiệu','Xác nhận loại văn bản và bổ sung Quốc hiệu nếu cần')
        if 'ĐỘC LẬP' not in first: add('MOTTO','warning','Đầu văn bản','Chưa tìm thấy tiêu ngữ','Bổ sung tiêu ngữ nếu thuộc văn bản hành chính')
    else:
        if 'ĐẢNG CỘNG SẢN VIỆT NAM' not in first:
            add('HEADER','warning','Đầu văn bản','Chưa tìm thấy tiêu đề Đảng','Xác nhận và thêm tiêu đề nếu phù hợp')
    if not re.search(r'(?im)^\s*số\s*[:\d]',first): add('NUMBER','info','Đầu văn bản','Chưa nhận diện số, ký hiệu văn bản','Kiểm tra theo loại văn bản và quy trình cấp số')
    # Layout-aware checks that the original V1 lacked.
    for ti,t in enumerate(doc.tables,1):
        try:
            table_cm=sum(col.width.cm for col in t.columns if col.width)
            allowed_cm=doc.sections[0].page_width.cm-doc.sections[0].left_margin.cm-doc.sections[0].right_margin.cm
            if table_cm>allowed_cm+.10:
                add('TABLE_WIDTH','warning',f'Bảng {ti}',f'Bảng rộng {table_cm:.2f} cm, vượt vùng in {allowed_cm:.2f} cm',
                    'Chỉnh cột bảng thủ công, tránh xuống dòng quốc hiệu hoặc tên cơ quan')
        except (TypeError,ValueError):pass
        if any(p.alignment==WD_ALIGN_PARAGRAPH.JUSTIFY for row in t.rows for c in row.cells for p in c.paragraphs):
            add('TABLE_JUSTIFY','warning',f'Bảng {ti}','Có đoạn căn đều hai lề trong ô bảng',
                'Cân nhắc căn giữa tên cơ quan, quốc hiệu, số ký hiệu và chức danh người ký')
    for i,p in enumerate(doc.paragraphs,1):
        if p.text.startswith('\t') and p.paragraph_format.first_line_indent and p.paragraph_format.first_line_indent.cm>=.6:
            add('DOUBLE_INDENT','warning',f'Đoạn {i}', 'Vừa có Tab đầu dòng, vừa đặt thụt dòng đầu',
                'Chọn chỉ một cách thụt đầu dòng; chế độ an toàn không tự thêm thụt dòng')
    return {'standard':policy,'standard_label':REFERENCE[policy]['label'], 'document_type':next((t for t in DOC_TYPES if re.search(r'(?m)^'+re.escape(t)+r'\s*$',first)), 'Chưa xác định'),
            'issues':issues,'counts':dict(Counter(x['level'] for x in issues)), 'stats':summary(doc)}

def _set_run_font(run, size):
    run.font.name='Times New Roman'
    rpr=run._element.get_or_add_rPr()
    rfonts=rpr.rFonts
    if rfonts is None:
        rfonts=OxmlElement('w:rFonts');rpr.insert(0,rfonts)
    for x in ['ascii','hAnsi','cs','eastAsia']: rfonts.set(qn('w:'+x),'Times New Roman')
    run.font.size=Pt(size)

def _replace_in_runs(p, fn):
    for r in p.runs:
        # Keep formatting and drawing XML intact; assigning text to run with drawings would delete objects.
        if r._element.xpath('.//w:drawing|.//w:pict|.//w:object|.//w:instrText|.//w:fldChar'):
            continue
        if r.text: r.text=fn(r.text)

def _normalize_text(s):
    s=s.replace('\u00a0',' ')
    return re.sub(r'(?<=\S) {2,}(?=\S)',' ',s)

def _tcvn_run(run):
    name=(_font_info(run) or '').lower()
    if name.startswith('.vn'):
        return ''.join(TCVN_MAP.get(c,c) for c in run.text)
    return run.text

def _vni_convert(s):
    """VNI-Windows common Vietnamese letter conversions, opt-in by VNI font name.
    Run boundaries can split encoded syllables, so human verification is mandatory.
    """
    tone=('','̀','́','̉','̃','̣')
    table={}
    simple={'a':'a','e':'e','i':'i','o':'o','u':'u','y':'y',
            'ö':'ư','ô':'ơ'}
    # In VNI, diacritics for a plain vowel are represented by `ø ù û õ ï`.
    marks=['','ø','ù','û','õ','ï']
    for v,target in simple.items():
        for suffix,accent in zip(marks,tone):
            if suffix:table[v+suffix]=unicodedata.normalize('NFC',target+accent)
    complex_vowels={
      'aâ':'â','aà':'ầ','aá':'ấ','aå':'ẩ','aã':'ẫ','aä':'ậ',
      'aê':'ă','aè':'ằ','aé':'ắ','aú':'ẳ','aü':'ẵ','aë':'ặ',
      'eâ':'ê','eà':'ề','eá':'ế','eå':'ể','eã':'ễ','eä':'ệ',
      'oâ':'ô','oà':'ồ','oá':'ố','oå':'ổ','oã':'ỗ','oä':'ộ',
      'öô':'ươ','öôø':'ườ','öôù':'ướ','öôû':'ưở','öôõ':'ưỡ','öôï':'ượ',
      'ñòa':'địa','ñ':'đ'
    }
    table.update(complex_vowels)
    # Longest match prevents conversion of `öôø` into two independent vowels.
    expressions=sorted(table,key=len,reverse=True)
    match=re.compile('|'.join(re.escape(k) for k in expressions),flags=re.IGNORECASE)
    def repl(m):
        token=m.group(0);val=table.get(token.lower(),token)
        if token[0].isupper():return val[0].upper()+val[1:]
        return val
    return unicodedata.normalize('NFC',match.sub(repl,s))

def add_page_field(section):
    """Place page number in top margin from page 2. Do not overwrite a pre-existing header.

    Word's different-first-page header option prevents numbers on page one. If an
    existing first-page header would be suppressed, skip instead of destroying it.
    """
    header=section.header
    if header._element.xpath('.//w:instrText[contains(text(),"PAGE")]'):return False
    if not section.different_first_page_header_footer and any(p.text.strip() for p in header.paragraphs):
        return False
    if not section.different_first_page_header_footer:
        section.different_first_page_header_footer=True
    section.header_distance=Cm(1)
    p=header.paragraphs[0] if header.paragraphs else header.add_paragraph()
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=p.add_run()
    begin=OxmlElement('w:fldChar');begin.set(qn('w:fldCharType'),'begin')
    instr=OxmlElement('w:instrText');instr.set(qn('xml:space'),'preserve');instr.text=' PAGE '
    sep=OxmlElement('w:fldChar');sep.set(qn('w:fldCharType'),'separate')
    mid=OxmlElement('w:t');mid.text='2'
    end=OxmlElement('w:fldChar');end.set(qn('w:fldCharType'),'end')
    for node in (begin,instr,sep,mid,end):run._r.append(node)
    _set_run_font(run,13)
    return True

def _table_paragraph_ids(doc):
    """Identify cell paragraphs, so body formatting never damages heading / signature tables."""
    def walk(table):
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    yield p._p
                for inner in cell.tables:
                    yield from walk(inner)
    for t in doc.tables:
        yield from walk(t)


def _font_name_only(run):
    """Replace text font family, preserve its exact size, bold/italic and field XML."""
    run.font.name='Times New Roman'
    rpr=run._element.get_or_add_rPr()
    rfonts=rpr.rFonts
    if rfonts is None:
        rfonts=OxmlElement('w:rFonts');rpr.insert(0,rfonts)
    for code in ('ascii','hAnsi','eastAsia','cs'):
        rfonts.set(qn('w:'+code),'Times New Roman')


def _is_special_body(p, text):
    """Headers, numbered subheads and Word list items must keep layout and indentation."""
    clean=text.lstrip('\t ').strip()
    if p.style.name.lower().startswith(('list ', 'heading', 'title')):return True
    if p._p.pPr is not None and p._p.pPr.numPr is not None:return True
    if re.match(r'^(?:[IVXLCDM]+\.|\d{1,2}\.|[-–•])\s+',clean):return True
    return False


def normalize(blob,standard='auto',options=None):
    """Safe, layout-preserving normalization (V1.1).

    Do not force justification or first-line indentation on paragraphs in tables,
    bulleted/numbered lists, lines with leading tabs, or centered subtitles.
    Existing runs' emphasis is kept. Unlike V1.0, paragraph modifications do
    not run over every paragraph indiscriminately.
    """
    options=options or {}
    doc=load(blob)
    policy=identify(doc) if standard=='auto' else standard
    if policy not in REFERENCE:raise ValueError('Quy chuẩn không được hỗ trợ.')
    cfg=REFERENCE[policy]
    safe=options.get('safe_layout',True)
    if options.get('page',True):
        for sec in doc.sections:
            landscape=sec.page_width>sec.page_height
            if not landscape:sec.page_width=Cm(21);sec.page_height=Cm(29.7)
            sec.top_margin,sec.bottom_margin,sec.left_margin,sec.right_margin=map(Cm,cfg['margins'])
    cell_ids=set(_table_paragraph_ids(doc))
    pars=list(iter_paragraphs(doc))
    for p in pars:
        if not p.text.strip():continue
        text=p.text
        kind=which_kind(text)
        in_table=p._p in cell_ids
        special=_is_special_body(p,text)
        if options.get('legacy',False):
            for run in p.runs:
                if run._element.xpath('.//w:drawing|.//w:pict|.//w:object|.//w:instrText|.//w:fldChar'):
                    continue
                f=(_font_info(run) or '').lower()
                if f.startswith('.vn'):run.text=_tcvn_run(run)
                elif 'vni-' in f:run.text=_vni_convert(run.text)
        if options.get('fonts',True):
            for run in p.runs:
                if not run.text.strip() or run._element.xpath('.//w:drawing|.//w:pict|.//w:object|.//w:instrText|.//w:fldChar'):
                    continue
                if safe:
                    # Important: do not alter existing 11-16pt titles, dates, signatures
                    # or multi-run headings. Especially not inside header / footer tables.
                    _font_name_only(run)
                    current=run.font.size.pt if run.font.size else None
                    if not in_table and not special and kind=='body' and current and (current<11 or current>16):
                        run.font.size=Pt(cfg['body_size'])
                else:
                    target=cfg['body_size']
                    if kind in ('quoc-hieu','party-title'):target=13 if policy=='admin' else 15
                    elif kind in ('tieu-ngu','sign','number','date','recipient','kinhgui'):target=13 if policy=='admin' else 14
                    elif kind=='title':target=14 if policy=='admin' else 16
                    elif kind=='heading':target=14
                    _set_run_font(run,target)
        if options.get('paragraphs',True):
            if safe:
                # Paragraphs inside tables and existing list/heading/number/date
                # layouts should not be force-justified or re-indented.
                if not in_table and not special:
                    pf=p.paragraph_format
                    if kind in ('body','basis'):
                        if p.alignment is None:p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
                        # A leading TAB already positions the first line. Avoid double indent.
                        if pf.first_line_indent is None and not text.startswith('\t'):
                            pf.first_line_indent=Cm(cfg['first_cm'])
                        if pf.space_after is None:pf.space_after=Pt(cfg['after_pt'])
                        if pf.line_spacing is None:
                            if cfg['line_pt']:
                                pf.line_spacing=Pt(cfg['line_pt']);pf.line_spacing_rule=WD_LINE_SPACING.EXACTLY
                            else:pf.line_spacing=1.15
                    # No change to position, boldness or indents of other kinds.
            else:
                pf=p.paragraph_format
                if kind in ('body','basis') and not in_table:
                    p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
                    pf.first_line_indent=Cm(0) if text.startswith('\t') else Cm(cfg['first_cm'])
                    pf.space_after=Pt(cfg['after_pt'])
                    if cfg['line_pt']:
                        pf.line_spacing=Pt(cfg['line_pt']);pf.line_spacing_rule=WD_LINE_SPACING.EXACTLY
                    else:pf.line_spacing=1.15
                elif kind in ('quoc-hieu','tieu-ngu','party-title','title') and not in_table:
                    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                    pf.first_line_indent=Cm(0)
                # Aggressive mode does not touch tabular header/footer layout either.
        if options.get('whitespace',False): _replace_in_runs(p,_normalize_text)
    if options.get('table',False):
        for t in doc.tables:
            for row in t.rows:
                for cell in row.cells:cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    if options.get('page_numbers',False):
        for sec in doc.sections:add_page_field(sec)
    dest=BytesIO();doc.save(dest)
    return dest.getvalue()

def _put(paragraph,text,bold=False,italic=False,size=13):
    r=paragraph.add_run(text);_set_run_font(r,size);r.bold=bold;r.italic=italic;return r

def _lines_for_component(key,meta,policy):
    admin=policy=='admin'
    supername=(meta.get('parent') or 'SỞ GIÁO DỤC VÀ ĐÀO TẠO').upper()[:200]
    org=(meta.get('organization') or 'TRƯỜNG THPT [TÊN TRƯỜNG]').upper()[:200]
    city=(meta.get('city') or 'TP. Hồ Chí Minh')[:120]
    name=(meta.get('signer') or '[Họ và tên người ký]')[:120]
    role=(meta.get('role') or 'HIỆU TRƯỞNG')[:120]
    lines={
        'quoc-hieu': ['CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM' if admin else 'ĐẢNG CỘNG SẢN VIỆT NAM','Độc lập - Tự do - Hạnh phúc' if admin else ''],
        'co-quan':[supername,org],
        'so-ky-hieu':['Số: …/…-'+('THPT' if admin else 'QĐ')],
        'dia-danh':[f'{city}, ngày … tháng … năm …'],
        'ten-loai':['QUYẾT ĐỊNH'], 'trich-yeu':['Về việc [nội dung]'],
        'kinh-gui':['Kính gửi: [Tên cơ quan, tổ chức]'],
        'can-cu':['Căn cứ [tên và số hiệu văn bản pháp lý];'],
        'noi-dung':['[Nhập nội dung văn bản]'],
        'chu-ky':[role,name],
        'noi-nhan':['Nơi nhận:','- Như trên;','- Lưu: VT.'],
        'do-khan':['KHẨN'],
        'du-thao':['DỰ THẢO'],
        'sao-y':['SAO Y','Số: …/SY-…','[Địa danh], ngày … tháng … năm …'],
    }
    return [s for s in lines.get(key,[]) if s]

def _paragraph_rule(p,side_indent_cm):
    # Line beneath national motto / organization: paragraph border, not underscore text.
    fmt=p.paragraph_format
    fmt.left_indent=Cm(side_indent_cm);fmt.right_indent=Cm(side_indent_cm)
    fmt.space_after=Pt(0)
    fmt.line_spacing=1
    ppr=p._p.get_or_add_pPr()
    borders=OxmlElement('w:pBdr');bottom=OxmlElement('w:bottom')
    for attr,value in [('val','single'),('sz','6'),('color','000000'),('space','1')]:
        bottom.set(qn('w:'+attr),value)
    borders.append(bottom);ppr.append(borders)

def _add_header(doc,policy,meta):
    admin=policy=='admin'
    section=doc.sections[0]
    section.header_distance=Cm(1)
    t=doc.add_table(rows=1,cols=2)
    t.autofit=False
    t.columns[0].width=Cm(6.0);t.columns[1].width=Cm(10.5)
    left=t.cell(0,0);right=t.cell(0,1);left.width=Cm(6.0);right.width=Cm(10.5)
    pa=left.paragraphs[0];pa.alignment=WD_ALIGN_PARAGRAPH.CENTER
    _put(pa,(meta.get('parent') or 'SỞ GIÁO DỤC VÀ ĐÀO TẠO').upper(),size=12)
    p=left.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    _put(p,(meta.get('organization') or 'TRƯỜNG THPT [TÊN TRƯỜNG]').upper(),bold=True,size=12 if admin else 14)
    if admin:_paragraph_rule(left.add_paragraph(),1.7)
    p=right.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    _put(p,'CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM' if admin else 'ĐẢNG CỘNG SẢN VIỆT NAM',bold=True,size=12 if admin else 15)
    if admin:
        p=right.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        _put(p,'Độc lập - Tự do - Hạnh phúc',bold=True,size=13)
    _paragraph_rule(right.add_paragraph(),2.35 if admin else 1.7)
    # Dedicated two-column number/date row: no text with manual spaces.
    t2=doc.add_table(rows=1,cols=2);t2.autofit=False
    t2.columns[0].width=Cm(6.0);t2.columns[1].width=Cm(10.5)
    t2.cell(0,0).width=Cm(6.0);t2.cell(0,1).width=Cm(10.5)
    p=t2.cell(0,0).paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER;_put(p,'Số: …/…-'+('THPT' if admin else 'QĐ'),size=13)
    p=t2.cell(0,1).paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    _put(p,f"{meta.get('city') or 'TP. Hồ Chí Minh'}, ngày … tháng … năm …",italic=True,size=13)
    doc.add_paragraph('')

def template_docx(kind,policy,meta):
    if kind not in TEMPLATE_TYPES:raise ValueError('Không có loại mẫu này.')
    if policy not in REFERENCE:raise ValueError('Quy chuẩn không được hỗ trợ.')
    name,description=TEMPLATE_TYPES[kind]
    doc=Document()
    s=doc.sections[0];s.page_width=Cm(21);s.page_height=Cm(29.7)
    s.top_margin,s.bottom_margin,s.left_margin,s.right_margin=map(Cm,REFERENCE[policy]['margins'])
    doc.styles['Normal'].font.name='Times New Roman';doc.styles['Normal'].font.size=Pt(REFERENCE[policy]['body_size'])
    _add_header(doc,policy,meta)
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    _put(p,name,bold=True,size=14 if policy=='admin' else 16)
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    _put(p,description,bold=True,size=14)
    doc.add_paragraph('')
    lines=['Kính gửi: [Cơ quan nhận văn bản]' if kind in ['cong-van','to-trinh'] else None,
           'Căn cứ [tên, số hiệu và ngày ban hành văn bản liên quan];' if kind in ['quyet-dinh','nghi-quyet'] else None,
           '[Nhập nội dung chi tiết của văn bản tại đây.]',
           '[Nội dung mục 1.]','[Nội dung mục 2.]']
    for txt in [x for x in lines if x]:
        p=doc.add_paragraph();_put(p,txt,size=REFERENCE[policy]['body_size']);p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.first_line_indent=Cm(1);p.paragraph_format.space_after=Pt(6)
    doc.add_paragraph('')
    t=doc.add_table(rows=1,cols=2)
    a,b=t.cell(0,0),t.cell(0,1)
    p=a.paragraphs[0];_put(p,'Nơi nhận:',bold=True,italic=True,size=12)
    for txt in ('- Như trên;','- Lưu: VT.'):_put(a.add_paragraph(),txt,size=11)
    p=b.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    _put(p,(meta.get('role') or 'HIỆU TRƯỞNG').upper(),bold=True,size=13)
    for _ in range(3):b.add_paragraph('')
    p=b.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    _put(p,meta.get('signer') or '[Họ tên người ký]',bold=True,size=13)
    add_page_field(s)
    out=BytesIO();doc.save(out);return out.getvalue()

def component_docx(key,policy,meta):
    if key not in [k for k,_ in COMPONENTS]:raise ValueError('Thành phần chưa được hỗ trợ.')
    doc=Document();s=doc.sections[0]
    s.top_margin,s.bottom_margin,s.left_margin,s.right_margin=map(Cm,REFERENCE[policy]['margins'])
    for line in _lines_for_component(key,meta,policy):
        p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER if key in ('quoc-hieu','ten-loai','chu-ky') else WD_ALIGN_PARAGRAPH.LEFT
        _put(p,line,bold=key in ('quoc-hieu','co-quan','chu-ky','ten-loai','do-khan'),size=13)
    out=BytesIO();doc.save(out);return out.getvalue()

def pdf_convert(blob:bytes):
    """External converter isolated in a temporary directory with subprocess without shell.
    Local deployments: LibreOffice installed; no external cloud service.
    """
    import subprocess,tempfile,shutil
    from pathlib import Path
    lo=shutil.which('libreoffice') or shutil.which('soffice')
    if not lo:
        import os
        for env in ('PROGRAMFILES','PROGRAMFILES(X86)'):
            candidate=Path(os.environ.get(env,''))/'LibreOffice'/'program'/'soffice.exe'
            if candidate.is_file():lo=str(candidate);break
    if not lo:raise RuntimeError('Chưa cài LibreOffice trên máy chủ. PDF không khả dụng; có thể tải DOCX và xuất PDF trong Word.')
    with tempfile.TemporaryDirectory(prefix='htbdoc-') as td:
        folder=Path(td);(folder/'input.docx').write_bytes(blob)
        cmd=[lo,'-env:UserInstallation='+(folder/'profile').as_uri(),'--headless','--convert-to','pdf:writer_pdf_Export','--outdir',str(folder),str(folder/'input.docx')]
        try:result=subprocess.run(cmd,capture_output=True,timeout=45,check=False)
        except subprocess.TimeoutExpired:raise RuntimeError('Quá thời gian chuyển đổi PDF (45 giây).')
        pdf=folder/'input.pdf'
        if result.returncode!=0 or not pdf.exists():raise RuntimeError('LibreOffice không chuyển đổi được tệp này.')
        return pdf.read_bytes()
