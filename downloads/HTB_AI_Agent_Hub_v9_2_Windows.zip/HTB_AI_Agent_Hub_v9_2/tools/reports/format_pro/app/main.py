"""Offline-first document formatting web interface and API.
Run: uvicorn app.main:app --host 127.0.0.1 --port 8765
"""
from __future__ import annotations
from io import BytesIO
import json, re, zipfile
from pathlib import Path
from urllib.parse import quote
from fastapi import FastAPI,File,UploadFile,Form,HTTPException,Request
from fastapi.responses import HTMLResponse,JSONResponse,StreamingResponse,FileResponse
from fastapi.staticfiles import StaticFiles
from .engine import (load,audit,normalize,template_docx,component_docx,validate_docx,
                     pdf_convert,SIZE_LIMIT,REFERENCE,TEMPLATE_TYPES,COMPONENTS)

BASE=Path(__file__).resolve().parent
app=FastAPI(title='HTB Document Format Pro',description='Local-first independent Vietnamese document formatter',version='1.1.0',docs_url='/api/docs',redoc_url=None)
app.mount('/static',StaticFiles(directory=str(BASE/'static')),name='static')

@app.middleware('http')
async def protect_host(req:Request,call_next):
    # Local installation only. In production put behind VPDT authentication proxy + HTTPS.
    if req.method!='GET':
        origin=req.headers.get('origin')
        host=req.headers.get('host','')
        if origin:
            from urllib.parse import urlparse
            try:
                o=urlparse(origin)
                if o.netloc.lower()!=host.lower() or o.scheme not in ('http','https'):
                    return JSONResponse(status_code=403,content={'detail':'Yêu cầu từ nguồn không được cho phép.'})
            except ValueError:return JSONResponse(status_code=403,content={'detail':'Nguồn không hợp lệ.'})
    resp=await call_next(req)
    resp.headers.update({'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'SAMEORIGIN',
         'Cache-Control':'no-store','Content-Security-Policy':"default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; frame-src 'self' blob:; object-src 'none'; base-uri 'none'"})
    return resp

@app.get('/',include_in_schema=False)
def index():return FileResponse(BASE/'static'/'index.html')

@app.get('/api/health')
def health():return {'ok':True,'version':'1.1.0','mode':'local','no_cloud_upload':True}

@app.get('/api/catalog')
def catalog():
    return {'standards':[{'id':k,'title':v['label']} for k,v in REFERENCE.items()],
            'templates':[{'id':k,'title':v[0],'subtitle':v[1]} for k,v in TEMPLATE_TYPES.items()],
            'components':[{'id':k,'title':v} for k,v in COMPONENTS],
            'version':'1.1.0'}

async def read_doc(file:UploadFile):
    name=file.filename or ''
    if not name.lower().endswith('.docx') or name.lower().endswith('.docm'):
        raise HTTPException(400,'Chỉ nhận tệp .docx (không nhận .doc, .docm, PDF).')
    data=await file.read(SIZE_LIMIT+1)
    try:validate_docx(data)
    except ValueError as e:raise HTTPException(400,str(e))
    return data

def profile_or_bad(profile):
    if profile not in ('auto','admin','party'):raise HTTPException(400,'Quy chuẩn không hợp lệ.')
    return profile

def dl(blob,mime,filename):
    name=re.sub('[^a-zA-Z0-9_.-]','_',filename)
    return StreamingResponse(BytesIO(blob),media_type=mime,headers={'Content-Disposition':f'attachment; filename="{name}"'})

def parse_opts(s):
    try:
        obj=json.loads(s)
        if not isinstance(obj,dict):raise ValueError()
    except (json.JSONDecodeError,ValueError):raise HTTPException(400,'Tùy chọn không phải đối tượng JSON.')
    return {k:bool(v) for k,v in obj.items() if k in ['page','fonts','paragraphs','whitespace','legacy','table','page_numbers','safe_layout']}

def parse_meta(s):
    try:
        obj=json.loads(s)
        if not isinstance(obj,dict):raise ValueError()
    except (ValueError,json.JSONDecodeError):raise HTTPException(400,'Thông tin cơ quan không hợp lệ.')
    return {k:str(v)[:200] for k,v in obj.items() if k in ('parent','organization','city','role','signer')}

@app.post('/api/analyze')
async def analyze(file:UploadFile=File(...),standard:str=Form('auto')):
    data=await read_doc(file)
    profile_or_bad(standard)
    try:return audit(load(data),standard)
    except ValueError as e:raise HTTPException(422,str(e))

@app.post('/api/normalize')
async def standardize(file:UploadFile=File(...),standard:str=Form('auto'),options:str=Form('{}')):
    data=await read_doc(file);profile_or_bad(standard);cfg=parse_opts(options)
    try:res=normalize(data,standard,cfg)
    except ValueError as e:raise HTTPException(422,str(e))
    filename=Path(file.filename or 'van-ban').stem+'_CHUAN_HOA.docx'
    return dl(res,'application/vnd.openxmlformats-officedocument.wordprocessingml.document',filename)

@app.post('/api/pdf')
async def make_pdf(file:UploadFile=File(...),standard:str=Form('auto'),options:str=Form('{}')):
    data=await read_doc(file);profile_or_bad(standard);cfg=parse_opts(options)
    try:
        result=normalize(data,standard,cfg)
        pdf=pdf_convert(result)
    except (ValueError,RuntimeError) as e:raise HTTPException(422,str(e))
    return dl(pdf,'application/pdf',Path(file.filename or 'van-ban').stem+'_CHUAN_HOA.pdf')

@app.post('/api/template')
async def make_template(kind:str=Form(...),standard:str=Form('admin'),meta:str=Form('{}')):
    if standard not in REFERENCE:raise HTTPException(400,'Quy chuẩn không hợp lệ.')
    try: data=template_docx(kind,standard,parse_meta(meta))
    except ValueError as e:raise HTTPException(400,str(e))
    return dl(data,'application/vnd.openxmlformats-officedocument.wordprocessingml.document',f'MAU_{kind}_{standard}.docx')

@app.post('/api/component')
async def make_component(key:str=Form(...),standard:str=Form('admin'),meta:str=Form('{}')):
    if standard not in REFERENCE:raise HTTPException(400,'Quy chuẩn không hợp lệ.')
    try: data=component_docx(key,standard,parse_meta(meta))
    except ValueError as e:raise HTTPException(400,str(e))
    return dl(data,'application/vnd.openxmlformats-officedocument.wordprocessingml.document',f'THANH_PHAN_{key}.docx')

@app.post('/api/batch')
async def batch(files:list[UploadFile]=File(...),standard:str=Form('auto'),options:str=Form('{}')):
    profile_or_bad(standard)
    if len(files)<1 or len(files)>12:raise HTTPException(400,'Chọn từ 1 đến 12 tệp DOCX mỗi lần.')
    cfg=parse_opts(options);buffer=BytesIO();report=[]
    try:
        with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            used=set()
            for i,f in enumerate(files,1):
                original=await read_doc(f)
                name=Path(f.filename or f'vanban{i}.docx').stem
                name=re.sub(r'[^\w-]','_',name,flags=re.UNICODE)[:70]
                if name in used:name+=f'_{i}'
                used.add(name)
                result=audit(load(original),standard)
                formatted=normalize(original,standard,cfg)
                z.writestr(f'{name}_CHUAN_HOA.docx',formatted)
                report.append({'file':f.filename,'standard':result['standard_label'],'issues':result['counts']})
            z.writestr('BAO_CAO_KIEM_TRA.json',json.dumps(report,ensure_ascii=False,indent=2))
    except ValueError as e:raise HTTPException(422,str(e))
    return dl(buffer.getvalue(),'application/zip','HTB_Format_Batch.zip')
