@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  set "PY_CMD=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Chua tim thay Python. Vui long cai Python 3.11+ tai https://www.python.org/downloads/
    pause & exit /b 1
  )
  set "PY_CMD=python"
)
if not exist ".venv\Scripts\python.exe" (
  echo Dang tao moi truong Python lan dau...
  %PY_CMD% -m venv .venv
)
if not exist ".venv\Scripts\python.exe" (echo Loi tao moi truong Python. & pause & exit /b 1)
echo Dang kiem tra thu vien...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (echo Loi cai thu vien. Kiem tra ket noi Internet. & pause & exit /b 1)
echo.
echo HTB FORMAT dang khoi dong. MO TRINH DUYET TAI http://127.0.0.1:8765
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 3; Start-Process 'http://127.0.0.1:8765'"
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8765
pause
