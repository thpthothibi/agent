from io import BytesIO
import json, zipfile
from docx import Document
from docx.shared import Cm,Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from fastapi.testclient import TestClient
from app.engine import (audit,load,normalize,template_docx,component_docx,validate_docx,TCVN_MAP,identify,REFERENCE,pdf_convert)
from app.main import app
client=TestClient(app)

def fixture(admin=True):
    d=Document();s=d.sections[0]
    s.left_margin=Cm(1.3);s.right_margin=Cm(1);s.top_margin=Cm(1)
    if admin:
        d.add_paragraph('CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM')
        d.add_paragraph('Độc lập - Tự do - Hạnh phúc')
    else:d.add_paragraph('ĐẢNG CỘNG SẢN VIỆT NAM')
    p=d.add_paragraph('QUYẾT ĐỊNH');p.alignment=WD_ALIGN_PARAGRAPH.LEFT
    p=d.add_paragraph('Nội  dung đang  gặp   vấn đề chính tả và căn lề.');p.add_run(' Giữ chữ đậm.').bold=True
    for r in p.runs:r.font.name='Arial';r.font.size=Pt(11)
    t=d.add_table(rows=2,cols=2)
    t.cell(0,0).text='Học sinh';t.cell(0,1).text='Điểm';t.cell(1,0).text='Nguyễn Văn A';t.cell(1,1).text='9.0'
    out=BytesIO();d.save(out);return out.getvalue()

def upload(blob,name='test.docx'):return {'file':(name,blob,'application/vnd.openxmlformats-officedocument.wordprocessingml.document')}

def test_analyze_detects_margin_and_font():
    res=audit(load(fixture()),'auto')
    assert res['standard']=='admin'
    assert any(x['code']=='MARGIN' for x in res['issues'])
    assert any(x['code']=='FONT' for x in res['issues'])
    assert res['stats']['tables']==1

def test_auto_party():
    assert identify(load(fixture(False)))=='party'

def test_normalize_keeps_content_and_tables():
    orig=load(fixture())
    b=normalize(fixture(),'admin',{'page':True,'fonts':True,'paragraphs':True,'whitespace':False})
    res=load(b)
    assert [p.text for p in orig.paragraphs]==[p.text for p in res.paragraphs]
    assert res.tables[0].cell(1,0).text=='Nguyễn Văn A'
    assert abs(res.sections[0].left_margin.cm-3)<0.01
    assert res.paragraphs[3].runs[-1].bold is True

def test_whitespace_option_opt_in():
    changed=load(normalize(fixture(),'admin',{'page':False,'fonts':False,'paragraphs':False,'whitespace':True}))
    assert 'Nội dung đang gặp vấn đề' in changed.paragraphs[3].text

def test_tcvn_char_map():
    assert ''.join(TCVN_MAP.get(x,x) for x in 'hép')=='hộp'

def test_add_page_num_idempotent():
    initial=normalize(fixture(),'admin',{'page_numbers':True,'page':False,'fonts':False,'paragraphs':False})
    second=normalize(initial,'admin',{'page_numbers':True,'page':False,'fonts':False,'paragraphs':False})
    assert load(second).sections[0].header._element.xml.count('PAGE')==1

def test_template_every_kind_and_component():
    from app.engine import TEMPLATE_TYPES,COMPONENTS
    for policy in REFERENCE:
        for kind in TEMPLATE_TYPES:
            b=template_docx(kind,policy,{'organization':'TRƯỜNG THPT HỒ THỊ BI','role':'HIỆU TRƯỞNG'})
            doc=load(b)
            assert len(doc.tables)>=2
            assert 'HỒ THỊ BI' in doc.tables[0].cell(0,0).text
        for key,_ in COMPONENTS:
            assert len(load(component_docx(key,policy,{})).paragraphs)>0

def test_bad_payload():
    try:validate_docx(b'not a zip')
    except ValueError:pass
    else:raise AssertionError('must reject')

def test_http_health_and_catalog():
    assert client.get('/api/health').json()['ok'] is True
    assert len(client.get('/api/catalog').json()['components'])==14
    assert client.get('/').status_code==200
    assert client.get('/static/main.js').status_code==200

def test_http_analyze_and_normalize():
    r=client.post('/api/analyze',files=upload(fixture()),data={'standard':'auto'})
    assert r.status_code==200,r.text
    assert r.json()['stats']['tables']==1
    r=client.post('/api/normalize',files=upload(fixture()),data={'standard':'admin','options':json.dumps({'page':True,'fonts':True})})
    assert r.status_code==200,r.text
    assert load(r.content).sections[0].left_margin.cm>2.9

def test_http_batch_and_template():
    files=[('files',('one.docx',fixture(),'application/vnd.openxmlformats-officedocument.wordprocessingml.document')),
           ('files',('two.docx',fixture(False),'application/vnd.openxmlformats-officedocument.wordprocessingml.document'))]
    r=client.post('/api/batch',files=files,data={'standard':'auto','options':'{}'})
    assert r.status_code==200,r.text
    with zipfile.ZipFile(BytesIO(r.content)) as z:
        assert len(z.namelist())==3
        assert len(json.loads(z.read('BAO_CAO_KIEM_TRA.json')))==2
    r=client.post('/api/template',data={'kind':'bao-cao','standard':'admin','meta':'{"organization":"TRƯỜNG THPT HỒ THỊ BI"}'})
    assert r.status_code==200
    assert 'HỒ THỊ BI' in load(r.content).tables[0].cell(0,0).text

def test_cross_origin_block():
    r=client.post('/api/analyze',files=upload(fixture()),headers={'origin':'https://untrusted.example'})
    assert r.status_code==403

def test_invalid_doc_and_unsupported():
    r=client.post('/api/analyze',files=upload(b'wrong','test.docx'))
    assert r.status_code==400
    r=client.post('/api/normalize',files=upload(fixture()),data={'standard':'imaginary'})
    assert r.status_code==400

def test_pdf_conversion_if_available():
    try:p=pdf_convert(template_docx('bao-cao','admin',{}))
    except RuntimeError:return
    assert p.startswith(b'%PDF')

def test_vni_examples():
    from app.engine import _vni_convert
    assert _vni_convert('Vieät Nam')=='Việt Nam'
    assert _vni_convert('Tieáng Vieät')=='Tiếng Việt'
    assert _vni_convert('Tröôøng')=='Trường'
    assert _vni_convert('ñòa phöông')=='địa phương'

def test_image_and_landscape_survive():
    from docx.enum.section import WD_ORIENT
    from PIL import Image
    img=BytesIO();Image.new('RGB',(50,50),'white').save(img,'PNG');img.seek(0)
    d=Document();d.add_paragraph('CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM');d.add_picture(img,width=Cm(1))
    s=d.add_section();s.orientation=WD_ORIENT.LANDSCAPE;s.page_width=Cm(29.7);s.page_height=Cm(21)
    p=d.add_paragraph('Phụ lục ngang');o=BytesIO();d.save(o)
    normalized=load(normalize(o.getvalue(),'admin',{'page':True,'fonts':True,'paragraphs':True}))
    assert len(normalized.inline_shapes)==1
    assert normalized.sections[1].page_width>normalized.sections[1].page_height

def test_v11_preserves_header_and_signature_table_format():
    """Regression: real documents include national heading in a two-column table."""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    d=Document()
    t=d.add_table(rows=1,cols=2)
    a=t.cell(0,0).paragraphs[0];a.text='CƠ QUAN CẤP TRÊN';a.alignment=WD_ALIGN_PARAGRAPH.CENTER
    a.runs[0].font.size=Pt(11)
    b=t.cell(0,1).paragraphs[0];b.text='CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM';b.alignment=WD_ALIGN_PARAGRAPH.CENTER
    b.runs[0].font.size=Pt(12);b.runs[0].bold=True
    content=d.add_paragraph('Nội dung giữ nguyên.');content.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
    footer=d.add_table(rows=1,cols=2)
    pp=footer.cell(0,0).paragraphs[0];pp.text='Nơi nhận:';pp.alignment=WD_ALIGN_PARAGRAPH.LEFT
    rr=footer.cell(0,1).paragraphs[0];rr.text='HIỆU TRƯỞNG';rr.alignment=WD_ALIGN_PARAGRAPH.CENTER
    buf=BytesIO();d.save(buf)
    out=load(normalize(buf.getvalue(),'admin',{'page':True,'fonts':True,'paragraphs':True,'safe_layout':True}))
    assert out.tables[0].cell(0,0).paragraphs[0].alignment==WD_ALIGN_PARAGRAPH.CENTER
    assert out.tables[0].cell(0,0).paragraphs[0].runs[0].font.size.pt==11
    assert out.tables[0].cell(0,1).paragraphs[0].alignment==WD_ALIGN_PARAGRAPH.CENTER
    assert out.tables[0].cell(0,1).paragraphs[0].runs[0].font.size.pt==12
    assert out.tables[1].cell(0,0).paragraphs[0].alignment==WD_ALIGN_PARAGRAPH.LEFT
    assert out.tables[1].cell(0,1).paragraphs[0].alignment==WD_ALIGN_PARAGRAPH.CENTER


def test_v11_does_not_double_indent_tabbed_lists():
    d=Document()
    p=d.add_paragraph('\tCăn cứ quy định hiện hành;')
    p.paragraph_format.first_line_indent=None
    q=d.add_paragraph('I. MỤC ĐÍCH, YÊU CẦU')
    q.paragraph_format.first_line_indent=None
    m=d.add_paragraph('1. Mục đích')
    m.paragraph_format.first_line_indent=None
    buf=BytesIO();d.save(buf)
    out=load(normalize(buf.getvalue(),'admin',{'page':False,'paragraphs':True,'safe_layout':True}))
    assert out.paragraphs[0].paragraph_format.first_line_indent is None
    assert out.paragraphs[1].paragraph_format.first_line_indent is None
    assert out.paragraphs[2].paragraph_format.first_line_indent is None
