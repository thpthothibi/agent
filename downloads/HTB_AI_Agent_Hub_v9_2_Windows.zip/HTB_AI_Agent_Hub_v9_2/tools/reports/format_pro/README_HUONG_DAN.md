# HTB DOCUMENT FORMAT PRO V1.1 — BẢN SỬA LỖI XÔ LỆCH BỐ CỤC

Khắc phục lỗi của phiên bản 1.0 khi chuẩn hóa văn bản có **bảng quốc hiệu/tên cơ quan, khối chữ ký, tab đầu dòng và danh sách tự động**.

## Cài đặt
1. Giải nén toàn bộ thư mục, không chép lẻ từng file.
2. Chạy `CHAY_TREN_WINDOWS.bat` trong Windows 11, Python 3.11+ cần được cài.
3. Mở http://127.0.0.1:8765, chọn DOCX và **giữ bật “Bảo vệ bố cục”**.
4. Bấm “Rà soát văn bản” trước và chỉ chuẩn hóa một bản sao; mở kiểm tra Word trước khi sử dụng.

## Bản 1.1 đã thay đổi
- Không tự căn đều hai lề hay thụt đầu dòng đối với ô bảng, quốc hiệu, số ký hiệu, nơi nhận, chữ ký, tiêu đề, đánh số/bullet.
- Không tự đổi mọi cỡ chữ trong ô bảng thành 13pt; giữ kích thước, chữ đậm, chữ nghiêng ban đầu.
- Không cộng thêm thụt đầu dòng khi văn bản đã sử dụng Tab.
- Kiểm tra bảng vượt vùng in, bảng căn đều sai và Tab + thụt dòng đầu chồng nhau.
- Bảo vệ bố cục bật sẵn; có thể bỏ chọn cho nhu cầu chỉnh mạnh nhưng cần duyệt thủ công.

## Giới hạn còn lại
Một DOCX đã bị làm hỏng bởi phiên bản 1.0 không thể tự suy ra toàn bộ thể thức gốc. Bản 1.1 **ngăn hỏng thêm**, không cam kết tự phục hồi bố cục gốc. Đối với tài liệu đã hỏng, sử dụng bản DOCX được sửa riêng hoặc bản gốc để chạy lại.

Lề A4, font và thể thức vẫn chỉ là hỗ trợ; bảng quá rộng phải chỉnh độ rộng theo nội dung và kiểm tra bằng Word. Không có tính năng tự xem trước trang in bằng trình duyệt, không có add-in Word hay chữ ký số. Bản chạy cục bộ không có xác thực; không mở ra Internet công khai.

Chạy test: `python -m pytest -q tests/test_system.py`.
