# Đề xuất tích hợp HTB Document Format Pro vào VPĐT của trường

## Kiến trúc an toàn (chưa triển khai với Appwrite thật)

```
[Người dùng đăng nhập VPĐT]
       │
       ▼
[Cloudflare Worker / Website VPĐT]
       │ xác thực phiên Appwrite + kiểm tra vai trò + giới hạn tần suất
       ▼
[API Gateway cùng domain của trường]
       │ HTTPS, token dịch vụ, kiểm tra kích thước và định dạng file
       ▼
[HTB Format Pro Python Service ở mạng riêng]
       │
       ├─ POST /api/analyze   → JSON kết quả rà soát
       ├─ POST /api/normalize → DOCX tạo bản mới
       └─ POST /api/pdf       → PDF (LibreOffice headless)
       │
       ▼
[Appwrite Storage bản gốc/bản mới + TablesDB lịch sử thao tác]
       │
       ▼
[Văn bản đi → Kiểm tra thể thức → Trình ký → Ký số → Phát hành]
```

### Vì sao không đưa toàn bộ vào Cloudflare Workers?

Workers thuận lợi để phục vụ giao diện, xác thực và điều phối request, nhưng bộ xử lý OOXML Python và xuất PDF qua LibreOffice phải được vận hành ở môi trường có runtime tương ứng. Dùng Appwrite Functions chạy Python để xử lý DOCX là một hướng cần kiểm thử giới hạn bộ nhớ, thời gian, dung lượng; PDF thường nên chạy trên dịch vụ container riêng.

### Công việc còn phải làm trước khi sử dụng production

1. Kết nối backend qua API nội bộ với tên miền HTTPS, bảo vệ bằng Appwrite JWT xác thực trên gateway; tuyệt đối không đặt API key quản trị trong JavaScript.
2. Phân quyền các vai trò: văn thư, người soạn, người duyệt, quản trị; nhật ký văn bản chỉ lưu metadata cần thiết.
3. Thiết kế Storage hai bản (`original_id`, `normalized_id`), kiểm soát phiên bản và khả năng hoàn tác.
4. Quét tệp, giới hạn dung lượng, deadline/tần suất theo tài khoản, chống zip bomb, chạy tiến trình chuyển đổi dưới người dùng không đặc quyền, không Internet egress.
5. Kiểm thử 20–50 văn bản thực tế của trường, bao gồm quốc hiệu trong bảng, hình ảnh logo, chữ ký, chân trang, header, văn bản Đảng, bảng/biểu, phụ lục ngang và nhiều section.
6. Phân biệt văn bản mật/nhạy cảm theo quy chế bảo mật, không tự động đưa lên bên thứ ba.
7. Cho văn thư xem trước PDF và xác nhận “Đã kiểm tra thể thức” trước nút Trình ký.

### Ghi chú deployment

- Dockerfile trong gói phục vụ triển khai dịch vụ tại máy chủ tin cậy.
- `docker compose` nên chỉ bind `127.0.0.1:8765`, đặt reverse proxy HTTPS + auth phía trước.
- Bản frontend trong gói sử dụng đường dẫn tuyệt đối `/api` và `/static`; khi chạy dưới đường dẫn con của VPĐT cần cấu hình rewrite hoặc sửa base path.
- Mã nguồn được phát hành như một bản thử độc lập, **chưa sửa hoặc triển khai vào kho GitHub/worker/Appwrite hiện có của trường**.
