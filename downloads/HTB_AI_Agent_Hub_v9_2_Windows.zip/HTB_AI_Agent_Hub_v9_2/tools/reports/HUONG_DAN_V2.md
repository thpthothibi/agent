# HTB AI Agent báo cáo v2 tích hợp HTB Format Pro

Đã tìm lại đúng hai bộ nguồn ngày 15/10/2026: HTB_Document_Format_Pro_V1_FULL.zip và HTB_Format_Pro_v1_1_Ban_Sua_Loi.zip. Bản v2 sử dụng bản v1.1 đã sửa lỗi bố cục để đưa công cụ định dạng vào agent báo cáo.

Đây là phần mềm HTB đã xây dựng độc lập trước đó, dựa trên nhu cầu chức năng của V-FORMAT. Không phải mã nguồn hoặc bộ cài V-FORMAT của TAFINEX, không tương đương toàn bộ sản phẩm thương mại. Không có add-in Word. Các bộ quy tắc định dạng kế thừa bản nguồn ngày 15/10, chưa được chứng nhận tuân thủ pháp luật hiện hành.

## Cài và chạy trên Windows

1. Cài Python 3.11 hoặc 3.12 từ https://www.python.org/downloads/ và bật Add Python to PATH.
2. Giải nén toàn bộ ZIP vào thư mục có quyền ghi, ví dụ D:\HTB_Agent_v2. Không chạy trực tiếp trong ZIP.
3. Chạy CAI_DAT.bat một lần. Cần Internet để cài thư viện.
4. Chạy CHAY_AGENT.bat, mở http://127.0.0.1:8501 nếu trình duyệt không tự mở.
5. Giữ cửa sổ lệnh trong khi sử dụng. Đóng cửa sổ để dừng agent.

PDF cần cài LibreOffice: https://www.libreoffice.org/download/download-libreoffice/. Trình chuyển đổi tự tìm LibreOffice trong PATH hoặc thư mục Program Files trên Windows. Nếu chưa có, vẫn tải Word/Excel/TXT bình thường và có thể xuất PDF từ Word.

Bản v2 đã kiểm tra trên Linux; các tệp BAT và chuyển PDF trên máy Windows vẫn cần kiểm tra thực tế trên máy của người dùng.

## Hai không gian làm việc

Chọn ở thanh bên trái:

**Agent báo cáo**: nạp dữ liệu, tổng hợp, viết nhận xét, tạo khung báo cáo có tên cơ quan/quốc hiệu/nơi nhận/khối chữ ký, tự chuẩn hóa bằng bộ HTB Format Pro, rà soát thể thức rồi tải Word/Excel/TXT/PDF.

**HTB Format Pro**: toàn bộ nhóm chức năng đã có trong bộ nguồn HTB v1.1 nằm trong cùng giao diện agent:

- Rà soát DOCX: khổ giấy, lề, phông, cỡ chữ, cách đoạn, khoảng trắng, gợi ý chính tả giới hạn, quốc hiệu, bảng quá rộng và lỗi thụt đầu dòng.
- Chuẩn hóa bản sao: bảo vệ bố cục bật sẵn; tùy chọn lề A4, phông, đoạn, khoảng trắng, chuyển mã theo phông, căn giữa theo chiều dọc ô bảng, số trang.
- Xử lý hàng loạt 1–12 DOCX; tối đa 15 MB/tệp. Tải từng Word hoặc toàn bộ ZIP cùng kết quả rà soát JSON. Có kiểm tra trước và sau chuẩn hóa.
- 12 mẫu văn bản: quyết định, kế hoạch, báo cáo, thông báo, tờ trình, công văn, biên bản, giấy mời, nghị quyết, hướng dẫn, quy chế, chương trình.
- 14 thành phần: quốc hiệu, cơ quan, số ký hiệu, địa danh/ngày tháng, tên loại, trích yếu, kính gửi, căn cứ, nội dung, chữ ký, nơi nhận, độ khẩn, dự thảo, sao y. Tải riêng hoặc chèn vào đầu/cuối DOCX đã chọn.
- Thông tin cơ quan: tên chủ quản, đơn vị, địa danh, chức danh, tên người ký; lưu trên máy hoặc nhập/xuất JSON. Đổi thông tin cho phù hợp trước khi tạo văn bản Đảng. Không tự tạo chữ ký thật hoặc cấp số văn bản.
- Chuyển PDF bằng LibreOffice cục bộ. Xem trước nội dung chữ trong giao diện không phải bản xem trước trang in.

Giao diện cũ cũng được giữ trong thư mục format_pro. Muốn mở riêng, chạy MO_FORMAT_GOC.bat tại thư mục chính rồi vào http://127.0.0.1:8765. Chỉ cần cài thư viện bằng CAI_DAT.bat ở thư mục chính. Giữ nguyên cấu trúc thư mục khi sao chép.

## Chạy thử agent báo cáo

1. Chọn Agent báo cáo; dữ liệu minh họa đã bật sẵn nếu chưa nạp tệp.
2. Nhóm theo Tổ; cột số Số tiết và Số hồ sơ; phép tính Tổng.
3. Bật khung báo cáo HTB và chuẩn hóa Word; chọn thể thức Hành chính hoặc tự nhận diện.
4. Bấm Tạo báo cáo, sửa nội dung nếu cần rồi tải Word và Excel.
5. Bấm Tạo thêm bản PDF nếu máy có LibreOffice.

Kết quả minh họa: Toán 35 tiết/7 hồ sơ; Ngữ văn 37/9; Ngoại ngữ 16/2. Các số này là giả để kiểm tra công cụ, không dùng làm số liệu thực của nhà trường.

## Đọc và tính dữ liệu

Excel XLSX đọc tất cả sheet có dữ liệu. CSV hỗ trợ UTF-8 và CP1258. Có thể chọn dòng tiêu đề, lọc theo tệp, sheet, giá trị và ngày. Các bảng được nối theo tên cột, không tự ghép theo tên hoặc khóa. Cần thống nhất tên cột trước khi nối. Một tệp đọc lỗi sẽ chặn tạo báo cáo, không âm thầm bỏ qua nguồn.

Cột số được gợi ý để người dùng kiểm tra trước khi tạo. Có tổng, trung bình, nhỏ nhất, lớn nhất. Số dòng là số bản ghi, không tự coi là số người. Ô thiếu không coi là 0. Dòng trùng chỉ bỏ khi người dùng chọn khóa và bật bỏ trùng. Không tự quy đổi giờ, phút, tiết, đơn vị hoặc định mức.

Ô văn bản dùng 1.234,5 thì chọn quy tắc VN; dùng 1,234.5 thì chọn Quốc tế. Ô Excel dạng số giữ giá trị gốc. Không cộng cột mã, SĐT, STT, SBD. Nhãn kỳ báo cáo không tự lọc ngày; cần dùng bộ lọc ngày.

Word/PDF/TXT đọc thành văn bản tham khảo. Chưa tự bóc bảng trong PDF/Word thành số. PDF ảnh chưa có OCR, chưa nhận DOC/XLS cũ. Bảng kết quả Word giới hạn 8 cột và 300 dòng; Excel chứa đầy đủ. Tối đa 200.000 dòng/lượt. Nhiều file lớn vẫn có thể vượt bộ nhớ máy.

Excel kết quả kèm __tep_nguon, __sheet_nguon, __dong_nguon và danh mục SHA256 để đối chiếu nguồn. Không tự lưu kết quả báo cáo xuống máy; cần bấm tải trước khi đóng phiên. Thay đổi dữ liệu hoặc cấu hình phải tạo lại để tránh báo cáo cũ. Thông tin cơ quan là phần duy nhất được lưu khi bấm Lưu trên máy.

Khung báo cáo HTB sử dụng mẫu báo cáo sẵn có của HTB Format Pro, điền nội dung tổng hợp và bảng kết quả vào trước nơi nhận/chữ ký. Với mẫu Word riêng tùy chọn, tắt khung HTB: bản này vẫn giữ tài liệu đó làm phần mở đầu và nối báo cáo ở trang mới, chưa tự hiểu mọi mẫu hay điền mọi ô bất kỳ.

## AI và chế độ không khóa

Tổng hợp và tất cả công cụ định dạng chạy không cần key, không gửi dữ liệu lên dịch vụ AI.

Ollama: cài https://ollama.com/, tải model phù hợp máy và nhập đúng tên model đã cài. Kết nối tại http://127.0.0.1:11434; không tải sẵn mô hình.

OpenAI API hoặc Gemini API: nhập tên model được tài khoản cho phép và khóa API tương ứng. Chỉ gửi dữ liệu khi bật cho phép. Gửi bảng tổng hợp, yêu cầu và tên nguồn; chỉ gửi văn bản tham khảo nếu chọn. Tên nhóm vẫn có thể là thông tin cá nhân. Không gửi bảng dòng gốc. Không lưu khóa API ra tệp.

Các gói thuê bao ChatGPT/Gemini và dịch vụ API được quản lý riêng; không tự sử dụng phiên đăng nhập hoặc quyền lợi thuê bao để thay API. Hạn mức/chi phí tùy tài khoản dịch vụ. Không có gọi AI thực tế trong quá trình kiểm thử này; cấu trúc kết nối được kiểm tra bằng phản hồi giả lập.

AI viết phần nhận xét đề xuất; chương trình tính số liệu. Cần rà soát nội dung AI trước khi sử dụng. Không tự suy diễn nguyên nhân hoặc số liệu chưa có. Nếu AI lỗi, xuất báo cáo theo quy tắc và ghi lỗi. Giới hạn 30.000 ký tự văn bản và 100.000 ký tự toàn bộ yêu cầu, thời gian chờ 180 giây.

## Phạm vi và thay đổi kỹ thuật

Chưa tự lấy dữ liệu từ VietSchool/website/Drive; chưa có OCR, tự chạy lịch hoặc theo dõi thư mục. Chưa tự điền B1/B2/C3 hay biểu mẫu riêng. Không gửi mail, công bố báo cáo hoặc ký số. Không cần đăng nhập để chạy bản cục bộ; trình khởi chạy chỉ lắng nghe tại 127.0.0.1.

Bộ định dạng khôi phục được sửa thêm:
- Giữ tham chiếu phần tử XML khi nhận diện đoạn trong bảng; không dùng id tạm của đối tượng. Tránh thụt dòng nhầm vào bảng tên cơ quan và khối chữ ký.
- Tìm LibreOffice trong Program Files và tạo URI cấu hình đúng trên Windows.
- Luồng báo cáo dùng dấu nhận diện ổn định để nút tải PDF không mất sau lần giao diện chạy lại.

Các chức năng mới: tích hợp chung giao diện; chuẩn hóa và kiểm tra báo cáo đầu ra; điền khung báo cáo HTB; chèn thành phần vào DOCX; lưu/nhập thông tin cơ quan; Gemini API.

## Kiểm tra

Sau khi cài thư viện, `python -m unittest discover -s . -p "test_*.py" -v` kiểm tra lõi và tích hợp. Muốn chạy test gốc: cài thêm pytest/httpx, chuyển vào format_pro và chạy `python -m pytest -q tests/test_system.py`. Xem KIEM_TRA.txt về kết quả đã chạy.

Tài liệu kỹ thuật: https://docs.streamlit.io/ ; https://docs.ollama.com/api ; https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create ; https://ai.google.dev/api/generate-content
