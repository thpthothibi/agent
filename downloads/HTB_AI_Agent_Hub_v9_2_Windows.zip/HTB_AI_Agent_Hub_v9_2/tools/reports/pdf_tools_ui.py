import hashlib,io,json
from pathlib import Path
import streamlit as st
from pdf_tools import *

BASE=Path(__file__).parent

@st.cache_data(show_spinner=False)
def cached_info(data,password):return inspect_pdf(data,password)


def _download_result(stamp):
    result=st.session_state.get('pdf_tool_result')
    if result and result['stamp']==stamp:
        for note in result.get('notes',[]):st.info(note)
        st.download_button('⬇ Tải kết quả',result['data'],result['name'],mime=result.get('mime'),key='pdf_result_download')
        if Path(result['name']).suffix.lower() in ('.docx','.xlsx','.txt'):
            if st.button('Đưa kết quả vào báo cáo nhiều nguồn'):
                origin=result.get('origin',{})
                converted_name=(Path(origin.get('file','PDF')).stem+'_'+result['name'])
                item={'name':converted_name,'data':result['data'],'origin':origin}
                queue=st.session_state.get('pdf_bridge',[])
                queue=[q for q in queue if q['name']!=converted_name]
                st.session_state['pdf_bridge']=(queue+[item])[-10:]
                st.session_state['pending_navigation']='Tổng hợp nhiều nguồn'
                st.rerun()
        if result.get('report'):
            st.json(result['report'])
            st.download_button('Tải nhật ký xử lý JSON',json.dumps(result['report'],ensure_ascii=False,indent=2).encode(),'Nhat_ky_PDF.json','application/json')
    elif result:st.caption('Tùy chọn hoặc nguồn đã đổi. Bấm xử lý để tạo bản mới.')


def render():
    st.title('📄 Công cụ PDF')
    st.caption('Xử lý tại máy • Tạo bản sao • Không cần API • Có xem trước và chọn trang')
    tool=st.selectbox('Chọn công cụ PDF',[
        'PDF → Word','PDF → Excel','PDF → Ảnh / TXT','Ghép nhiều PDF','Tách / Xóa / Sắp xếp / Xoay / Cắt trang',
        'Nén PDF','Ảnh / Word / Excel / PowerPoint → PDF','Đánh số trang / Watermark','Đặt / Gỡ mật khẩu','OCR PDF quét'])
    if tool=='Ghép nhiều PDF':
        files=st.file_uploader('Chọn 2–20 PDF, tổng không quá 100 MB',type=['pdf'],accept_multiple_files=True,key='pdf_merge_files')
        if not 2<=len(files)<=20:st.info('Chọn từ 2 đến 20 PDF để ghép.');return
        labels=[f'{i+1:02d} · {f.name}' for i,f in enumerate(files)]
        order=st.multiselect('Thứ tự ghép (bỏ chọn rồi chọn lại để đổi vị trí)',labels,default=labels)
        items=[]
        for label in order:
            i=labels.index(label);f=files[i]
            with st.expander(label):
                password=st.text_input('Mật khẩu nếu có',type='password',key=f'merge_password_{i}')
                spec=st.text_input('Trang cần lấy (trống = tất cả)',placeholder='1-3,5',key=f'merge_spec_{i}')
            items.append((f.name,f.getvalue(),password,spec))
        signature=hashlib.sha256(json.dumps([(n,p,s) for n,_,p,s in items]).encode()+b''.join(d for _,d,_,_ in items)).hexdigest()
        if st.button('Ghép PDF',type='primary',disabled=len(items)<2):
            try:
                with st.spinner('Đang ghép PDF…'):data,manifest=merge_pdfs(items)
                st.session_state['pdf_tool_result']={'stamp':signature,'data':data,'name':'PDF_ghep.pdf','mime':'application/pdf','report':manifest}
            except Exception as exc:st.error(str(exc))
        _download_result(signature);return
    if tool=='Ảnh / Word / Excel / PowerPoint → PDF':
        kind=st.radio('Loại nguồn',['Ảnh JPG/PNG','Word / Excel / PowerPoint'],horizontal=True)
        if kind=='Ảnh JPG/PNG':
            files=st.file_uploader('Chọn 1–50 ảnh',type=['jpg','jpeg','png'],accept_multiple_files=True,key='pdf_image_inputs')
            if not files:return
            labels=[f'{i+1:02d} · {f.name}' for i,f in enumerate(files)]
            order=st.multiselect('Thứ tự ảnh trong PDF',labels,default=labels)
            a4=st.checkbox('Đặt ảnh vừa trang A4, giữ tỷ lệ',value=True)
            items=[(files[labels.index(x)].name,files[labels.index(x)].getvalue()) for x in order]
            signature=hashlib.sha256(json.dumps([order,a4]).encode()+b''.join(d for _,d in items)).hexdigest()
            if st.button('Tạo PDF từ ảnh',type='primary'):
                try:
                    with st.spinner('Đang tạo PDF…'):data=images_to_pdf(items,a4)
                    st.session_state['pdf_tool_result']={'stamp':signature,'data':data,'name':'Anh_thanh_PDF.pdf','mime':'application/pdf'}
                except Exception as exc:st.error(str(exc))
        else:
            f=st.file_uploader('Chọn DOCX, XLSX hoặc PPTX',type=['docx','xlsx','pptx'],key='pdf_office_input')
            if not f:return
            signature=hashlib.sha256(f.name.encode()+f.getvalue()).hexdigest()
            st.caption('Cần LibreOffice. Với Excel, cấu hình vùng in/ngắt trang trong bảng tính trước để tránh quá nhiều trang.')
            if st.button('Chuyển Office sang PDF',type='primary'):
                try:
                    with st.spinner('LibreOffice đang chuyển…'):data=office_to_pdf(f.name,f.getvalue())
                    st.session_state['pdf_tool_result']={'stamp':signature,'data':data,'name':Path(f.name).stem+'.pdf','mime':'application/pdf'}
                except Exception as exc:st.error(str(exc))
        _download_result(signature);return

    source=st.file_uploader('Chọn PDF, tối đa 50 MB và 300 trang',type=['pdf'],key='pdf_source')
    demo=st.checkbox('Dùng PDF minh họa 3 trang',value=False)
    data=source.getvalue() if source else (BASE/'mau'/'PDF_minh_hoa_3_trang.pdf').read_bytes() if demo else None
    if not data:st.info('Chọn tệp hoặc bật PDF minh họa để bắt đầu.');return
    password=st.text_input('Mật khẩu mở PDF (nếu có)',type='password',key='pdf_source_password')
    try:info=cached_info(data,password)
    except Exception as exc:st.error(str(exc));return
    count=len(info['pages']);a,b,c=st.columns(3)
    a.metric('Số trang',count);b.metric('Dung lượng',f'{len(data)/1024:.1f} KB');c.metric('Trang chưa đọc được chữ',sum(p['Ký tự đọc được']==0 for p in info['pages']))
    if info['signed']:st.warning('PDF có trường chữ ký. Bản xử lý có thể làm mất hiệu lực chữ ký số; giữ bản gốc để đối chiếu.')
    if info['encrypted']:st.caption('PDF đã được mở bằng mật khẩu cung cấp. Bản xử lý không đặt mật khẩu lại, trừ công cụ Đặt mật khẩu; khi nén không giảm dung lượng thì giữ tệp gốc.')
    with st.expander('Xem trước trang / thông tin PDF'):
        p=st.number_input('Trang xem trước',min_value=1,max_value=count,value=1)
        if st.button('Hiện trang xem trước'):
            try:st.image(preview(data,int(p)-1,password),caption=f'Trang {p}',width=500)
            except Exception as exc:st.error(str(exc))
        st.dataframe(info['pages'],hide_index=True,width='stretch')
    spec='';options={};run=None;name='Ket_qua.pdf';mime='application/pdf';action='Xử lý PDF';notes=[]
    if tool=='PDF → Word':
        spec=st.text_input('Trang cần chuyển (trống = tất cả)',placeholder='1-3,5',key='pdf_word_pages')
        modes={'Word sửa được chữ và bảng':'layout','Chữ đơn giản':'text','Word dạng ảnh giữ hình thức':'image'}
        label=st.radio('Cách chuyển Word',list(modes))
        options={'mode':modes[label]}
        st.caption('Chế độ chữ/bảng có thể lệch bố cục phức tạp. Word dạng ảnh giữ hình thức nhưng không sửa riêng từng chữ. PDF quét cần OCR nếu muốn sửa chữ.')
        run=lambda:pdf_to_word(data,spec,password,options['mode'])
        name='PDF_chuyen_Word.docx';mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document';action='Chuyển PDF sang Word'
    elif tool=='PDF → Excel':
        spec=st.text_input('Trang cần trích (trống = tất cả)',placeholder='1-3,5',key='pdf_excel_pages')
        strategy=st.radio('Nhận diện bảng',['Có đường kẻ','Theo vị trí chữ (thử khi bảng không có đường kẻ)'])
        header=st.checkbox('Dòng đầu mỗi bảng là tiêu đề',value=True)
        options={'strategy':'lines' if strategy=='Có đường kẻ' else 'text','header':header}
        st.caption('Mỗi bảng nằm ở một sheet, kèm văn bản theo trang. Cần đối chiếu ô gộp và số thập phân. Không tự suy ra bảng số từ bản quét.')
        run=lambda:pdf_to_excel(data,spec,password,options['strategy'],header)
        name='PDF_chuyen_Excel.xlsx';mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';action='Chuyển PDF sang Excel'
    elif tool=='PDF → Ảnh / TXT':
        spec=st.text_input('Trang cần lấy',placeholder='Trống = tất cả',key='pdf_export_pages')
        kind=st.radio('Đầu ra',['Ảnh PNG (ZIP)','Ảnh JPG (ZIP)','Văn bản TXT'])
        dpi=st.slider('DPI ảnh',72,240,130)
        options={'kind':kind,'dpi':dpi}
        if kind=='Văn bản TXT':
            def run():
                texts,blank=extract_text(data,spec,password)
                if not any(p['text'].strip() for p in texts):raise ValueError('Không đọc được chữ. Hãy dùng OCR.')
                text='\n\n'.join(f'--- Trang {p["page"]} ---\n{p["text"]}' for p in texts)
                return text.encode('utf-8-sig'),{'note':'Trang chưa đọc được chữ: '+str(blank) if blank else 'Đã trích chữ từ các trang đã chọn.'}
            name='Noi_dung_PDF.txt';mime='text/plain'
        else:
            run=lambda:pdf_to_images(data,spec,password,'PNG' if kind.startswith('Ảnh PNG') else 'JPEG',dpi)
            name='Anh_tu_PDF.zip';mime='application/zip'
        action='Xuất ảnh / văn bản'
    elif tool=='Tách / Xóa / Sắp xếp / Xoay / Cắt trang':
        method=st.selectbox('Thao tác trang',['Lấy trang / sắp xếp lại','Tách thành nhiều file','Xóa trang','Xoay trang','Cắt lề hiển thị'])
        options={'method':method}
        if method=='Tách thành nhiều file':
            spec=st.text_input('Các nhóm trang cách nhau bằng dấu ;','1;2-3' if count>=3 else '1',key='pdf_split_spec')
            st.caption('Ví dụ: 1-2;3-5;6. Mỗi nhóm thành một PDF trong ZIP.')
            run=lambda:split_pdf(data,spec,password);name='PDF_da_tach.zip';mime='application/zip'
        else:
            spec=st.text_input('Trang áp dụng / thứ tự trang','' if method!='Xóa trang' else '1',placeholder='Ví dụ 3,1-2 hoặc 5-1',key='pdf_edit_spec')
            if method=='Lấy trang / sắp xếp lại':run=lambda:select_pages(data,spec,password);name='PDF_trang_da_chon.pdf'
            elif method=='Xóa trang':
                st.caption('Chỉ các trang được chỉ định sẽ bị loại khỏi bản sao. Không xóa file gốc.')
                run=lambda:delete_pages(data,spec,password);name='PDF_da_xoa_trang.pdf'
            elif method=='Xoay trang':
                degrees=st.selectbox('Góc theo chiều kim đồng hồ',[90,180,270]);options['degrees']=degrees
                run=lambda:rotate_pdf(data,spec,degrees,password);name='PDF_da_xoay.pdf'
            else:
                st.info('Cắt vùng hiển thị; không xóa hẳn dữ liệu ngoài vùng cắt và không dùng để che thông tin mật.')
                cols=st.columns(4);margins=[col.number_input(label,min_value=0.0,max_value=200.0,value=0.0,step=1.0) for col,label in zip(cols,['Trái mm','Phải mm','Trên mm','Dưới mm'])]
                options['margins']=margins
                run=lambda:crop_pdf(data,spec,*margins,password=password);name='PDF_da_cat_le.pdf'
        action='Áp dụng thao tác trang'
    elif tool=='Nén PDF':
        label=st.radio('Mức nén',['Giữ lớp chữ và chất lượng nội dung','Giảm chất lượng ảnh, giữ lớp chữ','Nén mạnh bằng ảnh toàn trang'])
        mode=['lossless','images','raster'][['Giữ lớp chữ và chất lượng nội dung','Giảm chất lượng ảnh, giữ lớp chữ','Nén mạnh bằng ảnh toàn trang'].index(label)]
        quality=st.slider('Chất lượng ảnh JPEG',30,95,75,disabled=mode=='lossless')
        dpi=st.slider('DPI khi nén mạnh',72,200,110,disabled=mode!='raster')
        accepted=True
        if mode=='raster':accepted=st.checkbox('Chấp nhận bản nén bằng ảnh không còn lớp chữ, liên kết và biểu mẫu tương tác',value=False)
        options={'mode':mode,'quality':quality,'dpi':dpi,'accepted':accepted}
        st.caption('Không bảo đảm mọi PDF đều nhỏ hơn. Nếu kết quả lớn hơn, công cụ giữ bản gốc và báo không giảm dung lượng.')
        if accepted:run=lambda:compress_pdf(data,mode,quality,dpi,password)
        name='PDF_da_nen.pdf';action='Nén PDF'
    elif tool=='Đánh số trang / Watermark':
        spec=st.text_input('Trang áp dụng (trống = tất cả)',key='pdf_stamp_pages')
        text=st.text_input('Chữ watermark (để trống nếu chỉ đánh số)',max_chars=150)
        numbers=st.checkbox('Thêm số trang',value=True)
        start=st.number_input('Số bắt đầu',min_value=1,value=1)
        options={'text':text,'numbers':numbers,'start':start}
        if text or numbers:run=lambda:stamp_pdf(data,spec,password,text,numbers,int(start))
        name='PDF_da_dong_dau.pdf';action='Thêm watermark / số trang'
    elif tool=='Đặt / Gỡ mật khẩu':
        method=st.radio('Mật khẩu',['Đặt mật khẩu mở mới','Gỡ mật khẩu đã biết'])
        new=st.text_input('Mật khẩu mới (ít nhất 6 ký tự)',type='password') if method.startswith('Đặt') else ''
        options={'method':method,'new':new}
        if method.startswith('Gỡ') and not info['encrypted']:st.info('Tệp này chưa được mã hóa bằng mật khẩu.')
        run=lambda:set_password(data,new,password,remove=method.startswith('Gỡ'))
        name='PDF_dat_mat_khau.pdf' if method.startswith('Đặt') else 'PDF_bo_mat_khau.pdf';action='Áp dụng mật khẩu'
    else:
        status=ocr_status()
        if not status['available']:st.info(status['note']+' Xem HUONG_DAN_PDF.md trong bộ cài.');return
        languages=st.multiselect('Ngôn ngữ OCR đã cài',status['languages'],default=[x for x in ['vie','eng'] if x in status['languages']])
        if 'vie' not in status['languages']:st.warning('Chưa có gói vie; OCR tiếng Việt có thể sai nhiều dấu. Cài gói vie trước khi nhận dạng hồ sơ tiếng Việt.')
        spec=st.text_input('Trang cần OCR (tối đa 30 trang/lượt)',key='pdf_ocr_pages')
        output=st.selectbox('Kết quả OCR',['docx','txt','pdf'],format_func=lambda x:{'docx':'Word có chữ OCR','txt':'Văn bản TXT','pdf':'PDF có lớp chữ tìm kiếm'}[x])
        dpi=st.slider('DPI OCR',100,240,200)
        options={'languages':languages,'output':output,'dpi':dpi}
        st.caption('OCR có thể sai tên, dấu và số; cần rà soát. Word OCR là chữ theo dòng, không tự khôi phục bảng. PDF OCR dựng lại trang từ ảnh.')
        if languages:run=lambda:ocr_pdf(data,spec,password,'+'.join(languages),output,dpi)
        name='PDF_OCR.'+output;mime={'docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','txt':'text/plain','pdf':'application/pdf'}[output];action='Chạy OCR'
    stamp=hashlib.sha256(tool.encode()+data+json.dumps([spec,password,options],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    if st.button(action,type='primary',disabled=run is None):
        try:
            with st.spinner('Đang xử lý; giữ cửa sổ này mở…'):result=run()
            report={};notes=[]
            if isinstance(result,tuple):blob,report=result
            else:blob=result
            if report.get('note'):notes.append(report['note'])
            if report.get('notes'):notes.extend(report['notes'])
            st.session_state['pdf_tool_result']={'stamp':stamp,'data':blob,'name':name,'mime':mime,'report':report,'notes':notes,'origin':{'file':source.name if source else 'PDF_minh_hoa_3_trang.pdf','sha256':hashlib.sha256(data).hexdigest(),'tool':tool,'pages':spec or 'all'}}
        except Exception as exc:
            st.session_state.pop('pdf_tool_result',None);st.error(f'Không tạo được kết quả: {exc}')
    _download_result(stamp)
