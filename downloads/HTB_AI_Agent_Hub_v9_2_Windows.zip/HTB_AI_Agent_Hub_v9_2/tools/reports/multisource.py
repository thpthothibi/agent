"""Multi-source ETL with explicit mapping, strict joins and row provenance."""
from __future__ import annotations
import io,json,re,hashlib,unicodedata
from pathlib import Path
import pandas as pd
from core import read_source,analyse,export_xlsx,safe_excel
TRACE='__nguon_chi_tiet'
SYSTEM={'__tep_nguon','__sheet_nguon','__dong_nguon',TRACE}


def canon(value):
    if pd.isna(value): return ''
    return re.sub(r'\s+',' ',unicodedata.normalize('NFC',str(value)).strip()).casefold()


def extract_inputs(inputs, header=0, pdf_tables=False, word_tables=False):
    tables=[];docs=[];sources=[];warnings=[]
    for source_index,(name,data) in enumerate(inputs,1):
        sid=f'S{source_index:03d}'
        sources.append({'id':sid,'name':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
        ext=Path(name).suffix.lower()
        extracted=[];text=''
        if ext=='.json':
            obj=json.loads(data.decode('utf-8-sig'))
            if not isinstance(obj,list) or any(not isinstance(x,dict) for x in obj): raise ValueError(f'{name}: JSON phải là danh sách các đối tượng.')
            frame=pd.json_normalize(obj)
            frame=frame.apply(lambda col:col.map(lambda v:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v))
            extracted=[frame]
        elif ext=='.pdf':
            import pdfplumber
            with pdfplumber.open(io.BytesIO(data)) as pdf:
                if len(pdf.pages)>300:raise ValueError(f'{name}: vượt 300 trang/lượt.')
                blank_pages=[]
                for page_no,page in enumerate(pdf.pages,1):
                    txt=page.extract_text() or ''
                    if txt.strip():docs.append({'source_id':sid,'name':name,'location':f'Trang {page_no}','text':txt})
                    else:blank_pages.append(page_no)
                    if pdf_tables:
                        for ti,rows in enumerate(page.extract_tables(),1):
                            table=_rows_frame(rows,header)
                            if table.empty:continue
                            table['__sheet_nguon']=f'Trang {page_no} / bảng {ti}'
                            extracted.append(table)
                if blank_pages:warnings.append(f'{sid} {name}: {len(blank_pages)} trang không đọc được chữ (có thể trang trắng hoặc ảnh); trang: '+', '.join(map(str,blank_pages[:30])))
            if not any(d['source_id']==sid for d in docs):warnings.append(f'{sid} {name}: không đọc được chữ; cần OCR riêng nếu là PDF ảnh.')
        else:
            extracted,text=read_source(name,data,header)
            if text:docs.append({'source_id':sid,'name':name,'location':'Nội dung','text':text})
            if ext=='.docx' and word_tables:
                from docx import Document
                for ti,table in enumerate(Document(io.BytesIO(data)).tables,1):
                    frame=_rows_frame([[c.text for c in row.cells] for row in table.rows],header)
                    if frame.empty:continue
                    frame['__sheet_nguon']=f'Bảng Word {ti}'
                    extracted.append(frame)
        for ti,table in enumerate(extracted,1):
            if table.empty:continue
            frame=table.copy()
            if any(str(c).startswith('__') and str(c) not in SYSTEM for c in frame.columns):raise ValueError(f'{name}: tên cột bắt đầu __ được dành riêng cho nguồn.')
            if '__tep_nguon' not in frame:frame['__tep_nguon']=name
            if '__sheet_nguon' not in frame:frame['__sheet_nguon']='JSON' if ext=='.json' else f'Bảng {ti}'
            if '__dong_nguon' not in frame:frame['__dong_nguon']=range(header+2,header+2+len(frame))
            frame[TRACE]=[json.dumps([{'source':sid,'file':name,'location':str(sh),'row':int(row)}],ensure_ascii=False) for sh,row in zip(frame['__sheet_nguon'],frame['__dong_nguon'])]
            data_columns=[c for c in frame if c not in SYSTEM]
            if any(not str(c).strip() for c in data_columns):raise ValueError(f'{name}: tên cột trống; kiểm tra dòng tiêu đề.')
            if len(set(data_columns))!=len(data_columns):raise ValueError(f'{name}: tên cột trùng.')
            tables.append({'id':f'{sid}_T{ti:03d}','label':f'{sid} · {name} · {frame.iloc[0]["__sheet_nguon"]}','frame':frame})
    return tables,docs,sources,warnings


def _rows_frame(rows, header):
    if not rows or len(rows)<=header+1:return pd.DataFrame()
    names=[re.sub(r'\s+',' ',str(x or '').strip()) or f'Cột_{i+1}' for i,x in enumerate(rows[header])]
    if len(set(names))!=len(names):raise ValueError('Bảng có tiêu đề trùng; chọn lại dòng tiêu đề hoặc chỉnh tệp nguồn.')
    body=[list(row)+[None]*max(0,len(names)-len(row)) for row in rows[header+1:]]
    if any(len(row)!=len(names) for row in body):raise ValueError('Bảng không đều số cột; cần kiểm tra trước khi tổng hợp.')
    frame=pd.DataFrame(body,columns=names)
    frame=frame.replace(r'^\s*$',None,regex=True)
    frame['__dong_nguon']=range(header+2,header+2+len(frame))
    return frame.dropna(how='all',subset=names).copy()


def apply_mapping(table, mapping):
    frame=table.copy()
    mapping={str(k):str(v).strip() for k,v in mapping.items()}
    missing=set(mapping)-set(frame.columns)
    if missing:raise ValueError(f'Cấu hình tham chiếu cột không còn tồn tại: {sorted(missing)}')
    if any(k in SYSTEM for k in mapping):raise ValueError('Không đổi tên cột nguồn.')
    if any(v.startswith('__') for v in mapping.values()):raise ValueError('Tên cột chuẩn không được bắt đầu __.')
    drop=[k for k,v in mapping.items() if not v]
    frame=frame.drop(columns=drop).rename(columns={k:v for k,v in mapping.items() if v})
    columns=[c for c in frame if c not in SYSTEM]
    if len(columns)!=len(set(columns)):raise ValueError('Hai cột cùng ánh xạ về một tên; hãy chọn tên khác hoặc bỏ một cột.')
    return frame


def combine(tables, mode='append', keys=None):
    if not tables: return pd.DataFrame(),pd.DataFrame()
    if sum(len(t) for t in tables)>200000:raise ValueError('Vượt giới hạn 200.000 dòng đầu vào.')
    if mode=='append':return pd.concat(tables,ignore_index=True,sort=False),pd.DataFrame()
    if len(tables)!=2:raise ValueError('Ghép theo khóa cần chọn đúng 2 bảng mỗi lượt.')
    if not keys:raise ValueError('Hãy chọn ít nhất một cột khóa.')
    left,right=[t.copy() for t in tables]
    for i,frame in enumerate((left,right),1):
        if any(k not in frame for k in keys):raise ValueError(f'Bảng {i} thiếu cột khóa.')
        norms=pd.DataFrame({k:frame[k].map(canon) for k in keys})
        if norms.eq('').any(axis=1).any():raise ValueError(f'Bảng {i} có khóa trống. Cần bổ sung hoặc bỏ dòng đó ở nguồn.')
        if norms.duplicated().any():raise ValueError(f'Bảng {i} có khóa trùng. Dừng ghép để tránh nhân đôi số liệu; cần bổ sung cột khóa hoặc sửa nguồn.')
        frame['__join_key']=list(norms.itertuples(index=False,name=None))
    # Key values from source 1 are kept; source 2 originals remain visible for comparison.
    rename={c:f'{c} [Nguồn 2]' for c in right if c!='__join_key'}
    right=right.rename(columns=rename)
    if any(c in left for c in right if c!='__join_key'):raise ValueError('Tên cột có hậu tố [Nguồn 2] bị trùng. Hãy đổi tên.')
    merged=left.merge(right,on='__join_key',how='outer',validate='one_to_one',indicator='__trang_thai_ghep')
    conflicts=[]
    overlap=[c for c in left if c in tables[1] and c not in SYSTEM and c not in keys and c!='__join_key']
    for idx,row in merged.iterrows():
        for col in overlap:
            a,b=row[col],row[rename[col]]
            if pd.notna(a) and pd.notna(b) and canon(a)!=canon(b):
                conflicts.append({'Dòng ghép':idx+2,'Khóa':str(row['__join_key']),'Cột':col,'Nguồn 1':str(a),'Nguồn 2':str(b)})
    for col in keys+['__tep_nguon','__sheet_nguon','__dong_nguon']:
        if col in merged and rename[col] in merged:merged[col]=merged[col].combine_first(merged[rename[col]])
    traces=[]
    for _,row in merged.iterrows():
        refs=[]
        for col in (TRACE,rename.get(TRACE)):
            if col and isinstance(row.get(col),str):refs.extend(json.loads(row[col]))
        traces.append(json.dumps(refs,ensure_ascii=False))
    merged[TRACE]=traces
    # Retain right-side values of shared data columns; do not choose a winner silently.
    merged=merged.drop(columns=['__join_key']+[rename[c] for c in SYSTEM if c in rename and rename[c] in merged])
    return merged,pd.DataFrame(conflicts)


def trace_summary(clean, groups):
    rows=[]
    iterator=clean.groupby(groups,dropna=False,sort=False) if groups else [((),clean)]
    for group,frame in iterator:
        group=group if isinstance(group,tuple) else (group,)
        group_values=dict(zip(groups,group))
        for _,record in frame.iterrows():
            for ref in json.loads(record.get(TRACE,'[]')):
                rows.append({**group_values,'Mã nguồn':ref['source'],'Tệp':ref['file'],'Vị trí':ref['location'],'Dòng nguồn':ref['row']})
    return pd.DataFrame(rows).drop_duplicates() if rows else pd.DataFrame()


def evidence_pack(docs,max_chars=60000):
    by={}
    for d in docs:by.setdefault(d['source_id'],[]).append(d)
    budget=max_chars//max(1,len(by));out=[];truncated=[]
    for sid,parts in by.items():
        remaining=budget
        total=sum(len(d['text']) for d in parts)
        if total>budget:truncated.append(sid)
        for part in parts:
            if remaining<=0:break
            text=part['text'][:remaining];remaining-=len(text)
            if text:out.append({'source_id':sid,'location':part['location'],'text':text})
    return out,truncated


def export_multi_xlsx(clean, summary, issues, sources, trace, conflicts, config):
    output=io.BytesIO(export_xlsx(clean,summary,issues,sources))
    config_text=json.dumps(config,ensure_ascii=False)
    config_chunks=[config_text[i:i+30000] for i in range(0,len(config_text),30000)]
    with pd.ExcelWriter(output,engine='openpyxl',mode='a') as writer:
        for name,frame in [('Lien_ket_nguon',trace),('Xung_dot',conflicts),('Cau_hinh',pd.DataFrame({'Phần':range(1,len(config_chunks)+1),'JSON':config_chunks}))]:
            safe_excel(frame).to_excel(writer,sheet_name=name,index=False)
            writer.sheets[name].freeze_panes='A2'
    return output.getvalue()


def attach_source_codes(summary, trace, groups):
    from collections import defaultdict
    lookup=defaultdict(set)
    for _,r in trace.iterrows():lookup[tuple(canon(r[g]) for g in groups)].add(r['Mã nguồn'])
    out=summary.copy()
    out['Mã nguồn']=[', '.join(sorted(lookup.get(tuple(canon(row[g]) for g in groups),set()))) for _,row in out.iterrows()]
    return out
