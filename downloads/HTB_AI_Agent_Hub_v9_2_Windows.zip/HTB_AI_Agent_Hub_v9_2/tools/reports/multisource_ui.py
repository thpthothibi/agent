import io,json,hashlib,re
from pathlib import Path
import pandas as pd
import streamlit as st
from core import analyse,numeric,deterministic_report,export_formal_report,ai_narrative
from multisource import (extract_inputs,apply_mapping,combine,trace_summary,evidence_pack,export_multi_xlsx,attach_source_codes,SYSTEM)
from document_plus import render_variable_template,template_context
from format_pro.app.engine import normalize,pdf_convert

BASE=Path(__file__).parent
ALIASES={'họ và tên':'Họ tên','họ tên':'Họ tên','ho ten':'Họ tên','full name':'Họ tên','lớp':'Lớp','class':'Lớp','điểm':'Điểm','score':'Điểm','tổ':'Tổ','số tiết':'Số tiết','số hồ sơ':'Số hồ sơ'}

@st.cache_data(show_spinner=False)
def cached_extract(inputs,header,pdf_tables,word_tables):
    return extract_inputs(inputs,header,pdf_tables,word_tables)


def render():
    st.title('🗂 Tổng hợp báo cáo từ nhiều nguồn')
    st.caption('Chọn nguồn → Kiểm tra bảng → Ánh xạ cột → Nối / ghép dữ liệu → Đối chiếu → Xuất báo cáo có nguồn')
    a,b=st.columns(2)
    title=a.text_input('Tên báo cáo','BÁO CÁO TỔNG HỢP NHIỀU NGUỒN')
    unit=b.text_input('Đơn vị','TRƯỜNG THPT HỒ THỊ BI')
    period=st.text_input('Kỳ báo cáo',placeholder='Nhãn kỳ; dùng bộ lọc ngày bên dưới nếu cần')
    files=st.file_uploader('Dữ liệu nguồn: XLSX, CSV, JSON, DOCX, PDF có chữ, TXT',type=['xlsx','csv','json','docx','pdf','txt'],accept_multiple_files=True,key='ms_files')
    queue=st.session_state.get('pdf_bridge',[])
    use_bridge=st.checkbox('Dùng kết quả chuyển đổi từ Công cụ PDF',value=bool(queue)) if queue else False
    demo=st.checkbox('Thử bộ dữ liệu nhiều nguồn',value=not bool(files or (queue if use_bridge else [])))
    inputs=[(f.name,f.getvalue()) for f in files]
    if use_bridge:
        inputs.extend((q['name'],q['data']) for q in queue)
        st.caption('Đã nhận kết quả chuyển đổi; Excel mặc định chỉ chọn các sheet bảng để tránh đếm trùng văn bản và danh mục.')
        if st.button('Bỏ các nguồn chuyển đổi đã nhận'):
            st.session_state.pop('pdf_bridge',None);st.rerun()
    if demo and not inputs:inputs=[(p.name,p.read_bytes()) for p in sorted((BASE/'mau_da_nguon').glob('*'))]
    if not inputs:st.info('Chọn dữ liệu hoặc bật bộ minh họa.');return
    if len(inputs)>30 or sum(len(b) for _,b in inputs)>50*1024*1024:st.error('Giới hạn 30 tệp và tổng 50 MB/lượt.');return
    if len(set(n for n,_ in inputs))!=len(inputs):st.error('Tên tệp bị trùng. Đổi tên để phân biệt nguồn.');return
    h=st.number_input('Dòng tiêu đề bảng (áp dụng cho các nguồn bảng)',min_value=1,max_value=100,value=1)
    a,b=st.columns(2)
    pdf_tables=a.checkbox('Trích bảng có đường kẻ trong PDF',value=False)
    word_tables=b.checkbox('Đọc thêm các bảng trong Word',value=False)
    try:tables,docs,sources,warnings=cached_extract(inputs,int(h)-1,pdf_tables,word_tables)
    except Exception as exc:st.error(f'Không đọc đủ nguồn. Đã dừng: {exc}');return
    if use_bridge:
        origins={q['name']:q['origin'] for q in queue}
        for item in sources:
            if item['name'] in origins:
                origin=origins[item['name']]
                item['original_file']=origin.get('file','')
                item['original_sha256']=origin.get('sha256','')
                item['conversion']=origin.get('tool','')
                item['original_pages']=origin.get('pages','')
    st.dataframe(pd.DataFrame(sources),hide_index=True,width='stretch')
    for warning in warnings:st.warning(warning)
    if warnings and not st.checkbox('Tôi đã kiểm tra nguồn chưa đọc được chữ và chấp nhận thiếu nội dung đó',value=False):return
    if (pdf_tables or word_tables) and not st.checkbox('Tôi sẽ đối chiếu các bảng được trích với bản gốc trước khi sử dụng',value=False):return
    if sum(len(t['frame']) for t in tables)>200000:st.error('Vượt 200.000 dòng đầu vào.');return
    loaded={}
    cfgfile=st.file_uploader('Nạp cấu hình ánh xạ đã lưu (tùy chọn)',type=['json'],key='ms_config')
    if cfgfile:
        try:
            loaded=json.loads(cfgfile.getvalue())
            if not isinstance(loaded,dict):raise ValueError('Cấu hình cần là một đối tượng JSON.')
        except Exception as exc:st.error(f'Cấu hình lỗi: {exc}');return
    for t in tables:
        t['key']=json.dumps([t['frame'].iloc[0]['__tep_nguon'],str(t['frame'].iloc[0]['__sheet_nguon'])],ensure_ascii=False)
    schema={t['key']:[c for c in t['frame'] if c not in SYSTEM] for t in tables}
    if loaded and loaded.get('schema')!=schema:
        st.error('Cấu trúc/tên nguồn đã khác cấu hình lưu. Bỏ tệp cấu hình và ánh xạ lại để tránh dùng nhầm cột.');return
    mapped=[];mapping_all={}
    if tables:
        st.subheader('1. Kiểm tra nguồn và chuẩn hóa tên cột')
        bridge_xlsx={q['name'] for q in queue if use_bridge and q['name'].endswith('.xlsx')}
        preferred=[t['id'] for t in tables if not (t['frame'].iloc[0]['__tep_nguon'] in bridge_xlsx) or ('_Bang_' in str(t['frame'].iloc[0]['__sheet_nguon']) and str(t['frame'].iloc[0]['__sheet_nguon']).startswith('Trang_'))]
        picked=st.multiselect('Các bảng đưa vào tổng hợp',[t['id'] for t in tables],default=[t['id'] for t in tables if t['key'] in loaded['selected_tables']] if loaded.get('selected_tables') else preferred,format_func=lambda x:next(t['label'] for t in tables if t['id']==x))
        for t in tables:
            if t['id'] not in picked:continue
            frame=t['frame'];cols=schema[t['key']]
            with st.expander(t['label']):
                st.dataframe(frame.head(60),hide_index=True,width='stretch')
                initial=loaded.get('mapping',{}).get(t['key'],{})
                rows=[{'Cột gốc':c,'Tên chuẩn':initial.get(c,ALIASES.get(c.strip().casefold(),c.strip()))} for c in cols]
                editor=st.data_editor(pd.DataFrame(rows),disabled=['Cột gốc'],hide_index=True,key='map_'+t['id']+'_'+hashlib.sha256(json.dumps(rows,ensure_ascii=False).encode()).hexdigest()[:8])
                mapping={r['Cột gốc']:str(r['Tên chuẩn']).strip() if pd.notna(r['Tên chuẩn']) else '' for _,r in editor.iterrows()}
                st.caption('Đổi Tên chuẩn để các nguồn dùng cùng tên cột; để trống để bỏ cột. Không tự ghép tên gần giống.')
                from rapidfuzz import process,fuzz
                hints=[]
                for col in cols:
                    match=process.extractOne(col,list(ALIASES),scorer=fuzz.WRatio)
                    if match and 70<=match[1]<100:hints.append(f'{col} → {ALIASES[match[0]]} ({match[1]:.0f}%, chỉ gợi ý)')
                if hints:st.write('Gợi ý tên cột: '+'; '.join(hints))
                try:mapped.append((t,apply_mapping(frame,mapping)))
                except ValueError as exc:st.error(str(exc));return
                mapping_all[t['key']]=mapping
        if not mapped:st.warning('Chưa chọn bảng nào.');return
        methods=['Nối dòng từ các bảng','Ghép hai bảng theo khóa']
        method=st.radio('Cách hợp nhất',methods,index=methods.index(loaded.get('method')) if loaded.get('method') in methods else 0,horizontal=True)
        keys=[]
        if method=='Ghép hai bảng theo khóa':
            common=set(mapped[0][1])
            for _,f in mapped[1:]:common &= set(f)
            keys=st.multiselect('Khóa ghép chính xác (ví dụ Họ tên + Lớp)',sorted(common-SYSTEM),default=[k for k in loaded.get('keys',[]) if k in common-SYSTEM])
            st.caption('Ghép một–một, giữ cả dòng chưa khớp; chặn khóa trống/trùng. Hai cột cùng tên được giữ riêng để đối chiếu, không tự chọn nguồn đúng.')
        try:frame,conflicts=combine([f for _,f in mapped],'join' if keys or method.startswith('Ghép') else 'append',keys)
        except ValueError as exc:st.error(str(exc));return
    else:
        method='Chỉ tài liệu chữ';keys=[];frame=pd.DataFrame();conflicts=pd.DataFrame()
        st.info('Không có bảng số liệu. Có thể lập báo cáo từ tài liệu chữ bằng AI; chưa có số liệu để tính.')
    if not conflicts.empty:
        st.warning(f'Có {len(conflicts)} giá trị khác nhau giữa hai nguồn. Không tự sửa giá trị nào.')
        st.dataframe(conflicts,hide_index=True,width='stretch')
    with st.expander('Dữ liệu sau hợp nhất'):
        st.dataframe(frame.head(100),hide_index=True,width='stretch')
        if '__trang_thai_ghep' in frame:st.write(frame['__trang_thai_ghep'].value_counts().to_dict())
    st.subheader('2. Chỉ tiêu và phạm vi báo cáo')
    cols=[c for c in frame if c not in SYSTEM and not c.startswith('__')]
    selected=frame.copy()
    date_col=st.selectbox('Lọc kỳ theo cột ngày',['(Không lọc)']+cols)
    date_issue=[]
    if date_col!='(Không lọc)':
        a,b=st.columns(2);start=a.date_input('Từ ngày');end=b.date_input('Đến ngày')
        if start>end:st.error('Ngày bắt đầu phải trước hoặc bằng ngày kết thúc.');return
        dates=pd.to_datetime(selected[date_col],errors='coerce',dayfirst=True)
        bad=int(dates.isna().sum())
        if bad:date_issue.append(f'{bad} dòng thiếu hoặc sai ngày không nằm trong kỳ lọc.')
        selected=selected[dates.dt.date.between(start,end)]
    groups=st.multiselect('Nhóm báo cáo',cols,default=[g for g in loaded.get('groups',[]) if g in cols])
    candidates=[c for c in cols if c not in groups]
    locale=st.radio('Cách viết số văn bản',['VN: 1.234,5','Quốc tế: 1,234.5'],index=1 if loaded.get('locale','').startswith('Quốc') else 0,horizontal=True)
    suggested=[]
    for c in candidates:
        if any(term in c.lower() for term in ['mã','sđt','sbd','ngày','id','date','stt']):continue
        v=selected[c].dropna()
        if len(v) and numeric(v,'VN' if locale.startswith('VN') else 'INT').notna().mean()>=.95:suggested.append(c)
    values=st.multiselect('Cột số cần tính (kiểm tra gợi ý trước khi tạo)',candidates,default=[v for v in loaded.get('values',suggested) if v in candidates])
    operation=st.selectbox('Phép tính',['sum','mean','min','max'],index=['sum','mean','min','max'].index(loaded.get('operation','sum')) if loaded.get('operation','sum') in ['sum','mean','min','max'] else 0,format_func=lambda x:{'sum':'Tổng','mean':'Trung bình','min':'Nhỏ nhất','max':'Lớn nhất'}[x])
    dupe_keys=st.multiselect('Cột khóa kiểm tra trùng',cols,default=[k for k in loaded.get('duplicate_keys',[]) if k in cols])
    dedup=st.checkbox('Bỏ dòng trùng sau dòng đầu',value=bool(loaded.get('dedup',False)))
    try:clean,summary,issues,duplicate_count=analyse(selected,groups,values,operation,'VN' if locale.startswith('VN') else 'INT',dupe_keys,dedup)
    except Exception as exc:st.error(f'Không tính được: {exc}');return
    if tables and clean.empty:st.warning('Không có bản ghi sau lọc.');return
    issues=date_issue+warnings+issues
    if demo:issues.append('DỮ LIỆU MINH HỌA, không phải số liệu thực của trường.')
    if len(conflicts):issues.append(f'{len(conflicts)} giá trị mâu thuẫn giữa nguồn; hai giá trị được giữ riêng.')
    if not period:issues.append('Chưa khai báo nhãn kỳ báo cáo.')
    if not tables:issues.append('Không có bảng số liệu; báo cáo chỉ dựa vào tài liệu chữ.')
    if tables and not values:issues.append('Chưa chọn cột số, chỉ thống kê số bản ghi.')
    traces=trace_summary(clean,groups)
    summary=attach_source_codes(summary,traces,groups)
    st.dataframe(summary,hide_index=True,width='stretch')
    for issue in issues:st.warning(issue)
    with st.expander('Truy nguồn theo nhóm kết quả'):st.dataframe(traces.head(200),hide_index=True,width='stretch')
    config={'selected_tables':[t['key'] for t,_ in mapped], 'schema':schema,'mapping':mapping_all,'groups':groups,'values':values,'operation':operation,'method':method,'keys':keys,'locale':locale,'dedup':dedup,'duplicate_keys':dupe_keys}
    st.download_button('Lưu cấu hình ánh xạ JSON',json.dumps(config,ensure_ascii=False,indent=2).encode(),'Cau_hinh_da_nguon.json','application/json')
    st.subheader('3. Nội dung báo cáo và nguồn bằng chứng')
    evidence,truncated=evidence_pack(docs)
    if truncated:st.warning('Chỉ đọc một phần văn bản của các nguồn sau vào AI do giới hạn dung lượng: '+', '.join(truncated))
    with st.expander('Văn bản dự kiến đưa vào phần nhận xét'):
        for block in evidence:st.text(f'[{block["source_id"]}] {block["location"]}\n{block["text"]}')
    provider=st.selectbox('Viết phần nhận xét',['Không AI','Ollama','OpenAI API','Gemini API'])
    model=st.text_input('Tên model (nếu dùng AI)') if provider!='Không AI' else ''
    api_key=st.text_input('API key',type='password') if provider in ('OpenAI API','Gemini API') else ''
    allow=True
    if provider in ('OpenAI API','Gemini API'):allow=st.checkbox('Cho phép gửi bảng tổng hợp, nguồn và văn bản hiển thị ở trên tới dịch vụ AI đã chọn',value=False)
    request=st.text_area('Yêu cầu báo cáo','Tổng hợp kết quả, các khác biệt giữa nguồn và kiến nghị. Dẫn mã nguồn [S001] sau mỗi nhận xét có căn cứ. Không tự bịa số hoặc nguyên nhân.')
    standard=st.selectbox('Thể thức báo cáo',['admin','party'],format_func=lambda x:'Hành chính' if x=='admin' else 'Văn bản Đảng')
    normalize_out=st.checkbox('Chuẩn hóa thể thức bản Word đầu ra',value=True)
    template=st.file_uploader('Mẫu Word có biến {{ don_vi }}, {{ noi_dung }}… (tùy chọn)',type=['docx'],key='ms_template')
    st.caption('Không chọn mẫu: dùng khung báo cáo HTB. Có mẫu: điền biến tại đúng vị trí bằng docxtpl. Biến hỗ trợ: tieu_de, don_vi, ky_bao_cao, noi_dung, so_nguon, kiem_tra, nguon, bang, bang_word, dong.')
    template_bytes=template.getvalue() if template else None
    stamp=hashlib.sha256(json.dumps({'config':config,'sources':sources,'title':title,'unit':unit,'period':period,'filtered':selected.to_json(),'provider':provider,'standard':standard,'normalize_out':normalize_out,'model':model,'request':request,'allow':allow,'template':hashlib.sha256(template_bytes or b'').hexdigest()},sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    if st.button('🚀 Tổng hợp và tạo báo cáo',type='primary'):
        if provider!='Không AI' and (not model.strip() or (provider in ('OpenAI API','Gemini API') and not api_key)):st.error('Nhập model và khóa API nếu cần.');return
        if not allow:st.error('Chưa cho phép gửi dữ liệu tới dịch vụ AI.');return
        text=deterministic_report(title,unit,period,clean,summary,issues,sources,operation)
        text+='\nVI. DANH MỤC MÃ NGUỒN\n'+'\n'.join(f'[{s["id"]}] {s["name"]}' for s in sources)
        if provider!='Không AI':
            payload={'yeu_cau':request,'bang_tong_hop':json.loads(summary.to_json(orient='records',force_ascii=False)),'kiem_tra':issues,'nguon':sources,'van_ban':evidence,'nguon_chi_doc_mot_phan':truncated}
            prompt=json.dumps(payload,ensure_ascii=False)
            if len(prompt)>120000:st.error('Yêu cầu quá lớn. Giảm số nhóm hoặc số tài liệu.');return
            try:
                with st.spinner('AI đang viết nhận xét từ các nguồn đã chọn…'):narrative=ai_narrative(provider,model.strip(),api_key,prompt)
                unknown=set(re.findall(r'\[(S\d{3})\]',narrative))-{s['id'] for s in sources}
                if unknown:issues.append('AI dẫn mã nguồn không có trong đầu vào: '+', '.join(sorted(unknown)))
                text+='\nVII. NHẬN XÉT AI ĐỀ XUẤT CẦN RÀ SOÁT\n'+narrative
            except Exception as exc:
                text+='\nVII. TRẠNG THÁI AI\nKhông tạo được phần nhận xét AI; giữ kết quả tổng hợp theo quy tắc.'
                st.warning(str(exc))
        elif docs:
            text+='\nVII. NỘI DUNG THAM KHẢO TỪ TÀI LIỆU\n'+'\n\n'.join(f'[{d["source_id"]}] {d["location"]}: {d["text"][:800]}' for d in evidence)
        converted=[s for s in sources if s.get('original_file')]
        if converted:
            text+='\nVIII. NGUỒN TRƯỚC CHUYỂN ĐỔI\n'+'\n'.join(f'[{s["id"]}] {s["original_file"]}; trang {s["original_pages"]}; {s["conversion"]}' for s in converted)
        st.session_state['ms_result']={'stamp':stamp,'issues':issues}
        st.session_state['ms_editor']=text
    result=st.session_state.get('ms_result')
    if not result:return
    if result['stamp']!=stamp:st.info('Dữ liệu / cấu hình thay đổi. Tạo lại để xuất kết quả mới.');return
    edited=st.text_area('Báo cáo có thể sửa trước khi xuất',key='ms_editor',height=400)
    try:
        if template_bytes:word=render_variable_template(template_bytes,template_context(title,unit,period,edited,summary,result['issues'],sources))
        else:word=export_formal_report(edited,summary,unit,period,standard)
        if normalize_out:word=normalize(word,standard,{'safe_layout':True})
        excel=export_multi_xlsx(clean,summary,result['issues'],sources,traces,conflicts,config)
        a,b=st.columns(2)
        a.download_button('⬇ Báo cáo tổng hợp Word',word,'Bao_cao_da_nguon.docx')
        b.download_button('⬇ Excel kèm truy nguồn và mâu thuẫn',excel,'So_lieu_da_nguon.xlsx')
        digest=hashlib.sha256((stamp+edited).encode()).hexdigest()
        if st.button('Tạo PDF báo cáo nhiều nguồn'):
            try:st.session_state['ms_pdf']={'digest':digest,'data':pdf_convert(word)}
            except RuntimeError as exc:st.warning(str(exc))
        pdf=st.session_state.get('ms_pdf')
        if pdf and pdf['digest']==digest:st.download_button('⬇ PDF báo cáo nhiều nguồn',pdf['data'],'Bao_cao_da_nguon.pdf','application/pdf')
    except Exception as exc:st.error(f'Không xuất được báo cáo: {exc}')
