import io, unittest
import pandas as pd
from docx import Document
from core import *

class CoreTests(unittest.TestCase):
    def test_demo_and_source(self):
        data = (Path(__file__).parent/'mau/du_lieu_minh_hoa.csv').read_bytes()
        tables,_=read_source('demo.csv',data)
        self.assertEqual(tables[0].iloc[0]['__dong_nguon'],2)
        clean,result,issues,_=analyse(tables[0],['Tổ'],['Số tiết','Số hồ sơ'])
        self.assertEqual(list(result['Số tiết']),[35,37,16])
        self.assertEqual(list(result['Số hồ sơ']),[7,9,2])
    def test_numeric_vn_and_invalid(self):
        frame=pd.DataFrame({'g':['A','A','B'],'v':['1.234,5','x',None]})
        _,s,issues,_=analyse(frame,['g'],['v'])
        self.assertEqual(s.iloc[0]['v'],1234.5)
        self.assertTrue(pd.isna(s.iloc[1]['v']))
        self.assertTrue(issues)
        self.assertEqual(numeric(pd.Series(['7.25',7.25]),'INT').tolist(),[7.25,7.25])
    def test_dedup_and_mean(self):
        f=pd.DataFrame({'id':[1,1,2],'v':[2,2,8]})
        c,s,i,d=analyse(f,[],['v'],'mean',duplicate_keys=['id'],drop_duplicates=True)
        self.assertEqual(d,1);self.assertEqual(len(c),2);self.assertEqual(s.iloc[0]['v'],5)
    def test_exports_and_formula(self):
        f=pd.DataFrame({'name':['=1+1'],'v':[3]})
        data=export_xlsx(f,f,[],[{'name':'test'}])
        from openpyxl import load_workbook
        ws=load_workbook(io.BytesIO(data))['Du_lieu']
        self.assertEqual(ws['A2'].data_type,'s')
        self.assertTrue(ws['A2'].value.startswith("'="))
        doc=Document(io.BytesIO(export_docx('BÁO CÁO\nI. Kết quả\nĐúng',f)))
        self.assertEqual(len(doc.tables),1)
        self.assertIn('Đúng','\n'.join(p.text for p in doc.paragraphs))
    def test_blank_rows_and_numeric_excel(self):
        data=io.BytesIO()
        pd.DataFrame({'v':[7.25,None,8.5]}).to_excel(data,index=False)
        tables,_=read_source('a.xlsx',data.getvalue())
        self.assertEqual(tables[0]['__dong_nguon'].tolist(),[2,4])
        _,s,_,_=analyse(tables[0],[],['v'])
        self.assertEqual(s.iloc[0]['v'],15.75)
    def test_ai_transport_mock(self):
        from unittest.mock import patch
        class Response(io.BytesIO):
            def __enter__(self): return self
            def __exit__(self,*args): self.close()
        with patch('urllib.request.urlopen', return_value=Response(b'{"response":"ok"}')) as m:
            self.assertEqual(ai_narrative('Ollama','test','','hello'),'ok')
            self.assertFalse(json.loads(m.call_args.args[0].data)['stream'])
        with patch('urllib.request.urlopen', return_value=Response(b'{"choices":[{"message":{"content":"ok"}}]}')):
            self.assertEqual(ai_narrative('OpenAI API','test','key','hello'),'ok')

if __name__=='__main__': unittest.main()
