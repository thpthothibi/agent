"""Offline PDF operations. Sources are never overwritten."""
from __future__ import annotations
import io,json,re,zipfile,tempfile,subprocess,sys,shutil,os,threading
from pathlib import Path
from pypdf import PdfReader,PdfWriter

MAX_BYTES=50*1024*1024
MAX_PAGES=300
PDFIUM_LOCK=threading.RLock()
FONT_LOCK=threading.RLock()


def open_pdf(data,password=''):
    if not data or len(data)>MAX_BYTES:raise ValueError('PDF trống hoặc vượt 50 MB.')
    if b'%PDF-' not in data[:1024]:raise ValueError('Tệp không có dấu nhận diện PDF hợp lệ.')
    try:
        reader=PdfReader(io.BytesIO(data),strict=False)
        if reader.is_encrypted and not reader.decrypt(password):raise ValueError('PDF cần mật khẩu mở đúng. Không dò hoặc bỏ qua mật khẩu.')
        if not 0<len(reader.pages)<=MAX_PAGES:raise ValueError('Giới hạn 1–300 trang PDF mỗi tệp.')
        return reader
    except ValueError:raise
    except Exception as exc:raise ValueError('Không đọc được PDF. Tệp có thể hỏng hoặc cần phương thức bảo vệ khác.') from exc


def page_numbers(spec,total,allow_duplicates=True):
    if not spec.strip() or spec.strip().casefold() in ('all','tất cả'):return list(range(total))
    if len(spec)>3000:raise ValueError('Danh sách trang quá dài.')
    result=[]
    for token in spec.replace(' ','').split(','):
        if re.fullmatch(r'\d+',token):part=[int(token)]
        elif re.fullmatch(r'\d+-\d+',token):
            a,b=map(int,token.split('-'))
            if min(a,b)<1 or max(a,b)>total:raise ValueError(f'Trang phải nằm trong 1–{total}.')
            part=list(range(a,b+(1 if b>=a else -1),1 if b>=a else -1))
        else:raise ValueError('Trang dùng dạng 1-3,5,8 hoặc 5-1. Không để dấu phẩy thừa.')
        if any(p<1 or p>total for p in part):raise ValueError(f'Trang phải nằm trong 1–{total}.')
        result.extend(p-1 for p in part)
        if len(result)>MAX_PAGES:raise ValueError('Một kết quả chỉ được chứa tối đa 300 trang.')
    if not allow_duplicates and len(set(result))!=len(result):raise ValueError('Danh sách trang đang trùng.')
    return result


def dump(writer):
    out=io.BytesIO();writer.write(out);return out.getvalue()


def inspect_pdf(data,password=''):
    reader=open_pdf(data,password);fields=reader.get_fields() or {}
    pages=[]
    for i,page in enumerate(reader.pages,1):
        try:text=page.extract_text() or ''
        except Exception:text=''
        pages.append({'Trang':i,'Rộng mm':round(float(page.mediabox.width)*25.4/72,1),'Cao mm':round(float(page.mediabox.height)*25.4/72,1),'Xoay':page.rotation,'Ký tự đọc được':len(text.strip())})
    return {'pages':pages,'encrypted':reader.is_encrypted,'signed':any(f.get('/FT')=='/Sig' for f in fields.values()),'metadata':{str(k):str(v) for k,v in (reader.metadata or {}).items()}}


def select_pages(data,spec='',password=''):
    reader=open_pdf(data,password);writer=PdfWriter()
    writer.append(reader,pages=page_numbers(spec,len(reader.pages)),import_outline=False)
    return dump(writer)


def delete_pages(data,spec,password=''):
    reader=open_pdf(data,password);deleted=set(page_numbers(spec,len(reader.pages)))
    if len(deleted)==len(reader.pages):raise ValueError('Không thể xóa hết các trang.')
    writer=PdfWriter()
    writer.append(reader,pages=[i for i in range(len(reader.pages)) if i not in deleted],import_outline=False)
    return dump(writer)


def merge_pdfs(items):
    if not 2<=len(items)<=20:raise ValueError('Chọn 2–20 PDF để ghép.')
    writer=PdfWriter();count=0;manifest=[]
    if sum(len(data) for _,data,_,_ in items)>100*1024*1024:raise ValueError('Tổng các tệp ghép vượt 100 MB.')
    for source_index,(name,data,password,spec) in enumerate(items,1):
        reader=open_pdf(data,password);indices=page_numbers(spec,len(reader.pages))
        manifest.append({'file':name,'start':count+1,'source_pages':[i+1 for i in indices]})
        count+=len(indices)
        if count>MAX_PAGES:raise ValueError('Bản ghép vượt 300 trang.')
        if reader.get_fields():reader.add_form_topname(f'Nguon_{source_index}')
        writer.append(reader,pages=indices,import_outline=False)
    return dump(writer),manifest


def split_pdf(data,specs,password=''):
    reader=open_pdf(data,password);out=io.BytesIO();report=[]
    parts=[s.strip() for s in specs.split(';')]
    if not parts or any(not s for s in parts) or len(parts)>100:raise ValueError('Dùng các nhóm trang cách nhau bằng ;, tối đa 100 nhóm.')
    selections=[page_numbers(spec,len(reader.pages)) for spec in parts]
    if sum(len(x) for x in selections)>300:raise ValueError('Tổng các phần tách vượt 300 trang.')
    total_bytes=0
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for i,spec in enumerate(parts,1):
            indices=page_numbers(spec,len(reader.pages));writer=PdfWriter()
            writer.append(reader,pages=indices,import_outline=False)
            filename=f'Phan_{i:03d}.pdf';blob=dump(writer);total_bytes+=len(blob)
            if total_bytes>150*1024*1024:raise ValueError('Các phần tách vượt 150 MB; chọn ít nhóm hơn.')
            z.writestr(filename,blob);report.append({'file':filename,'pages':[p+1 for p in indices]})
        z.writestr('DANH_MUC_TRANG.json',json.dumps(report,ensure_ascii=False,indent=2))
    return out.getvalue()


def rotate_pdf(data,spec,degrees,password=''):
    if degrees not in (90,180,270):raise ValueError('Góc xoay là 90, 180 hoặc 270 độ theo chiều kim đồng hồ.')
    reader=open_pdf(data,password);indices=set(page_numbers(spec,len(reader.pages)));writer=PdfWriter(clone_from=reader)
    for i,page in enumerate(writer.pages):
        if i in indices:page.rotate(degrees)
    return dump(writer)


def crop_pdf(data,spec,left_mm=0,right_mm=0,top_mm=0,bottom_mm=0,password=''):
    if min(left_mm,right_mm,top_mm,bottom_mm)<0:raise ValueError('Lề cắt không được âm.')
    reader=open_pdf(data,password);indices=set(page_numbers(spec,len(reader.pages)));writer=PdfWriter(clone_from=reader)
    left,right,top,bottom=[float(v)*72/25.4 for v in (left_mm,right_mm,top_mm,bottom_mm)]
    for i,page in enumerate(writer.pages):
        if i in indices:
            page.transfer_rotation_to_content()
            box=page.cropbox;x0=float(box.left)+left;x1=float(box.right)-right;y0=float(box.bottom)+bottom;y1=float(box.top)-top
            if x1<=x0 or y1<=y0:raise ValueError(f'Trang {i+1}: lề cắt vượt kích thước trang.')
            page.cropbox.lower_left=(x0,y0);page.cropbox.upper_right=(x1,y1)
    return dump(writer)


def compress_pdf(data,mode='lossless',quality=75,dpi=110,password=''):
    reader=open_pdf(data,password)
    if not 30<=quality<=95:raise ValueError('Chất lượng JPEG cần trong 30–95.')
    if not 72<=dpi<=200:raise ValueError('DPI nén cần trong 72–200.')
    notes=[]
    if mode=='raster':
        if len(reader.pages)>100:raise ValueError('Nén ảnh giới hạn 100 trang/lượt.')
        from reportlab.pdfgen import canvas
        from reportlab.lib.utils import ImageReader
        out=io.BytesIO();c=canvas.Canvas(out,pageCompression=1)
        for index,png,width,height in rendered_pages(data,list(range(len(reader.pages))),password,dpi):
            from PIL import Image
            with Image.open(io.BytesIO(png)) as im:
                jpg=io.BytesIO();im.convert('RGB').save(jpg,'JPEG',quality=quality,optimize=True)
            c.setPageSize((width,height));c.drawImage(ImageReader(io.BytesIO(jpg.getvalue())),0,0,width=width,height=height);c.showPage()
        c.save();result=out.getvalue();notes.append('Nén bằng ảnh: không còn lớp chữ có thể chọn, liên kết hoặc biểu mẫu tương tác.')
    else:
        writer=PdfWriter(clone_from=reader)
        failed=0
        for page in writer.pages:
            if mode=='images':
                for image in list(page.images):
                    try:image.replace(image.image,quality=quality)
                    except Exception:failed+=1
            elif mode!='lossless':raise ValueError('Chế độ nén không hợp lệ.')
            page.compress_content_streams(level=9)
        writer.compress_identical_objects(remove_duplicates=True,remove_unreferenced=True)
        result=dump(writer)
        if failed:notes.append(f'{failed} ảnh không thay đổi vì định dạng ảnh không hỗ trợ.')
    if len(result)>=len(data):
        notes.append('Không giảm dung lượng ở mức đã chọn; giữ bản PDF gốc thay vì báo nén thành công.')
        result=data
    return result,{'before_bytes':len(data),'after_bytes':len(result),'saved_percent':round((1-len(result)/len(data))*100,1),'notes':notes}


def rendered_pages(data,indices,password='',dpi=130):
    import pypdfium2 as pdfium
    if not 72<=dpi<=240:raise ValueError('DPI ảnh cần trong 72–240.')
    with PDFIUM_LOCK:
        doc=pdfium.PdfDocument(data,password=password or None)
        try:
            for index in indices:
                page=doc[index]
                try:
                    width,height=page.get_size()
                    if width*height*(dpi/72)**2>25_000_000:raise ValueError('Trang quá lớn để dựng ảnh ở DPI này; hãy giảm DPI.')
                    bitmap=page.render(scale=dpi/72)
                    try:
                        image=bitmap.to_pil();out=io.BytesIO();image.save(out,'PNG');image.close()
                        yield index,out.getvalue(),width,height
                    finally:bitmap.close()
                finally:page.close()
        finally:doc.close()


def preview(data,page_index=0,password='',dpi=100):
    reader=open_pdf(data,password)
    if not 0<=page_index<len(reader.pages):raise ValueError('Trang xem trước không hợp lệ.')
    return next(rendered_pages(data,[page_index],password,dpi))[1]


def pdf_to_images(data,spec='',password='',fmt='PNG',dpi=130):
    reader=open_pdf(data,password);indices=page_numbers(spec,len(reader.pages))
    if len(indices)>50:raise ValueError('Xuất ảnh giới hạn 50 trang/lượt.')
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for order,(index,png,_,_) in enumerate(rendered_pages(data,indices,password,dpi),1):
            if fmt=='JPEG':
                from PIL import Image
                with Image.open(io.BytesIO(png)) as im:
                    jpg=io.BytesIO();im.convert('RGB').save(jpg,'JPEG',quality=90);blob=jpg.getvalue()
            elif fmt=='PNG':blob=png
            else:raise ValueError('Định dạng ảnh không hỗ trợ.')
            z.writestr(f'{order:03d}_trang_{index+1:03d}.'+('jpg' if fmt=='JPEG' else 'png'),blob)
    return out.getvalue()


def images_to_pdf(items,fit_a4=True):
    from PIL import Image,ImageOps
    from reportlab.pdfgen import canvas
    from reportlab.lib.utils import ImageReader
    if not 1<=len(items)<=50:raise ValueError('Chọn 1–50 ảnh JPG/PNG mỗi lượt.')
    if sum(len(b) for _,b in items)>100*1024*1024:raise ValueError('Tổng ảnh vượt 100 MB.')
    out=io.BytesIO();c=canvas.Canvas(out,pageCompression=1)
    for name,data in items:
        with Image.open(io.BytesIO(data)) as original:
            if original.width*original.height>25_000_000:raise ValueError(f'{name}: ảnh vượt 25 triệu điểm ảnh.')
            oriented=ImageOps.exif_transpose(original)
            rgba=oriented.convert('RGBA');im=Image.new('RGB',rgba.size,'white');im.paste(rgba,mask=rgba.getchannel('A'));rgba.close()
            width,height=(595.276,841.89) if fit_a4 else (im.width*72/150,im.height*72/150)
            scale=min(width/im.width,height/im.height);w,h=im.width*scale,im.height*scale
            c.setPageSize((width,height));c.drawImage(ImageReader(im),(width-w)/2,(height-h)/2,width=w,height=h);c.showPage();im.close()
    c.save();return out.getvalue()


def extract_text(data,spec='',password=''):
    reader=open_pdf(data,password);indices=page_numbers(spec,len(reader.pages));pages=[];blank=[]
    for i in indices:
        text=reader.pages[i].extract_text() or ''
        pages.append({'page':i+1,'text':text})
        if not text.strip():blank.append(i+1)
    return pages,blank


def pdf_to_excel(data,spec='',password='',table_mode='lines',header=True):
    import pandas as pd,pdfplumber
    from core import safe_excel
    reader=open_pdf(data,password);indices=page_numbers(spec,len(reader.pages));out=io.BytesIO();manifest=[];texts=[];count=0
    if table_mode not in ('lines','text'):raise ValueError('Chế độ nhận diện bảng không hợp lệ.')
    settings={'vertical_strategy':table_mode,'horizontal_strategy':table_mode}
    with pdfplumber.open(io.BytesIO(data),password=password or None) as pdf, pd.ExcelWriter(out,engine='openpyxl') as writer:
        for page_index in indices:
            page=pdf.pages[page_index];text=page.extract_text() or ''
            for line in text.splitlines():texts.append({'Trang':page_index+1,'Văn bản':line})
            for rows in page.extract_tables(settings):
                if not rows:continue
                count+=1
                if count>100:raise ValueError('Vượt 100 bảng/lượt. Hãy chọn ít trang hơn.')
                columns=rows[0] if header else [f'Cột_{i+1}' for i in range(len(rows[0]))]
                # Keep duplicate/blank headers visible, but make them unique for Excel operations.
                names=[]
                for i,value in enumerate(columns):
                    name=re.sub(r'\s+',' ',str(value or '').strip()) or f'Cột_{i+1}'
                    while name in names:name+=f'_{i+1}'
                    names.append(name)
                frame=pd.DataFrame(rows[1:] if header else rows,columns=names)
                sheet=f'Trang_{page_index+1}_Bang_{count}'[:31]
                safe_excel(frame).to_excel(writer,sheet_name=sheet,index=False)
                writer.sheets[sheet].freeze_panes='A2'
                manifest.append({'Trang':page_index+1,'Sheet':sheet,'Dòng dữ liệu':len(frame),'Cột':len(frame.columns)})
        safe_excel(pd.DataFrame(texts,columns=['Trang','Văn bản'])).to_excel(writer,sheet_name='Van_ban_theo_trang',index=False)
        pd.DataFrame(manifest,columns=['Trang','Sheet','Dòng dữ liệu','Cột']).to_excel(writer,sheet_name='Danh_muc_bang',index=False)
    return out.getvalue(),{'tables':count,'text_lines':len(texts),'note':'Không tìm thấy bảng. Excel chỉ có văn bản đọc được theo trang; chưa phải bảng số liệu.' if not count else 'Bảng trích tự động; cần đối chiếu ô gộp, tiêu đề và dấu thập phân với PDF gốc.'}


def pdf_to_word(data,spec='',password='',mode='layout',dpi=130):
    selected=select_pages(data,spec,password);pages,blank=extract_text(selected)
    if mode=='layout':
        if blank:raise ValueError('Các trang '+', '.join(map(str,blank))+' không đọc được chữ. Dùng Word dạng ảnh hoặc OCR trước.')
        with tempfile.TemporaryDirectory(prefix='htb-pdf-word-') as td:
            src=Path(td)/'source.pdf';dest=Path(td)/'output.docx';src.write_bytes(selected)
            worker=Path(__file__).with_name('pdf_worker.py')
            try:result=subprocess.run([sys.executable,str(worker),str(src),str(dest)],capture_output=True,timeout=180,check=False)
            except subprocess.TimeoutExpired:raise RuntimeError('Chuyển Word quá 180 giây; chọn ít trang hơn.') from None
            if result.returncode or not dest.is_file():raise RuntimeError('Không chuyển được bố cục PDF này. Thử chế độ Chữ đơn giản hoặc Word dạng ảnh.')
            blob=dest.read_bytes()
        return blob,{'note':'Word có chữ/bảng có thể sửa. Font, cột và bố cục phức tạp có thể khác PDF gốc.'}
    from docx import Document
    from docx.shared import Inches,Pt,Cm
    doc=Document();doc.styles['Normal'].font.name='Times New Roman';doc.styles['Normal'].font.size=Pt(12)
    if mode=='text':
        if blank:raise ValueError('Có trang không đọc được chữ. Dùng OCR hoặc Word dạng ảnh; không xuất bản Word thiếu trang chữ.')
        for i,page in enumerate(pages):
            if i:doc.add_page_break()
            for line in page['text'].splitlines():doc.add_paragraph(line)
        note='Chữ có thể sửa, chưa khôi phục nguyên bố cục hoặc bảng.'
    elif mode=='image':
        from docx.enum.section import WD_SECTION_START
        if len(pages)>50:raise ValueError('Word dạng ảnh giới hạn 50 trang/lượt.')
        for i,(index,png,width,height) in enumerate(rendered_pages(selected,list(range(len(pages))),dpi=dpi)):
            sec=doc.sections[0] if i==0 else doc.add_section(WD_SECTION_START.NEW_PAGE)
            sec.page_width=Inches(width/72);sec.page_height=Inches(height/72)
            sec.left_margin=sec.right_margin=sec.top_margin=sec.bottom_margin=Cm(0.5)
            p=doc.add_paragraph();p.paragraph_format.space_after=Pt(0)
            p.paragraph_format.space_before=Pt(0)
            scale=min((width-72/2.54)/width,(height-72/2.54-6)/height)
            run=p.add_run();run.font.size=Pt(1)
            run.add_picture(io.BytesIO(png),width=Inches(max(.1,width*scale/72)))
        note='Word chứa ảnh các trang, giữ hình thức nhưng không sửa riêng từng chữ/bảng.'
    else:raise ValueError('Chế độ Word không hợp lệ.')
    out=io.BytesIO();doc.save(out);return out.getvalue(),{'note':note}


def _font():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    with FONT_LOCK:
        if 'HTBPDF' in pdfmetrics.getRegisteredFontNames():return 'HTBPDF'
        candidates=[Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts'/'arial.ttf',Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),Path('/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf')]
        for p in candidates:
            if p.is_file():pdfmetrics.registerFont(TTFont('HTBPDF',str(p)));return 'HTBPDF'
    return 'Helvetica'


def stamp_pdf(data,spec='',password='',text='',numbers=False,start=1):
    from reportlab.pdfgen import canvas
    from reportlab.lib.colors import Color
    reader=open_pdf(data,password);indices=set(page_numbers(spec,len(reader.pages)));writer=PdfWriter(clone_from=reader);font=_font();seq=start
    if len(text)>150:raise ValueError('Watermark tối đa 150 ký tự.')
    if font=='Helvetica' and any(ord(c)>127 for c in text):raise ValueError('Thiếu font Unicode cho watermark. Cài Arial/DejaVu Sans hoặc dùng chữ không dấu.')
    for i,page in enumerate(writer.pages):
        if i in indices:
            page.transfer_rotation_to_content();width,height=float(page.mediabox.width),float(page.mediabox.height)
            overlay=io.BytesIO();c=canvas.Canvas(overlay,pagesize=(width,height))
            if text:
                c.saveState();c.setFillColor(Color(.35,.35,.35,alpha=.2));c.setFont(font,min(36,max(12,width/max(len(text)*.55,1))));c.translate(width/2,height/2);c.rotate(35);c.drawCentredString(0,0,text);c.restoreState()
            if numbers:c.setFont(font,10);c.setFillColorRGB(0,0,0);c.drawCentredString(width/2,18,str(seq));seq+=1
            c.save();page.merge_page(PdfReader(io.BytesIO(overlay.getvalue())).pages[0])
    return dump(writer)


def set_password(data,new_password='',password='',remove=False):
    reader=open_pdf(data,password);writer=PdfWriter(clone_from=reader)
    if not remove:
        if len(new_password)<6:raise ValueError('Mật khẩu mới cần ít nhất 6 ký tự.')
        writer.encrypt(new_password,algorithm='AES-256-R5')
    return dump(writer)


def office_to_pdf(name,data):
    ext=Path(name).suffix.lower()
    if ext not in ('.docx','.xlsx','.pptx'):raise ValueError('Chỉ nhận DOCX/XLSX/PPTX.')
    if not data or len(data)>MAX_BYTES:raise ValueError('Tệp trống hoặc vượt 50 MB.')
    lo=shutil.which('libreoffice') or shutil.which('soffice')
    if not lo:
        for env in ('PROGRAMFILES','PROGRAMFILES(X86)'):
            path=Path(os.environ.get(env,''))/'LibreOffice'/'program'/'soffice.exe'
            if path.is_file():lo=str(path);break
    if not lo:raise RuntimeError('Cần cài LibreOffice để chuyển Word/Excel/PowerPoint sang PDF.')
    with tempfile.TemporaryDirectory(prefix='htb-office-') as td:
        folder=Path(td);src=folder/('source'+ext);src.write_bytes(data)
        args=[lo,'-env:UserInstallation='+(folder/'profile').as_uri(),'--headless','--convert-to','pdf','--outdir',str(folder),str(src)]
        try:result=subprocess.run(args,capture_output=True,timeout=90,check=False)
        except subprocess.TimeoutExpired:raise RuntimeError('Chuyển PDF quá 90 giây.') from None
        dest=folder/'source.pdf'
        if result.returncode or not dest.is_file():raise RuntimeError('LibreOffice không chuyển được tệp này.')
        return dest.read_bytes()


def ocr_status():
    import pytesseract
    cmd=shutil.which('tesseract')
    if not cmd:
        for env in ('PROGRAMFILES','PROGRAMFILES(X86)'):
            path=Path(os.environ.get(env,''))/'Tesseract-OCR'/'tesseract.exe'
            if path.is_file():cmd=str(path);break
    if not cmd:return {'available':False,'languages':[],'note':'Chưa cài Tesseract OCR.'}
    pytesseract.pytesseract.tesseract_cmd=cmd
    try:langs=pytesseract.get_languages(config='')
    except Exception:return {'available':False,'languages':[],'note':'Không đọc được ngôn ngữ của Tesseract.'}
    return {'available':True,'languages':[x for x in langs if x!='osd'],'note':'Cần gói vie để nhận dạng tiếng Việt.'}


def ocr_pdf(data,spec='',password='',language='eng',output='txt',dpi=200):
    import pytesseract
    from PIL import Image
    status=ocr_status()
    if not status['available']:raise RuntimeError(status['note'])
    if any(lang not in status['languages'] for lang in language.split('+')):raise ValueError('Ngôn ngữ OCR chưa cài trên máy.')
    reader=open_pdf(data,password);indices=page_numbers(spec,len(reader.pages))
    if len(indices)>30:raise ValueError('OCR giới hạn 30 trang/lượt.')
    texts=[];writer=PdfWriter();recognized=False
    for index,png,_,_ in rendered_pages(data,indices,password,dpi):
        with Image.open(io.BytesIO(png)) as im:
            if output=='pdf':
                blob=pytesseract.image_to_pdf_or_hocr(im,lang=language,extension='pdf',timeout=90)
                ocr_reader=PdfReader(io.BytesIO(blob))
                recognized=recognized or any((p.extract_text() or '').strip() for p in ocr_reader.pages)
                writer.append(ocr_reader)
            else:texts.append({'page':index+1,'text':pytesseract.image_to_string(im,lang=language,timeout=90)})
    if output=='pdf':
        if not recognized:raise ValueError('OCR không nhận được chữ. Kiểm tra ngôn ngữ, độ rõ và hướng trang.')
        return dump(writer)
    if not any(p['text'].strip() for p in texts):raise ValueError('OCR không nhận được chữ. Kiểm tra ngôn ngữ, độ rõ và hướng trang.')
    text='\n\n'.join(f'--- Trang {p["page"]} ---\n{p["text"]}' for p in texts)
    if output=='txt':return text.encode('utf-8-sig')
    if output=='docx':
        from docx import Document
        from docx.shared import Pt
        doc=Document();doc.styles['Normal'].font.name='Times New Roman';doc.styles['Normal'].font.size=Pt(12)
        for i,p in enumerate(texts):
            if i:doc.add_page_break()
            doc.add_paragraph(f'Trang {p["page"]}')
            for line in p['text'].splitlines():doc.add_paragraph(line)
        out=io.BytesIO();doc.save(out);return out.getvalue()
    raise ValueError('Định dạng OCR không hợp lệ.')
