import importlib.util,sys,shutil
from pathlib import Path
from importlib.metadata import version
from pdf_tools import ocr_status
lines=['HTB AI Agent v4 - PDF diagnostics','Python '+sys.version.split()[0]]
for name in ['pypdf','pdfplumber','pdf2docx','pypdfium2','pytesseract','reportlab','Pillow']:
 try:lines.append(name+': '+version(name))
 except Exception:lines.append(name+': missing')
lo=shutil.which('libreoffice') or shutil.which('soffice')
if not lo:
 import os
 lo=next((str(p) for env in ('PROGRAMFILES','PROGRAMFILES(X86)') if (p:=Path(os.environ.get(env,''))/'LibreOffice'/'program'/'soffice.exe').is_file()),None)
lines.append('LibreOffice: '+('available' if lo else 'not found'))
try:
 status=ocr_status();lines.append('Tesseract: '+str(status['available']));lines.append('OCR languages: '+', '.join(status['languages']))
except Exception:lines.append('Tesseract: not available')
report='\n'.join(lines)
print(report)
(Path(__file__).parent/'CHAN_DOAN_PDF.txt').write_text(report,encoding='utf-8')
