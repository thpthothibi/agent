import io,json,unittest
from unittest.mock import patch
from pathlib import Path
from docx import Document
from docx.shared import Cm,Pt
from format_pro.app.engine import load,normalize,audit,template_docx,component_docx,TEMPLATE_TYPES,COMPONENTS
from core import ai_narrative,export_docx

class IntegrationTests(unittest.TestCase):
    def test_gemini_rest_and_blocked_reply(self):
        class Response(io.BytesIO):
            def __enter__(self):return self
            def __exit__(self,*args):self.close()
        response={'candidates':[{'content':{'parts':[{'text':'Nhận xét kiểm thử'}]}}]}
        with patch('urllib.request.urlopen',return_value=Response(json.dumps(response).encode())) as mock:
            self.assertEqual(ai_narrative('Gemini API','test-model','test-key','Dữ liệu'),'Nhận xét kiểm thử')
            request=mock.call_args.args[0]
            self.assertIn('generativelanguage.googleapis.com',request.full_url)
            self.assertIn('systemInstruction',json.loads(request.data))
        with patch('urllib.request.urlopen',return_value=Response(b'{}')):
            with self.assertRaises(RuntimeError):ai_narrative('Gemini API','test-model','test-key','Dữ liệu')
    def test_report_format_preserves_table_numbers(self):
        import pandas as pd
        summary=pd.DataFrame({'Tổ':['Toán','Văn'],'Số tiết':[35,37]})
        raw=export_docx('BÁO CÁO\nI. KẾT QUẢ\nNội dung',summary)
        doc=load(normalize(raw,'admin',{'safe_layout':True}))
        self.assertEqual(doc.tables[0].cell(1,1).text,'35')
        self.assertEqual(doc.tables[0].cell(2,1).text,'37')
        self.assertAlmostEqual(doc.sections[0].page_width.cm,21,places=2)
    def test_catalog_and_layout(self):
        self.assertEqual(len(TEMPLATE_TYPES),12);self.assertEqual(len(COMPONENTS),14)
        for key in TEMPLATE_TYPES:
            doc=load(template_docx(key,'admin',{'organization':'HỒ THỊ BI'}))
            before=doc.tables[0].cell(0,1).text
            buf=io.BytesIO();doc.save(buf)
            after=load(normalize(buf.getvalue(),'admin',{'safe_layout':True})).tables[0].cell(0,1).text
            self.assertEqual(before,after)
    def test_normalization_keeps_long_header_indent(self):
        raw=template_docx('bao-cao','admin',{'organization':'TRƯỜNG THPT HỒ THỊ BI'})
        out=load(normalize(raw,'admin',{'safe_layout':True}))
        for table in out.tables[:2]:
            for row in table.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        self.assertIsNone(p.paragraph_format.first_line_indent)
    def test_formal_report_fills_original_skeleton(self):
        import pandas as pd
        from core import export_formal_report
        doc=load(export_formal_report('BÁO CÁO KIỂM THỬ\nĐơn vị: Hồ Thị Bi\nI. KẾT QUẢ\nĐã tổng hợp',pd.DataFrame({'Số hồ sơ':[7]}),'HỒ THỊ BI','10/2026'))
        self.assertIn('HỒ THỊ BI',doc.tables[0].cell(0,0).text)
        self.assertNotIn('[Nội dung mục 1.]','\n'.join(p.text for p in doc.paragraphs))
        self.assertEqual(doc.styles['Heading 1'].font.color.rgb.__str__(),'000000')
    def test_component_append_preserves_original(self):
        from format_ui import append_component
        raw=template_docx('bao-cao','admin',{})
        piece=component_docx('kinh-gui','admin',{})
        doc=load(append_component(raw,piece))
        self.assertEqual(doc.paragraphs[-1].text,'Kính gửi: [Tên cơ quan, tổ chức]')
        self.assertEqual(len(doc.tables),3)

if __name__=='__main__':unittest.main()
