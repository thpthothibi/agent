@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Please install Python 3.11 or 3.12 from https://www.python.org/downloads/
  echo Enable Add Python to PATH, then run this file again.
  pause
  exit /b 1
)
py -3.12 -V >nul 2>nul
if errorlevel 1 (
  py -3.11 -V >nul 2>nul
  if errorlevel 1 (
    echo Please install Python 3.12 or 3.11, then run this file again.
    pause
    exit /b 1
  )
  py -3.11 -m venv .venv
) else (
  py -3.12 -m venv .venv
)
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto fail
echo Installation complete. Run CHAY_AGENT.bat
pause
exit /b 0
:fail
echo Installation failed. Check Python version and internet connection.
pause
exit /b 1
