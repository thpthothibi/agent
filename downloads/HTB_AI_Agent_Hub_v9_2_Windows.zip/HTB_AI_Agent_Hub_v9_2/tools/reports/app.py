import io, json, hashlib
from pathlib import Path
import pandas as pd
import streamlit as st
from core import (META, read_source, analyse, deterministic_report, ai_narrative, export_xlsx, export_docx, numeric, export_formal_report)

st.set_page_config(page_title='HTB • Agent báo cáo', page_icon='📊', layout='wide')
pending=st.session_state.pop('pending_navigation',None)
if pending:st.session_state['workspace']=pending
page = st.sidebar.radio('Không gian làm việc', ['Agent báo cáo','Tổng hợp nhiều nguồn','HTB Format Pro','Chuẩn hóa mở rộng','Công cụ PDF'],key='workspace')
if page == 'Công cụ PDF':
    from pdf_tools_ui import render
    render()
    st.stop()
if page == 'Tổng hợp nhiều nguồn':
    from multisource_ui import render
    render()
    st.stop()
if page == 'Chuẩn hóa mở rộng':
    from document_plus_ui import render
    render()
    st.stop()
if page == 'HTB Format Pro':
    from format_ui import render
    render()
    st.stop()
st.markdown('''<style>.stApp{background:#f5f8ff}h1,h2,h3{color:#153f75}div.stButton>button[kind=primary]{background:#1769c2;border:0} .block-container{padding-top:2rem}</style>''', unsafe_allow_html=True)
st.title('📊 HTB • Agent báo cáo')
st.caption('Nhận dữ liệu → Kiểm tra → Tổng hợp → Viết báo cáo → Xuất Word / Excel')
with st.sidebar:
    st.header('Cấu hình trợ lý')
    mode = st.selectbox('Chế độ', ['Tổng hợp không dùng AI', 'Ollama', 'OpenAI API', 'Gemini API'])
    model = ''; key = ''
    if mode == 'Ollama':
        model = st.text_input('Model đã cài trong Ollama', placeholder='Nhập đúng tên model trên máy')
        st.caption('Kết nối Ollama tại máy này, cổng 11434.')
    elif mode in ('OpenAI API','Gemini API'):
        model = st.text_input('Tên model API', placeholder='Nhập model mà tài khoản API được sử dụng')
        key = st.text_input('API key', type='password')
        st.caption('Khóa chỉ dùng trong phiên hiện tại. Gói ChatGPT và tài khoản API được quản lý riêng.')
    st.divider()
    st.write('Phiên bản 4.0 • Chạy trên máy tính')
    st.caption('Bản này nhận tệp do bạn chọn. Chưa tự đăng nhập VietSchool hoặc lấy dữ liệu từ website.')

left, right = st.columns([2,1])
with left:
    title = st.text_input('Tên báo cáo', 'BÁO CÁO TỔNG HỢP KẾT QUẢ THỰC HIỆN')
    unit = st.text_input('Đơn vị', 'TRƯỜNG THPT HỒ THỊ BI')
with right:
    period = st.text_input('Kỳ báo cáo', placeholder='Ví dụ: từ 01/10/2025 đến 30/09/2026')
    st.caption('Nhãn kỳ báo cáo không tự lọc dữ liệu. Dùng bộ lọc ngày ở bước 2.')
files = st.file_uploader('1. Nạp dữ liệu thô (có thể chọn nhiều file)', type=['xlsx','csv','docx','pdf','txt'], accept_multiple_files=True)
demo = st.checkbox('Chạy thử bằng dữ liệu minh họa', value=not bool(files))
header = st.number_input('Dòng tiêu đề bảng Excel/CSV (tính từ 1)', min_value=1, max_value=100, value=1)
inputs = [(f.name, f.getvalue()) for f in files]
if demo and not inputs:
    sample = Path(__file__).parent / 'mau' / 'du_lieu_minh_hoa.csv'
    inputs = [(sample.name, sample.read_bytes())]
if not inputs:
    st.info('Chọn dữ liệu hoặc bật chạy thử để bắt đầu.'); st.stop()
tables, docs, sources, errors = [], [], [], []
for name, data in inputs:
    try:
        ts, text = read_source(name, data, int(header)-1)
        tables.extend(ts)
        if text: docs.append({'name':name,'text':text})
        sources.append({'name':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'type':'bảng' if ts else 'văn bản'})
    except Exception as exc:
        errors.append(f'{name}: {exc}')
for err in errors: st.error(err)
if errors:
    st.warning('Đã dừng tạo báo cáo vì có tệp đọc lỗi. Hãy sửa hoặc bỏ tệp lỗi để tránh báo cáo thiếu nguồn.'); st.stop()
frame = pd.concat(tables, ignore_index=True, sort=False) if tables else pd.DataFrame()
if len(frame)>200000:
    st.error('Giới hạn 200.000 dòng mỗi lần. Hãy tách dữ liệu.'); st.stop()
with st.expander('Dữ liệu đã đọc và nguồn', expanded=True):
    st.dataframe(pd.DataFrame(sources), hide_index=True, width='stretch')
    if not frame.empty: st.dataframe(frame.head(100), hide_index=True, width='stretch')
    for d in docs:
        st.text_area('Văn bản: '+d['name'], d['text'][:20000], height=120, disabled=True)
    if len(tables)>1: st.info('Các bảng được nối theo tên cột. Bảng khác cấu trúc có thể tạo ô trống; hãy kiểm tra cột và nguồn trước khi tổng hợp.')

st.subheader('2. Quy tắc tổng hợp')
cols = [c for c in frame.columns if c not in META]
selected = frame.copy()
if cols:
    with st.expander('Lọc bảng / kỳ báo cáo / giá trị'):
        src_options = list(dict.fromkeys(frame['__tep_nguon']))
        source_pick = st.multiselect('Dùng dữ liệu từ tệp', src_options, default=src_options)
        selected = selected[selected['__tep_nguon'].isin(source_pick)]
        sheets = list(dict.fromkeys(selected['__sheet_nguon']))
        sheet_pick = st.multiselect('Dùng các sheet', sheets, default=sheets)
        selected = selected[selected['__sheet_nguon'].isin(sheet_pick)]
        filter_col = st.selectbox('Lọc theo cột', ['(Không lọc)']+cols)
        if filter_col != '(Không lọc)':
            options = sorted(selected[filter_col].dropna().astype(str).unique())
            chosen = st.multiselect('Giữ những giá trị', options, default=options)
            selected = selected[selected[filter_col].astype(str).isin(chosen)]
        date_col = st.selectbox('Cột ngày để lọc kỳ', ['(Không lọc ngày)']+cols)
        if date_col != '(Không lọc ngày)':
            a,b = st.columns(2)
            begin = a.date_input('Từ ngày', value=pd.Timestamp.today().date().replace(month=1,day=1))
            end = b.date_input('Đến ngày')
            if begin>end: st.error('Ngày bắt đầu phải trước hoặc bằng ngày kết thúc.'); st.stop()
            dates = pd.to_datetime(selected[date_col], errors='coerce', dayfirst=True)
            invalid = int(dates.isna().sum())
            if invalid: st.warning(f'{invalid} dòng không đọc được ngày và sẽ nằm ngoài kỳ lọc.')
            selected = selected[dates.dt.date.between(begin,end)]
    a,b,c = st.columns(3)
    groups = a.multiselect('Nhóm theo', cols, default=[cols[0]] if cols else [])
    candidates = [c for c in cols if c not in groups]
    suggestions = []
    for name in candidates:
        if any(term in name.lower() for term in ['mã', 'sđt', 'sbd', 'stt', 'ngày', 'năm', 'id', 'phone', 'date']): continue
        nonempty = selected[name].dropna()
        if len(nonempty) and numeric(nonempty, 'VN').notna().mean() >= 0.95:
            suggestions.append(name)
    values = b.multiselect('Cột số cần tính (kiểm tra gợi ý, không chọn mã / SĐT)', candidates, default=suggestions)
    op_label = c.selectbox('Phép tính', ['Tổng','Trung bình','Nhỏ nhất','Lớn nhất'])
    locale = st.radio('Số viết dạng văn bản', ['VN: 1.234,5','Quốc tế: 1,234.5'], horizontal=True)
    st.caption('Quy tắc dấu chỉ áp dụng ô văn bản. Ô Excel dạng số giữ đúng giá trị gốc. Không tự quy đổi giờ, tiết hoặc đơn vị.')
    duplicate_keys = st.multiselect('Khóa kiểm tra trùng (bỏ trống: so toàn bộ cột dữ liệu)', cols)
    dedup = st.checkbox('Bỏ dòng trùng, giữ dòng đầu', value=False)
else:
    groups,values,duplicate_keys,dedup,locale,op_label = [],[],[],False,'VN','Tổng'
    st.info('Nguồn hiện tại là văn bản. AI có thể viết nhận xét khi bạn cho phép sử dụng nội dung dưới đây. Không tự chuyển bảng trong PDF/Word thành số liệu.')
ops = {'Tổng':'sum','Trung bình':'mean','Nhỏ nhất':'min','Lớn nhất':'max'}
operation = ops[op_label]
clean, summary, issues, duplicates = analyse(selected, groups, values, operation, 'VN' if locale.startswith('VN') else 'INT', duplicate_keys, dedup)
if cols and clean.empty: st.warning('Không có dòng nào sau khi lọc. Hãy kiểm tra bộ lọc.'); st.stop()
if demo: issues.insert(0, 'DỮ LIỆU MINH HỌA: không sử dụng làm số liệu thực của nhà trường.')
if not period: issues.append('Chưa khai báo kỳ báo cáo.')
if cols and not values: issues.append('Chưa chọn cột số; chỉ thống kê số bản ghi.')
if not cols: issues.append('Chỉ có tài liệu văn bản, chưa có bảng số liệu để tính toán.')
a,b,c = st.columns(3)
a.metric('Dòng sau xử lý',len(clean)); b.metric('Nhóm kết quả',len(summary)); c.metric('Dòng trùng phát hiện',duplicates)
st.dataframe(summary, hide_index=True, width='stretch')
for item in issues: st.warning(item)

st.subheader('3. Tạo nội dung báo cáo')
instructions = st.text_area('Yêu cầu phần nhận xét / đề xuất', 'Viết ngắn gọn, văn phong hành chính; nêu kết quả, hạn chế dữ liệu và kiến nghị.')
include_docs = st.checkbox('Cho AI đọc nội dung Word / PDF / TXT (tối đa 30.000 ký tự tổng cộng)', value=False, disabled=not docs or mode=='Tổng hợp không dùng AI')
cloud_ok = True
if mode in ('OpenAI API','Gemini API'):
    cloud_ok = st.checkbox('Cho phép gửi bảng tổng hợp, tên nguồn, yêu cầu nhận xét và văn bản được chọn tới dịch vụ AI đã chọn', value=False)
    st.caption('Bảng dòng gốc không được gửi. Tên nhóm trong bảng tổng hợp có thể vẫn chứa thông tin cá nhân.')
formal_report = st.checkbox('Dùng khung báo cáo HTB có quốc hiệu, cơ quan, nơi nhận và khối chữ ký', value=True)
template_file = st.file_uploader('Tài liệu mở đầu / bìa Word (tùy chọn; agent nối báo cáo ở trang mới, chưa tự điền ô mẫu)', type=['docx'], disabled=formal_report)
template = template_file.getvalue() if template_file and not formal_report else None
from format_ui import settings as format_settings
from format_pro.app.engine import normalize as normalize_word, audit as audit_word, load as load_word, pdf_convert
apply_format = st.checkbox('Chuẩn hóa báo cáo Word bằng HTB Format Pro', value=True)
format_standard, format_options = format_settings('report_') if apply_format else ('auto', {})
profile_path = Path(__file__).parent / 'pages_data' / 'co_quan.json'
profile_sha = hashlib.sha256(profile_path.read_bytes() if profile_path.exists() else b'').hexdigest()
config = {'org_profile_sha':profile_sha, 'formal_report': formal_report, 'format': [apply_format,format_standard,format_options], 'sources':sources,'groups':groups,'values':values,'op':operation,'locale':locale,'keys':duplicate_keys,'dedup':dedup,'title':title,'unit':unit,'period':period,'mode':mode,'model':model,'instructions':instructions,'include_docs':include_docs,'cloud_ok':cloud_ok,'template':hashlib.sha256(template or b'').hexdigest(),'filtered':selected.to_json(date_format='iso')}
fingerprint = hashlib.sha256(json.dumps(config,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
if st.button('🚀 Tạo báo cáo', type='primary'):
    if mode!='Tổng hợp không dùng AI' and (not model.strip() or (mode in ('OpenAI API','Gemini API') and not key)):
        st.error('Hãy nhập model và khóa API nếu dùng dịch vụ trực tuyến.')
    elif not cloud_ok: st.error('Cần cho phép gửi dữ liệu tổng hợp trước khi dùng API.')
    else:
        with st.spinner('Agent đang tạo báo cáo…'):
            text = deterministic_report(title,unit,period,clean,summary,issues,sources,operation)
            logs = ['Đã đọc và ghi nhận nguồn dữ liệu.','Đã áp dụng bộ lọc, kiểm tra trùng và dữ liệu thiếu.','Đã tính bảng tổng hợp.']
            if mode!='Tổng hợp không dùng AI':
                payload = {'tieu_de':title,'don_vi':unit,'ky':period,'phep_tinh':operation,'yeu_cau':instructions,'kiem_tra':issues,'bang':json.loads(summary.to_json(orient='records',force_ascii=False)),'nguon':[s['name'] for s in sources]}
                if include_docs:
                    joined = '\n\n'.join(d['name']+'\n'+d['text'] for d in docs)
                    payload['tai_lieu'] = joined[:30000]
                    if len(joined)>30000: logs.append('Văn bản gửi AI giới hạn 30.000 ký tự, không bao gồm toàn bộ tài liệu.')
                prompt = json.dumps(payload,ensure_ascii=False)
                if len(prompt)>100000:
                    st.error('Bảng tổng hợp quá dài để gửi AI. Giảm số nhóm hoặc dùng chế độ không AI.'); st.stop()
                try:
                    narrative = ai_narrative(mode,model.strip(),key,prompt)
                    text += '\nVI. NHẬN XÉT DO AI ĐỀ XUẤT — CẦN RÀ SOÁT\n'+narrative
                    logs.append('Đã nhận phần nhận xét do AI đề xuất.')
                except Exception as exc:
                    text += '\nVI. TRẠNG THÁI AI\nKhông tạo được phần AI. Báo cáo hiện tại dùng nội dung tổng hợp theo quy tắc.'
                    logs.append(str(exc)); st.warning(str(exc))
            st.session_state['result'] = {'fingerprint':fingerprint,'text':text,'logs':logs}
            st.session_state['editor'] = text
if 'result' in st.session_state:
    result = st.session_state['result']
    if result['fingerprint']!=fingerprint:
        st.info('Cấu hình hoặc dữ liệu đã thay đổi. Bấm Tạo báo cáo để có kết quả mới.'); st.stop()
    st.subheader('4. Xem trước và xuất báo cáo')
    edited = st.text_area('Nội dung có thể chỉnh sửa', key='editor', height=420)
    with st.expander('Nhật ký xử lý'): st.write('\n\n'.join(result['logs']))
    try:
        word = export_formal_report(edited,summary,unit,period,'party' if format_standard=='party' else 'admin') if formal_report else export_docx(edited,summary,template)
        if apply_format:
            word = normalize_word(word,format_standard,format_options)
        word_digest = hashlib.sha256((fingerprint + edited).encode()).hexdigest()
        excel = export_xlsx(clean,summary,issues,sources)
        a,b,c = st.columns(3)
        a.download_button('⬇ Báo cáo Word',word,'Bao_cao.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document')
        b.download_button('⬇ Số liệu Excel',excel,'So_lieu_bao_cao.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        c.download_button('⬇ Nội dung TXT',edited.encode('utf-8-sig'),'Bao_cao.txt','text/plain')
        if apply_format:
            with st.expander('Kết quả kiểm tra thể thức báo cáo Word'):
                checks = audit_word(load_word(word),format_standard)
                if checks['issues']: st.dataframe(checks['issues'],hide_index=True,width='stretch')
                else: st.success('Không phát hiện lỗi theo bộ kiểm tra đã chọn.')
        if st.button('Tạo thêm bản PDF'):
            try: st.session_state['report_pdf']={'digest':word_digest,'data':pdf_convert(word)}
            except RuntimeError as exc: st.warning(str(exc))
        pdf = st.session_state.get('report_pdf')
        if pdf and pdf['digest']==word_digest: st.download_button('⬇ Báo cáo PDF',pdf['data'],'Bao_cao.pdf','application/pdf')
        st.caption('PDF cần LibreOffice trên máy. Có thể xuất PDF trực tiếp từ Word nếu chưa cài LibreOffice.')
    except Exception as exc: st.error(f'Không xuất được tệp: {exc}')
