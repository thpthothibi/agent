# HTB Agent Hub v5 — Cá chép cũ, chuyển động mới, chữ đậm

- Khôi phục đúng nhân vật Cá Chép AI hoạt hình từ bộ tool gốc người dùng cung cấp.
- Dùng ảnh gốc độ phân giải cao để giữ nét khi hiển thị lớn. Không dùng hình cá koi chụp từ trên xuống của v4 cho giao diện hiện tại.
- Cá tự bơi cả khi chờ; tăng nhịp khi có tiến trình đang mở hoặc khi bấm thử. Uốn thân và đuôi theo sóng, đường đi cong nhẹ, giảm tốc và quay đầu mềm ở hai phía. Có hồ cá lớn và bật/tắt chuyển động.
- Chữ xanh đậm, tên agent và tiêu đề đậm, nhãn/nút dễ nhận diện, thẻ có viền rõ và bóng nhẹ. Giữ nút A+ tăng cỡ chữ.
- Đồng bộ bộ chuyển động và kiểu chữ trong Site và Hub chạy trên máy tính.
- Phạm vi nghiệp vụ của sáu bộ tool giữ như bản trước; chuyển động không xác nhận tác vụ đã hoàn thành.
