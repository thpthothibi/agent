# HTB Agent Hub v9 — Kho cloud có phiên bản

## Cách sử dụng
1. Mở Site và đăng nhập cùng tài khoản ChatGPT được cấp quyền truy cập Site.
2. Trong Vận hành & Hồ sơ, tạo/xử lý tác vụ như v8. Tạm dừng trước khi lưu nếu tác vụ đang chạy.
3. Tại Lưu cloud & Khôi phục nhiều máy, chọn đúng hồ sơ rồi nhấn Lưu hồ sơ lên cloud. Đây là thao tác gửi nguồn Excel đã đọc, điểm, cấu hình và nhật ký lên kho riêng của Site. Tải Excel vào trình duyệt không tự gửi lên cloud.
4. Lưu thành công hiển thị phiên bản. Nội dung giống bản đã lưu không tạo phiên bản trùng. Thay đổi trên máy được hiển thị riêng; nếu cloud đã có bản mới hơn thì ghi bị chặn, không lấy số phiên bản mới để âm thầm ghi đè.
5. Trên máy khác, đăng nhập cùng tài khoản, mở kho cloud, chọn Lấy về máy, kiểm tra phạm vi và tích xác nhận.
6. Nếu máy đã có cùng mã nhưng khác nội dung, bản máy được giữ thành hồ sơ Đã lưu trữ trước khi thay bằng bản cloud. Dùng Sửa từ bản sao tại hồ sơ lưu trữ để phục hồi khi cần.
7. Hồ sơ lấy về được đưa về tạm dừng, kiểm tra lại từ đầu và bỏ duyệt cũ. Nếu nội dung máy vốn đã khớp hoàn toàn với bản cloud thì giữ nguyên hồ sơ, chỉ cập nhật mốc đồng bộ.
8. Chọn Phiên bản để xem 50 lần lưu gần nhất. Phục hồi phiên bản cũ luôn tạo hồ sơ mới, không thay bản đang có.

## Phạm vi
- Kho cloud theo tài khoản đăng nhập Site, dùng D1 cho chỉ mục/phiên bản và R2 cho nội dung hồ sơ; tệp không có URL công khai.
- Site tiếp tục giữ quyền truy cập riêng hiện có. Chưa có chia sẻ hồ sơ giữa tài khoản hoặc phân quyền theo tổ/môn.
- Đồng bộ thủ công từng hồ sơ, tối đa 8 MB/yêu cầu; bản nháp chưa thành tác vụ và mẫu cấu hình riêng chưa được đồng bộ. Hồ sơ lớn cần chia theo lớp/môn hoặc dùng sao lưu JSON.
- Bản JSON và dữ liệu cục bộ vẫn dùng được khi không có cloud. Bản sao lưu cloud không thay thế việc kiểm tra dữ liệu trước khi xuất.
- Bản v9 chưa có thao tác xóa cloud. Các phiên bản cũ được giữ lại, giao diện hiển thị 50 phiên bản gần nhất.
- Hub Windows chỉ là bộ mở/giám sát tool gốc. Kho cloud hoạt động trên Site, không chạy từ localhost của Hub và không tự chuyển file giữa tool desktop.
- Không có đăng nhập hoặc ghi Vietschool tự động. Robot/cá chép giữ nguyên; không dùng Runway.

## Bảo vệ khi lỗi
- API yêu cầu danh tính ChatGPT, lọc tất cả bản ghi theo ID người dùng và chặn yêu cầu ghi khác nguồn.
- Mỗi lần ghi dùng số phiên bản đã biết. Hai nơi gửi cùng lúc chỉ một lần thay đổi được chấp nhận.
- SHA-256 kiểm tra nội dung trước khi đọc về; ghi R2 thất bại không làm tăng phiên bản trong D1.
- Khi mất phản hồi sau ghi, hệ thống kiểm tra lại trạng thái; làm mới danh sách trước khi thử lại, không tự tiếp tục nghiệp vụ.
- Không gửi mã ghép nối, phiên đăng nhập tool desktop hoặc khóa API của các tool trong yêu cầu cloud.
