# Phạm vi tích hợp
- Bảo toàn sáu bộ mã nguồn, tài nguyên, hướng dẫn và kiểm thử được cung cấp; bỏ các thư mục build, Git, môi trường ảo và danh tính Site lồng trong ZIP.
- SDB: xóa PIN mặc định trong Python/tiện ích Chrome; thêm xác nhận trước RUN_CURRENT / RUN_SELECTED / FILL_ONLY.
- OMR: thêm xác nhận trước start_run.
- Nhập điểm: thêm xác nhận trước chọn Excel và tự chạy; xác nhận sẵn có trong thao tác dán được giữ lại.
- run_tool.py khởi chạy công cụ GUI với thư mục import riêng, ghi các điểm vào thao tác mà không ghi tham số hoặc khóa.
- Báo cáo chạy Streamlit cục bộ, Skill Studio dùng worker Node gốc. Phòng thi và Skill Studio nhúng trực tiếp trong Site.
- Hub chỉ giám sát tiến trình và mở công cụ. Chưa có giao thức tiến độ nghiệp vụ dùng chung, dừng/tiếp tục dùng nút trong tool gốc. Chuỗi mô phỏng của Site không phải chuỗi chạy tự động giữa các tool desktop.
