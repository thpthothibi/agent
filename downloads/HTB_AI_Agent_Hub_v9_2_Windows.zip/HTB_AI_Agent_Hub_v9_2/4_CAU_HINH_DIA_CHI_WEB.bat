@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
 .venv\Scripts\python.exe configure_origin.py
) else (
 python configure_origin.py
)
pause
