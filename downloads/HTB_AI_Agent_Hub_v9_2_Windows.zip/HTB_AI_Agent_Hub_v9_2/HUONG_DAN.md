# Bản vá v9.1: Sửa nút Bắt đầu nhập điểm

Đọc SUA_LOI_MO_CHROME_V9_1.md. Nếu chưa mở được Chrome, chạy 3_KIEM_TRA_KHOI_DONG.bat.

# Bản v9: Kho cloud có phiên bản

Đọc NANG_CAP_V9.md để lưu và lấy hồ sơ trên nhiều máy. Các phần dưới giữ hướng dẫn bản trước.

# Bản v8: Rà soát ngoại lệ & Bản sửa có truy vết

Đọc NANG_CAP_V8.md và DANH_GIA_V8.md trước. Các phần dưới giữ hướng dẫn những phiên bản trước.

# Bản v7: Vận hành & Hồ sơ

Đọc NANG_CAP_V7.md để dùng xử lý Excel thật, lưu điểm tiếp tục và sao lưu. Các phần dưới là hướng dẫn tool gốc được giữ lại.

# HTB AI Agent Hub v6 — Sáu bộ tool trong một trung tâm

## Cài trên Windows
1. Giải nén toàn bộ ZIP vào thư mục riêng. Không chạy trực tiếp trong ZIP.
2. Cài Python 3.10+ 64-bit có Tcl/Tk (khuyên dùng 3.11/3.12), chọn Add Python to PATH.
3. Chạy `1_CAI_DAT_WINDOWS.bat` một lần. Cần Internet tải các thư viện và Chromium.
4. Chạy `2_MO_HE_THONG.bat`. Giao diện mở tại `http://127.0.0.1:8781`.
5. Chọn tool. Hub mở đúng giao diện gốc; file và bộ lọc được chọn trong giao diện đó.
6. Khi kết thúc, đóng các tool trước, rồi đóng cửa sổ Hub.

## Các bộ tích hợp
- Nhập điểm, đối chiếu, chuyển nhiều Excel vào mẫu, cộng TL/TN: tool v2.4.1.
- Sửa phiếu SBD/mã đề và dò tên đợt chấm: tool v3.18.
- Ký thay Sổ đầu bài: tool v2.3 và tiện ích Chrome kèm trong `tools/sdb`.
- Văn bản, đầu việc, hạn xử lý, sao lưu: tool v3.
- Báo cáo đa nguồn, chuẩn hóa Word, công cụ PDF: tool v4 (Streamlit, cổng 8782).
- Skill Studio, 300 mẫu và prompt: tool v7. Bản web chạy trực tiếp; API AI cần Node.js 22+, khóa API của chính bạn; không phải đăng nhập Gmail là có API.
- Phòng thi & SBD: bản web gốc từ tool v2.4.1; có cấu hình nhóm môn, mẫu in và Excel.

## Kết nối Site
Mở Site → Tool gốc tích hợp → Kết nối máy tính. Sao chép mã ghép nối từ Hub cục bộ. Mã đổi mỗi lần khởi động, chỉ giữ trong bộ nhớ trình duyệt. Nếu trình duyệt chặn truy cập localhost/mạng cục bộ, sử dụng giao diện `http://127.0.0.1:8781` để mở các tool. Không cần mở cổng router hay công khai máy tính.

## Trạng thái và xác nhận
Hub giám sát tiến trình thật: chưa mở / đang mở / đã đóng / lỗi. **Đang mở không có nghĩa đang xử lý hay đã hoàn tất nghiệp vụ.** Không có phần trăm giả cho tool gốc. Nhật ký nội bộ của mỗi tool vẫn nằm trong tool; Hub chỉ ghi sự kiện mở/đóng và một số điểm vào thao tác.
Nhấn Mở tool chỉ mở giao diện, không tự nhập điểm hay ký sổ. Tool nhập điểm, phiếu lỗi và ký sổ được thêm xác nhận lô trước thao tác bên ngoài. Kiểm tra cấu hình, danh sách và đợt trong tool trước khi đồng ý. PIN ký sổ mặc định đã bỏ; tự nhập trong phiên làm việc. Tắt tiến trình có thể làm gián đoạn; ưu tiên Dừng trong tool, rồi đóng cửa sổ.
Không tự khẳng định phiên đăng nhập, OCR hay bộ chọn giao diện web hiện tại hoạt động: cần thử trên tài khoản thật và rà soát kết quả. Không chạy thử ghi dữ liệu thật trong quá trình đóng gói.

## AI chuyển động
Cá chép v4 dùng hình cá tự nhiên nhìn từ trên xuống. Thân và đuôi uốn theo sóng truyền, vây quạt nhẹ; cá lượn vòng và quay đầu liên tục trên Canvas. Nút bật/tắt chuyển động tôn trọng lựa chọn của người dùng. Khi có tiến trình đang mở, cá bơi để biểu thị tool đang hoạt động. Trong Site có trạng thái chờ duyệt, tạm dừng và hoàn tất cho luồng mô phỏng; trạng thái tool gốc được ghi riêng. Nút thử chuyển động chỉ thử hiệu ứng.

## Tệp, kết quả và giới hạn
Các tool giữ giao diện, chức năng và định dạng gốc, chưa hợp nhất toàn bộ màn hình hoặc mô hình dữ liệu. Không tự chuyển file giữa hai tool desktop; chọn file xuất của bước trước trong bước tiếp theo. Mọi tool dùng chung bộ cài Python, nhưng phiên đăng nhập và cấu hình riêng được giữ theo từng tool.
Chương trình chạy trên máy của bạn; đường dẫn lưu và dữ liệu do tool gốc quyết định. Báo cáo PDF cần thêm LibreOffice để đổi Office sang PDF; OCR cần Tesseract và gói ngôn ngữ thích hợp; Ollama/mô hình AI cần cài riêng. Những thành phần này không tự được cài bởi Hub.

## Chẩn đoán
Nhật ký điều phối: `workspace/hub-events.jsonl`. Lỗi mở tool: `workspace/<tool>-process.log`. Không gửi nhật ký chứa thông tin học sinh hoặc tài khoản lên nơi công khai.
`IMPORT_MANIFEST.json` ghi nguồn và SHA-256 các file được nhập. `INTEGRATION_CHANGES.md` liệt kê các chỉnh sửa có chủ đích.

## Nâng cấp giao diện v4
Chữ lớn hơn, đậm hơn và tương phản rõ hơn trong Site và Hub trên máy. Nút A+ trên Site cho phép tăng thêm cỡ chữ, tự ghi nhớ lựa chọn. Nút Xem cá lớn mở hồ cá lớn để quan sát chuyển động.

## Nâng cấp v5 — Khôi phục cá chép cũ
Dùng lại đúng mẫu Cá Chép AI hoạt hình trong bộ tool gốc, với ảnh độ phân giải cao 528 × 352. Canvas cho cá tự bơi theo đường cong, uốn thân/đuôi, lắc nhẹ và quay đầu mềm. Chuyển động được bật sẵn theo yêu cầu, có nút tắt. Site và Hub trên máy có chữ đậm hơn, tương phản rõ hơn, thẻ/nút xanh dương đồng bộ.

## Luồng AI & Robot — v6
Mở “Luồng AI & Robot” trong Site hoặc “Mở phòng mô phỏng” trong Hub trên máy. Chọn một trong sáu quy trình, số dòng, tốc độ và có/không tình huống lỗi minh họa. Chạy liên tục hoặc từng bước, tạm dừng, chạy lại bước lỗi, mô phỏng bỏ qua ngoại lệ và duyệt ở cổng duyệt. Tải nhật ký JSON hoặc xem lịch sử các lượt hoàn tất trên trình duyệt.

Ảnh robot do người dùng cung cấp được dựng thành hoạt cảnh bằng Canvas: bàn tay gõ nhịp, đầu chuyển động nhẹ, đèn mắt và mã lệnh chuyển động. Không sử dụng Runway hoặc API tạo video. Video MP4 kèm theo dài 6 giây, 24 fps, 960 × 548. Chỉ là hoạt cảnh 2D từ ảnh gốc, không phải mô hình robot 3D hay video quay robot thật. Chuyển động và sơ đồ không khẳng định tác vụ ngoài hệ thống đã chạy.
