# Kiểm tra bản tích hợp v3 — 09/11/2026

Đã kiểm tra trên môi trường Linux xây dựng:
- TypeScript: không lỗi; bản production Site build thành công.
- 12 kiểm tra Hub: danh mục nguồn, xác thực ghép nối, chặn Origin/Host khác, chặn đường dẫn ngoài vùng cho phép, cần xác nhận mở tool, từ chối tool ngoài danh sách, phục vụ tool web, xác nhận lô đã được chèn.
- 19 kiểm tra gốc của bộ Báo cáo/PDF: đạt sau khi bổ sung đủ thư viện cho môi trường kiểm thử (pytesseract, pdf2docx, OpenCV). Gồm ghép/tách, xoay, cắt, nén, PDF sang Word/Excel, OCR và báo cáo.
- Bộ kiểm tra gốc Skill Studio: đạt với yêu cầu API và kết quả mô phỏng, schema, lỗi quota/quyền, không phản hồi khóa và tài nguyên Worker.
- Worker Node gốc của Skill Studio mở qua Hub và trả health thành công, không lưu khóa.
- Cộng điểm gốc: Decimal 7,25 + 2,25 = 9,50; khóa trùng bị chặn; thiếu nguồn TN không tự coi là 0.
- 104 tệp Python trong các tool: biên dịch cú pháp thành công.
- Kiểm tra giao diện: phòng thi gốc xử lý 65 học sinh mẫu thành 3 phòng; SBD giữ số 0 đầu, có bảng xem trước. Skill Studio hiển thị 300 mẫu. Route /api/ai/status của Site trả sẵn sàng. Cá chép đổi khung hình và bơi khi thử chuyển động.

Chưa kiểm tra trực tiếp:
- Cài đặt và chạy mọi cửa sổ desktop trên máy Windows của người dùng.
- Ghép nối Site tới localhost trên trình duyệt Windows cụ thể (có thể phụ thuộc quyền mạng cục bộ).
- Đăng nhập, bộ chọn giao diện mới nhất, OCR ảnh phiếu thực tế, nhập điểm/lưu phiếu hoặc ký sổ trên tài khoản thật.
- Gọi AI trả phí với khóa thật; cần API và hạn mức riêng của nhà cung cấp.

Không dùng các kết quả kiểm thử này để khẳng định đã ghi hoặc sửa dữ liệu của trường.
