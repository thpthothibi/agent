from pathlib import Path
from urllib.parse import urlparse
v=input("Nhap origin web (vi du https://agent.example.edu.vn), khong kem /ten-repo/: ").strip().rstrip("/")
u=urlparse(v)
if u.scheme not in ("http","https") or not u.netloc or u.path or u.query or u.fragment: raise SystemExit("Dia chi khong hop le. Chi nhap scheme + ten mien.")
Path(__file__).with_name("site-origin.txt").write_text(v,encoding="utf-8")
print("Da luu. Hay dong va mo lai Hub.")
