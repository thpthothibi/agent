from pathlib import Path
ROOT=Path(__file__).resolve().parent
CATALOG={
 'grades':{'title':'Nhập điểm & Đối chiếu Vietschool','version':'2.4.1','kind':'desktop','folder':'grades','entry':'htb_agent.py'},
 'sum':{'title':'Cộng điểm TL + TN','version':'2.4.1','kind':'desktop','folder':'grades','entry':'cong_diem/app.py'},
 'omr':{'title':'Phiếu lỗi SBD / Mã đề','version':'3.18','kind':'desktop','folder':'omr','entry':'vietschool_sbd_agent.py'},
 'sdb':{'title':'Ký thay Sổ đầu bài','version':'2.3','kind':'desktop','folder':'sdb','entry':'ai_agent_ky_thay_win.py'},
 'documents':{'title':'Văn bản & Đầu việc','version':'3','kind':'desktop','folder':'documents','entry':'app.py'},
 'reports':{'title':'Báo cáo · Word · Excel · PDF','version':'4','kind':'streamlit','folder':'reports','entry':'app.py','port':8782},
 'skills':{'title':'Skill Studio · Prompt AI','version':'7','kind':'node','folder':'skills','entry':'scripts/dev-server.mjs','port':8783},
 'rooms':{'title':'Phòng thi & SBD','version':'2.4.1','kind':'static','folder':'grades','entry':'phong_thi/index.html'},
}
